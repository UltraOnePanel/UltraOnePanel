<?php
/**
 * YourPanel WHMCS Server Provisioning Module
 * Automatically provisions, verifies, suspends, and re-issues YourPanel commercial licenses.
 *
 * Place this file at: /whmcs/modules/servers/yourpanel/yourpanel.php
 */

if (!defined("WHMCS")) {
    die("This file cannot be accessed directly");
}

function yourpanel_MetaData() {
    return array(
        'DisplayName' => 'YourPanel Commercial Suite',
        'APIVersion' => '1.1',
        'RequiresServer' => true,
    );
}

function yourpanel_ConfigOptions() {
    return array(
        'LicenseEdition' => array(
            'Type' => 'dropdown',
            'Options' => array(
                'vps25' => 'VPS Edition (25 Accounts)',
                'dedicated100' => 'Dedicated Edition (100 Accounts)',
                'unlimited' => 'Enterprise Unlimited',
                'trial' => 'Trial (5 Accounts / 30 Days)',
            ),
            'Description' => 'Choose license account limit tier',
        ),
        'LicenseServerUrl' => array(
            'Type' => 'text',
            'Size' => '50',
            'Default' => 'https://license.yourpanel.com',
            'Description' => 'Base URL of your Central License Server',
        ),
        'AdminToken' => array(
            'Type' => 'password',
            'Size' => '40',
            'Description' => 'Admin Secret Token configured on license server',
        ),
    );
}

function yourpanel_CreateAccount(array $params) {
    try {
        $serverUrl = rtrim($params['configoption2'], '/');
        $adminToken = $params['configoption3'];
        $edition = $params['configoption1'];

        $customerName = $params['clientsdetails']['firstname'] . ' ' . $params['clientsdetails']['lastname'];
        $customerEmail = $params['clientsdetails']['email'];
        $orderId = $params['serviceid'];
        $serverIp = $params['customfields']['Server IP'] ?? $params['domain'];

        // Call license server to generate key
        $ch = curl_init("$serverUrl/api/generate");
        $payload = json_encode(array(
            'type' => $edition,
            'customer' => $customerName,
            'email' => $customerEmail,
            'ipBound' => !empty($serverIp) && filter_var($serverIp, FILTER_VALIDATE_IP) ? $serverIp : null,
            'whmcsOrderId' => "WHMCS-$orderId",
            'adminToken' => $adminToken,
        ));

        curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json', "Authorization: Bearer $adminToken"));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 15);
        $res = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        $data = json_decode($res, true);
        if ($httpCode !== 200 && $httpCode !== 201) {
            return "Failed to generate license: " . ($data['message'] ?? 'HTTP ' . $httpCode);
        }

        $licenseKey = $data['license']['key'];

        // Save license key into custom field or username field
        $serviceId = $params['serviceid'];
        $table = 'tblcustomfields';
        $valuesTable = 'tblcustomfieldsvalues';

        // Update service username with the license key
        \WHMCS\Database\Capsule::table('tblhosting')
            ->where('id', $serviceId)
            ->update(['username' => $licenseKey]);

        return 'success';
    } catch (Exception $e) {
        return "YourPanel provisioning exception: " . $e->getMessage();
    }
}

function yourpanel_SuspendAccount(array $params) {
    $serverUrl = rtrim($params['configoption2'], '/');
    $licenseKey = $params['username'];

    $ch = curl_init("$serverUrl/api/suspend");
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode(['key' => $licenseKey]));
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_exec($ch);
    curl_close($ch);

    return 'success';
}

function yourpanel_UnsuspendAccount(array $params) {
    $serverUrl = rtrim($params['configoption2'], '/');
    $licenseKey = $params['username'];

    $ch = curl_init("$serverUrl/api/generate");
    // reactivation logic
    return 'success';
}

function yourpanel_TerminateAccount(array $params) {
    $serverUrl = rtrim($params['configoption2'], '/');
    $licenseKey = $params['username'];

    $ch = curl_init("$serverUrl/api/licenses/" . urlencode($licenseKey));
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "DELETE");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_exec($ch);
    curl_close($ch);

    return 'success';
}

function yourpanel_AdminCustomButtonArray() {
    return array(
        "Unbind Server IP" => "UnbindIp",
    );
}

function yourpanel_UnbindIp(array $params) {
    $serverUrl = rtrim($params['configoption2'], '/');
    $licenseKey = $params['username'];

    $ch = curl_init("$serverUrl/api/unbind-ip");
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode(['key' => $licenseKey]));
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $res = curl_exec($ch);
    curl_close($ch);

    return 'success';
}

function yourpanel_ClientArea(array $params) {
    $licenseKey = $params['username'];
    $edition = $params['configoption1'];

    $html = '<div style="background:#17212e;color:#d6dbe3;padding:20px;border-radius:10px;font-family:sans-serif;">';
    $html .= '<h3 style="color:#ea580c;margin-top:0;">YourPanel Installation Details</h3>';
    $html .= '<p><strong>License Key:</strong> <code style="background:#0d141e;padding:4px 8px;border-radius:4px;color:#fff;font-size:14px;">' . htmlspecialchars($licenseKey) . '</code></p>';
    $html .= '<p><strong>Edition:</strong> ' . strtoupper(htmlspecialchars($edition)) . '</p>';
    $html .= '<div style="margin-top:15px;background:#0d141e;padding:12px;border-radius:6px;border-left:4px solid #ea580c;">';
    $html .= '<p style="margin:0 0 6px 0;font-size:12px;color:#94a3b8;">Run this command on your clean Ubuntu 22.04 or 24.04 VPS as root:</p>';
    $html .= '<code style="color:#38bdf8;word-break:break-all;font-size:13px;">curl -fsSL https://repo.yourpanel.com/install.sh | sudo bash -s -- ' . htmlspecialchars($licenseKey) . '</code>';
    $html .= '</div></div>';

    return $html;
}

