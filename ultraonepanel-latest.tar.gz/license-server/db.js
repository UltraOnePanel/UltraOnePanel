let MongoClient = null;
try {
  MongoClient = require("mongodb").MongoClient;
} catch (_) {}
const fs = require("fs");
const path = require("path");

const MONGODB_URI = process.env.MONGODB_URI || "mongodb://127.0.0.1:27017/ultraone_licenses";

function resolveJsonFile() {
  if (process.env.LICENSES_FILE && fs.existsSync(path.dirname(process.env.LICENSES_FILE))) {
    return process.env.LICENSES_FILE;
  }
  if (fs.existsSync("/opt/license-server")) {
    return "/opt/license-server/licenses.json";
  }
  if (fs.existsSync("/etc/facezila")) {
    return "/etc/facezila/licenses.json";
  }
  return path.join(__dirname, "licenses.json");
}

const JSON_FILE = resolveJsonFile();

let dbClient = null;
let licensesCollection = null;

async function initDB() {
  if (MongoClient && (process.env.MONGODB_URI || process.env.USE_MONGODB === "true")) {
    try {
      dbClient = new MongoClient(MONGODB_URI, { serverSelectionTimeoutMS: 2000 });
      await dbClient.connect();
      const db = dbClient.db();
      licensesCollection = db.collection("licenses");
      await licensesCollection.createIndex({ key: 1 }, { unique: true });
      await licensesCollection.createIndex({ ipBound: 1 });
      console.log("Connected to MongoDB for Central License Management");
      return;
    } catch (e) {
      console.warn("MongoDB unavailable, using persistent JSON store at:", JSON_FILE);
    }
  }
}

function readJsonLicenses() {
  if (!fs.existsSync(JSON_FILE)) {
    const seed = [
      {
        key: "UO-FULL-UNL-LIFE-0001-DEMO",
        product: "whm_cpanel",
        tier: "Enterprise",
        maxAccounts: 0,
        maxDomains: 0,
        allowWhm: true,
        allowCpanel: true,
        ipBound: "185.70.184.125",
        expiryDate: new Date(Date.now() + 3650 * 86400000).toISOString(),
        isLifetime: true,
        durationDays: 3650,
        status: "active",
        createdAt: new Date().toISOString(),
        orderId: "MASTER-001",
        customer: "UltraOne Master Licensing Authority",
        email: "admin@ultraonepanel.com",
        phone: "+1-800-ULTRAONE",
        notes: "Master authority license"
      },
      {
        key: "UO-FULL-PRO-365D-1001-DEMO",
        product: "whm_cpanel",
        tier: "Pro-30",
        maxAccounts: 30,
        maxDomains: 30,
        allowWhm: true,
        allowCpanel: true,
        ipBound: "87.232.72.181",
        expiryDate: new Date(Date.now() + 365 * 86400000).toISOString(),
        isLifetime: false,
        durationDays: 365,
        status: "active",
        createdAt: new Date().toISOString(),
        orderId: "DEMO-002",
        customer: "CyberHost VPS Client",
        email: "admin@cyberhost.com",
        phone: "+1-555-0199",
        notes: "Standard commercial 30-account VPS client"
      }
    ];
    try {
      const dir = path.dirname(JSON_FILE);
      if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
      fs.writeFileSync(JSON_FILE, JSON.stringify(seed, null, 2), "utf8");
    } catch (_) {}
    return seed;
  }
  try {
    return JSON.parse(fs.readFileSync(JSON_FILE, "utf8"));
  } catch (_) {
    return [];
  }
}

function writeJsonLicenses(data) {
  try {
    const dir = path.dirname(JSON_FILE);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(JSON_FILE, JSON.stringify(data, null, 2), "utf8");
  } catch (e) {
    console.error("Failed to write licenses.json:", e.message);
  }
}

const LicenseDAO = {
  getFilePath() {
    return JSON_FILE;
  },

  async findByKey(key) {
    const k = String(key || "").trim().toUpperCase();
    if (licensesCollection) {
      return await licensesCollection.findOne({ key: k });
    }
    const all = readJsonLicenses();
    return all.find((l) => (l.key || "").toUpperCase() === k) || null;
  },

  async list() {
    if (licensesCollection) {
      return await licensesCollection.find({}).sort({ createdAt: -1 }).toArray();
    }
    return readJsonLicenses();
  },

  async insert(record) {
    if (licensesCollection) {
      await licensesCollection.insertOne(record);
      return record;
    }
    const all = readJsonLicenses();
    all.unshift(record);
    writeJsonLicenses(all);
    return record;
  },

  async update(key, updates) {
    const k = String(key || "").trim().toUpperCase();
    if (licensesCollection) {
      await licensesCollection.updateOne({ key: k }, { $set: updates });
      return await licensesCollection.findOne({ key: k });
    }
    const all = readJsonLicenses();
    const idx = all.findIndex((l) => (l.key || "").toUpperCase() === k);
    if (idx !== -1) {
      all[idx] = { ...all[idx], ...updates };
      writeJsonLicenses(all);
      return all[idx];
    }
    return null;
  },

  async delete(key) {
    const k = String(key || "").trim().toUpperCase();
    if (licensesCollection) {
      await licensesCollection.deleteOne({ key: k });
      return;
    }
    let all = readJsonLicenses();
    all = all.filter((l) => (l.key || "").toUpperCase() !== k);
    writeJsonLicenses(all);
  },
};

module.exports = {
  initDB,
  LicenseDAO,
};
