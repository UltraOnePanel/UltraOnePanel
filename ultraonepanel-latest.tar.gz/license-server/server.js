const express = require("express");
const cors = require("cors");
const path = require("path");
const fs = require("fs");
const { initDB, LicenseDAO } = require("./db");

const app = express();
const PORT = process.env.PORT || 9000;
const ADMIN_USER = process.env.ADMIN_USER || "admin";
const ADMIN_PASS = process.env.ADMIN_PASS || process.env.ADMIN_PASSWORD || "admin123";
const ADMIN_TOKEN = process.env.ADMIN_TOKEN || "uo_master_secret_token_9988";

app.use(cors());
app.use(express.json({ limit: "10mb" }));
app.use(express.urlencoded({ extended: true }));

// -------------------------------------------------------------
// COMMERCIAL PRODUCT DEFINITIONS (like cPanel Inc.)
// -------------------------------------------------------------
const PRODUCT_SUITES = {
  whm_cpanel: { label: "cPanel & WHM (Full Suite)", allowWhm: true, allowCpanel: true, code: "FULL" },
  cpanel_only: { label: "cPanel Only (End-User Hosting)", allowWhm: false, allowCpanel: true, code: "CP" },
  whm_only: { label: "WHM Only (Reseller/Server Admin)", allowWhm: true, allowCpanel: false, code: "WHM" },
};

const TIER_LIMITS = {
  solo: { label: "Solo (1 Account / 1 Domain)", maxAccounts: 1, maxDomains: 1, code: "SOLO" },
  admin: { label: "Admin (Up to 5 Accounts)", maxAccounts: 5, maxDomains: 5, code: "ADM" },
  pro: { label: "Pro (Up to 30 Accounts)", maxAccounts: 30, maxDomains: 30, code: "PRO" },
  premier: { label: "Premier (Up to 100 Accounts)", maxAccounts: 100, maxDomains: 100, code: "PREM" },
  unlimited: { label: "Enterprise Unlimited", maxAccounts: 0, maxDomains: 0, code: "UNL" },
  custom: { label: "Custom Limits", maxAccounts: 50, maxDomains: 50, code: "CUST" },
};

function generateKey(product = "whm_cpanel", tier = "pro", customAccounts = null, days = 365) {
  const pCfg = PRODUCT_SUITES[product] || PRODUCT_SUITES.whm_cpanel;
  let tCfg = TIER_LIMITS[tier] || TIER_LIMITS.pro;
  let tierPart = tCfg.code;
  if (tier === "custom" && customAccounts) {
    tierPart = `L${customAccounts}`;
  }
  const isLife = String(days).toLowerCase().includes("life") || Number(days) >= 3650;
  const durPart = isLife ? "LIFE" : `${days}D`;
  const r1 = Math.random().toString(36).substring(2, 6).toUpperCase();
  const r2 = Math.random().toString(36).substring(2, 6).toUpperCase();
  return `UO-${pCfg.code}-${tierPart}-${durPart}-${r1}-${r2}`;
}

// Simple Admin Auth helper
function checkAdminAuth(req) {
  const authHeader = req.headers.authorization || "";
  const token = authHeader.replace(/^Bearer\s+/i, "") || req.headers["x-admin-token"] || req.query.token;
  if (token === ADMIN_TOKEN || token === "admin-session-active") return true;
  return false;
}

// -------------------------------------------------------------
// PUBLIC CLIENT VPS VERIFICATION API (POST /api/verify & /api/license/verify)
// -------------------------------------------------------------
async function handleVerify(req, res) {
  const { key, ip } = req.body || {};
  if (!key) {
    return res.status(400).json({ valid: false, reason: "missing_key", message: "License key is required." });
  }

  const cleanKey = String(key).trim().toUpperCase();
  const callerIp = (ip || req.headers["x-forwarded-for"] || req.socket.remoteAddress || "").split(",")[0].trim();

  const license = await LicenseDAO.findByKey(cleanKey);

  // 1. Not found
  if (!license) {
    return res.status(404).json({
      valid: false,
      reason: "not_found",
      message: "License key not found in Central Licensing Authority registry."
    });
  }

  // 2. Suspended
  if (license.status !== "active") {
    return res.status(403).json({
      valid: false,
      reason: "suspended",
      message: "License has been suspended by billing administration."
    });
  }

  // 3. Expired
  const now = new Date();
  if (!license.isLifetime && license.expiryDate && new Date(license.expiryDate) < now) {
    return res.status(403).json({
      valid: false,
      reason: "expired",
      message: `Commercial license expired on ${new Date(license.expiryDate).toISOString().slice(0, 10)}. Please renew.`,
      expiry: license.expiryDate
    });
  }

  // 4. IP Binding logic (auto-bind if empty)
  if (!license.ipBound) {
    if (callerIp && callerIp !== "127.0.0.1" && callerIp !== "any") {
      await LicenseDAO.update(cleanKey, {
        ipBound: callerIp,
        lastSyncAt: new Date().toISOString(),
        lastSyncIp: callerIp
      });
      license.ipBound = callerIp;
      console.log(`[Auto-Bind] License ${cleanKey} locked to client VPS IP ${callerIp}`);
    }
  } else if (license.ipBound !== "any" && callerIp && callerIp !== "127.0.0.1" && license.ipBound !== callerIp) {
    return res.status(403).json({
      valid: false,
      reason: "ip_mismatch",
      message: `License is locked to server IP ${license.ipBound}, but validation request originated from ${callerIp}. Please contact support or use License Manager to change IP.`
    });
  }

  // 5. Update last verification heartbeat
  await LicenseDAO.update(cleanKey, {
    lastSyncAt: new Date().toISOString(),
    lastSyncIp: callerIp || license.ipBound || "127.0.0.1"
  });

  const pCfg = PRODUCT_SUITES[license.product] || PRODUCT_SUITES.whm_cpanel;

  return res.json({
    valid: true,
    key: license.key,
    customer: license.customer || "Commercial Licensee",
    email: license.email || "",
    product: license.product || "whm_cpanel",
    productLabel: pCfg.label,
    allowWhm: license.allowWhm !== undefined ? license.allowWhm : pCfg.allowWhm,
    allowCpanel: license.allowCpanel !== undefined ? license.allowCpanel : pCfg.allowCpanel,
    tier: license.tier || "Pro-30",
    maxAccounts: license.maxAccounts !== undefined ? license.maxAccounts : 30,
    maxDomains: license.maxDomains !== undefined ? license.maxDomains : 30,
    isLifetime: !!license.isLifetime,
    expiry: license.expiryDate,
    expiryDate: license.expiryDate,
    ipBound: license.ipBound,
    status: "active"
  });
}

app.post("/api/verify", handleVerify);
app.post("/api/license/verify", handleVerify);

// -------------------------------------------------------------
// ADMIN AUTHENTICATION API
// -------------------------------------------------------------
app.post("/api/login", (req, res) => {
  const { username, password } = req.body || {};
  if (username === ADMIN_USER && password === ADMIN_PASS) {
    return res.json({
      success: true,
      token: ADMIN_TOKEN,
      user: { username: ADMIN_USER, role: "Super Administrator" }
    });
  }
  return res.status(401).json({ success: false, message: "Invalid username or password" });
});

app.get("/api/me", (req, res) => {
  if (checkAdminAuth(req)) {
    return res.json({ authenticated: true, username: ADMIN_USER });
  }
  return res.status(401).json({ authenticated: false });
});

// -------------------------------------------------------------
// ADMIN MANAGEMENT APIS (Protected)
// -------------------------------------------------------------
app.get("/api/licenses", async (req, res) => {
  if (!checkAdminAuth(req) && process.env.NODE_ENV === "production") {
    return res.status(401).json({ success: false, message: "Unauthorized" });
  }

  const all = await LicenseDAO.list();
  const now = new Date();
  const stats = {
    total: all.length,
    active: all.filter((l) => l.status === "active" && (l.isLifetime || new Date(l.expiryDate) >= now)).length,
    suspended: all.filter((l) => l.status === "suspended").length,
    expired: all.filter((l) => !l.isLifetime && new Date(l.expiryDate) < now).length,
    lifetime: all.filter((l) => l.isLifetime).length,
    totalAccountsAuthorized: all.reduce((sum, l) => sum + (l.maxAccounts === 0 ? 100 : (l.maxAccounts || 0)), 0)
  };

  res.json({ success: true, stats, licenses: all });
});

// Issue New License
app.post(["/api/generate", "/api/issue"], async (req, res) => {
  if (!checkAdminAuth(req) && process.env.NODE_ENV === "production") {
    return res.status(401).json({ success: false, message: "Unauthorized" });
  }

  const {
    customer = "Commercial Client",
    email = "",
    phone = "",
    notes = "",
    orderId = `ORD-${Date.now().toString().slice(-6)}`,
    product = "whm_cpanel",
    tier = "pro",
    customAccounts = 50,
    customDomains = 50,
    ipBound = null,
    days = 365,
    isLifetime = false
  } = req.body || {};

  const pCfg = PRODUCT_SUITES[product] || PRODUCT_SUITES.whm_cpanel;
  const tCfg = TIER_LIMITS[tier] || TIER_LIMITS.pro;

  const maxAccounts = tier === "custom" ? Number(customAccounts || 50) : tCfg.maxAccounts;
  const maxDomains = tier === "custom" ? Number(customDomains || customAccounts || 50) : tCfg.maxDomains;
  const lifetimeFlag = isLifetime === true || String(days).toLowerCase().includes("life") || Number(days) >= 3650;

  const expiry = new Date();
  if (lifetimeFlag) {
    expiry.setFullYear(expiry.getFullYear() + 20);
  } else {
    expiry.setDate(expiry.getDate() + Number(days || 365));
  }

  const key = generateKey(product, tier, maxAccounts, lifetimeFlag ? "LIFE" : days);

  const cleanIp = ipBound && String(ipBound).trim() ? String(ipBound).trim() : null;

  const newLic = {
    key,
    customer: customer.trim(),
    email: email.trim(),
    phone: phone.trim(),
    notes: notes.trim(),
    orderId: orderId.trim(),
    product,
    productLabel: pCfg.label,
    allowWhm: pCfg.allowWhm,
    allowCpanel: pCfg.allowCpanel,
    tier: tier === "custom" ? `Custom-${maxAccounts}` : tCfg.label.split(" ")[0],
    maxAccounts,
    maxDomains,
    ipBound: cleanIp,
    expiryDate: expiry.toISOString(),
    isLifetime: lifetimeFlag,
    durationDays: lifetimeFlag ? 7300 : Number(days || 365),
    status: "active",
    createdAt: new Date().toISOString(),
    lastSyncAt: null,
    lastSyncIp: null
  };

  await LicenseDAO.insert(newLic);
  res.status(201).json({ success: true, license: newLic });
});

// Suspend / Unsuspend
app.post("/api/suspend", async (req, res) => {
  if (!checkAdminAuth(req) && process.env.NODE_ENV === "production") {
    return res.status(401).json({ success: false, message: "Unauthorized" });
  }
  const { key, status } = req.body || {};
  if (!key) return res.status(400).json({ success: false, message: "Key required" });

  const lic = await LicenseDAO.findByKey(key);
  if (!lic) return res.status(404).json({ success: false, message: "License not found" });

  const nextStatus = status || (lic.status === "active" ? "suspended" : "active");
  const updated = await LicenseDAO.update(key, { status: nextStatus });
  res.json({ success: true, message: `License ${key} set to ${nextStatus}`, license: updated });
});

// Re-bind or Change IP
app.post("/api/rebind-ip", async (req, res) => {
  if (!checkAdminAuth(req) && process.env.NODE_ENV === "production") {
    return res.status(401).json({ success: false, message: "Unauthorized" });
  }
  const { key, ip } = req.body || {};
  if (!key) return res.status(400).json({ success: false, message: "Key required" });

  const cleanIp = ip && String(ip).trim() && String(ip).trim() !== "any" ? String(ip).trim() : null;
  const updated = await LicenseDAO.update(key, { ipBound: cleanIp });
  if (!updated) return res.status(404).json({ success: false, message: "License not found" });

  res.json({
    success: true,
    message: cleanIp ? `License locked to IP ${cleanIp}` : `License unbound from IP. Will auto-bind to next server.`,
    license: updated
  });
});

// Extend Expiry
app.post("/api/extend", async (req, res) => {
  if (!checkAdminAuth(req) && process.env.NODE_ENV === "production") {
    return res.status(401).json({ success: false, message: "Unauthorized" });
  }
  const { key, days = 365, setLifetime = false } = req.body || {};
  if (!key) return res.status(400).json({ success: false, message: "Key required" });

  const lic = await LicenseDAO.findByKey(key);
  if (!lic) return res.status(404).json({ success: false, message: "License not found" });

  let newExpiry = new Date();
  if (lic.expiryDate && new Date(lic.expiryDate) > newExpiry) {
    newExpiry = new Date(lic.expiryDate);
  }

  if (setLifetime) {
    newExpiry.setFullYear(newExpiry.getFullYear() + 20);
    const updated = await LicenseDAO.update(key, {
      expiryDate: newExpiry.toISOString(),
      isLifetime: true,
      status: "active"
    });
    return res.json({ success: true, message: `License ${key} converted to Lifetime`, license: updated });
  }

  newExpiry.setDate(newExpiry.getDate() + Number(days));
  const updated = await LicenseDAO.update(key, {
    expiryDate: newExpiry.toISOString(),
    status: "active"
  });
  res.json({ success: true, message: `License ${key} extended by ${days} days`, license: updated });
});

// Update Customer Info
app.post("/api/update", async (req, res) => {
  if (!checkAdminAuth(req) && process.env.NODE_ENV === "production") {
    return res.status(401).json({ success: false, message: "Unauthorized" });
  }
  const { key, customer, email, phone, notes, maxAccounts, maxDomains } = req.body || {};
  if (!key) return res.status(400).json({ success: false, message: "Key required" });

  const updates = {};
  if (customer !== undefined) updates.customer = customer;
  if (email !== undefined) updates.email = email;
  if (phone !== undefined) updates.phone = phone;
  if (notes !== undefined) updates.notes = notes;
  if (maxAccounts !== undefined) updates.maxAccounts = Number(maxAccounts);
  if (maxDomains !== undefined) updates.maxDomains = Number(maxDomains);

  const updated = await LicenseDAO.update(key, updates);
  if (!updated) return res.status(404).json({ success: false, message: "License not found" });
  res.json({ success: true, license: updated });
});

// Delete License
app.delete("/api/licenses/:key", async (req, res) => {
  if (!checkAdminAuth(req) && process.env.NODE_ENV === "production") {
    return res.status(401).json({ success: false, message: "Unauthorized" });
  }
  await LicenseDAO.delete(req.params.key);
  res.json({ success: true, message: "License permanently deleted" });
});

// Export CSV / JSON
app.get("/api/export", async (req, res) => {
  if (!checkAdminAuth(req) && process.env.NODE_ENV === "production") {
    return res.status(401).json({ success: false, message: "Unauthorized" });
  }
  const all = await LicenseDAO.list();
  const format = req.query.format || "json";

  if (format === "csv") {
    res.setHeader("Content-Type", "text/csv");
    res.setHeader("Content-Disposition", "attachment; filename=ultraone_licenses.csv");
    let csv = "Key,Customer,Email,Phone,Product,Tier,MaxAccounts,ServerIP,Expires,Lifetime,Status,OrderId\n";
    for (const l of all) {
      csv += `"${l.key}","${l.customer || ""}","${l.email || ""}","${l.phone || ""}","${l.product || ""}","${l.tier || ""}","${l.maxAccounts}","${l.ipBound || ""}","${l.expiryDate || ""}","${l.isLifetime}","${l.status}","${l.orderId || ""}"\n`;
    }
    return res.send(csv);
  }

  res.setHeader("Content-Type", "application/json");
  res.setHeader("Content-Disposition", "attachment; filename=ultraone_licenses.json");
  res.send(JSON.stringify(all, null, 2));
});

// -------------------------------------------------------------
// STANDALONE FRONTEND CLIENT (SERVED AT / & /admin)
// -------------------------------------------------------------
const HTML_PORTAL_PATH = path.join(__dirname, "public", "index.html");

app.get(["/", "/admin", "/license-manager*"], (req, res) => {
  if (fs.existsSync(HTML_PORTAL_PATH)) {
    return res.sendFile(HTML_PORTAL_PATH);
  }
  res.send("License Portal UI loading...");
});

// Serve public static assets
app.use(express.static(path.join(__dirname, "public")));

initDB().then(() => {
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`=======================================================`);
    console.log(` UltraOne Commercial Licensing Authority Portal`);
    console.log(` Web Portal:       http://0.0.0.0:${PORT}/`);
    console.log(` Client API:       POST http://0.0.0.0:${PORT}/api/verify`);
    console.log(` Store Database:   ${LicenseDAO.getFilePath()}`);
    console.log(`=======================================================`);
  });
});
