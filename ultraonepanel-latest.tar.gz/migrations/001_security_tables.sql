-- ============================================================
-- uPanel AI Cyber Security & Advanced Hosting Protection Module
-- Database Migration: 001_security_tables.sql
-- ============================================================

-- 1. Security Settings (Global & Per-Site Overrides)
CREATE TABLE IF NOT EXISTS `security_settings` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `scope` ENUM('global', 'site') NOT NULL DEFAULT 'global',
  `domain` VARCHAR(255) NULL,
  `waf_enabled` TINYINT(1) DEFAULT 1,
  `waf_mode` ENUM('detection', 'blocking') DEFAULT 'detection',
  `clamav_enabled` TINYINT(1) DEFAULT 1,
  `fim_enabled` TINYINT(1) DEFAULT 1,
  `ai_enabled` TINYINT(1) DEFAULT 0,
  `ai_provider` VARCHAR(50) DEFAULT 'local',
  `ai_api_key_enc` TEXT NULL,
  `bot_protection_level` ENUM('low', 'medium', 'high') DEFAULT 'medium',
  `quarantine_threshold` ENUM('high', 'critical', 'manual') DEFAULT 'high',
  `auto_isolate_compromised` TINYINT(1) DEFAULT 0,
  `notify_email` VARCHAR(255) NULL,
  `notify_telegram` VARCHAR(100) NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY `uk_scope_domain` (`scope`, `domain`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 2. Security Events Stream (Aggregated Real-Time Events)
CREATE TABLE IF NOT EXISTS `security_events` (
  `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
  `domain` VARCHAR(255) NOT NULL,
  `source_ip` VARCHAR(45) NOT NULL,
  `event_type` VARCHAR(50) NOT NULL,
  `category` ENUM('SQLI', 'XSS', 'RCE', 'BRUTE_FORCE', 'MALWARE', 'BOT', 'ANOMALY', 'FIM') NOT NULL,
  `severity` ENUM('INFO', 'LOW', 'MEDIUM', 'HIGH', 'CRITICAL') NOT NULL,
  `request_uri` TEXT NULL,
  `raw_details` JSON NULL,
  `action_taken` ENUM('LOGGED', 'BLOCKED', 'CHALLENGED', 'QUARANTINED', 'ISOLATED') NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_domain_created` (`domain`, `created_at`),
  INDEX `idx_severity` (`severity`),
  INDEX `idx_source_ip` (`source_ip`),
  INDEX `idx_category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 3. Malware & Antivirus Scans
CREATE TABLE IF NOT EXISTS `security_scans` (
  `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
  `scan_uuid` VARCHAR(64) NOT NULL UNIQUE,
  `domain` VARCHAR(255) NULL,
  `target_path` VARCHAR(500) NOT NULL,
  `scan_type` ENUM('manual', 'scheduled', 'upload', 'fim') NOT NULL,
  `status` ENUM('queued', 'running', 'completed', 'failed', 'cancelled') DEFAULT 'queued',
  `files_scanned` INT DEFAULT 0,
  `threats_found` INT DEFAULT 0,
  `scanner_engine` VARCHAR(50) DEFAULT 'clamav+yara',
  `started_at` TIMESTAMP NULL,
  `completed_at` TIMESTAMP NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_scan_status` (`status`),
  INDEX `idx_scan_domain` (`domain`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 4. Scan Results (Infections and Anomalies Detected)
CREATE TABLE IF NOT EXISTS `security_scan_results` (
  `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
  `scan_id` BIGINT NOT NULL,
  `domain` VARCHAR(255) NOT NULL,
  `file_path` VARCHAR(1000) NOT NULL,
  `threat_name` VARCHAR(255) NOT NULL,
  `scanner_engine` ENUM('clamav', 'yara', 'heuristic', 'ai') NOT NULL,
  `confidence` DECIMAL(3,2) NOT NULL DEFAULT 1.00,
  `is_quarantined` TINYINT(1) DEFAULT 0,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`scan_id`) REFERENCES `security_scans`(`id`) ON DELETE CASCADE,
  INDEX `idx_result_domain` (`domain`),
  INDEX `idx_result_quarantined` (`is_quarantined`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 5. Safe Quarantine Vault Ledger
CREATE TABLE IF NOT EXISTS `security_quarantine` (
  `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
  `quarantine_uuid` VARCHAR(64) NOT NULL UNIQUE,
  `domain` VARCHAR(255) NOT NULL,
  `account_user` VARCHAR(100) NOT NULL,
  `original_file_path` VARCHAR(1000) NOT NULL,
  `quarantine_file_path` VARCHAR(1000) NOT NULL,
  `sha256` CHAR(64) NOT NULL,
  `file_size` BIGINT NOT NULL,
  `original_permissions` VARCHAR(10) NOT NULL,
  `original_owner` VARCHAR(50) NOT NULL,
  `threat_name` VARCHAR(255) NOT NULL,
  `status` ENUM('quarantined', 'restored', 'deleted') DEFAULT 'quarantined',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `actioned_at` TIMESTAMP NULL,
  INDEX `idx_quarantine_domain` (`domain`),
  INDEX `idx_quarantine_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 6. File Integrity Monitoring (FIM Baseline)
CREATE TABLE IF NOT EXISTS `security_file_baselines` (
  `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
  `domain` VARCHAR(255) NOT NULL,
  `file_path` VARCHAR(1000) NOT NULL,
  `sha256` CHAR(64) NOT NULL,
  `permissions` VARCHAR(10) NOT NULL,
  `owner` VARCHAR(50) NOT NULL,
  `mtime` BIGINT NOT NULL,
  `last_verified_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_fim_domain` (`domain`),
  INDEX `idx_fim_file` (`file_path`(255))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 7. Blocked & Allowed IP Rules
CREATE TABLE IF NOT EXISTS `security_ip_rules` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `ip_address` VARCHAR(50) NOT NULL UNIQUE,
  `type` ENUM('whitelist', 'blacklist') NOT NULL,
  `reason` VARCHAR(255) NOT NULL,
  `banned_by` VARCHAR(50) DEFAULT 'system',
  `expires_at` TIMESTAMP NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_ip_type` (`type`),
  INDEX `idx_ip_address` (`ip_address`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 8. Immutable Security Audit Log (Hash-Chained Ledger)
CREATE TABLE IF NOT EXISTS `security_audit_logs` (
  `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
  `event_uuid` VARCHAR(64) NOT NULL UNIQUE,
  `actor_type` ENUM('admin', 'user', 'system', 'ai') NOT NULL,
  `actor_name` VARCHAR(100) NOT NULL,
  `actor_ip` VARCHAR(45) NULL,
  `action` VARCHAR(100) NOT NULL,
  `target` VARCHAR(500) NOT NULL,
  `details` JSON NULL,
  `result` ENUM('SUCCESS', 'FAILURE', 'DENIED') NOT NULL,
  `chain_hash` CHAR(64) NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_audit_actor` (`actor_name`),
  INDEX `idx_audit_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
