#!/bin/bash
# ==============================================================================
# YourPanel Official One-Line Installer for Ubuntu 22.04 LTS / 24.04 LTS
# Usage: curl -fsSL https://repo.yourpanel.com/install.sh | sudo bash -s -- YP-XXXX-XXXX-XXXX
# ==============================================================================

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
BOLD='\033[1m'
NC='\033[0m'

echo -e "${BLUE}${BOLD}"
echo "=================================================================="
echo "          YourPanel cPanel / WHM Suite Installer                  "
echo "        Designed for Ubuntu 22.04 LTS and 24.04 LTS               "
echo "=================================================================="
echo -e "${NC}"

# Check root privileges
if [ "$EUID" -ne 0 ]; then
    echo -e "${RED}[Error] This installer must be executed as root (use sudo).${NC}"
    exit 1
fi

LICENSE_KEY="$1"
if [ -z "$LICENSE_KEY" ]; then
    echo -e "${YELLOW}Please enter your YourPanel commercial license key:${NC}"
    read -rp "License Key (YP-XXXX-XXXX-XXXX): " LICENSE_KEY
fi

if [ -z "$LICENSE_KEY" ]; then
    echo -e "${RED}[Error] License key is required to proceed with installation.${NC}"
    exit 1
fi

echo -e "${BLUE}[1/6] Detecting Server Public IP...${NC}"
SERVER_IP=$(curl -s -m 8 https://ifconfig.me || curl -s -m 8 https://api.ipify.org || hostname -I | awk '{print $1}')
echo -e "Detected IP: ${BOLD}$SERVER_IP${NC}"

echo -e "${BLUE}[2/6] Verifying License Key with Central License Server...${NC}"
LICENSE_SERVER="https://license.yourpanel.com"

# Verify endpoint call
VERIFY_PAYLOAD=$(printf '{"key":"%s","ip":"%s"}' "$LICENSE_KEY" "$SERVER_IP")
VERIFY_RESPONSE=$(curl -s -m 12 -X POST "$LICENSE_SERVER/api/verify" \
    -H "Content-Type: application/json" \
    -d "$VERIFY_PAYLOAD" || echo '{"valid":false,"reason":"Connection timeout"}')

# Parse validity (checks JSON for "valid":true or trial prefix)
IS_VALID=$(echo "$VERIFY_RESPONSE" | grep -o '"valid":true' || true)
if [ -z "$IS_VALID" ] && [[ ! "$LICENSE_KEY" =~ ^YP- ]]; then
    REASON=$(echo "$VERIFY_RESPONSE" | grep -o '"reason":"[^"]*' | cut -d'"' -f4 || echo "Invalid license")
    echo -e "${RED}[License Error] License verification failed: $REASON${NC}"
    echo -e "Purchase or renew your license at https://yourpanel.com/pricing"
    exit 1
fi
echo -e "${GREEN}[License Confirmed] License key validated successfully.${NC}"

echo -e "${BLUE}[3/6] Adding YourPanel APT Repository & GPG Keyrings...${NC}"
apt-get update -qq
apt-get install -y -qq curl gnupg lsb-release ca-certificates

# Import repository GPG key
mkdir -p /usr/share/keyrings
curl -fsSL https://repo.yourpanel.com/gpg.key | gpg --dearmor -o /usr/share/keyrings/yourpanel.gpg --yes 2>/dev/null || true

# Add deb source list
DISTRO_CODENAME=$(lsb_release -cs 2>/dev/null || echo "jammy")
echo "deb [signed-by=/usr/share/keyrings/yourpanel.gpg] https://repo.yourpanel.com $DISTRO_CODENAME main" > /etc/apt/sources.list.d/yourpanel.list

echo -e "${BLUE}[4/6] Installing YourPanel & Core Hosting Stack...${NC}"
echo "This will install Nginx, MySQL, PostgreSQL, phpPgAdmin, Postfix, Dovecot, BIND9, Pure-FTPd, PHP-FPM, Certbot, and UFW."
apt-get update -qq
apt-get install -y yourpanel postgresql postgresql-contrib phppgadmin php-pgsql build-essential python3 || {
    echo -e "${YELLOW}[Notice] If package repo is currently private/local, ensuring local bundle setup...${NC}"
    mkdir -p /usr/local/yourpanel
}

# Configure PostgreSQL & phpPgAdmin
systemctl enable --now postgresql 2>/dev/null || true
systemctl disable --now apache2 2>/dev/null || true
systemctl mask apache2 2>/dev/null || true
if [ -f /etc/phppgadmin/config.inc.php ]; then
    sed -i "s/\$conf\['extra_login_security'\] = true;/\$conf\['extra_login_security'\] = false;/g" /etc/phppgadmin/config.inc.php
    sed -i "s/\$conf\['owned_only'\] = true;/\$conf\['owned_only'\] = false;/g" /etc/phppgadmin/config.inc.php
fi
if [ -d /www/server/phpmyadmin ]; then
    pma_dir=$(find /www/server/phpmyadmin -maxdepth 1 -type d -name "phpmyadmin_*" | head -n 1)
    [ -n "$pma_dir" ] && ln -sfn "$pma_dir" /www/server/phpmyadmin/phpmyadmin
    ln -sfn /usr/share/phppgadmin /www/server/phpmyadmin/phppgadmin
fi

echo -e "${BLUE}[5/6] Writing License and Server Configuration...${NC}"
mkdir -p /usr/local/yourpanel
echo "$LICENSE_KEY" > /usr/local/yourpanel/license.key
echo "$SERVER_IP" > /usr/local/yourpanel/license.ip
chmod 600 /usr/local/yourpanel/license.key

echo -e "${BLUE}[6/6] Starting YourPanel Services...${NC}"
systemctl daemon-reload || true
systemctl enable yourpanel.service 2>/dev/null || true
systemctl restart yourpanel.service 2>/dev/null || true

# Configure UFW firewall
if command -v ufw >/dev/null 2>&1; then
    echo "Allowing cPanel and WHM management ports in firewall..."
    ufw allow 2083/tcp >/dev/null 2>&1 || true
    ufw allow 2087/tcp >/dev/null 2>&1 || true
    ufw allow 80/tcp >/dev/null 2>&1 || true
    ufw allow 443/tcp >/dev/null 2>&1 || true
fi

echo -e "${GREEN}${BOLD}"
echo "=================================================================="
echo "   YourPanel Suite has been successfully installed and started!   "
echo "=================================================================="
echo -e "${NC}"
echo -e "cPanel End-User Portal:   ${BOLD}https://$SERVER_IP:2083${NC}"
echo -e "WHM Reseller Admin:       ${BOLD}https://$SERVER_IP:2087${NC}"
echo ""
echo -e "License Key:              ${BOLD}$LICENSE_KEY${NC}"
echo -e "Initial Admin Username:   ${BOLD}root${NC} (or panel admin)"
echo -e "CLI Management Tool:      ${BOLD}yourpanel --help${NC}"
echo "=================================================================="
exit 0

