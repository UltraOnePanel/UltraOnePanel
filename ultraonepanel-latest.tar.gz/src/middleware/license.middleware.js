const licenseService = require("../services/license.service");

async function checkLicenseStatus() {
  try {
    const status = await licenseService.getLocalStatus();
    return {
      ...status,
      valid: status.isValid,
      reason: status.isValid ? null : (status.isExpired ? "License expired" : "Invalid license"),
    };
  } catch (err) {
    return {
      valid: false,
      reason: err.message,
    };
  }
}

// Middleware guarding WHM administration routes
async function requireValidLicense(req, res, next) {
  try {
    const status = await checkLicenseStatus();
    if (!status.valid) {
      return res.status(403).json({
        success: false,
        error: "LICENSE_INVALID",
        message: status.reason || "License verification failed. Access restricted to administrator license activation.",
      });
    }
    req.license = status;
    next();
  } catch (err) {
    res.status(500).json({ success: false, message: "License verification system error: " + err.message });
  }
}

module.exports = {
  checkLicenseStatus,
  requireValidLicense,
};
