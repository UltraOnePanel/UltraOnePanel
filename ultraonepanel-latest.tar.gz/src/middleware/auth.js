const authService = require("../services/auth.service");
const tokensService = require("../services/tokens.service");

function requiredService(req) {
  const path = req.originalUrl.split("?")[0];
  if (path === "/api/email" || path.startsWith("/api/email/")) return "email";
  if (
    path === "/api/ftp" ||
    path.startsWith("/api/ftp/") ||
    path === "/api/tools/ftp" ||
    path.startsWith("/api/tools/ftp/")
  ) return "ftp";
  if (path === "/api/files" || path.startsWith("/api/files/")) return "files";
  if (
    path === "/api/websites" ||
    path.startsWith("/api/websites/") ||
    path === "/api/domains" ||
    path.startsWith("/api/domains/") ||
    path === "/api/dns" ||
    path.startsWith("/api/dns/")
  ) return "websites";
  if (path === "/api/databases" || path.startsWith("/api/databases/")) return "databases";
  return null;
}

function authorizeSubuser(req, res) {
  if (req.user?.role !== "subuser") return true;
  const service = requiredService(req);
  if (service && req.user.services?.[service]) return true;
  const path = req.originalUrl.split("?")[0];
  if (
    ["/api/auth/me", "/api/auth/logout", "/api/auth/password", "/api/auth/profile"].includes(path) ||
    (req.method === "GET" && path === "/api/license/status") ||
    (req.method === "GET" && ["/api/stats", "/api/stats/history"].includes(path))
  ) {
    return true;
  }
  res.status(403).json({ success: false, message: service ? `Access to ${service} is not enabled for this user.` : "This action is not available to managed users." });
  return false;
}

module.exports = function authMiddleware(req, res, next) {
  // 1. Check custom X-API-Key or X-Token header
  const apiKey = req.headers["x-api-key"] || req.headers["x-token"];
  if (apiKey) {
    const apiUser = tokensService.verifyApiToken(apiKey);
    if (apiUser) {
      req.user = apiUser;
      if (!authorizeSubuser(req, res)) return;
      return next();
    }
    return res.status(401).json({ success: false, message: "Invalid or expired API Key" });
  }

  // 2. Check Authorization Bearer header
  const header = req.headers["authorization"] || "";
  let token = header.startsWith("Bearer ") ? header.slice(7) : null;

  // Plain <a href> downloads cannot send headers, so GETs may pass ?token=.
  if (!token && req.method === "GET" && typeof req.query.token === "string") {
    token = req.query.token;
  }

  if (!token) {
    return res.status(401).json({ success: false, message: "No authentication token provided" });
  }

  // 3. If token format is API Token (YP_tok_)
  if (token.startsWith("YP_tok_")) {
    const apiUser = tokensService.verifyApiToken(token);
    if (apiUser) {
      req.user = apiUser;
      if (!authorizeSubuser(req, res)) return;
      return next();
    }
    return res.status(401).json({ success: false, message: "Invalid or expired API Token" });
  }

  // 4. Fallback to standard JWT session verification
  try {
    req.user = authService.verify(token);
    if (req.user.role === "subuser") {
      const current = authService.getSubuser(req.user.owner, req.user.username);
      if (!current) return res.status(401).json({ success: false, message: "Managed user no longer exists." });
      req.user.services = current.services;
    }
    if (!authorizeSubuser(req, res)) return;
    next();
  } catch (e) {
    // If JWT failed, check if token exists as an API token in store
    const apiUser = tokensService.verifyApiToken(token);
    if (apiUser) {
      req.user = apiUser;
      return next();
    }
    return res.status(401).json({ success: false, message: "Invalid or expired session token" });
  }
};
