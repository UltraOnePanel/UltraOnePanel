const authService = require("../services/auth.service");
const tokensService = require("../services/tokens.service");

module.exports = function authMiddleware(req, res, next) {
  // 1. Check custom X-API-Key or X-Token header
  const apiKey = req.headers["x-api-key"] || req.headers["x-token"];
  if (apiKey) {
    const apiUser = tokensService.verifyApiToken(apiKey);
    if (apiUser) {
      req.user = apiUser;
      return next();
    }
    return res.status(401).json({ success: false, message: "Invalid or expired API Key" });
  }

  // 2. Check Authorization Bearer header
  const header = req.headers["authorization"] || "";
  let token = header.startsWith("Bearer ") ? header.slice(7) : null;

  // Plain <a href> downloads cannot send headers, so GETs may pass ?token=.
  if (!token && req.method === "GET" && typeof req.query.token === "string") {
    token = req.query.token;
  }

  if (!token) {
    return res.status(401).json({ success: false, message: "No authentication token provided" });
  }

  // 3. If token format is API Token (YP_tok_)
  if (token.startsWith("YP_tok_")) {
    const apiUser = tokensService.verifyApiToken(token);
    if (apiUser) {
      req.user = apiUser;
      return next();
    }
    return res.status(401).json({ success: false, message: "Invalid or expired API Token" });
  }

  // 4. Fallback to standard JWT session verification
  try {
    req.user = authService.verify(token);
    next();
  } catch (e) {
    // If JWT failed, check if token exists as an API token in store
    const apiUser = tokensService.verifyApiToken(token);
    if (apiUser) {
      req.user = apiUser;
      return next();
    }
    return res.status(401).json({ success: false, message: "Invalid or expired session token" });
  }
};
