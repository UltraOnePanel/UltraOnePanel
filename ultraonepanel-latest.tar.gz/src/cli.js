#!/usr/bin/env node
// Command-line entry for cron jobs and the installer.
//   node src/cli.js backup [--type "Full Account"] [--domain example.com] [--keep 7]
//   node src/cli.js reset-admin <password>
const path = require("path");
require("dotenv").config({ path: path.resolve(__dirname, "../.env") });

function arg(name, fallback) {
  const i = process.argv.indexOf("--" + name);
  return i > 0 && process.argv[i + 1] ? process.argv[i + 1] : fallback;
}

async function main() {
  const cmd = process.argv[2];
  if (cmd === "backup") {
    const backup = require("./services/backup.service");
    const domain = arg("domain");
    const r = await backup.createBackup({ type: arg("type", "Full Account"), domain, user: "cron", wait: true });
    const pruned = await backup.prune({ scope: domain || "all", keep: Number(arg("keep", 7)) });
    console.log(new Date().toISOString(), "backup", r.filename, r.status, "pruned", pruned.deleted);
    if (r.status !== "completed") process.exitCode = 1;
  } else if (cmd === "reset-admin") {
    const bcrypt = require("bcryptjs");
    const store = require("./lib/store");
    const password = process.argv[3];
    if (!password || password.length < 8) throw new Error("Usage: reset-admin <password (min 8 chars)>");
    const admin = store.read("admin", { username: process.env.ADMIN_USERNAME || "admin" });
    store.write("admin", { ...admin, hash: bcrypt.hashSync(password, 12), passwordChangedAt: Date.now() });
    console.log("Admin password updated for", admin.username);
  } else {
    console.log("Usage: cli.js backup [--type T] [--domain D] [--keep N] | reset-admin <password>");
    process.exitCode = 1;
  }
}

main().catch((e) => { console.error(e.message); process.exit(1); });
