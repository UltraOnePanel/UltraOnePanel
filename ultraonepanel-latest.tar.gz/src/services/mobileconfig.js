/**
 * Apple iOS / iPadOS / macOS .mobileconfig Profile & QR Code Service
 * Standard: Apple Configuration Profile Reference (com.apple.mail.managed)
 */

const crypto = require("crypto");
const { generateQrSvg } = require("../lib/qrcode");

function generateUuid() {
  if (crypto.randomUUID) return crypto.randomUUID().toUpperCase();
  return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (c) => {
    const r = (Math.random() * 16) | 0;
    const v = c === "x" ? r : (r & 0x3) | 0x8;
    return v.toString(16).toUpperCase();
  });
}

function escapeXml(str) {
  return String(str || "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&apos;");
}

function buildMobileconfigXml({ email, domain, host, displayName, organizationName }) {
  const mailHost = host || `mail.${domain}`;
  const cleanEmail = email.toLowerCase().trim();
  const org = organizationName || `${domain} Hosting`;
  const name = displayName || cleanEmail;
  const topUuid = generateUuid();
  const mailUuid = generateUuid();

  return `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>PayloadDisplayName</key>
  <string>${escapeXml(name)}</string>
  <key>PayloadDescription</key>
  <string>Email account configuration for ${escapeXml(cleanEmail)}</string>
  <key>PayloadIdentifier</key>
  <string>com.facezila.mail.${escapeXml(cleanEmail.replace(/[^a-zA-Z0-9]/g, "."))}</string>
  <key>PayloadOrganization</key>
  <string>${escapeXml(org)}</string>
  <key>PayloadRemovalDisallowed</key>
  <false/>
  <key>PayloadType</key>
  <string>Configuration</string>
  <key>PayloadUUID</key>
  <string>${topUuid}</string>
  <key>PayloadVersion</key>
  <integer>1</integer>
  <key>PayloadContent</key>
  <array>
    <dict>
      <key>EmailAccountDescription</key>
      <string>${escapeXml(cleanEmail)}</string>
      <key>EmailAccountName</key>
      <string>${escapeXml(name)}</string>
      <key>EmailAccountType</key>
      <string>EmailAccountTypeIMAP</string>
      <key>EmailAddress</key>
      <string>${escapeXml(cleanEmail)}</string>
      <key>IncomingMailServerAuthentication</key>
      <string>EmailAuthPassword</string>
      <key>IncomingMailServerHostName</key>
      <string>${escapeXml(mailHost)}</string>
      <key>IncomingMailServerPortNumber</key>
      <integer>993</integer>
      <key>IncomingMailServerUseSSL</key>
      <true/>
      <key>IncomingMailServerUsername</key>
      <string>${escapeXml(cleanEmail)}</string>
      <key>OutgoingMailServerAuthentication</key>
      <string>EmailAuthPassword</string>
      <key>OutgoingMailServerHostName</key>
      <string>${escapeXml(mailHost)}</string>
      <key>OutgoingMailServerPortNumber</key>
      <integer>465</integer>
      <key>OutgoingMailServerUseSSL</key>
      <true/>
      <key>OutgoingMailServerUsername</key>
      <string>${escapeXml(cleanEmail)}</string>
      <key>OutgoingPasswordSameAsIncomingPassword</key>
      <true/>
      <key>PayloadDescription</key>
      <string>Configures Email settings for ${escapeXml(cleanEmail)}</string>
      <key>PayloadDisplayName</key>
      <string>IMAP Account (${escapeXml(cleanEmail)})</string>
      <key>PayloadIdentifier</key>
      <string>com.facezila.mail.${escapeXml(cleanEmail.replace(/[^a-zA-Z0-9]/g, "."))}.account</string>
      <key>PayloadType</key>
      <string>com.apple.mail.managed</string>
      <key>PayloadUUID</key>
      <string>${mailUuid}</string>
      <key>PayloadVersion</key>
      <integer>1</integer>
    </dict>
  </array>
</dict>
</plist>`;
}

function handleMobileconfigDownload(req, res) {
  let email = req.params.email || req.query.email || "";
  email = email.replace(/\.mobileconfig$/i, "").trim().toLowerCase();
  if (!email || !email.includes("@")) {
    return res.status(400).send("Invalid email address");
  }

  const domain = email.split("@")[1];
  const host = `mail.${domain}`;
  const xml = buildMobileconfigXml({ email, domain, host });

  res.setHeader("Content-Type", "application/x-apple-aspen-config; charset=utf-8");
  res.setHeader("Content-Disposition", `attachment; filename="${email}.mobileconfig"`);
  res.setHeader("Cache-Control", "no-cache");
  return res.status(200).send(xml);
}

function getConnectDeviceInfo({ email, hostHeader, protocol = "https" }) {
  const cleanEmail = String(email || "").trim().toLowerCase();
  const parts = cleanEmail.split("@");
  const domain = parts[1] || "sunvexaenergy.in";
  const mailHost = `mail.${domain}`;
  const baseHost = hostHeader || "185.70.184.125:2083";
  const baseUrl = `${protocol}://${baseHost}`;

  const mobileconfigUrl = `${baseUrl}/api/email/accounts/${encodeURIComponent(cleanEmail)}/mobileconfig`;
  const autoconfigUrl = `${baseUrl}/autoconfig/mail/config-v1.1.xml?emailaddress=${encodeURIComponent(cleanEmail)}`;
  const autodiscoverUrl = `${baseUrl}/Autodiscover/Autodiscover.xml?email=${encodeURIComponent(cleanEmail)}`;

  // Generate QR Code encoding the direct mobileconfig download URL
  const qrSvg = generateQrSvg(mobileconfigUrl, { cellSize: 4, margin: 2 });

  return {
    email: cleanEmail,
    domain,
    username: cleanEmail,
    mailHost,
    ssl: {
      incoming: {
        server: mailHost,
        imapPort: 993,
        pop3Port: 995,
        security: "SSL / TLS",
        auth: "Normal Password",
      },
      outgoing: {
        server: mailHost,
        smtpPort: 465,
        smtpAltPort: 587,
        security: "SSL / TLS (or STARTTLS for 587)",
        auth: "Normal Password (Username & Password required)",
      },
    },
    nonSsl: {
      incoming: {
        server: mailHost,
        imapPort: 143,
        pop3Port: 110,
        security: "None / Plaintext",
      },
      outgoing: {
        server: mailHost,
        smtpPort: 25,
        smtpAltPort: 587,
        security: "None",
      },
    },
    endpoints: {
      mobileconfigUrl,
      autoconfigUrl,
      autodiscoverUrl,
    },
    qrSvg,
  };
}

module.exports = {
  buildMobileconfigXml,
  handleMobileconfigDownload,
  getConnectDeviceInfo,
  generateQrSvg,
};

