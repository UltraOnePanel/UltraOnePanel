const crypto=require("crypto"),{generateQrSvg}=require("../lib/qrcode");function generateUuid(){return crypto.randomUUID?crypto.randomUUID().toUpperCase():"xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g,c=>{const r=Math.random()*16|0;return(c==="x"?r:r&3|8).toString(16).toUpperCase()})}function escapeXml(str){return String(str||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&apos;")}function buildMobileconfigXml({email,domain,host,displayName,organizationName}){const mailHost=host||`mail.${domain}`,cleanEmail=email.toLowerCase().trim(),org=organizationName||`${domain} Hosting`,name=displayName||cleanEmail,topUuid=generateUuid(),mailUuid=generateUuid();return`<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>PayloadDisplayName</key>
  <string>${escapeXml(name)}</string>
  <key>PayloadDescription</key>
  <string>Email account configuration for ${escapeXml(cleanEmail)}</string>
  <key>PayloadIdentifier</key>
  <string>com.facezila.mail.${escapeXml(cleanEmail.replace(/[^a-zA-Z0-9]/g,"."))}</string>
  <key>PayloadOrganization</key>
  <string>${escapeXml(org)}</string>
  <key>PayloadRemovalDisallowed</key>
  <false/>
  <key>PayloadType</key>
  <string>Configuration</string>
  <key>PayloadUUID</key>
  <string>${topUuid}</string>
  <key>PayloadVersion</key>
  <integer>1</integer>
  <key>PayloadContent</key>
  <array>
    <dict>
      <key>EmailAccountDescription</key>
      <string>${escapeXml(cleanEmail)}</string>
      <key>EmailAccountName</key>
      <string>${escapeXml(name)}</string>
      <key>EmailAccountType</key>
      <string>EmailAccountTypeIMAP</string>
      <key>EmailAddress</key>
      <string>${escapeXml(cleanEmail)}</string>
      <key>IncomingMailServerAuthentication</key>
      <string>EmailAuthPassword</string>
      <key>IncomingMailServerHostName</key>
      <string>${escapeXml(mailHost)}</string>
      <key>IncomingMailServerPortNumber</key>
      <integer>993</integer>
      <key>IncomingMailServerUseSSL</key>
      <true/>
      <key>IncomingMailServerUsername</key>
      <string>${escapeXml(cleanEmail)}</string>
      <key>OutgoingMailServerAuthentication</key>
      <string>EmailAuthPassword</string>
      <key>OutgoingMailServerHostName</key>
      <string>${escapeXml(mailHost)}</string>
      <key>OutgoingMailServerPortNumber</key>
      <integer>465</integer>
      <key>OutgoingMailServerUseSSL</key>
      <true/>
      <key>OutgoingMailServerUsername</key>
      <string>${escapeXml(cleanEmail)}</string>
      <key>OutgoingPasswordSameAsIncomingPassword</key>
      <true/>
      <key>PayloadDescription</key>
      <string>Configures Email settings for ${escapeXml(cleanEmail)}</string>
      <key>PayloadDisplayName</key>
      <string>IMAP Account (${escapeXml(cleanEmail)})</string>
      <key>PayloadIdentifier</key>
      <string>com.facezila.mail.${escapeXml(cleanEmail.replace(/[^a-zA-Z0-9]/g,"."))}.account</string>
      <key>PayloadType</key>
      <string>com.apple.mail.managed</string>
      <key>PayloadUUID</key>
      <string>${mailUuid}</string>
      <key>PayloadVersion</key>
      <integer>1</integer>
    </dict>
  </array>
</dict>
</plist>`}function handleMobileconfigDownload(req,res){let email=req.params.email||req.query.email||"";if(email=email.replace(/\.mobileconfig$/i,"").trim().toLowerCase(),!email||!email.includes("@"))return res.status(400).send("Invalid email address");const domain=email.split("@")[1],host=`mail.${domain}`,xml=buildMobileconfigXml({email,domain,host});return res.setHeader("Content-Type","application/x-apple-aspen-config; charset=utf-8"),res.setHeader("Content-Disposition",`attachment; filename="${email}.mobileconfig"`),res.setHeader("Cache-Control","no-cache"),res.status(200).send(xml)}function getConnectDeviceInfo({email,hostHeader,protocol="https"}){const cleanEmail=String(email||"").trim().toLowerCase(),domain=cleanEmail.split("@")[1]||"sunvexaenergy.in",mailHost=`mail.${domain}`,baseHost=hostHeader||(process.env.SERVER_HOSTNAME?`${process.env.SERVER_HOSTNAME}:2083`:process.env.SERVER_IP?`${process.env.SERVER_IP}:2083`:"localhost:2083"),baseUrl=`${protocol}://${baseHost}`,mobileconfigUrl=`${baseUrl}/api/email/accounts/${encodeURIComponent(cleanEmail)}/mobileconfig`,autoconfigUrl=`${baseUrl}/autoconfig/mail/config-v1.1.xml?emailaddress=${encodeURIComponent(cleanEmail)}`,autodiscoverUrl=`${baseUrl}/Autodiscover/Autodiscover.xml?email=${encodeURIComponent(cleanEmail)}`,qrSvg=generateQrSvg(mobileconfigUrl,{cellSize:4,margin:2});return{email:cleanEmail,domain,username:cleanEmail,mailHost,ssl:{incoming:{server:mailHost,imapPort:993,pop3Port:995,security:"SSL / TLS",auth:"Normal Password"},outgoing:{server:mailHost,smtpPort:465,smtpAltPort:587,security:"SSL / TLS (or STARTTLS for 587)",auth:"Normal Password (Username & Password required)"}},nonSsl:{incoming:{server:mailHost,imapPort:143,pop3Port:110,security:"None / Plaintext"},outgoing:{server:mailHost,smtpPort:25,smtpAltPort:587,security:"None"}},endpoints:{mobileconfigUrl,autoconfigUrl,autodiscoverUrl},qrSvg}}module.exports={buildMobileconfigXml,handleMobileconfigDownload,getConnectDeviceInfo,generateQrSvg};
