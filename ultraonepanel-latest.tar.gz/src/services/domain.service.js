const websites = require("./website.service");
const validate = require("../lib/validate");
const store = require("../lib/store");

async function listDomains(user) {
  const userObj = typeof user === "object" && user !== null ? user : (user ? { username: user } : null);
  let sites = await websites.listWebsites(userObj);

  const uName = userObj ? userObj.username : null;
  if (uName && uName !== "root" && uName !== "admin" && uName !== "system") {
    const accounts = store.read("accounts", {});
    const userAccount = accounts[uName];
    const userRootDomain = (userObj.domain || (userAccount ? userAccount.domain : null) || "").toLowerCase();

    sites = sites.filter((s) => {
      if (s.owner === uName) return true;
      if (userRootDomain && (s.domain === userRootDomain || s.domain.endsWith("." + userRootDomain))) {
        return true;
      }
      return false;
    });
  }

  const rows = [];
  for (const w of sites) {
    const isSub = validate.isSubdomain(w.domain);
    rows.push({
      domain: w.domain,
      type: w.redirect ? "Redirect" : (w.domainType === "Subdomain" || isSub ? "Subdomain" : (w.domainType || "Addon")),
      documentRoot: w.redirect ? "" : w.documentRoot,
      targetUrl: w.redirect || null,
      php: w.redirect ? "-" : w.php,
      ssl: w.ssl,
      status: w.redirect ? "Redirected" : w.status,
    });
    for (const alias of w.aliases || []) {
      rows.push({
        domain: alias,
        type: "Alias",
        documentRoot: w.documentRoot,
        targetUrl: null,
        parent: w.domain,
        php: w.php,
        ssl: false,
        status: w.status,
      });
    }
  }
  return rows;
}

async function addDomain({ domain, type = "Addon", php, targetUrl, parent, user, currentUser }) {
  domain = validate.domain(domain);

  if (currentUser && currentUser.role !== "admin" && currentUser.username !== "root") {
    const uDomain = (currentUser.domain || "").toLowerCase().trim();
    if (type === "Subdomain" && uDomain && !domain.endsWith("." + uDomain)) {
      throw validate.badRequest(`Subdomain must belong to your domain: .${uDomain}`);
    }
    if (type === "Alias" && parent) {
      const meta = websites.getMeta(validate.domain(parent)) || {};
      if (!websites.isUserAllowedSite(parent, meta, currentUser)) {
        throw validate.badRequest("Permission denied: Parent domain does not belong to your account.");
      }
    }
  }

  if (type === "Redirect") {
    if (!targetUrl) throw validate.badRequest("Redirect target URL is required.");
    const target = /^https?:\/\//i.test(targetUrl) ? targetUrl.trim() : "https://" + targetUrl.trim();
    await websites.createWebsite({ domain, redirect: target, type: "Redirect", user, currentUser });
    return { domain, type, targetUrl: target };
  }

  if (type === "Alias" || type === "Parked") {
    if (!parent) throw validate.badRequest("Choose the website this alias should point to.");
    const meta = websites.getMeta(validate.domain(parent)) || {};
    await websites.setAliases({ domain: parent, aliases: [...(meta.aliases || []), domain], user });
    return { domain, type: "Alias", parent };
  }

  if (type === "Subdomain" && domain.split(".").length < 3) {
    throw validate.badRequest("A subdomain looks like blog.example.com.");
  }
  const r = await websites.createWebsite({ domain, php, type: type === "Subdomain" ? "Subdomain" : "PHP", user, currentUser });
  return { domain, type, documentRoot: r.docRoot, php: r.php };
}

async function deleteDomain({ domain, user, currentUser }) {
  domain = validate.domain(domain);
  const all = await listDomains(currentUser || user);
  const row = all.find((d) => d.domain === domain);
  if (row && row.type === "Alias") {
    const meta = websites.getMeta(row.parent) || {};
    await websites.setAliases({ domain: row.parent, aliases: (meta.aliases || []).filter((a) => a !== domain), user });
    return { domain, status: "deleted" };
  }
  return websites.deleteWebsite({ domain, user, currentUser });
}

module.exports = { listDomains, addDomain, deleteDomain };
