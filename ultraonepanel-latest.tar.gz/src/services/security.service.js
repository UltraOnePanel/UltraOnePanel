const fs = require("fs");
const path = require("path");
const os = require("os");
const crypto = require("crypto");
const { execSync } = require("child_process");
const shell = require("./shell.service");
const store = require("../lib/store");
const validate = require("../lib/validate");
const sshkeys = require("./sshkeys.service");
const websites = require("./website.service");
const { generateQrSvg } = require("../lib/qrcode");

const RULE_RE = /^\[\s*(\d+)\]\s+(.+?)\s{2,}(ALLOW|DENY|REJECT|LIMIT)(?:\s+(IN|OUT|FWD))?\s+(.+?)(?:\s+#\s*(.*))?$/;

function sshPort() {
  try {
    const m = fs.readFileSync("/etc/ssh/sshd_config", "utf8").match(/^\s*Port\s+(\d+)/m);
    return m ? Number(m[1]) : 22;
  } catch (_) {
    return 22;
  }
}

function protectedPorts() {
  return new Set([String(sshPort()), String(process.env.PORT || 5000)]);
}

function meta() {
  return store.read("security", { blocked: {} });
}

/** Parse `ufw status numbered` into rule objects (v4 and v6 rows merged). */
async function readUfw() {
  if (!shell.IS_LINUX || !shell.hasCommand("ufw")) return { enabled: false, installed: false, rows: [] };
  const out = await shell.tryGet("ufw status numbered", "");
  const enabled = /Status:\s+active/.test(out);
  const rows = [];
  for (const line of out.split("\n")) {
    const m = line.trim().match(RULE_RE);
    if (!m) continue;
    const v6 = /\(v6\)/.test(m[2]) || /\(v6\)/.test(m[5]);
    rows.push({
      num: Number(m[1]),
      to: m[2].replace(/\s*\(v6\)/, "").trim(),
      action: m[3],
      direction: m[4] || "IN",
      from: m[5].replace(/\s*\(v6\)/, "").trim(),
      comment: (m[6] || "").trim(),
      v6,
    });
  }
  return { enabled, installed: true, rows };
}

async function fail2banStatus() {
  const state = await shell.serviceStatus("fail2ban");
  if (state !== "active") return { active: false, state, jails: [] };
  const out = await shell.tryGet("fail2ban-client status", "");
  const names = ((out.match(/Jail list:\s*(.*)/) || [])[1] || "").split(",").map((s) => s.trim()).filter(Boolean);
  const jails = [];
  for (const name of names) {
    const j = await shell.tryGet("fail2ban-client status " + shell.q(name), "");
    jails.push({
      name,
      currentlyBanned: Number((j.match(/Currently banned:\s*(\d+)/) || [])[1] || 0),
      totalBanned: Number((j.match(/Total banned:\s*(\d+)/) || [])[1] || 0),
      bannedIps: ((j.match(/Banned IP list:\s*(.*)/) || [])[1] || "").split(/\s+/).filter(Boolean),
    });
  }
  return { active: true, state, jails };
}

async function getSecurityStatus() {
  const [ufw, f2b] = await Promise.all([readUfw(), fail2banStatus()]);
  const blockedMeta = meta().blocked;

  const seen = new Set();
  const rules = [];
  for (const r of ufw.rows) {
    if (r.to === "Anywhere") continue;
    const [port, proto] = r.to.split("/");
    const key = r.to + "|" + r.action + "|" + r.from;
    if (seen.has(key)) continue;
    seen.add(key);
    rules.push({
      port: /^\d+$/.test(port) ? Number(port) : port,
      protocol: proto ? proto.toUpperCase() : "TCP/UDP",
      action: r.action,
      source: r.from,
      comment: r.comment,
      protected: protectedPorts().has(port),
    });
  }

  const blockedIps = [];
  for (const r of ufw.rows) {
    if (r.to !== "Anywhere" || !["DENY", "REJECT"].includes(r.action) || r.from === "Anywhere") continue;
    if (blockedIps.some((b) => b.ip === r.from)) continue;
    const m = blockedMeta[r.from] || {};
    blockedIps.push({ ip: r.from, reason: m.reason || r.comment || "Manual ban", blockedAt: m.at || "", bannedAt: m.at || "" });
  }

  return {
    firewallEnabled: ufw.enabled,
    firewallInstalled: ufw.installed,
    sshPort: sshPort(),
    fail2banActive: f2b.active,
    fail2banState: f2b.state,
    fail2banJails: f2b.jails,
    wafActive: false,
    rules,
    blockedIps,
  };
}

function assertUfw() {
  if (shell.IS_LINUX && !shell.hasCommand("ufw")) throw new Error("UFW is not installed on this server.");
}

async function blockIp({ ip, reason, user }) {
  assertUfw();
  ip = validate.ip(ip);
  const note = String(reason || "Manual ban").replace(/['\r\n]/g, "").slice(0, 60);
  await shell.run("ufw prepend deny from " + shell.q(ip) + " to any comment " + shell.q("fz: " + note), { user });
  store.update("security", { blocked: {} }, (s) => { s.blocked[ip] = { reason: note, at: new Date().toISOString().slice(0, 10) }; });
  return { ip, reason: note, blockedAt: new Date().toISOString().slice(0, 10) };
}

async function unblockIp({ ip, user }) {
  assertUfw();
  ip = validate.ip(ip);
  await shell.run("ufw delete deny from " + shell.q(ip) + " to any", { user });
  store.update("security", { blocked: {} }, (s) => { delete s.blocked[ip]; });
  return { ip, status: "unblocked" };
}

function protoArg(protocol) {
  const p = String(protocol || "TCP").toLowerCase();
  if (p === "tcp" || p === "udp") return p;
  if (p === "tcp/udp" || p === "any" || p === "both") return null;
  throw validate.badRequest("Protocol must be TCP, UDP or TCP/UDP");
}

async function addPortRule({ port, protocol = "TCP", action = "ALLOW", comment, user }) {
  assertUfw();
  port = validate.port(port);
  const proto = protoArg(protocol);
  if (port.includes(":") && !proto) throw validate.badRequest("Port ranges need a protocol (TCP or UDP).");
  const verb = String(action).toUpperCase() === "DENY" ? "deny" : "allow";
  const note = String(comment || "Custom rule").replace(/['\r\n]/g, "").slice(0, 60);
  await shell.run("ufw " + verb + " " + port + (proto ? "/" + proto : "") + " comment " + shell.q(note), { user });
  return { port: /^\d+$/.test(port) ? Number(port) : port, protocol: proto ? proto.toUpperCase() : "TCP/UDP", action: verb.toUpperCase(), comment: note };
}

async function deletePortRule({ port, protocol, user }) {
  assertUfw();
  port = validate.port(port);
  if (protectedPorts().has(port)) {
    throw validate.badRequest("Port " + port + " keeps SSH or the panel reachable and cannot be closed from here.");
  }
  const { rows } = await readUfw();
  const wanted = protocol ? protoArg(protocol) : undefined;
  const matches = rows.filter((r) => {
    const [p, pr] = r.to.split("/");
    return p === port && (wanted === undefined || (pr || null) === wanted);
  });
  if (!matches.length) throw validate.badRequest("No firewall rule found for port " + port);
  const specs = [...new Set(matches.map((r) => r.action.toLowerCase() + " " + r.to))];
  for (const spec of specs) await shell.run("ufw delete " + spec, { user });
  return { port, status: "deleted", removed: specs };
}

// --- SSH Keys ---
async function listSshKeys() {
  return await sshkeys.listKeys();
}

async function addSshKey(data) {
  return await sshkeys.addKey(data);
}

async function deleteSshKey(data) {
  return await sshkeys.deleteKey(data);
}

async function generateSshKey({ name = "id_ed25519", comment = "facezila", type = "ed25519" }) {
  const cleanType = type === "rsa" ? "rsa" : "ed25519";
  const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), "fz-key-"));
  const keyPath = path.join(tmpDir, "id_" + cleanType);
  try {
    if (shell.IS_LINUX && shell.hasCommand("ssh-keygen")) {
      const bits = cleanType === "rsa" ? " -b 2048" : "";
      execSync(`ssh-keygen -t ${cleanType}${bits} -N "" -f "${keyPath}" -C "${comment.replace(/[^a-zA-Z0-9@._-]/g, "")}"`);
    } else {
      const { publicKey, privateKey } = crypto.generateKeyPairSync(cleanType === "rsa" ? "rsa" : "ed25519", {
        modulusLength: 2048,
        publicKeyEncoding: { type: "pkcs1", format: "pem" },
        privateKeyEncoding: { type: "pkcs8", format: "pem" },
      });
      fs.writeFileSync(keyPath, privateKey);
      fs.writeFileSync(keyPath + ".pub", publicKey);
    }
    const privateKey = fs.readFileSync(keyPath, "utf8");
    const publicKey = fs.readFileSync(keyPath + ".pub", "utf8").trim();
    const keyRecord = await sshkeys.addKey({ name, key: publicKey });
    return { name, type: cleanType, publicKey, privateKey, fingerprint: keyRecord.id };
  } finally {
    try { fs.rmSync(tmpDir, { recursive: true, force: true }); } catch (_) {}
  }
}

// --- 2FA (RFC 6238 TOTP) ---
function base32Encode(buffer) {
  const alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";
  let bits = 0, value = 0, output = "";
  for (let i = 0; i < buffer.length; i++) {
    value = (value << 8) | buffer[i];
    bits += 8;
    while (bits >= 5) {
      output += alphabet[(value >>> (bits - 5)) & 31];
      bits -= 5;
    }
  }
  if (bits > 0) output += alphabet[(value << (5 - bits)) & 31];
  return output;
}

function base32Decode(str) {
  const alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";
  let bits = 0, value = 0, output = [];
  const cleanStr = (str || "").replace(/=+$/, "").toUpperCase();
  for (let i = 0; i < cleanStr.length; i++) {
    const idx = alphabet.indexOf(cleanStr[i]);
    if (idx === -1) continue;
    value = (value << 5) | idx;
    bits += 5;
    if (bits >= 8) {
      output.push((value >>> (bits - 8)) & 255);
      bits -= 8;
    }
  }
  return Buffer.from(output);
}

function generateSecret() {
  return base32Encode(crypto.randomBytes(20));
}

function generateTOTP(secret, counter = Math.floor(Date.now() / 30000)) {
  const key = base32Decode(secret);
  const buf = Buffer.alloc(8);
  buf.writeBigInt64BE(BigInt(counter));
  const hmac = crypto.createHmac("sha1", key).update(buf).digest();
  const offset = hmac[hmac.length - 1] & 0x0f;
  const code = (((hmac[offset] & 0x7f) << 24) | ((hmac[offset + 1] & 0xff) << 16) | ((hmac[offset + 2] & 0xff) << 8) | (hmac[offset + 3] & 0xff)) % 1000000;
  return code.toString().padStart(6, "0");
}

function verifyTOTP(secret, token, window = 1) {
  if (!secret || !token) return false;
  const current = Math.floor(Date.now() / 30000);
  for (let i = -window; i <= window; i++) {
    if (generateTOTP(secret, current + i) === String(token).trim()) return true;
  }
  return false;
}

async function get2faStatus(username = "admin") {
  const tfa = store.read("2fa", {});
  const userConfig = tfa[username];
  return { enabled: !!(userConfig && userConfig.enabled) };
}

async function setup2fa(username = "admin") {
  const secret = generateSecret();
  const otpauthUrl = `otpauth://totp/Facezila:${encodeURIComponent(username)}?secret=${secret}&issuer=Facezila`;
  const qrSvg = generateQrSvg(otpauthUrl, { width: 180, height: 180 });
  return { secret, otpauthUrl, qrSvg };
}

async function verify2fa({ username = "admin", secret, token }) {
  if (!verifyTOTP(secret, token)) {
    throw validate.badRequest("Invalid 6-digit verification code. Please check your authenticator app.");
  }
  store.update("2fa", {}, (s) => {
    s[username] = { enabled: true, secret, enabledAt: new Date().toISOString() };
  });
  return { success: true, enabled: true };
}

async function disable2fa({ username = "admin", token }) {
  const tfa = store.read("2fa", {});
  const userConfig = tfa[username];
  if (userConfig && userConfig.enabled && token) {
    if (!verifyTOTP(userConfig.secret, token)) {
      throw validate.badRequest("Invalid 6-digit verification code.");
    }
  }
  store.update("2fa", {}, (s) => {
    if (s[username]) s[username].enabled = false;
  });
  return { success: true, enabled: false };
}

async function toggle2fa({ username = "admin", enabled }) {
  if (!enabled) {
    return disable2fa({ username });
  }
  return { success: true, enabled: false, message: "Use /security/2fa/setup and /security/2fa/verify to enable." };
}

// --- Hotlink Protection ---
async function getHotlink(domain) {
  const d = domain || "default";
  const all = store.read("hotlink", {});
  return all[d] || {
    enabled: false,
    urls: [d !== "default" ? `http://${d}` : "http://sunvexaenergy.in", d !== "default" ? `https://${d}` : "https://sunvexaenergy.in"],
    extensions: ["jpg", "jpeg", "gif", "png", "bmp", "webp", "svg", "mp4"],
    allowDirect: true,
    redirectUrl: "",
  };
}

async function saveHotlink({ domain, config, user }) {
  const d = domain || "default";
  const conf = {
    enabled: !!config.enabled,
    urls: Array.isArray(config.urls) ? config.urls : (config.urls || "").split("\n").map(s => s.trim()).filter(Boolean),
    extensions: Array.isArray(config.extensions) ? config.extensions : (config.extensions || "").split(",").map(s => s.trim().replace(/^\./, "")).filter(Boolean),
    allowDirect: config.allowDirect !== false,
    redirectUrl: (config.redirectUrl || "").trim(),
  };

  store.update("hotlink", {}, (s) => { s[d] = conf; });

  if (d !== "default") {
    try {
      const site = await websites.getWebsite(d);
      if (site && site.documentRoot && fs.existsSync(site.documentRoot)) {
        const htPath = path.join(site.documentRoot, ".htaccess");
        let content = fs.existsSync(htPath) ? fs.readFileSync(htPath, "utf8") : "";
        content = content.replace(/# BEGIN Facezila Hotlink Protection[\s\S]*?# END Facezila Hotlink Protection\r?\n?/g, "").trim();

        if (conf.enabled && conf.extensions.length > 0) {
          const urlConds = conf.urls.map((u) => {
            const clean = u.replace(/^https?:\/\//, "").replace(/^www\./, "").replace(/\/$/, "");
            return `RewriteCond %{HTTP_REFERER} !^https?://(www\\.)?${clean.replace(/\./g, "\\.")} [NC]`;
          }).join("\n");

          const directCond = conf.allowDirect ? "RewriteCond %{HTTP_REFERER} !^$ [NC]\n" : "";
          const target = conf.redirectUrl || "-";
          const flags = conf.redirectUrl ? "[R,NC]" : "[F,NC]";
          const block = `\n# BEGIN Facezila Hotlink Protection\nRewriteEngine On\n${directCond}${urlConds}\nRewriteRule \\.(${conf.extensions.join("|")})$ ${target} ${flags}\n# END Facezila Hotlink Protection\n`;
          content = (content ? content + "\n" : "") + block;
        }

        fs.writeFileSync(htPath, content, "utf8");
      }
    } catch (e) {
      console.warn("Hotlink .htaccess update warning:", e.message);
    }
  }

  return { success: true, config: conf };
}

// --- Leech Protection ---
async function getLeech(domain) {
  const d = domain || "default";
  const all = store.read("leech", {});
  return all[d] || [];
}

async function saveLeech({ domain, config, user }) {
  const d = domain || "default";
  const conf = {
    path: config.path || "/",
    maxLogins: Number(config.maxLogins) || 4,
    redirectUrl: (config.redirectUrl || "").trim(),
    emailAlert: (config.emailAlert || "").trim(),
    disableCompromised: !!config.disableCompromised,
    configuredAt: new Date().toISOString().slice(0, 10),
  };

  store.update("leech", {}, (s) => {
    if (!s[d]) s[d] = [];
    s[d] = s[d].filter((c) => c.path !== conf.path);
    s[d].push(conf);
  });

  return { success: true, directory: conf };
}

async function deleteLeech({ domain, path: dirPath, user }) {
  const d = domain || "default";
  store.update("leech", {}, (s) => {
    if (s[d]) s[d] = s[d].filter((c) => c.path !== dirPath);
  });
  return { success: true, path: dirPath };
}

module.exports = {
  getSecurityStatus,
  blockIp,
  unblockIp,
  addPortRule,
  deletePortRule,
  listSshKeys,
  addSshKey,
  deleteSshKey,
  generateSshKey,
  get2faStatus,
  setup2fa,
  verify2fa,
  disable2fa,
  toggle2fa,
  getHotlink,
  saveHotlink,
  getLeech,
  saveLeech,
  deleteLeech,
};
