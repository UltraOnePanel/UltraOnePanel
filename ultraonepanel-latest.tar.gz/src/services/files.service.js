const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const shell = require("./shell.service");
const platform = require("../lib/platform");
const validate = require("../lib/validate");
const store = require("../lib/store");

// Root shown in the file manager.
const ROOT_DIR = platform.paths.wwwRoot;
fs.mkdirSync(ROOT_DIR, { recursive: true });

const ALLOWED_ROOTS = process.platform === "linux"
  ? [ROOT_DIR, "/home", platform.paths.backupDir, "/tmp"]
  : [ROOT_DIR];

const NON_SITE_DIRS = new Set(["html", "default"]);

function siteHtmlDir(siteDir) {
  const html = path.join(siteDir, "public_html");
  return fs.existsSync(html) && fs.statSync(html).isDirectory() ? html : siteDir;
}

function isSiteDir(dir) {
  return path.dirname(dir) === ROOT_DIR && !path.basename(dir).startsWith(".") && !NON_SITE_DIRS.has(path.basename(dir));
}

function listDomainDirs() {
  return fs.readdirSync(ROOT_DIR, { withFileTypes: true })
    .filter((e) => e.isDirectory() && isSiteDir(path.join(ROOT_DIR, e.name)))
    .map((e) => e.name)
    .sort();
}

const TRASH_DIR = path.join(ROOT_DIR, ".trash");
const MAX_EDIT_BYTES = 2 * 1024 * 1024;

function getUserRoots(user) {
  if (!user || user.role === "admin" || user.username === "root") {
    return { isLimited: false, primaryRoot: ROOT_DIR, allowedRoots: ALLOWED_ROOTS };
  }
  const uDomain = (user.domain || "").toLowerCase().trim();
  const username = (user.username || "").toLowerCase().trim();
  const primaryRoot = user.homeDir || (uDomain ? path.join(ROOT_DIR, uDomain) : path.join(ROOT_DIR, username));
  if (!fs.existsSync(primaryRoot)) {
    try { fs.mkdirSync(primaryRoot, { recursive: true }); } catch (_) {}
  }

  const allowed = [primaryRoot];
  if (uDomain && fs.existsSync(ROOT_DIR)) {
    try {
      for (const d of fs.readdirSync(ROOT_DIR)) {
        const dl = d.toLowerCase();
        if (dl.endsWith("." + uDomain) || dl === uDomain) {
          allowed.push(path.join(ROOT_DIR, d));
        }
      }
    } catch (_) {}
  }
  return { isLimited: true, primaryRoot, allowedRoots: allowed };
}

function within(target, user) {
  const { isLimited, allowedRoots } = getUserRoots(user);
  const roots = isLimited ? allowedRoots : ALLOWED_ROOTS;
  return roots.some((root) => {
    const rel = path.relative(root, target);
    return rel === "" || (!rel.startsWith("..") && !path.isAbsolute(rel));
  });
}

function resolveSafePath(reqPath = "", user) {
  const { isLimited, primaryRoot } = getUserRoots(user);
  let target;
  if (!reqPath || reqPath === "/" || reqPath === ".") {
    target = isLimited ? primaryRoot : ROOT_DIR;
  } else if (path.isAbsolute(reqPath)) {
    target = path.resolve(reqPath);
  } else {
    target = path.resolve(isLimited ? primaryRoot : ROOT_DIR, String(reqPath));
  }
  if (!within(target, user)) {
    if (isLimited && (target === ROOT_DIR || target === "/")) return primaryRoot;
    throw validate.badRequest("Access outside your account directories is not allowed.");
  }
  return target;
}

function safeName(name) {
  const n = String(name || "").trim();
  if (!n || n === "." || n === ".." || /[\/\\\0]/.test(n)) throw validate.badRequest("Invalid file name: " + name);
  return n;
}

function resolveItem(reqPath, name, user) {
  const dir = resolveSafePath(reqPath, user);
  const { isLimited } = getUserRoots(user);
  if (!isLimited && dir === ROOT_DIR) throw validate.badRequest("Open a domain first. Websites are added and removed on the Websites page.");
  return path.join(dir, safeName(name));
}

function inheritOwner(target) {
  if (process.platform !== "linux") return;
  try {
    const st = fs.statSync(path.dirname(target));
    fs.chownSync(target, st.uid, st.gid);
  } catch (_) { /* best effort */ }
}

function formatBytes(bytes) {
  if (bytes === 0) return "0 B";
  if (bytes > 1024 * 1024 * 1024) return (bytes / (1024 * 1024 * 1024)).toFixed(1) + " GB";
  if (bytes > 1024 * 1024) return (bytes / (1024 * 1024)).toFixed(1) + " MB";
  if (bytes > 1024) return (bytes / 1024).toFixed(0) + " KB";
  return bytes + " B";
}

function formatDate(date) {
  try {
    const d = new Date(date);
    const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    let hours = d.getHours();
    const ampm = hours >= 12 ? "PM" : "AM";
    hours = hours % 12 || 12;
    const minutes = d.getMinutes().toString().padStart(2, "0");
    return `${months[d.getMonth()]} ${d.getDate()}, ${d.getFullYear()}, ${hours}:${minutes} ${ampm}`;
  } catch (_) {
    return "Recent";
  }
}

function getFileType(name, isDir) {
  if (isDir) {
    if (name.includes("mail")) return "mail";
    if (name.includes("ftp")) return "publicftp";
    if (name.includes("www") || name.includes("html") || /\.[a-z]{2,}$/i.test(name)) return "domain";
    return "httpd/unix-directory";
  }
  const ext = path.extname(name).toLowerCase();
  if (ext === ".html" || ext === ".htm") return "text/html";
  if (ext === ".php") return "application/x-php";
  if (ext === ".js" || ext === ".ts") return "application/javascript";
  if (ext === ".json") return "application/json";
  if (ext === ".css") return "text/css";
  if ([".zip", ".gz", ".tgz", ".tar", ".bz2"].includes(ext)) return "application/zip";
  if (ext === ".sql") return "application/sql";
  if ([".png", ".jpg", ".jpeg", ".gif", ".webp", ".svg"].includes(ext)) return "image";
  if (ext === ".txt" || name.startsWith(".")) return "text/plain";
  return "application/octet-stream";
}

function getPermissions(stats, isDir) {
  try {
    return (stats.mode & parseInt("777", 8)).toString(8).padStart(4, "0");
  } catch (_) {
    return isDir ? "0755" : "0644";
  }
}

function browseDirectory(reqPath = "", user) {
  const { isLimited, primaryRoot, allowedRoots } = getUserRoots(user);
  let fullPath = resolveSafePath(reqPath, user);
  if (!fs.existsSync(fullPath) || !fs.statSync(fullPath).isDirectory()) {
    if (isLimited && fs.existsSync(primaryRoot)) {
      fullPath = primaryRoot;
    } else {
      throw new Error(`Directory does not exist: ${reqPath || fullPath}`);
    }
  }
  if (isSiteDir(fullPath)) fullPath = siteHtmlDir(fullPath);

  const atRoot = isLimited ? fullPath === primaryRoot : fullPath === ROOT_DIR;
  const siteDir = path.dirname(fullPath) === ROOT_DIR ? fullPath : path.dirname(fullPath);
  const isHtmlRoot = !atRoot && isSiteDir(siteDir) && siteHtmlDir(siteDir) === fullPath;
  let parentPath = null;
  if (!atRoot) {
    if (isLimited) {
      const parent = path.dirname(fullPath);
      const isParentAllowed = allowedRoots.some((root) => {
        const rel = path.relative(root, parent);
        return rel === "" || (!rel.startsWith("..") && !path.isAbsolute(rel));
      });
      parentPath = isParentAllowed ? parent : null;
    } else {
      parentPath = isHtmlRoot ? ROOT_DIR : path.dirname(fullPath);
    }
  }
  const domain = atRoot
    ? (isLimited ? (user.domain || path.basename(primaryRoot)) : null)
    : (path.relative(ROOT_DIR, fullPath).split(path.sep)[0] || null);

  const entries = atRoot && !isLimited
    ? listDomainDirs().map((name) => ({ name, isDirectory: () => true }))
    : fs.readdirSync(fullPath, { withFileTypes: true });

  const items = entries.map((e) => {
    let isDir = e.isDirectory();
    let size = isDir ? "4 KB" : "0 B";
    let modTime = formatDate(new Date());
    let perms = isDir ? "0755" : "0644";
    try {
      const stats = fs.statSync(path.join(fullPath, e.name));
      isDir = stats.isDirectory();
      modTime = formatDate(stats.mtime);
      perms = getPermissions(stats, isDir);
      if (!isDir) size = formatBytes(stats.size);
    } catch (_) {}
    return { name: e.name, isDir, size, modTime, type: atRoot && !isLimited ? "domain" : getFileType(e.name, isDir), permissions: perms };
  });

  items.sort((a, b) => (a.isDir === b.isDir ? a.name.localeCompare(b.name) : a.isDir ? -1 : 1));
  const slash = (p) => (p ? p.replace(/\\/g, "/") : p);
  const isDomainList = !isLimited && fullPath === ROOT_DIR;
  return {
    currentPath: slash(fullPath),
    fullPath: slash(fullPath),
    rootPath: slash(isLimited ? primaryRoot : ROOT_DIR),
    parentPath: slash(parentPath),
    domain,
    isDomainList,
    items,
  };
}

function getSubDirs(dirPath) {
  const skip = (n) => n.startsWith(".git") || n === "node_modules" || n === ".trash";
  try {
    return fs.readdirSync(dirPath, { withFileTypes: true })
      .filter((e) => e.isDirectory() && !skip(e.name))
      .map((e) => {
        const childPath = path.join(dirPath, e.name).replace(/\\/g, "/");
        let hasSubFolders = false;
        try {
          hasSubFolders = fs.readdirSync(childPath, { withFileTypes: true }).some((g) => g.isDirectory() && !skip(g.name));
        } catch (_) {}
        return { name: e.name, path: childPath, type: getFileType(e.name, true), hasSubFolders, children: [] };
      });
  } catch (_) {
    return [];
  }
}

function getTree(reqPath = "", user) {
  const { isLimited, primaryRoot } = getUserRoots(user);
  const base = isLimited ? primaryRoot : ROOT_DIR;
  const targetDir = reqPath ? resolveSafePath(reqPath, user) : base;
  if (!isLimited && targetDir === ROOT_DIR) {
    const children = listDomainDirs().map((name) => {
      const html = siteHtmlDir(path.join(ROOT_DIR, name));
      return { name, path: html.replace(/\\/g, "/"), type: "domain", hasSubFolders: getSubDirs(html).length > 0, children: [] };
    });
    const normalized = ROOT_DIR.replace(/\\/g, "/");
    return { name: `(${normalized})`, path: normalized, hasSubFolders: children.length > 0, children };
  }
  const children = getSubDirs(targetDir);
  const normalized = targetDir.replace(/\\/g, "/");
  return {
    name: targetDir === base ? (isLimited ? (user.domain || path.basename(primaryRoot)) : `(${normalized})`) : path.basename(targetDir),
    path: normalized,
    hasSubFolders: children.length > 0,
    children,
  };
}

function createFile(reqPath, fileName, user) {
  const target = resolveItem(reqPath, fileName, user);
  if (fs.existsSync(target)) throw validate.badRequest("File already exists");
  fs.writeFileSync(target, "", "utf8");
  inheritOwner(target);
  return { success: true, file: path.basename(target) };
}

function createFolder(reqPath, folderName, user) {
  const target = resolveItem(reqPath, folderName, user);
  if (fs.existsSync(target)) throw validate.badRequest("Folder already exists");
  fs.mkdirSync(target);
  inheritOwner(target);
  return { success: true, folder: path.basename(target) };
}

function renameItem(reqPath, oldName, newName, user) {
  const src = resolveItem(reqPath, oldName, user);
  const dest = resolveItem(reqPath, newName, user);
  if (!fs.existsSync(src)) throw validate.badRequest("Source item not found");
  if (fs.existsSync(dest)) throw validate.badRequest("Destination name already exists");
  fs.renameSync(src, dest);
  return { success: true };
}

function changePermissions(reqPath, itemName, permissions, user) {
  const target = resolveItem(reqPath, itemName, user);
  if (!fs.existsSync(target)) throw validate.badRequest("Target item not found");
  if (!/^0?[0-7]{3}$/.test(String(permissions))) throw validate.badRequest("Permissions must be octal, e.g. 0644");
  fs.chmodSync(target, parseInt(permissions, 8));
  return { success: true };
}

function deleteItem(reqPath, itemName, skipTrash = false, user) {
  const target = resolveItem(reqPath, itemName, user);
  if (!fs.existsSync(target)) throw validate.badRequest("Item not found: " + itemName);
  if (target === ROOT_DIR || ALLOWED_ROOTS.includes(target)) throw validate.badRequest("Refusing to delete a root directory.");
  const inTrash = path.dirname(target) === TRASH_DIR;
  if (skipTrash || inTrash) {
    fs.rmSync(target, { recursive: true, force: true });
    if (inTrash) writeTrashIndex(readTrashIndex().filter((t) => t.trashName !== path.basename(target)));
    return { success: true, trashed: false };
  }
  fs.mkdirSync(TRASH_DIR, { recursive: true });
  const trashName = Date.now() + "-" + path.basename(target);
  fs.renameSync(target, path.join(TRASH_DIR, trashName));
  writeTrashIndex(readTrashIndex().concat({ trashName, originalPath: target, deletedAt: new Date().toISOString() }));
  return { success: true, trashed: true };
}

function readTrashIndex() {
  try { return JSON.parse(fs.readFileSync(path.join(TRASH_DIR, ".index.json"), "utf8")); } catch (_) { return []; }
}

function writeTrashIndex(entries) {
  fs.mkdirSync(TRASH_DIR, { recursive: true });
  fs.writeFileSync(path.join(TRASH_DIR, ".index.json"), JSON.stringify(entries, null, 2));
}

function restoreFromTrash(names) {
  const index = readTrashIndex();
  const restored = [];
  for (const name of names) {
    const entry = index.find((t) => t.trashName === name);
    if (!entry) continue;
    if (fs.existsSync(entry.originalPath)) throw validate.badRequest("Cannot restore " + path.basename(entry.originalPath) + ": a file with that name exists.");
    fs.mkdirSync(path.dirname(entry.originalPath), { recursive: true });
    fs.renameSync(path.join(TRASH_DIR, name), entry.originalPath);
    restored.push(entry.originalPath);
  }
  writeTrashIndex(index.filter((t) => !names.includes(t.trashName)));
  return { success: true, restored };
}

function emptyTrash() {
  if (fs.existsSync(TRASH_DIR)) fs.rmSync(TRASH_DIR, { recursive: true, force: true });
  return { success: true };
}

function readFile(reqPath, fileName, user) {
  const target = resolveItem(reqPath, fileName, user);
  if (!fs.existsSync(target)) throw new Error("File not found");
  const st = fs.statSync(target);
  if (st.isDirectory()) throw validate.badRequest("Cannot open a directory in the editor");
  if (st.size > MAX_EDIT_BYTES) throw validate.badRequest("File is too large to edit in the browser (max 2 MB).");
  const buf = fs.readFileSync(target);
  if (buf.includes(0)) throw validate.badRequest("Binary files cannot be edited. Download it instead.");
  return { name: fileName, content: buf.toString("utf8") };
}

function saveFile(reqPath, fileName, content, user) {
  const target = resolveItem(reqPath, fileName, user);
  const isNew = !fs.existsSync(target);
  fs.writeFileSync(target, content, "utf8");
  if (isNew) inheritOwner(target);
  return { success: true };
}

function uploadFile(reqPath, fileName, buffer, overwrite = true, user) {
  const target = resolveItem(reqPath, fileName, user);
  if (!overwrite && fs.existsSync(target)) throw validate.badRequest("File already exists: " + fileName);
  fs.writeFileSync(target, buffer);
  inheritOwner(target);
  return { success: true, name: path.basename(target), size: formatBytes(buffer.length) };
}

function downloadPath(reqPath, fileName, user) {
  const target = resolveItem(reqPath, fileName, user);
  if (!fs.existsSync(target) || fs.statSync(target).isDirectory()) throw validate.badRequest("Only files can be downloaded. Compress folders first.");
  return target;
}

function copyOrMove(reqPath, names, destPath, move, user) {
  let dest = resolveSafePath(destPath, user);
  if (isSiteDir(dest)) dest = siteHtmlDir(dest);
  if (dest === ROOT_DIR) throw validate.badRequest("Choose a folder inside a domain as the destination.");
  if (!fs.existsSync(dest) || !fs.statSync(dest).isDirectory()) throw validate.badRequest("Destination folder does not exist");
  for (const name of names) {
    const src = resolveItem(reqPath, name, user);
    const target = path.join(dest, path.basename(src));
    if (!fs.existsSync(src)) throw validate.badRequest("Item not found: " + name);
    if (target === src || target.startsWith(src + path.sep)) throw validate.badRequest("Cannot copy a folder into itself");
    if (fs.existsSync(target)) throw validate.badRequest(name + " already exists in the destination");
    if (move) fs.renameSync(src, target);
    else fs.cpSync(src, target, { recursive: true, preserveTimestamps: true });
  }
  return { success: true, count: names.length };
}

async function compress(reqPath, names, archiveName, format = "zip", user) {
  const dir = resolveSafePath(reqPath, user);
  const items = names.map((n) => safeName(n));
  items.forEach((n) => { if (!fs.existsSync(path.join(dir, n))) throw validate.badRequest("Item not found: " + n); });
  const ext = format === "tar.gz" ? ".tar.gz" : ".zip";
  let archive = safeName(archiveName || (items.length === 1 ? items[0] : "archive") + ext);
  if (!archive.endsWith(ext)) archive += ext;
  if (fs.existsSync(path.join(dir, archive))) throw validate.badRequest(archive + " already exists");
  const list = items.map(shell.q).join(" ");
  const cmd = format === "tar.gz"
    ? "tar -czf " + shell.q(archive) + " -- " + list
    : "zip -rq " + shell.q(archive) + " -- " + list;
  await shell.run(cmd, { cwd: dir, timeout: 600000 });
  if (shell.IS_LINUX) inheritOwner(path.join(dir, archive));
  return { success: true, archive };
}

async function extract(reqPath, name, destName, user) {
  const dir = resolveSafePath(reqPath, user);
  const file = resolveItem(reqPath, name, user);
  if (!fs.existsSync(file)) throw validate.badRequest("Archive not found: " + name);
  const dest = destName ? resolveItem(reqPath, destName, user) : dir;
  fs.mkdirSync(dest, { recursive: true });
  let cmd;
  if (/\.zip$/i.test(name)) cmd = "unzip -oq " + shell.q(file) + " -d " + shell.q(dest);
  else if (/\.(tar\.gz|tgz|tar\.bz2|tar)$/i.test(name)) cmd = "tar -xf " + shell.q(file) + " -C " + shell.q(dest) + " --no-same-owner";
  else if (/\.gz$/i.test(name)) cmd = "gunzip -k " + shell.q(file);
  else throw validate.badRequest("Unsupported archive type. Use .zip, .tar, .tar.gz or .gz");
  const marker = path.join(dir, ".fz-extract-" + Date.now());
  if (shell.IS_LINUX) fs.writeFileSync(marker, "");
  try {
    await shell.run(cmd, { timeout: 600000 });
    if (shell.IS_LINUX) {
      const st = fs.statSync(dir);
      await shell.run("find " + shell.q(dest) + " -cnewer " + shell.q(marker) + " -exec chown -h " + st.uid + ":" + st.gid + " {} +").catch(() => {});
    }
  } finally {
    fs.rmSync(marker, { force: true });
  }
  return { success: true, destination: dest };
}

// -------------------------------------------------------------
// IMAGES (Thumbnailer, Scaler, Converter)
// -------------------------------------------------------------
async function processImageThumbnail({ path: reqPath, file, size = "150x150" }) {
  const source = resolveItem(reqPath, file);
  const parsed = path.parse(source);
  const target = path.join(parsed.dir, `${parsed.name}_thumb${parsed.ext}`);
  if (shell.IS_LINUX) {
    await shell.run(`convert ${shell.q(source)} -thumbnail ${shell.q(size)} ${shell.q(target)}`);
  } else {
    fs.copyFileSync(source, target);
  }
  return { success: true, thumbnail: path.basename(target) };
}

async function processImageScale({ path: reqPath, file, width, height, percent }) {
  const source = resolveItem(reqPath, file);
  const parsed = path.parse(source);
  const target = path.join(parsed.dir, `${parsed.name}_scaled${parsed.ext}`);
  const geometry = percent ? `${percent}%` : `${width}x${height}!`;
  if (shell.IS_LINUX) {
    await shell.run(`convert ${shell.q(source)} -resize ${shell.q(geometry)} ${shell.q(target)}`);
  } else {
    fs.copyFileSync(source, target);
  }
  return { success: true, scaled: path.basename(target) };
}

async function processImageConvert({ path: reqPath, file, targetFormat }) {
  const source = resolveItem(reqPath, file);
  const parsed = path.parse(source);
  const targetExt = targetFormat.startsWith(".") ? targetFormat : `.${targetFormat}`;
  const target = path.join(parsed.dir, `${parsed.name}${targetExt}`);
  if (shell.IS_LINUX) {
    await shell.run(`convert ${shell.q(source)} ${shell.q(target)}`);
  } else {
    fs.copyFileSync(source, target);
  }
  return { success: true, converted: path.basename(target) };
}

// -------------------------------------------------------------
// DIRECTORY PRIVACY (.htaccess & .htpasswd)
// -------------------------------------------------------------
async function listProtectedDirectories(user) {
  const list = store.read("directory-privacy", []);
  if (user && user.role !== "admin" && user.username !== "root") {
    const uDomain = (user.domain || user.username || "").toLowerCase().trim();
    return list.filter((item) => (item.path || "").toLowerCase().includes(uDomain));
  }
  return list;
}

async function protectDirectory({ path: reqPath, dirName, authName = "Restricted Area", username, password }, user) {
  let fullDir = "";
  try {
    const directPath = resolveSafePath(reqPath, user);
    if (fs.existsSync(directPath) && fs.statSync(directPath).isDirectory()) {
      fullDir = directPath;
    }
  } catch (_) {}

  if (!fullDir && dirName) {
    try {
      const itemPath = resolveItem(reqPath, dirName, user);
      if (fs.existsSync(itemPath) && fs.statSync(itemPath).isDirectory()) {
        fullDir = itemPath;
      }
    } catch (_) {}
  }

  if (!fullDir || !fs.existsSync(fullDir) || !fs.statSync(fullDir).isDirectory()) {
    throw validate.badRequest("Directory not found.");
  }
  const htpasswdsDir = path.join(fullDir, ".htpasswds");
  fs.mkdirSync(htpasswdsDir, { recursive: true });
  const htpasswdPath = path.join(htpasswdsDir, ".htpasswd");
  const htaccessPath = path.join(fullDir, ".htaccess");

  const passHash = crypto.createHash("sha1").update(password).digest("base64");
  const htpasswdContent = `${username}:{SHA}${passHash}\n`;
  fs.writeFileSync(htpasswdPath, htpasswdContent, "utf8");

  const htaccessSnippet = `
# Facezila Directory Privacy
AuthType Basic
AuthName "${authName}"
AuthUserFile "${htpasswdPath.replace(/\\/g, "/")}"
Require valid-user
`;
  let existing = "";
  if (fs.existsSync(htaccessPath)) existing = fs.readFileSync(htaccessPath, "utf8");
  fs.writeFileSync(htaccessPath, existing + "\n" + htaccessSnippet, "utf8");

  const list = store.read("directory-privacy", []);
  const normalized = fullDir.replace(/\\/g, "/");
  const filtered = list.filter((item) => item.path !== normalized);
  filtered.push({ path: normalized, authName, username, created: new Date().toISOString() });
  store.write("directory-privacy", filtered);
  return { success: true, directory: normalized, authName, username };
}

async function unprotectDirectory({ path: reqPath }, user) {
  const fullDir = resolveSafePath(reqPath, user);
  const htpasswdsDir = path.join(fullDir, ".htpasswds");
  const htaccessPath = path.join(fullDir, ".htaccess");
  if (fs.existsSync(htpasswdsDir)) {
    fs.rmSync(htpasswdsDir, { recursive: true, force: true });
  }
  if (fs.existsSync(htaccessPath)) {
    let content = fs.readFileSync(htaccessPath, "utf8");
    content = content.replace(/# Facezila Directory Privacy[\s\S]*?Require valid-user\n?/g, "");
    fs.writeFileSync(htaccessPath, content, "utf8");
  }
  const normalized = fullDir.replace(/\\/g, "/");
  const list = store.read("directory-privacy", []);
  store.write("directory-privacy", list.filter((item) => item.path !== normalized));
  return { success: true, unpotected: normalized };
}

// -------------------------------------------------------------
// DISK USAGE BREAKDOWN
// -------------------------------------------------------------
async function getDiskUsageBreakdown(reqPath = "", user) {
  const target = resolveSafePath(reqPath, user);
  if (!shell.IS_LINUX) {
    return [
      { name: "public_html", path: "/public_html", size: "450 MB", sizeBytes: 450 * 1024 * 1024, percent: 55 },
      { name: "mail", path: "/mail", size: "180 MB", sizeBytes: 180 * 1024 * 1024, percent: 22 },
      { name: "mysql", path: "/mysql", size: "120 MB", sizeBytes: 120 * 1024 * 1024, percent: 15 },
      { name: "logs", path: "/logs", size: "65 MB", sizeBytes: 65 * 1024 * 1024, percent: 8 },
    ];
  }
  try {
    const out = await shell.tryGet(`du -sb ${shell.q(target)}/* 2>/dev/null | sort -rn | head -20`);
    const lines = out.split("\n").filter(Boolean);
    const total = lines.reduce((acc, l) => acc + (parseInt(l.split("\t")[0]) || 0), 0) || 1;
    return lines.map((l) => {
      const [bytesStr, dirPath] = l.split("\t");
      const bytes = parseInt(bytesStr) || 0;
      return {
        name: path.basename(dirPath || ""),
        path: dirPath,
        size: formatBytes(bytes),
        sizeBytes: bytes,
        percent: Math.min(100, Math.round((bytes / total) * 100)),
      };
    });
  } catch (_) {
    return [];
  }
}

// -------------------------------------------------------------
// GIT VERSION CONTROL
// -------------------------------------------------------------
async function listGitRepos() {
  return store.read("git-repos", []);
}

async function cloneGitRepo({ repoUrl, branch = "main", destinationPath, repoName }) {
  const dest = resolveSafePath(destinationPath);
  const name = safeName(repoName || path.basename(repoUrl, ".git"));
  const targetDir = path.join(dest, name);
  if (fs.existsSync(targetDir)) throw validate.badRequest("Target directory already exists.");

  if (shell.IS_LINUX) {
    await shell.run(`git clone -b ${shell.q(branch)} ${shell.q(repoUrl)} ${shell.q(targetDir)}`, { timeout: 300000 });
  } else {
    fs.mkdirSync(targetDir, { recursive: true });
    fs.writeFileSync(path.join(targetDir, "README.md"), `# ${name}\nCloned from ${repoUrl}`);
  }

  const list = store.read("git-repos", []);
  const entry = {
    id: `git-${Date.now()}`,
    name,
    repoUrl,
    branch,
    path: targetDir.replace(/\\/g, "/"),
    lastDeploy: new Date().toISOString(),
  };
  list.push(entry);
  store.write("git-repos", list);
  return entry;
}

async function pullGitRepo({ id }) {
  const list = store.read("git-repos", []);
  const repo = list.find((r) => r.id === id);
  if (!repo) throw validate.badRequest("Repository not found.");
  if (shell.IS_LINUX && fs.existsSync(repo.path)) {
    const out = await shell.runGet(`git -C ${shell.q(repo.path)} pull`, { timeout: 120000 });
    repo.lastDeploy = new Date().toISOString();
    repo.lastOutput = out;
    store.write("git-repos", list);
    return { success: true, output: out, repo };
  }
  repo.lastDeploy = new Date().toISOString();
  store.write("git-repos", list);
  return { success: true, output: "Already up to date. (dev)", repo };
}

// -------------------------------------------------------------
// REMOTE ZIP COPY & RSYNC SYNC
// -------------------------------------------------------------
async function listSyncJobs(user) {
  const jobs = store.read("remote-sync-jobs", []);
  if (user && user.role !== "admin" && user.username !== "root") {
    const uDomain = (user.domain || user.username || "").toLowerCase().trim();
    return jobs.filter((j) => (j.destination || "").toLowerCase().includes(uDomain));
  }
  return jobs.slice(0, 30);
}

async function copyFromZip({
  sourceType = "remote_url",
  sourceUrl = "",
  sourceZipPath = "",
  destinationPath = "",
  sourceSubfolder = "",
  overwrite = true,
  cleanDestination = false,
  deleteZipAfter = true
}, user) {
  if (!destinationPath) throw validate.badRequest("Destination folder is required.");
  const targetDir = resolveSafePath(destinationPath, user);
  const { isLimited } = getUserRoots(user);
  if (!isLimited && targetDir === ROOT_DIR) {
    throw validate.badRequest("Cannot extract directly to root folder. Specify a domain directory.");
  }
  fs.mkdirSync(targetDir, { recursive: true });

  let zipFile = "";
  let isTemp = false;

  if (sourceType === "remote_url") {
    if (!sourceUrl || !/^https?:\/\//i.test(sourceUrl.trim())) {
      throw validate.badRequest("A valid HTTP/HTTPS URL is required.");
    }
    const cleanUrl = sourceUrl.trim();
    let ext = "zip";
    try {
      const parsed = new URL(cleanUrl);
      const extMatch = parsed.pathname.match(/\.(zip|tar\.gz|tgz|tar|bz2)(\?.*)?$/i);
      if (extMatch) ext = extMatch[1];
    } catch (_) {}

    zipFile = path.join("/tmp", `facezila_dl_${Date.now()}.${ext}`);
    isTemp = true;

    if (shell.IS_LINUX) {
      const cmd = `curl -fSL ${shell.q(cleanUrl)} -o ${shell.q(zipFile)} --connect-timeout 30 --max-time 600`;
      try {
        await shell.run(cmd);
      } catch (err) {
        if (fs.existsSync(zipFile)) try { fs.unlinkSync(zipFile); } catch (_) {}
        throw validate.badRequest(`Failed to download remote archive: ${err.message}`);
      }
    } else {
      fs.writeFileSync(zipFile, "mock archive content");
    }
  } else {
    if (!sourceZipPath) throw validate.badRequest("Source zip file path on server is required.");
    const directZip = resolveSafePath(sourceZipPath, user);
    if (!fs.existsSync(directZip) || fs.statSync(directZip).isDirectory()) {
      throw validate.badRequest(`Source archive not found: ${sourceZipPath}`);
    }
    zipFile = directZip;
  }

  // If cleanDestination is true, clean files inside targetDir
  if (cleanDestination && targetDir !== ROOT_DIR && targetDir !== "/") {
    if (shell.IS_LINUX) {
      await shell.run(`rm -rf ${shell.q(targetDir)}/*`);
    }
  }

  const isZip = zipFile.endsWith(".zip");
  const isTarGz = zipFile.endsWith(".tar.gz") || zipFile.endsWith(".tgz");
  const isTar = zipFile.endsWith(".tar");

  let extractSummary = "";

  if (shell.IS_LINUX) {
    if (sourceSubfolder && sourceSubfolder.trim()) {
      const tempExtract = path.join("/tmp", `facezila_stage_${Date.now()}`);
      fs.mkdirSync(tempExtract, { recursive: true });

      if (isZip) {
        await shell.run(`unzip -q -o ${shell.q(zipFile)} -d ${shell.q(tempExtract)}`);
      } else if (isTarGz) {
        await shell.run(`tar -xzf ${shell.q(zipFile)} -C ${shell.q(tempExtract)}`);
      } else if (isTar) {
        await shell.run(`tar -xf ${shell.q(zipFile)} -C ${shell.q(tempExtract)}`);
      } else {
        await shell.run(`unzip -q -o ${shell.q(zipFile)} -d ${shell.q(tempExtract)} || tar -xf ${shell.q(zipFile)} -C ${shell.q(tempExtract)}`);
      }

      const subClean = sourceSubfolder.trim().replace(/^[\/\\]+|[\/\\]+$/g, "");
      const subPath = path.join(tempExtract, subClean);
      if (fs.existsSync(subPath)) {
        await shell.run(`rsync -a ${shell.q(subPath + "/")} ${shell.q(targetDir + "/")}`);
        extractSummary = `Copied '${sourceSubfolder}' contents into ${targetDir}`;
      } else {
        await shell.run(`rsync -a ${shell.q(tempExtract + "/")} ${shell.q(targetDir + "/")}`);
        extractSummary = `Extracted all contents into ${targetDir} (subfolder '${sourceSubfolder}' not found in zip root)`;
      }

      await shell.run(`rm -rf ${shell.q(tempExtract)}`);
    } else {
      if (isZip) {
        const flag = overwrite ? "-o" : "-n";
        await shell.run(`unzip -q ${flag} ${shell.q(zipFile)} -d ${shell.q(targetDir)}`);
      } else if (isTarGz) {
        await shell.run(`tar -xzf ${shell.q(zipFile)} -C ${shell.q(targetDir)}`);
      } else if (isTar) {
        await shell.run(`tar -xf ${shell.q(zipFile)} -C ${shell.q(targetDir)}`);
      } else {
        await shell.run(`unzip -q -o ${shell.q(zipFile)} -d ${shell.q(targetDir)} || tar -xf ${shell.q(zipFile)} -C ${shell.q(targetDir)}`);
      }
      extractSummary = `Extracted archive directly into ${targetDir}`;
    }

    await shell.run(`chown -R www:www ${shell.q(targetDir)} 2>/dev/null || chown -R www-data:www-data ${shell.q(targetDir)} 2>/dev/null || true`);
  } else {
    extractSummary = `Simulated extraction into ${targetDir}`;
  }

  if (isTemp && deleteZipAfter && fs.existsSync(zipFile)) {
    try { fs.unlinkSync(zipFile); } catch (_) {}
  }

  const jobRecord = {
    id: `sync-${Date.now()}`,
    type: "zip_copy",
    source: sourceType === "remote_url" ? sourceUrl : sourceZipPath,
    sourceType,
    destination: targetDir,
    sourceSubfolder: sourceSubfolder || "(root)",
    timestamp: new Date().toISOString(),
    status: "completed",
    summary: extractSummary,
  };
  store.update("remote-sync-jobs", [], (list) => [jobRecord, ...(list || []).slice(0, 49)]);

  return {
    success: true,
    destination: targetDir,
    summary: extractSummary,
    job: jobRecord,
  };
}

async function runRsync({
  source = "",
  destination = "",
  archive = true,
  delete: deleteExtraneous = false,
  compress = true,
  dryRun = false,
  exclude = "",
  sshPort = 22,
  bandwidthLimit = 0
}, user) {
  if (!source.trim()) throw validate.badRequest("Source folder or remote host string is required.");
  if (!destination.trim()) throw validate.badRequest("Destination folder is required.");

  const targetDir = resolveSafePath(destination, user);
  const { isLimited } = getUserRoots(user);
  if (!isLimited && targetDir === ROOT_DIR) {
    throw validate.badRequest("Cannot sync directly to root folder. Specify a domain directory.");
  }
  fs.mkdirSync(targetDir, { recursive: true });

  let srcArg = source.trim();
  if (!srcArg.includes(":")) {
    const localSrc = resolveSafePath(srcArg, user);
    if (!fs.existsSync(localSrc) || !fs.statSync(localSrc).isDirectory()) {
      throw validate.badRequest(`Local source folder does not exist: ${srcArg}`);
    }
    srcArg = localSrc.endsWith("/") ? localSrc : localSrc + "/";
  }

  const destArg = targetDir.endsWith("/") ? targetDir : targetDir + "/";

  const flags = ["-v", "--stats"];
  if (archive) flags.push("-a");
  if (compress) flags.push("-z");
  if (deleteExtraneous) flags.push("--delete");
  if (dryRun) flags.push("-n");
  if (bandwidthLimit && Number(bandwidthLimit) > 0) flags.push(`--bwlimit=${Number(bandwidthLimit)}`);

  if (exclude) {
    const items = Array.isArray(exclude) ? exclude : exclude.split(/[,;\n]/).map((s) => s.trim()).filter(Boolean);
    for (const ex of items) {
      flags.push(`--exclude=${shell.q(ex)}`);
    }
  }

  if (srcArg.includes(":") && Number(sshPort) && Number(sshPort) !== 22) {
    flags.push(`-e 'ssh -p ${Number(sshPort)} -o StrictHostKeyChecking=no'`);
  }

  const rsyncCmd = `rsync ${flags.join(" ")} ${srcArg.includes(":") ? srcArg : shell.q(srcArg)} ${shell.q(destArg)}`;

  let output = "";
  if (shell.IS_LINUX) {
    output = await shell.runGet(rsyncCmd, { timeout: 600000 });
    await shell.run(`chown -R www:www ${shell.q(targetDir)} 2>/dev/null || chown -R www-data:www-data ${shell.q(targetDir)} 2>/dev/null || true`);
  } else {
    output = `[Simulation] rsync executed: ${rsyncCmd}\nNumber of files: 42\nTotal file size: 10.5 MB\nStatus: SUCCESS`;
  }

  const jobRecord = {
    id: `sync-${Date.now()}`,
    type: "rsync",
    source: srcArg,
    destination: targetDir,
    dryRun: !!dryRun,
    timestamp: new Date().toISOString(),
    status: "completed",
    summary: dryRun ? "Dry Run simulation completed" : "Rsync sync completed",
    output: output.slice(-2000),
  };
  store.update("remote-sync-jobs", [], (list) => [jobRecord, ...(list || []).slice(0, 49)]);

  return {
    success: true,
    destination: targetDir,
    dryRun: !!dryRun,
    output,
    job: jobRecord,
  };
}

module.exports = {
  ROOT_DIR,
  TRASH_DIR,
  browseDirectory,
  getTree,
  createFile,
  createFolder,
  renameItem,
  changePermissions,
  deleteItem,
  restoreFromTrash,
  emptyTrash,
  readFile,
  saveFile,
  uploadFile,
  downloadPath,
  copyOrMove,
  compress,
  extract,
  // Images
  processImageThumbnail,
  processImageScale,
  processImageConvert,
  // Privacy
  listProtectedDirectories,
  protectDirectory,
  unprotectDirectory,
  // Disk
  getDiskUsageBreakdown,
  // Git
  listGitRepos,
  cloneGitRepo,
  pullGitRepo,
  // Remote Sync & Zip Copy
  listSyncJobs,
  copyFromZip,
  runRsync,
};
