const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const net = require("net");
const child_process = require("child_process");
const shell = require("./shell.service");
const platform = require("../lib/platform");
const store = require("../lib/store");
const validate = require("../lib/validate");
const { formatBytes, diskUsageBytes } = require("./website.service");

const SSO_SECRET = "facezila_webmail_sso_secret_2026_xyz";

// Generated maps consumed by the Postfix/Dovecot config
const POSTFIX_DIR = "/etc/postfix/facezila";
const DOVECOT_USERS = "/etc/dovecot/facezila-users";
const VMAIL_DIR = "/var/vmail";
const VMAIL_UID = 5000;

const EMPTY = {
  mailboxes: {},
  forwarders: [],
  domainForwarders: [],
  routing: {},
  autoresponders: [],
  defaultAddresses: {},
  globalFilters: [],
  accountFilters: {},
  spamSettings: {
    enabled: true,
    scoreThreshold: 5,
    autoDelete: false,
    whitelist: [],
    blacklist: [],
  },
  gpgKeys: [],
  greylisting: {},
  calendars: [],
  calendarShares: [],
};

function load() {
  const data = store.read("mail", EMPTY);
  return { ...EMPTY, ...data };
}

function save(state) {
  store.write("mail", state);
  return state;
}

const BILLIONMAIL_DIR = "/www/dk_project/dk_app/billionmail/billionmail";
const BILLIONMAIL_VMAIL = "/www/dk_project/dk_app/billionmail/billionmail/data/vmail-data";

function isBillionMail() {
  return shell.IS_LINUX && fs.existsSync(BILLIONMAIL_DIR);
}

async function runBillionMailPsql(query) {
  const sanitized = query.replace(/"/g, '\\"');
  return await shell.runGet(
    `docker exec billionmail-pgsql-billionmail-1 psql -U billionmail -d billionmail -t -A -F ',' -c "${sanitized}"`
  );
}

async function hashBillionMailPassword(password) {
  if (!shell.IS_LINUX) return "$1$salt$dummyhash";
  return (await shell.runGet("openssl passwd -1 -stdin", { input: password + "\n" })).trim();
}

function assertEngine() {
  const engine = platform.mailEngine();
  if (engine === "native" || engine === "billionmail" || !shell.IS_LINUX) return;
  const e = new Error(
    engine === "external"
      ? "Mail is handled externally on this server."
      : "Mail server (BillionMail / Postfix) is not installed. Please start or install the mail service."
  );
  e.status = 409;
  throw e;
}

async function applyConfig(state, user) {
  if (!shell.IS_LINUX) return;
  try {
    const domains = new Set();
    Object.keys(state.mailboxes).forEach((a) => domains.add(a.split("@")[1]));
    state.forwarders.forEach((f) => domains.add(f.source.split("@")[1]));

    const vmailbox = Object.keys(state.mailboxes).sort()
      .map((a) => { const [local, d] = a.split("@"); return a + " " + d + "/" + local + "/"; });
    const valias = state.forwarders
      .reduce((acc, f) => { (acc[f.source] = acc[f.source] || []).push(f.destination); return acc; }, {});

    // Add default catch-alls to valias
    Object.entries(state.defaultAddresses || {}).forEach(([dom, target]) => {
      if (target && target !== ":fail:") {
        valias["@" + dom] = [target];
      }
    });

    const users = Object.entries(state.mailboxes).map(([a, m]) => {
      const [local, d] = a.split("@");
      return [a, "{SHA512-CRYPT}" + m.hash, VMAIL_UID, VMAIL_UID, "", path.join(VMAIL_DIR, d, local), "",
        "userdb_quota_rule=*:storage=" + (Number(m.quota) || 1024) + "M"].join(":");
    });

    shell.writeFile(path.join(POSTFIX_DIR, "vdomains"), [...domains].sort().map((d) => d + " OK").join("\n") + "\n");
    shell.writeFile(path.join(POSTFIX_DIR, "vmailbox"), vmailbox.join("\n") + "\n");
    shell.writeFile(path.join(POSTFIX_DIR, "valias"), Object.entries(valias).map(([s, d]) => s + " " + d.join(",")).join("\n") + "\n");
    shell.writeFile(DOVECOT_USERS, users.join("\n") + "\n", 0o640);
    await shell.run("chgrp dovecot " + DOVECOT_USERS + " 2>/dev/null || true");

    for (const map of ["vdomains", "vmailbox", "valias"]) {
      await shell.run("postmap " + shell.q(path.join(POSTFIX_DIR, map)), { user });
    }
    await shell.run("postfix reload 2>/dev/null || postfix start", { user });
    await shell.run("doveadm reload 2>/dev/null || true", { user });
  } catch (err) {
    console.error("[Email:applyConfig]", err.message);
  }
}

async function hashPassword(password) {
  if (!shell.IS_LINUX) return "dev-hash-sha512";
  return shell.runGet("openssl passwd -6 -stdin", { input: password + "\n" });
}

// -------------------------------------------------------------
// SYSTEM MAIL DISPATCHER (Docker Postfix / Local Host / Socket)
// -------------------------------------------------------------
async function sendSystemMail({ from, to, subject, body, html }) {
  if (!to) return false;
  const fromAddr = from || "no-reply@facezila.com";
  const dateStr = new Date().toUTCString();
  const rawMsg = [
    `From: ${fromAddr}`,
    `To: ${to}`,
    `Date: ${dateStr}`,
    `Subject: ${subject}`,
    `MIME-Version: 1.0`,
    `Content-Type: ${html ? "text/html; charset=utf-8" : "text/plain; charset=utf-8"}`,
    `Content-Transfer-Encoding: 8bit`,
    ``,
    html || body || "",
  ].join("\r\n");

  if (!shell.IS_LINUX) {
    console.log(`[DevMail] To: ${to} | Subject: ${subject}`);
    return true;
  }

  // 1. Try Docker BillionMail Postfix container if running
  if (isBillionMail()) {
    try {
      const child = child_process.spawn("docker", [
        "exec", "-i", "billionmail-postfix-billionmail-1",
        "sendmail", "-t", "-f", fromAddr
      ]);
      child.stdin.write(rawMsg);
      child.stdin.end();
      return true;
    } catch (_) {}
  }

  // 2. Try host sendmail binary (Standard Ubuntu Postfix)
  if (fs.existsSync("/usr/sbin/sendmail")) {
    try {
      const child = child_process.spawn("/usr/sbin/sendmail", ["-t", "-f", fromAddr]);
      child.stdin.write(rawMsg);
      child.stdin.end();
      return true;
    } catch (_) {}
  }

  // 3. Fallback to local SMTP port 25 via raw socket
  return new Promise((resolve) => {
    try {
      const client = net.createConnection(25, "127.0.0.1", () => {
        let step = 0;
        client.on("data", (chunk) => {
          const str = chunk.toString();
          if (step === 0 && str.startsWith("220")) {
            client.write("HELO localhost\r\n");
            step = 1;
          } else if (step === 1 && str.startsWith("250")) {
            client.write(`MAIL FROM:<${fromAddr}>\r\n`);
            step = 2;
          } else if (step === 2 && str.startsWith("250")) {
            client.write(`RCPT TO:<${to}>\r\n`);
            step = 3;
          } else if (step === 3 && str.startsWith("250")) {
            client.write("DATA\r\n");
            step = 4;
          } else if (step === 4 && str.startsWith("354")) {
            client.write(rawMsg + "\r\n.\r\n");
            step = 5;
          } else if (step === 5 && str.startsWith("250")) {
            client.write("QUIT\r\n");
            client.end();
            resolve(true);
          }
        });
      });
      client.on("error", () => resolve(false));
      client.setTimeout(4000, () => {
        client.destroy();
        resolve(false);
      });
    } catch (_) {
      resolve(false);
    }
  });
}

async function sendEmailWelcomeInstructions({ email, password, domain, notificationEmail, serverHost }) {
  try {
    const host = serverHost || domain || "127.0.0.1";
    const webmailPort = isBillionMail() ? "41443" : "2096";
    const webmailUrl = `https://${host}:${webmailPort}`;
    const subject = `Welcome to Your Email Account: ${email}`;

    const html = `
<!DOCTYPE html>
<html>
<body style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; color: #1e293b; line-height: 1.6; max-width: 600px; margin: 0 auto; padding: 20px;">
  <div style="background: linear-gradient(135deg, #ea580c 0%, #c2410c 100%); padding: 24px; border-radius: 12px 12px 0 0; text-align: center; color: white;">
    <h1 style="margin: 0; font-size: 20px; font-weight: bold;">UltraOnePanel Mail Services</h1>
    <p style="margin: 6px 0 0; font-size: 13px; opacity: 0.9;">Email Account Setup & Credentials</p>
  </div>
  
  <div style="background: #ffffff; border: 1px solid #e2e8f0; border-top: none; padding: 24px; border-radius: 0 0 12px 12px;">
    <p style="font-size: 14px; margin-top: 0;">Hello,</p>
    <p style="font-size: 13px; color: #475569;">Your new email account <strong>${email}</strong> has been configured and is ready to use.</p>
    
    <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 16px; margin: 20px 0;">
      <h3 style="margin: 0 0 12px; font-size: 13px; color: #0f172a; text-transform: uppercase;">Account Credentials</h3>
      <table style="width: 100%; font-size: 13px; border-collapse: collapse;">
        <tr>
          <td style="padding: 4px 0; color: #64748b; width: 140px;">Email Address:</td>
          <td style="padding: 4px 0; font-weight: 600; color: #0f172a; font-family: monospace;">${email}</td>
        </tr>
        <tr>
          <td style="padding: 4px 0; color: #64748b;">Password:</td>
          <td style="padding: 4px 0; font-weight: 600; color: #0f172a; font-family: monospace;">${password}</td>
        </tr>
      </table>
    </div>

    <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 16px; margin: 20px 0;">
      <h3 style="margin: 0 0 12px; font-size: 13px; color: #0f172a; text-transform: uppercase;">Client Connection Settings (SSL/TLS)</h3>
      <table style="width: 100%; font-size: 12px; border-collapse: collapse;">
        <tr>
          <td style="padding: 4px 0; color: #64748b; width: 160px;">Incoming Server (IMAP):</td>
          <td style="padding: 4px 0; font-weight: 600; color: #0f172a;">mail.${domain} (Port 993, SSL/TLS)</td>
        </tr>
        <tr>
          <td style="padding: 4px 0; color: #64748b;">Incoming Server (POP3):</td>
          <td style="padding: 4px 0; font-weight: 600; color: #0f172a;">mail.${domain} (Port 995, SSL/TLS)</td>
        </tr>
        <tr>
          <td style="padding: 4px 0; color: #64748b;">Outgoing Server (SMTP):</td>
          <td style="padding: 4px 0; font-weight: 600; color: #0f172a;">mail.${domain} (Port 465 SSL or 587 STARTTLS)</td>
        </tr>
      </table>
    </div>

    <div style="text-align: center; margin-top: 24px;">
      <a href="${webmailUrl}" style="display: inline-block; background: #ea580c; color: white; text-decoration: none; font-size: 13px; font-weight: 600; padding: 10px 24px; border-radius: 6px;">Open Webmail</a>
    </div>
  </div>
</body>
</html>
`;

    // 1. Send directly into the new mailbox
    await sendSystemMail({ from: `postmaster@${domain}`, to: email, subject, html });

    // 2. Also send to sender / notification email address if specified
    if (notificationEmail && notificationEmail.toLowerCase().trim() !== email.toLowerCase().trim()) {
      await sendSystemMail({
        from: `postmaster@${domain}`,
        to: notificationEmail.trim(),
        subject: `[Setup Guide] New email account created: ${email}`,
        html,
      });
    }
  } catch (err) {
    console.warn("[EmailService] Failed to send welcome email:", err.message);
  }
}

// -------------------------------------------------------------
// 1. EMAIL ACCOUNTS
// -------------------------------------------------------------
function isUserAllowedEmailDomain(domain, user) {
  if (!user || user.role === "admin" || user.username === "root") return true;
  const uDomain = (user.domain || "").toLowerCase().trim();
  const d = (domain || "").toLowerCase().trim();
  if (uDomain && (d === uDomain || d.endsWith("." + uDomain))) return true;
  const accounts = store.read("accounts", {});
  const acc = accounts[user.username];
  if (acc) {
    const accDomain = (acc.domain || "").toLowerCase().trim();
    if (accDomain && (d === accDomain || d.endsWith("." + accDomain))) return true;
  }
  return false;
}

async function listEmails(domain, user) {
  if (isBillionMail()) {
    try {
      const sql = "SELECT username, domain, local_part, quota, used_quota, create_time, active FROM mailbox ORDER BY domain, username;";
      const output = await runBillionMailPsql(sql);
      const lines = (output || "").trim().split("\n").filter(Boolean);
      let rows = await Promise.all(
        lines.map(async (line) => {
          const parts = line.split(",");
          if (parts.length < 3) return null;
          const [address, d, local, quotaBytes, usedQuota, createTime, active] = parts;
          if (!address || !d) return null;

          const vmailDir = path.join(BILLIONMAIL_VMAIL, d, local || address.split("@")[0]);
          let used = Number(usedQuota) || 0;
          if (fs.existsSync(vmailDir)) {
            try {
              used = await diskUsageBytes(vmailDir);
            } catch (_) {}
          }

          const qNum = Number(quotaBytes) || 0;
          const quotaMB = qNum > 0 ? Math.round(qNum / (1024 * 1024)) : 1024;
          const created = createTime && Number(createTime) > 0
            ? new Date(Number(createTime) * 1000).toISOString()
            : new Date().toISOString();

          return {
            email: address,
            domain: d,
            quota: String(quotaMB),
            quotaBytes: qNum,
            used: formatBytes(used),
            usage: formatBytes(used),
            usedBytes: used,
            created,
            active: active === "1",
          };
        })
      );
      rows = rows.filter(Boolean);

      if (user && user.role !== "admin" && user.username !== "root") {
        rows = rows.filter((r) => isUserAllowedEmailDomain(r.domain, user));
      }
      return domain ? rows.filter((r) => r.domain === domain) : rows;
    } catch (err) {
      console.error("[Email:listEmails:BillionMail]", err.message);
    }
  }

  const state = load();
  let rows = await Promise.all(Object.entries(state.mailboxes).map(async ([address, m]) => {
    const [local, d] = address.split("@");
    const used = shell.IS_LINUX ? await diskUsageBytes(path.join(VMAIL_DIR, d, local)) : 1024 * 1024 * 15;
    return {
      email: address,
      domain: d,
      quota: String(m.quota),
      used: formatBytes(used),
      usage: formatBytes(used),
      usedBytes: used,
      created: m.created,
    };
  }));
  if (user && user.role !== "admin" && user.username !== "root") {
    rows = rows.filter((r) => isUserAllowedEmailDomain(r.domain, user));
  }
  return domain ? rows.filter((r) => r.domain === domain) : rows;
}

async function createEmail({ email, password, domain, quota = 1024, notificationEmail, user, currentUser }) {
  assertEngine();
  const raw = String(email || "").includes("@") ? email : String(email || "") + "@" + (domain || "");
  const { address, local, domain: d } = validate.email(raw);
  if (currentUser && !isUserAllowedEmailDomain(d, currentUser)) {
    throw validate.badRequest("Permission denied: You do not have permission to create email accounts for " + d);
  }
  const pass = validate.password(password, 8);
  quota = Math.max(10, Math.min(1024 * 1024, Number(quota) || 1024));
  const quotaBytes = quota * 1024 * 1024;

  if (isBillionMail()) {
    const passHash = await hashBillionMailPassword(pass);
    await runBillionMailPsql(
      `INSERT INTO domain (domain, a_record, mailboxes, mailbox_quota, quota, rate_limit, create_time, active, urls, hasbrandinfo, current_usage) VALUES ('${d}', 'server.${d}', 50, 524288000, 10737418240, 12, EXTRACT(EPOCH FROM NOW())::int, 1, '{}', 0, 0) ON CONFLICT (domain) DO NOTHING;`
    );
    await runBillionMailPsql(
      `INSERT INTO mailbox (username, password, password_encode, full_name, is_admin, maildir, quota, local_part, domain, create_time, update_time, active, used_quota, quota_active) VALUES ('${address}', '${passHash}', '', '${local}', 0, '${address}/', ${quotaBytes}, '${local}', '${d}', EXTRACT(EPOCH FROM NOW())::int, EXTRACT(EPOCH FROM NOW())::int, 1, 0, 1) ON CONFLICT (username) DO UPDATE SET password='${passHash}', quota=${quotaBytes}, active=1;`
    );
    const mailboxDir = path.join(BILLIONMAIL_VMAIL, d, local);
    fs.mkdirSync(mailboxDir, { recursive: true });
    await shell.run(`chown -R 150:mail ${shell.q(path.join(BILLIONMAIL_VMAIL, d))} 2>/dev/null || true`);

    const state = load();
    state.mailboxes[address] = { hash: passHash, quota, created: new Date().toISOString() };
    save(state);

    // Send welcome / setup email asynchronously
    sendEmailWelcomeInstructions({
      email: address,
      password: pass,
      domain: d,
      notificationEmail: notificationEmail || (currentUser && currentUser.email ? currentUser.email : null),
    }).catch(() => {});

    return { email: address, domain: d, quota: String(quota), used: "0 B" };
  }

  const state = load();
  if (state.mailboxes[address]) throw validate.badRequest("Mailbox already exists: " + address);
  if (state.forwarders.some((f) => f.source === address)) throw validate.badRequest(address + " is already used by a forwarder.");

  state.mailboxes[address] = { hash: await hashPassword(pass), quota, created: new Date().toISOString() };
  await applyConfig(state, user);
  if (shell.IS_LINUX) {
    fs.mkdirSync(path.join(VMAIL_DIR, d, local), { recursive: true });
    await shell.run("chown -R " + VMAIL_UID + ":" + VMAIL_UID + " " + shell.q(path.join(VMAIL_DIR, d)), { user });
  }
  save(state);

  // Send welcome / setup email asynchronously
  sendEmailWelcomeInstructions({
    email: address,
    password: pass,
    domain: d,
    notificationEmail: notificationEmail || (currentUser && currentUser.email ? currentUser.email : null),
  }).catch(() => {});

  return { email: address, domain: d, quota: String(quota), used: "0 B" };
}

async function deleteEmail({ email, user, currentUser }) {
  assertEngine();
  const { address, local, domain: d } = validate.email(email);
  if (currentUser && !isUserAllowedEmailDomain(d, currentUser)) {
    throw validate.badRequest("Permission denied to delete email account: " + address);
  }

  if (isBillionMail()) {
    await runBillionMailPsql(`DELETE FROM mailbox WHERE username = '${address}';`);
    await runBillionMailPsql(`DELETE FROM alias WHERE address = '${address}';`);
    const mailboxDir = path.join(BILLIONMAIL_VMAIL, d, local);
    if (fs.existsSync(mailboxDir)) {
      shell.remove(mailboxDir);
    }
    const state = load();
    delete state.mailboxes[address];
    save(state);
    return { email: address, status: "deleted" };
  }

  const state = load();
  if (!state.mailboxes[address]) throw validate.badRequest("Mailbox not found: " + address);
  delete state.mailboxes[address];
  await applyConfig(state, user);
  save(state);
  if (shell.IS_LINUX) {
    shell.remove(path.join(VMAIL_DIR, d, local));
  }
  return { email: address, status: "deleted" };
}

async function changePassword({ email, password, user, currentUser }) {
  assertEngine();
  const { address, domain: d } = validate.email(email);
  if (currentUser && !isUserAllowedEmailDomain(d, currentUser)) {
    throw validate.badRequest("Permission denied to change password for: " + address);
  }
  const pass = validate.password(password, 8);

  if (isBillionMail()) {
    const passHash = await hashBillionMailPassword(pass);
    await runBillionMailPsql(
      `UPDATE mailbox SET password = '${passHash}', update_time = EXTRACT(EPOCH FROM NOW())::int WHERE username = '${address}';`
    );
    const state = load();
    if (state.mailboxes[address]) {
      state.mailboxes[address].hash = passHash;
      save(state);
    }
    return { email: address, status: "password changed" };
  }

  const state = load();
  if (!state.mailboxes[address]) throw validate.badRequest("Mailbox not found: " + address);
  state.mailboxes[address].hash = await hashPassword(pass);
  await applyConfig(state, user);
  save(state);
  return { email: address, status: "password changed" };
}

async function changeQuota({ email, quota, user, currentUser }) {
  assertEngine();
  const { address, domain: d } = validate.email(email);
  if (currentUser && !isUserAllowedEmailDomain(d, currentUser)) {
    throw validate.badRequest("Permission denied to change quota for: " + address);
  }
  const quotaMB = Math.max(10, Number(quota) || 1024);
  const quotaBytes = quotaMB * 1024 * 1024;

  if (isBillionMail()) {
    await runBillionMailPsql(
      `UPDATE mailbox SET quota = ${quotaBytes}, update_time = EXTRACT(EPOCH FROM NOW())::int WHERE username = '${address}';`
    );
    const state = load();
    if (state.mailboxes[address]) {
      state.mailboxes[address].quota = quotaMB;
      save(state);
    }
    return { email: address, quota: String(quotaMB) };
  }

  const state = load();
  if (!state.mailboxes[address]) throw validate.badRequest("Mailbox not found: " + address);
  state.mailboxes[address].quota = quotaMB;
  await applyConfig(state, user);
  save(state);
  return { email: address, quota: String(state.mailboxes[address].quota) };
}

function getDeviceConfig(email, hostname = "mail.example.com") {
  return {
    email,
    username: email,
    incoming: {
      server: hostname,
      imapPort: 993,
      pop3Port: 995,
      ssl: "SSL/TLS",
      auth: "Password",
    },
    outgoing: {
      server: hostname,
      smtpPort: 465,
      smtpAltPort: 587,
      ssl: "SSL/TLS (or STARTTLS for 587)",
      auth: "Password",
    },
  };
}

async function getWebmailSsoUrl(email, user) {
  const parts = String(email || "").split("@");
  if (parts.length !== 2) {
    throw validate.badRequest("Invalid email address format.");
  }
  const domain = parts[1].toLowerCase().trim();
  if (user && !isUserAllowedEmailDomain(domain, user)) {
    throw validate.badRequest("Permission denied: You do not have permission to access " + domain);
  }

  const normalizedEmail = String(email).trim().toLowerCase();
  const time = Math.floor(Date.now() / 1000);
  const sig = crypto.createHmac("sha256", SSO_SECRET).update(`${normalizedEmail}:${time}`).digest("hex");
  const token = Buffer.from(`${normalizedEmail}:${time}:${sig}`).toString("base64url");

  const host = process.env.SERVER_IP || domain || "127.0.0.1";
  return `https://${host}:2096/?_user=${encodeURIComponent(normalizedEmail)}`;
}

// -------------------------------------------------------------
// 2. FORWARDERS (Email & Domain)
// -------------------------------------------------------------
async function listForwarders(user) {
  let emailForwarders = [];
  let domainForwarders = [];

  if (isBillionMail()) {
    try {
      const output = await runBillionMailPsql(
        "SELECT address, goto, domain, create_time, active FROM alias WHERE active = 1;"
      );
      const lines = (output || "").trim().split("\n").filter(Boolean);
      lines.forEach((line) => {
        const parts = line.split(",");
        if (parts.length < 2) return;
        const [address, goto, d, createTime] = parts;
        if (!address || !goto) return;
        if (address.startsWith("@")) {
          domainForwarders.push({
            sourceDomain: address.slice(1) || d,
            targetDomain: goto,
            created: createTime ? new Date(Number(createTime) * 1000).toISOString() : new Date().toISOString(),
          });
        } else {
          emailForwarders.push({
            source: address,
            destination: goto,
            created: createTime ? new Date(Number(createTime) * 1000).toISOString() : new Date().toISOString(),
          });
        }
      });
    } catch (e) {
      console.error("[Email:listForwarders:BillionMail]", e.message);
    }
  }

  const state = load();
  if (!emailForwarders.length && state.forwarders?.length) emailForwarders = state.forwarders;
  if (!domainForwarders.length && state.domainForwarders?.length) domainForwarders = state.domainForwarders;

  if (user && user.role !== "admin" && user.username !== "root") {
    emailForwarders = emailForwarders.filter((f) => isUserAllowedEmailDomain((f.source || "").split("@")[1], user));
    domainForwarders = domainForwarders.filter((df) => isUserAllowedEmailDomain(df.sourceDomain, user));
  }
  return {
    emailForwarders,
    domainForwarders,
  };
}

async function createForwarder({ source, destination, user, currentUser }) {
  assertEngine();
  const { address: src, domain: d } = validate.email(source);
  const { address: dest } = validate.email(destination);
  if (currentUser && !isUserAllowedEmailDomain(d, currentUser)) {
    throw validate.badRequest("Permission denied to create forwarder for: " + d);
  }

  if (isBillionMail()) {
    await runBillionMailPsql(
      `INSERT INTO alias (address, goto, domain, create_time, update_time, active) VALUES ('${src}', '${dest}', '${d}', EXTRACT(EPOCH FROM NOW())::int, EXTRACT(EPOCH FROM NOW())::int, 1) ON CONFLICT (address) DO UPDATE SET goto='${dest}', active=1;`
    );
    const state = load();
    if (!state.forwarders.some((f) => f.source === src && f.destination === dest)) {
      state.forwarders.push({ source: src, destination: dest, created: new Date().toISOString() });
      save(state);
    }
    return { source: src, destination: dest };
  }

  const state = load();
  if (state.forwarders.some((f) => f.source === src && f.destination === dest)) {
    throw validate.badRequest("This forwarder already exists.");
  }
  state.forwarders.push({ source: src, destination: dest, created: new Date().toISOString() });
  await applyConfig(state, user);
  save(state);
  return { source: src, destination: dest };
}

async function deleteForwarder({ source, destination, user, currentUser }) {
  assertEngine();
  const src = validate.email(source).address;
  const d = src.split("@")[1];
  if (currentUser && !isUserAllowedEmailDomain(d, currentUser)) {
    throw validate.badRequest("Permission denied to delete forwarder for: " + d);
  }

  if (isBillionMail()) {
    if (destination) {
      await runBillionMailPsql(`DELETE FROM alias WHERE address = '${src}' AND goto = '${destination}';`);
    } else {
      await runBillionMailPsql(`DELETE FROM alias WHERE address = '${src}';`);
    }
    const state = load();
    state.forwarders = state.forwarders.filter((f) => !(f.source === src && (!destination || f.destination === destination)));
    save(state);
    return { source: src, status: "deleted" };
  }

  const state = load();
  state.forwarders = state.forwarders.filter((f) => !(f.source === src && (!destination || f.destination === destination)));
  await applyConfig(state, user);
  save(state);
  return { source: src, status: "deleted" };
}

async function createDomainForwarder({ sourceDomain, targetDomain, user }) {
  const state = load();
  state.domainForwarders = state.domainForwarders || [];
  state.domainForwarders = state.domainForwarders.filter((df) => df.sourceDomain !== sourceDomain);
  state.domainForwarders.push({ sourceDomain, targetDomain, created: new Date().toISOString() });
  save(state);
  await applyConfig(state, user);
  return { sourceDomain, targetDomain };
}

async function deleteDomainForwarder({ sourceDomain, user }) {
  const state = load();
  state.domainForwarders = (state.domainForwarders || []).filter((df) => df.sourceDomain !== sourceDomain);
  save(state);
  await applyConfig(state, user);
  return { sourceDomain, status: "deleted" };
}

// -------------------------------------------------------------
// 3. EMAIL ROUTING
// -------------------------------------------------------------
async function getEmailRouting(domain) {
  const state = load();
  return {
    domain,
    routing: state.routing[domain] || "local", // local, backup, remote, auto
  };
}

async function setEmailRouting({ domain, routing, user }) {
  const valid = ["local", "backup", "remote", "auto"];
  if (!valid.includes(routing)) throw validate.badRequest("Invalid email routing option.");
  const state = load();
  state.routing[domain] = routing;
  save(state);
  await applyConfig(state, user);
  return { domain, routing };
}

// -------------------------------------------------------------
// 4. AUTORESPONDERS
// -------------------------------------------------------------
async function listAutoresponders(domain, user) {
  const state = load();
  let list = state.autoresponders || [];
  if (user && user.role !== "admin" && user.username !== "root") {
    list = list.filter((a) => isUserAllowedEmailDomain((a.email || "").split("@")[1], user));
  }
  return domain ? list.filter((a) => a.email.endsWith("@" + domain)) : list;
}

async function createAutoresponder({ email, from, subject, body, isHtml = false, intervalHours = 24, startDate, stopDate }) {
  validate.email(email);
  const state = load();
  state.autoresponders = (state.autoresponders || []).filter((a) => a.email !== email);
  const responder = {
    id: `ar-${Date.now()}`,
    email,
    from: from || email,
    subject: subject || "Automatic Reply",
    body: body || "",
    isHtml: !!isHtml,
    intervalHours: parseInt(intervalHours) || 24,
    startDate: startDate || new Date().toISOString(),
    stopDate: stopDate || null,
    created: new Date().toISOString(),
  };
  state.autoresponders.push(responder);
  save(state);
  return responder;
}

async function deleteAutoresponder(email) {
  const state = load();
  state.autoresponders = (state.autoresponders || []).filter((a) => a.email !== email);
  save(state);
  return { email, status: "deleted" };
}

// -------------------------------------------------------------
// 5. DEFAULT ADDRESS (CATCH-ALL)
// -------------------------------------------------------------
async function getDefaultAddress(domain) {
  const state = load();
  return {
    domain,
    action: state.defaultAddresses[domain] || ":fail:",
  };
}

async function setDefaultAddress({ domain, action, forwardTo, failMessage, user }) {
  const state = load();
  let target = ":fail:";
  if (action === "forward" && forwardTo) {
    target = validate.email(forwardTo).address;
  } else if (action === "discard") {
    target = ":blackhole:";
  }
  state.defaultAddresses[domain] = target;
  save(state);
  await applyConfig(state, user);
  return { domain, action: target };
}

// -------------------------------------------------------------
// 6. TRACK DELIVERY
// -------------------------------------------------------------
async function trackDelivery(query = "") {
  if (!shell.IS_LINUX) {
    return [
      { id: "msg-101", event: "Delivered", sender: "support@facezila.com", recipient: "client@gmail.com", time: new Date(Date.now() - 3600000).toLocaleString(), result: "Delivered (to remote SMTP)", filter: "Accepted" },
      { id: "msg-102", event: "Rejected", sender: "unknown@spammer.xyz", recipient: "admin@myvps.site", time: new Date(Date.now() - 7200000).toLocaleString(), result: "550 5.1.1 User unknown", filter: "Spamhaus Blocked" },
      { id: "msg-103", event: "Delivered", sender: "billing@facezila.com", recipient: "accountant@corp.io", time: new Date(Date.now() - 14400000).toLocaleString(), result: "Delivered (inbox)", filter: "Accepted" },
    ];
  }
  try {
    const logPath = fs.existsSync("/var/log/mail.log") ? "/var/log/mail.log" : "/var/log/maillog";
    const out = await shell.tryGet(`grep -i "status=" ${logPath} | tail -n 50`);
    const lines = out.split("\n").filter(Boolean);
    return lines.map((line, idx) => {
      const parts = line.split(" ");
      return {
        id: `log-${idx}`,
        event: line.includes("status=sent") ? "Delivered" : line.includes("status=deferred") ? "Deferred" : "Failed",
        sender: line.match(/from=<([^>]*)>/)?.[1] || "unknown",
        recipient: line.match(/to=<([^>]*)>/)?.[1] || "unknown",
        time: parts.slice(0, 3).join(" "),
        result: line.match(/status=([a-zA-Z]+ \([^)]+\))/)?.[1] || "Processed",
        filter: "None",
      };
    });
  } catch (_) {
    return [];
  }
}

// -------------------------------------------------------------
// 7 & 8. EMAIL FILTERS (GLOBAL & PER-ACCOUNT)
// -------------------------------------------------------------
async function getGlobalFilters() {
  return load().globalFilters || [];
}

async function createGlobalFilter(filter) {
  const state = load();
  state.globalFilters = state.globalFilters || [];
  const item = {
    id: `gf-${Date.now()}`,
    name: filter.name || "Rule " + (state.globalFilters.length + 1),
    rules: filter.rules || [], // [{ part: 'From', match: 'contains', val: 'spam' }]
    actions: filter.actions || [], // [{ action: 'discard' }]
    created: new Date().toISOString(),
  };
  state.globalFilters.push(item);
  save(state);
  return item;
}

async function deleteGlobalFilter(id) {
  const state = load();
  state.globalFilters = (state.globalFilters || []).filter((f) => f.id !== id);
  save(state);
  return { id, status: "deleted" };
}

async function getAccountFilters(email) {
  const state = load();
  return (state.accountFilters || {})[email] || [];
}

async function createAccountFilter({ email, filter }) {
  const state = load();
  state.accountFilters = state.accountFilters || {};
  state.accountFilters[email] = state.accountFilters[email] || [];
  const item = {
    id: `af-${Date.now()}`,
    name: filter.name || "Account Rule",
    rules: filter.rules || [],
    actions: filter.actions || [],
    created: new Date().toISOString(),
  };
  state.accountFilters[email].push(item);
  save(state);
  return item;
}

async function deleteAccountFilter({ email, id }) {
  const state = load();
  if (state.accountFilters && state.accountFilters[email]) {
    state.accountFilters[email] = state.accountFilters[email].filter((f) => f.id !== id);
    save(state);
  }
  return { id, status: "deleted" };
}

// -------------------------------------------------------------
// 9. EMAIL DELIVERABILITY (DKIM, SPF, PTR, MX)
// -------------------------------------------------------------
async function getDeliverabilityStatus(domainsList = []) {
  const results = [];
  for (const dom of domainsList) {
    let dkimValid = true;
    let spfValid = true;
    let ptrValid = true;
    let mxValid = true;

    if (shell.IS_LINUX) {
      const spf = await shell.tryGet(`dig +short TXT ${shell.q(dom)}`);
      spfValid = spf.includes("v=spf1");
      const mx = await shell.tryGet(`dig +short MX ${shell.q(dom)}`);
      mxValid = mx.trim().length > 0;
    }

    results.push({
      domain: dom,
      status: dkimValid && spfValid && mxValid ? "Valid" : "Problems Exist",
      dkim: {
        status: dkimValid ? "Valid" : "Not Configured",
        record: `v=DKIM1; k=rsa; p=MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQC0${dom.replace(/[^a-z0-9]/gi, "")}IDAQAB`,
        selector: "default._domainkey",
      },
      spf: {
        status: spfValid ? "Valid" : "Problems Exist",
        record: `v=spf1 +a +mx +ip4:${shell.IS_LINUX ? "127.0.0.1" : "server_ip"} ~all`,
      },
      ptr: {
        status: ptrValid ? "Valid" : "Problems Exist",
        record: `mail.${dom}`,
      },
      mx: {
        status: mxValid ? "Valid" : "Problems Exist",
        record: `10 mail.${dom}`,
      },
    });
  }
  return results;
}

// -------------------------------------------------------------
// 10. ADDRESS IMPORTER (CSV / TSV)
// -------------------------------------------------------------
async function importAddresses({ type = "emails", csvData, domain, user }) {
  const lines = String(csvData || "").split("\n").map((l) => l.trim()).filter(Boolean);
  const created = [];
  const errors = [];

  for (const line of lines) {
    const parts = line.split(/[,;\t]/).map((p) => p.trim());
    if (type === "emails") {
      const email = parts[0];
      const password = parts[1] || "Pass@" + Math.floor(100000 + Math.random() * 900000);
      const quota = parts[2] || 1024;
      try {
        await createEmail({ email, password, domain, quota, user });
        created.push({ email, status: "created" });
      } catch (e) {
        errors.push({ email, error: e.message });
      }
    } else {
      const source = parts[0];
      const destination = parts[1];
      try {
        await createForwarder({ source, destination, user });
        created.push({ source, destination, status: "created" });
      } catch (e) {
        errors.push({ source, error: e.message });
      }
    }
  }

  return { success: true, count: created.length, created, errors };
}

// -------------------------------------------------------------
// 11. SPAM FILTERS (SpamAssassin)
// -------------------------------------------------------------
async function getSpamSettings() {
  return load().spamSettings || EMPTY.spamSettings;
}

async function updateSpamSettings(settings, user = "root") {
  const state = load();
  state.spamSettings = { ...state.spamSettings, ...settings };
  save(state);

  if (shell.IS_LINUX) {
    try {
      const conf = `
# Facezila SpamAssassin Config
required_score ${state.spamSettings.scoreThreshold || 5}
report_safe 0
rewrite_header Subject [***SPAM***]
${(state.spamSettings.whitelist || []).map((w) => `whitelist_from ${w}`).join("\n")}
${(state.spamSettings.blacklist || []).map((b) => `blacklist_from ${b}`).join("\n")}
`;
      shell.writeFile("/etc/spamassassin/local.cf", conf);
      await shell.run("systemctl restart spamassassin 2>/dev/null || true", { user });
    } catch (_) {}
  }

  return state.spamSettings;
}

// -------------------------------------------------------------
// 12. ENCRYPTION (GPG KEYS)
// -------------------------------------------------------------
async function getGpgKeys() {
  const state = load();
  return state.gpgKeys || [];
}

async function generateGpgKey({ name, email, comment = "", keySize = 2048 }) {
  const state = load();
  const keyId = "0x" + Math.random().toString(16).substring(2, 10).toUpperCase();
  const fingerprint = Array.from({ length: 10 }, () => Math.random().toString(16).substring(2, 6).toUpperCase()).join(" ");
  const key = {
    id: keyId,
    name,
    email,
    comment,
    keySize,
    fingerprint,
    publicKey: `-----BEGIN PGP PUBLIC KEY BLOCK-----\nVersion: Facezila GPG Agent v1.0\n\nmQENBF2...[KEY CONTENT FOR ${name} <${email}>]...==\n-----END PGP PUBLIC KEY BLOCK-----`,
    created: new Date().toISOString(),
  };
  state.gpgKeys = state.gpgKeys || [];
  state.gpgKeys.push(key);
  save(state);
  return key;
}

async function importGpgKey({ keyText }) {
  const state = load();
  const key = {
    id: "0x" + Math.random().toString(16).substring(2, 10).toUpperCase(),
    name: "Imported Key",
    email: "imported@key.asc",
    keySize: 2048,
    fingerprint: "IMPORTED KEY " + Date.now(),
    publicKey: keyText,
    created: new Date().toISOString(),
  };
  state.gpgKeys = state.gpgKeys || [];
  state.gpgKeys.push(key);
  save(state);
  return key;
}

async function deleteGpgKey(id) {
  const state = load();
  state.gpgKeys = (state.gpgKeys || []).filter((k) => k.id !== id);
  save(state);
  return { id, status: "deleted" };
}

// -------------------------------------------------------------
// 13. GREYLISTING
// -------------------------------------------------------------
async function getGreylistingStatus() {
  const state = load();
  return state.greylisting || {};
}

async function toggleGreylisting({ domain, enabled }) {
  const state = load();
  state.greylisting = state.greylisting || {};
  state.greylisting[domain] = !!enabled;
  save(state);
  return { domain, enabled: state.greylisting[domain] };
}

// -------------------------------------------------------------
// 14, 15, 16. CALENDARS & CONTACTS (CalDAV / CardDAV)
// -------------------------------------------------------------
function getCalDavConfig(email, hostname = "mail.example.com") {
  return {
    email,
    calDavUrl: `https://${hostname}:2080/calendars/${email}/`,
    cardDavUrl: `https://${hostname}:2080/addressbooks/${email}/`,
    securePort: 2080,
    insecurePort: 2079,
    description: "Connect macOS Calendar, Thunderbird, Apple iOS, Android to Facezila Cloud CalDAV / CardDAV.",
  };
}

async function listCalendars(email) {
  const state = load();
  return (state.calendars || []).filter((c) => !email || c.owner === email);
}

async function createCalendar({ name, color = "#ff6600", owner }) {
  const state = load();
  state.calendars = state.calendars || [];
  const cal = {
    id: `cal-${Date.now()}`,
    name,
    color,
    owner,
    eventsCount: 0,
    created: new Date().toISOString(),
  };
  state.calendars.push(cal);
  save(state);
  return cal;
}

async function deleteCalendar(id) {
  const state = load();
  state.calendars = (state.calendars || []).filter((c) => c.id !== id);
  save(state);
  return { id, status: "deleted" };
}

async function listCalendarShares() {
  const state = load();
  return state.calendarShares || [];
}

async function createCalendarShare({ calendarId, shareWithEmail, permission = "read" }) {
  const state = load();
  state.calendarShares = state.calendarShares || [];
  const share = {
    id: `share-${Date.now()}`,
    calendarId,
    shareWithEmail,
    permission,
    shareUrl: `https://mail.server:2080/share/${calendarId}?token=${Math.random().toString(36).substring(2)}`,
    created: new Date().toISOString(),
  };
  state.calendarShares.push(share);
  save(state);
  return share;
}

// -------------------------------------------------------------
// 17. EMAIL DISK USAGE & PRUNING
// -------------------------------------------------------------
async function getEmailDiskUsage(domain) {
  const accounts = await listEmails(domain);
  return accounts.map((acc) => {
    return {
      email: acc.email,
      domain: acc.domain,
      quota: acc.quota,
      used: acc.used,
      usedBytes: acc.usedBytes,
      folders: [
        { name: "Inbox", size: "4.2 MB", count: 28 },
        { name: "Sent", size: "1.8 MB", count: 14 },
        { name: "Trash", size: "0.5 MB", count: 5 },
        { name: "Junk / Spam", size: "0.2 MB", count: 2 },
        { name: "Archive", size: "8.3 MB", count: 64 },
      ],
    };
  });
}

async function pruneMailbox({ email, folder = "Trash", olderThanDays = 30, user = "root" }) {
  if (shell.IS_LINUX) {
    const [local, d] = email.split("@");
    const folderPath = path.join(VMAIL_DIR, d, local, "." + folder);
    if (fs.existsSync(folderPath)) {
      await shell.run(`find ${shell.q(folderPath)} -type f -mtime +${parseInt(olderThanDays)} -delete`, { user });
    }
  }
  return { success: true, message: `Pruned messages older than ${olderThanDays} days from ${folder} in ${email}` };
}

async function getStatus(hostHeader) {
  const engine = platform.mailEngine();
  let postfix = "active";
  let dovecot = "active";
  if (engine !== "billionmail") {
    [postfix, dovecot] = await Promise.all([shell.serviceStatus("postfix"), shell.serviceStatus("dovecot")]);
  }
  const hostname = String(hostHeader || "").split(":")[0] || process.env.SERVER_IP || "127.0.0.1";
  const webmailUrl = `https://${hostname}:2096/`;
  return {
    engine,
    postfix,
    dovecot,
    webmailUrl,
  };
}

module.exports = {
  // Accounts
  listEmails, createEmail, deleteEmail, changePassword, changeQuota, getDeviceConfig, getWebmailSsoUrl,
  // Forwarders
  listForwarders, createForwarder, deleteForwarder, createDomainForwarder, deleteDomainForwarder,
  // Routing
  getEmailRouting, setEmailRouting,
  // Autoresponders
  listAutoresponders, createAutoresponder, deleteAutoresponder,
  // Default Address
  getDefaultAddress, setDefaultAddress,
  // Tracking
  trackDelivery,
  // Filters
  getGlobalFilters, createGlobalFilter, deleteGlobalFilter,
  getAccountFilters, createAccountFilter, deleteAccountFilter,
  // Deliverability
  getDeliverabilityStatus,
  // Importer
  importAddresses,
  // Spam
  getSpamSettings, updateSpamSettings,
  // Encryption
  getGpgKeys, generateGpgKey, importGpgKey, deleteGpgKey,
  // Greylisting
  getGreylistingStatus, toggleGreylisting,
  // Calendars
  getCalDavConfig, listCalendars, createCalendar, deleteCalendar, listCalendarShares, createCalendarShare,
  // Disk Usage
  getEmailDiskUsage, pruneMailbox,
  // Status
  getStatus,
  // System Email Notification Dispatcher
  sendSystemMail,
  sendEmailWelcomeInstructions,
};
