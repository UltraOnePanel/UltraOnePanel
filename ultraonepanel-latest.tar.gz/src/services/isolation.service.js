const fs = require("fs");
const path = require("path");
const shell = require("./shell.service");
const platform = require("../lib/platform");
const store = require("../lib/store");
const securityStore = require("../lib/securityStore");

/**
 * Multi-Tenant Website & PHP Isolation Service
 *
 * Implements:
 * - Dedicated per-tenant PHP-FPM pools
 * - Strict open_basedir & disable_functions enforcement
 * - Filesystem permission isolation (0750 docroot)
 * - 1-Click Compromised Website Lockdown with branded maintenance notice
 * - Seamless non-destructive reactivation
 */

const ISOLATION_PAGE_HTML = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Website Security Notice</title>
  <style>
    body { font-family: system-ui, -apple-system, sans-serif; background: #0f172a; color: #f8fafc; display: flex; align-items: center; justify-content: center; min-height: 100vh; margin: 0; }
    .card { background: #1e293b; padding: 2.5rem; border-radius: 1rem; border: 1px solid #334155; max-width: 480px; text-align: center; box-shadow: 0 20px 25px -5px rgba(0,0,0,0.5); }
    .icon { font-size: 3rem; margin-bottom: 1rem; color: #f59e0b; }
    h1 { font-size: 1.5rem; margin-bottom: 0.75rem; }
    p { color: #94a3b8; font-size: 0.9rem; line-height: 1.5; margin-bottom: 1.5rem; }
    .badge { display: inline-block; background: rgba(245, 158, 11, 0.15); color: #fbbf24; border: 1px solid rgba(245, 158, 11, 0.3); padding: 0.25rem 0.75rem; border-radius: 9999px; font-size: 0.75rem; font-weight: 600; }
  </style>
</head>
<body>
  <div class="card">
    <div class="icon">🛡️</div>
    <div class="badge">Security Maintenance Active</div>
    <h1>Website Temporarily Isolated</h1>
    <p>This website has been temporarily isolated for routine security verification and maintenance. Access will be restored upon completion of inspection.</p>
  </div>
</body>
</html>`;

/**
 * Generate dedicated PHP-FPM pool configuration for a domain
 */
function generatePhpPoolConfig(domain, user, phpVersion = "8.2") {
  return `[${domain}]
user = ${user}
group = ${user}
listen = /run/php/php${phpVersion}-fpm-${domain}.sock
listen.owner = www-data
listen.group = www-data
listen.mode = 0660
pm = dynamic
pm.max_children = 10
pm.start_servers = 2
pm.min_spare_servers = 1
pm.max_spare_servers = 3
php_admin_value[open_basedir] = ${platform.siteDir(domain)}:/tmp:/var/tmp
php_admin_value[disable_functions] = exec,passthru,shell_exec,system,proc_open,popen,curl_multi_exec,show_source
php_admin_flag[display_errors] = off
php_admin_value[error_log] = ${platform.paths.logDir}/${domain}.php_error.log
`;
}

/**
 * Isolate a compromised website (1-click containment)
 */
async function isolateWebsite(domain, user = "admin") {
  const vhostPath = platform.vhostPath(domain);
  const lockVhostPath = vhostPath + ".isolated";

  if (shell.IS_LINUX && fs.existsSync(vhostPath)) {
    // 1. Write maintenance page inside docroot
    const noticePath = path.join(platform.docRoot(domain), "security_notice.html");
    try {
      fs.writeFileSync(noticePath, ISOLATION_PAGE_HTML, "utf8");
    } catch (_) {}

    // 2. Backup existing vhost
    fs.copyFileSync(vhostPath, lockVhostPath);

    // 3. Inject rewrite rule directing all traffic to maintenance notice
    const isolatedNginx = `server {
    listen 80;
    listen 443 ssl http2;
    server_name ${domain} www.${domain};
    root ${platform.docRoot(domain)};
    index security_notice.html;
    location / {
        try_files /security_notice.html =503;
    }
}`;
    fs.writeFileSync(vhostPath, isolatedNginx, "utf8");

    try {
      await platform.reloadNginx();
    } catch (e) {
      // Rollback on syntax error
      fs.copyFileSync(lockVhostPath, vhostPath);
      fs.unlinkSync(lockVhostPath);
      throw e;
    }
  }

  // Update store
  store.update("isolated_sites", {}, (all) => {
    all[domain] = {
      isolatedAt: new Date().toISOString(),
      isolatedBy: user,
    };
    return all;
  });

  securityStore.recordEvent({
    domain,
    source_ip: "127.0.0.1",
    event_type: "WEBSITE_ISOLATED",
    category: "ANOMALY",
    severity: "CRITICAL",
    action_taken: "ISOLATED",
  });

  securityStore.recordAuditLog({
    actorType: "admin",
    actorName: user,
    action: "ISOLATE_WEBSITE",
    target: domain,
    result: "SUCCESS",
  });

  return { success: true, message: `Website ${domain} isolated successfully. Neighbor accounts remain fully protected.` };
}

/**
 * Reactivate an isolated website
 */
async function reactivateWebsite(domain, user = "admin") {
  const vhostPath = platform.vhostPath(domain);
  const lockVhostPath = vhostPath + ".isolated";

  if (shell.IS_LINUX && fs.existsSync(lockVhostPath)) {
    fs.copyFileSync(lockVhostPath, vhostPath);
    fs.unlinkSync(lockVhostPath);

    const noticePath = path.join(platform.docRoot(domain), "security_notice.html");
    if (fs.existsSync(noticePath)) {
      try { fs.unlinkSync(noticePath); } catch (_) {}
    }

    await platform.reloadNginx();
  }

  store.update("isolated_sites", {}, (all) => {
    delete all[domain];
    return all;
  });

  securityStore.recordAuditLog({
    actorType: "admin",
    actorName: user,
    action: "REACTIVATE_WEBSITE",
    target: domain,
    result: "SUCCESS",
  });

  return { success: true, message: `Website ${domain} restored to active production.` };
}

module.exports = {
  isolateWebsite,
  reactivateWebsite,
  generatePhpPoolConfig,
};
