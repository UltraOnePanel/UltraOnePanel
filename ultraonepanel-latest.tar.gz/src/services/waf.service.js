const fs = require("fs");
const path = require("path");
const shell = require("./shell.service");
const platform = require("../lib/platform");
const store = require("../lib/store");
const securityStore = require("../lib/securityStore");
const validate = require("../lib/validate");

/**
 * WAF Engine Manager
 *
 * Implements ModSecurity v3 + OWASP Core Rule Set (CRS) integration:
 * - Centralized and per-domain WAF policy management
 * - DetectionOnly vs Active Blocking mode
 * - Safe rollback configuration testing via `nginx -t`
 * - Rule exclusion management (prevent false positives on CMS)
 * - Incident event parsing from web server audit logs
 */

const MODSEC_BASE_DIR = "/etc/nginx/modsec";
const MODSEC_VHOST_DIR = platform.IS_AAPANEL
  ? "/www/server/panel/vhost/nginx/modsec"
  : "/etc/nginx/modsec/sites";

function ensureModSecDirs() {
  if (!shell.IS_LINUX) return;
  try {
    fs.mkdirSync(MODSEC_BASE_DIR, { recursive: true, mode: 0o755 });
    fs.mkdirSync(MODSEC_VHOST_DIR, { recursive: true, mode: 0o755 });
  } catch (_) {}
}

/**
 * Get WAF Configuration (Global or Per-Domain)
 */
async function getWafConfig(domain = null) {
  const globalSettings = securityStore.getSettings("global");
  const siteSettings = domain ? securityStore.getSettings(domain) : null;

  let modsecInstalled = false;
  if (shell.IS_LINUX) {
    modsecInstalled = fs.existsSync("/usr/lib/x86_64-linux-gnu/libmodsecurity.so") ||
      fs.existsSync("/usr/local/modsecurity/lib/libmodsecurity.so") ||
      fs.existsSync("/etc/nginx/modules/ngx_http_modsecurity_module.so");
  } else {
    modsecInstalled = true;
  }

  const exclusions = store.read("waf_exclusions", {});

  return {
    installed: modsecInstalled,
    global: {
      enabled: Boolean(globalSettings.waf_enabled),
      mode: globalSettings.waf_mode || "detection", // 'detection' or 'blocking'
      owaspCrsVersion: "3.3.4",
      paranoiaLevel: 1,
    },
    site: domain
      ? {
          domain,
          enabled: siteSettings ? Boolean(siteSettings.waf_enabled) : Boolean(globalSettings.waf_enabled),
          mode: siteSettings?.waf_mode || globalSettings.waf_mode || "detection",
          exclusions: exclusions[domain] || [],
        }
      : null,
  };
}

/**
 * Generate per-domain ModSecurity configuration snippet
 */
function generateDomainSnippet(domain, { enabled = true, mode = "detection", exclusions = [] }) {
  const lines = [
    `# uPanel Automated ModSecurity Configuration for ${domain}`,
    `# Generated at ${new Date().toISOString()}`,
    "",
  ];

  if (!enabled) {
    lines.push("modsecurity off;");
    return lines.join("\n");
  }

  lines.push("modsecurity on;");
  if (mode === "blocking") {
    lines.push("modsecurity_rules 'SecRuleEngine On';");
  } else {
    lines.push("modsecurity_rules 'SecRuleEngine DetectionOnly';");
  }

  // Common CMS exclusions to prevent false-positives
  lines.push("");
  lines.push("# Per-domain custom rule exclusions");
  for (const ruleId of exclusions) {
    if (/^\d+$/.test(String(ruleId).trim())) {
      lines.push(`modsecurity_rules 'SecRuleRemoveById ${ruleId}';`);
    }
  }

  return lines.join("\n");
}

/**
 * Update WAF Settings and safely deploy configuration
 */
async function updateWafConfig({ domain = "global", enabled, mode, exclusions }, user = "admin") {
  ensureModSecDirs();

  const isGlobal = !domain || domain === "global";
  const targetKey = isGlobal ? "global" : domain;

  const updates = {};
  if (enabled !== undefined) updates.waf_enabled = Boolean(enabled);
  if (mode !== undefined && (mode === "detection" || mode === "blocking")) updates.waf_mode = mode;

  // 1. Update settings store
  securityStore.updateSettings(targetKey, updates, user);

  // 2. If exclusions passed, persist them
  if (Array.isArray(exclusions) && !isGlobal) {
    store.update("waf_exclusions", {}, (all) => {
      all[domain] = exclusions.filter((id) => /^\d+$/.test(String(id)));
      return all;
    });
  }

  // 3. Write configuration file to disk on Linux
  if (shell.IS_LINUX && !isGlobal) {
    const configPath = path.join(MODSEC_VHOST_DIR, `${domain}.conf`);
    const backupPath = configPath + ".bak";

    // Backup existing configuration if present
    if (fs.existsSync(configPath)) {
      try {
        fs.copyFileSync(configPath, backupPath);
      } catch (_) {}
    }

    const currentExclusions = store.read("waf_exclusions", {})[domain] || [];
    const content = generateDomainSnippet(domain, {
      enabled: updates.waf_enabled !== undefined ? updates.waf_enabled : true,
      mode: updates.waf_mode || "detection",
      exclusions: currentExclusions,
    });

    fs.writeFileSync(configPath, content, "utf8");

    // Pre-reload syntax test via nginx -t
    try {
      await platform.reloadNginx();
      if (fs.existsSync(backupPath)) fs.unlinkSync(backupPath);
    } catch (err) {
      // Syntax failed! Immediate rollback
      console.error(`[WAF] Nginx syntax check failed for ${domain}. Rolling back:`, err.message);
      if (fs.existsSync(backupPath)) {
        fs.copyFileSync(backupPath, configPath);
        fs.unlinkSync(backupPath);
      } else {
        fs.unlinkSync(configPath);
      }
      throw new Error(`WAF configuration validation failed: ${err.message}. Changes rolled back.`);
    }
  }

  // 4. Record audit log
  securityStore.recordAuditLog({
    actorType: "admin",
    actorName: user,
    action: "UPDATE_WAF_CONFIG",
    target: targetKey,
    details: { enabled, mode, exclusions },
    result: "SUCCESS",
  });

  return await getWafConfig(isGlobal ? null : domain);
}

module.exports = {
  getWafConfig,
  updateWafConfig,
  generateDomainSnippet,
};
