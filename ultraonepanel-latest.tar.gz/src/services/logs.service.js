const fs = require("fs");
const path = require("path");
const shell = require("./shell.service");
const platform = require("../lib/platform");
const validate = require("../lib/validate");
const websites = require("./website.service");
const stats = require("./stats.service");

/**
 * Log sources the panel can show. Per-site logs take a domain.
 */
function sources() {
  const nginxError = platform.IS_AAPANEL ? "/www/wwwlogs/nginx_error.log" : "/var/log/nginx/error.log";
  return {
    "nginx-error": { label: "Nginx error log", file: nginxError },
    "panel-audit": { label: "Panel command audit", file: "/var/log/facezila/commands.log" },
    "auth": { label: "SSH / auth log", file: "/var/log/auth.log" },
    "mail": { label: "Mail log", file: "/var/log/mail.log" },
    "site-access": { label: "Website access log", perSite: true },
    "site-error": { label: "Website error log", perSite: true },
    "nginx-access": { label: "Nginx access log", perSite: true },
  };
}

async function listSources() {
  return Object.entries(sources()).map(([id, s]) => ({
    id,
    label: s.label,
    perSite: !!s.perSite,
    available: s.perSite ? true : shell.IS_LINUX && fs.existsSync(s.file),
  }));
}

async function tail({ source, domain, lines = 200 }) {
  const s = sources()[source];
  if (!s) throw validate.badRequest("Unknown log source: " + source);
  let file = s.file;
  if (s.perSite) {
    domain = validate.domain(domain);
    file = source === "site-error" ? platform.errorLog(domain) : platform.accessLog(domain);
  }
  const n = Math.max(10, Math.min(2000, Number(lines) || 200));
  if (!shell.IS_LINUX || !fs.existsSync(file)) return { source, file, lines: [] };
  const out = await shell.tryGet("tail -n " + n + " " + shell.q(file), "");
  return { source, file, lines: out ? out.split("\n") : [] };
}

/**
 * Parse structured web visitors from access log
 */
async function getVisitors({ domain, limit = 100 }) {
  const allSites = await websites.listWebsites();
  const d = domain || (allSites[0] && allSites[0].domain) || "sunvexaenergy.in";
  const file = platform.accessLog(d);

  if (!shell.IS_LINUX || !fs.existsSync(file)) {
    return {
      domain: d,
      file,
      totalVisits: 0,
      uniqueIps: 0,
      statusCounts: {},
      topUrls: [],
      visitors: [],
    };
  }

  const n = Math.max(20, Math.min(1000, Number(limit) || 200));
  const out = await shell.tryGet("tail -n " + n + " " + shell.q(file), "");
  const lines = out ? out.split("\n").filter(Boolean) : [];

  const visitors = [];
  const statusCounts = {};
  const urlCounts = {};
  const ipSet = new Set();

  const LOG_RE = /^(\S+)\s+\S+\s+(\S+)\s+\[([^\]]+)\]\s+"([A-Z]+)\s+([^"\s]+)(?:\s+HTTP\/[0-9.]+)?\"\s+(\d{3})\s+(\d+|-)\s+"([^"]*)"\s+"([^"]*)"/;

  for (let i = lines.length - 1; i >= 0; i--) {
    const line = lines[i].trim();
    if (!line) continue;
    const m = line.match(LOG_RE);
    if (m) {
      const ip = m[1];
      const time = m[3];
      const method = m[4];
      const url = m[5];
      const statusCode = Number(m[6]);
      const bytes = m[7] === "-" ? 0 : Number(m[7]);
      const referer = m[8] === "-" ? "" : m[8];
      const userAgent = m[9] === "-" ? "" : m[9];

      ipSet.add(ip);
      statusCounts[statusCode] = (statusCounts[statusCode] || 0) + 1;
      urlCounts[url] = (urlCounts[url] || 0) + 1;

      visitors.push({
        ip,
        time,
        method,
        url,
        status: statusCode,
        bytes,
        referer,
        userAgent,
      });
    } else {
      // Fallback simple line parsing
      const parts = line.split(" ");
      const ip = parts[0] || "127.0.0.1";
      ipSet.add(ip);
      visitors.push({
        ip,
        time: new Date().toISOString().slice(11, 19),
        method: "GET",
        url: "/",
        status: 200,
        bytes: 0,
        referer: "",
        userAgent: line.slice(0, 80),
      });
    }
  }

  const topUrls = Object.entries(urlCounts)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5)
    .map(([url, count]) => ({ url, count }));

  return {
    domain: d,
    file,
    totalVisits: visitors.length,
    uniqueIps: ipSet.size,
    statusCounts,
    topUrls,
    visitors: visitors.slice(0, Number(limit) || 100),
  };
}

/**
 * Parse structured web server and site errors
 */
async function getErrors({ domain, limit = 100 }) {
  let file = sources()["nginx-error"].file;
  if (domain && domain !== "all") {
    file = platform.errorLog(domain);
  }

  if (!shell.IS_LINUX || !fs.existsSync(file)) {
    return { domain: domain || "all", file, errors: [] };
  }

  const n = Math.max(20, Math.min(1000, Number(limit) || 200));
  const out = await shell.tryGet("tail -n " + n + " " + shell.q(file), "");
  const lines = out ? out.split("\n").filter(Boolean) : [];

  const errors = [];
  const ERR_RE = /^(\d{4}\/\d{2}\/\d{2}\s+\d{2}:\d{2}:\d{2})\s+\[(\w+)\]\s+(?:(\d+)#\d+:\s+)?(?:\*\d+\s+)?(.*)$/;

  for (let i = lines.length - 1; i >= 0; i--) {
    const line = lines[i].trim();
    if (!line) continue;
    const m = line.match(ERR_RE);
    if (m) {
      const timestamp = m[1];
      const level = m[2];
      const pid = m[3] || "";
      const rawMsg = m[4];

      const clientMatch = rawMsg.match(/client:\s+([^,\s]+)/);
      const reqMatch = rawMsg.match(/request:\s+"([^"]+)"/);

      errors.push({
        timestamp,
        level,
        pid,
        message: rawMsg.replace(/,\s+client:.*$/, "").replace(/,\s+server:.*$/, ""),
        client: clientMatch ? clientMatch[1] : "",
        request: reqMatch ? reqMatch[1] : "",
      });
    } else {
      errors.push({
        timestamp: new Date().toISOString().slice(0, 19).replace("T", " "),
        level: "error",
        pid: "",
        message: line,
        client: "",
        request: "",
      });
    }
  }

  return {
    domain: domain || "all",
    file,
    totalErrors: errors.length,
    errors: errors.slice(0, Number(limit) || 100),
  };
}

/**
 * List raw logs available for download / inspection
 */
async function getRawLogs({ domain }) {
  const allSites = await websites.listWebsites();
  const rawList = [];

  for (const site of allSites) {
    const acc = platform.accessLog(site.domain);
    const err = platform.errorLog(site.domain);

    const accStat = shell.IS_LINUX && fs.existsSync(acc) ? fs.statSync(acc) : null;
    const errStat = shell.IS_LINUX && fs.existsSync(err) ? fs.statSync(err) : null;

    rawList.push({
      domain: site.domain,
      accessLog: {
        file: acc,
        exists: !!accStat,
        sizeBytes: accStat ? accStat.size : 0,
        mtime: accStat ? accStat.mtime.toISOString().slice(0, 19).replace("T", " ") : "",
      },
      errorLog: {
        file: err,
        exists: !!errStat,
        sizeBytes: errStat ? errStat.size : 0,
        mtime: errStat ? errStat.mtime.toISOString().slice(0, 19).replace("T", " ") : "",
      },
    });
  }

  return { logs: rawList };
}

/**
 * Bandwidth usage summary per site
 */
async function getBandwidthStats() {
  const raw = await getRawLogs({});
  const siteBandwidth = raw.logs.map((item) => {
    return {
      domain: item.domain,
      bytes: item.accessLog.sizeBytes,
      humanSize: formatBytes(item.accessLog.sizeBytes),
      mtime: item.accessLog.mtime,
    };
  }).sort((a, b) => b.bytes - a.bytes);

  const totalBytes = siteBandwidth.reduce((sum, s) => sum + s.bytes, 0);

  return {
    totalBytes,
    humanTotal: formatBytes(totalBytes),
    sites: siteBandwidth,
  };
}

/**
 * CPU, connection pool, and concurrent usage metrics
 */
async function getUsageStats() {
  let activeConn = 0;
  if (shell.IS_LINUX) {
    const ssOut = await shell.tryGet("ss -t state established 2>/dev/null | wc -l", "1");
    activeConn = Math.max(0, Number(ssOut.trim()) - 1);
  }

  const [serverStats, procList] = await Promise.all([
    stats.getStats(),
    stats.getProcesses(10),
  ]);

  return {
    activeConnections: activeConn,
    cpu: serverStats.cpu,
    memory: serverStats.memory,
    uptime: serverStats.uptime,
    processes: Array.isArray(procList) ? procList : (procList.processes || []),
  };
}

function formatBytes(bytes) {
  if (bytes < 1024) return bytes + " B";
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + " KB";
  if (bytes < 1024 * 1024 * 1024) return (bytes / (1024 * 1024)).toFixed(1) + " MB";
  return (bytes / (1024 * 1024 * 1024)).toFixed(2) + " GB";
}

module.exports = {
  sources,
  listSources,
  tail,
  getVisitors,
  getErrors,
  getRawLogs,
  getBandwidthStats,
  getUsageStats,
};
