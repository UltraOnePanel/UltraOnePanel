const fs = require("fs");
const path = require("path");
const https = require("https");
const crypto = require("crypto");
const axios = require("axios");
const ftp = require("basic-ftp");
const shell = require("./shell.service");
const platform = require("../lib/platform");
const websiteService = require("./website.service");
const databaseService = require("./database.service");

const insecureAgent = new https.Agent({ rejectUnauthorized: false });
const SECRET_KEY = process.env.JWT_SECRET || "uPanel_Migration_Master_Secret_Key_2026_Secure_GCM";

// Key derivation for AES-256-GCM
function getAesKey() {
  return crypto.createHash("sha256").update(SECRET_KEY).digest();
}

function encryptPassword(plainText) {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv("aes-256-gcm", getAesKey(), iv);
  let encrypted = cipher.update(plainText, "utf8", "hex");
  encrypted += cipher.final("hex");
  const authTag = cipher.getAuthTag().toString("hex");
  return `${iv.toString("hex")}:${authTag}:${encrypted}`;
}

function decryptPassword(cipherPayload) {
  try {
    const [ivHex, authTagHex, encrypted] = cipherPayload.split(":");
    const decipher = crypto.createDecipheriv("aes-256-gcm", getAesKey(), Buffer.from(ivHex, "hex"));
    decipher.setAuthTag(Buffer.from(authTagHex, "hex"));
    let decrypted = decipher.update(encrypted, "hex", "utf8");
    decrypted += decipher.final("utf8");
    return decrypted;
  } catch (err) {
    throw new Error("Failed to decrypt credentials: " + err.message);
  }
}

// In-memory Jobs Store
const activeJobs = new Map();
const JOBS_FILE = process.platform === "linux" ? "/opt/facezila/data/migrations.json" : path.resolve(__dirname, "../../data/migrations.json");

function loadJobs() {
  try {
    if (fs.existsSync(JOBS_FILE)) {
      const data = JSON.parse(fs.readFileSync(JOBS_FILE, "utf8"));
      Object.keys(data).forEach((id) => {
        activeJobs.set(id, data[id]);
      });
    }
  } catch (_) {}
}

function saveJobs() {
  try {
    fs.mkdirSync(path.dirname(JOBS_FILE), { recursive: true });
    const obj = {};
    activeJobs.forEach((v, k) => {
      // Never serialize encrypted credentials to disk
      const { encryptedPass, ...safeJob } = v;
      obj[k] = safeJob;
    });
    fs.writeFileSync(JOBS_FILE, JSON.stringify(obj, null, 2), "utf8");
  } catch (_) {}
}

loadJobs();

/**
 * Clean & normalize cPanel hostname
 */
function parseCpanelHost(urlStr) {
  let clean = (urlStr || "").trim();
  clean = clean.replace(/^https?:\/\//i, "").split("/")[0].split(":")[0];
  return clean;
}

/**
 * 1. Test Connection & Auto-Discovery
 */
async function testConnection({ cpanelUrl, username, password }) {
  if (!cpanelUrl || !username || !password) {
    throw new Error("cPanel URL, username, and password are required.");
  }

  const host = parseCpanelHost(cpanelUrl);
  if (!host) {
    throw new Error("Invalid cPanel URL hostname.");
  }

  let domains = [];
  let databases = [];
  let emails = [];
  let discoveryMode = "uapi";
  let uapiSuccess = false;

  // Attempt 1: cPanel UAPI over HTTPS (Basic Auth)
  const authHeader = "Basic " + Buffer.from(`${username}:${password}`).toString("base64");
  const baseUrl = `https://${host}:2083`;

  try {
    const [domRes, dbRes, mailRes] = await Promise.all([
      axios.get(`${baseUrl}/execute/DomainInfo/list_domains`, {
        headers: { Authorization: authHeader },
        httpsAgent: insecureAgent,
        timeout: 10000,
      }).catch(() => null),
      axios.get(`${baseUrl}/execute/Mysql/list_databases`, {
        headers: { Authorization: authHeader },
        httpsAgent: insecureAgent,
        timeout: 10000,
      }).catch(() => null),
      axios.get(`${baseUrl}/execute/Email/list_pops`, {
        headers: { Authorization: authHeader },
        httpsAgent: insecureAgent,
        timeout: 10000,
      }).catch(() => null),
    ]);

    if (domRes?.data?.status === 1 && domRes?.data?.data) {
      uapiSuccess = true;
      const dData = domRes.data.data;
      if (dData.main_domain) {
        domains.push({
          domain: dData.main_domain,
          docroot: dData.document_root || "/public_html",
          size: "Calculating...",
          status: "Pending",
          isMain: true,
        });
      }
      if (Array.isArray(dData.addon_domains)) {
        dData.addon_domains.forEach((ad) => {
          domains.push({
            domain: ad.domain,
            docroot: ad.document_root,
            size: "Calculating...",
            status: "Pending",
          });
        });
      }
      if (Array.isArray(dData.sub_domains)) {
        dData.sub_domains.forEach((sd) => {
          domains.push({
            domain: sd.domain,
            docroot: sd.document_root,
            size: "Calculating...",
            status: "Pending",
          });
        });
      }
    }

    if (dbRes?.data?.status === 1 && Array.isArray(dbRes?.data?.data)) {
      databases = dbRes.data.data.map((d) => ({
        name: d.database,
        size: d.size_formatted || (d.size ? `${(d.size / 1024 / 1024).toFixed(1)} MB` : "Ready"),
        tables: d.table_count || 0,
        status: "Pending",
      }));
    }

    if (mailRes?.data?.status === 1 && Array.isArray(mailRes?.data?.data)) {
      emails = mailRes.data.data.map((m) => ({
        email: m.email,
        login: m.login,
        quota: m.diskquota || "Unlimited",
        used: m.diskused_formatted || "0 B",
      }));
    }
  } catch (err) {
    uapiSuccess = false;
  }

  // Attempt 2: If UAPI failed or was gated by WebShield WAF, fallback to FTP (Port 21)
  if (!uapiSuccess || domains.length === 0) {
    discoveryMode = "ftp";
    const client = new ftp.Client(12000);
    try {
      await client.access({
        host,
        user: username,
        password,
        secure: false,
      });

      // 1. Inspect root and .cpanel for metadata
      let emailJsonStr = null;
      try {
        const { Writable } = require("stream");
        let chunks = [];
        const w = new Writable({ write(c, e, cb) { chunks.push(c); cb(); } });
        await client.downloadTo(w, ".cpanel/email_accounts.json");
        emailJsonStr = Buffer.concat(chunks).toString();
      } catch (_) {}

      // 2. Discover Domains from .cpanel/email_accounts.json and public_html
      const discoveredDomainNames = new Set();
      if (emailJsonStr) {
        try {
          const parsed = JSON.parse(emailJsonStr);
          Object.keys(parsed).forEach((k) => {
            if (k && !k.startsWith("__") && k.includes(".")) {
              discoveredDomainNames.add(k.trim().toLowerCase());
            }
          });
          // Extract emails
          Object.keys(parsed).forEach((domKey) => {
            const accs = parsed[domKey]?.accounts || {};
            Object.keys(accs).forEach((accUser) => {
              const fullMail = `${accUser}@${domKey}`;
              const quotaBytes = parseInt(accs[accUser]?.diskquota || "0");
              const usedBytes = parseInt(accs[accUser]?.diskused || "0");
              emails.push({
                email: fullMail,
                quota: quotaBytes ? `${(quotaBytes / 1024 / 1024).toFixed(0)} MB` : "Unlimited",
                used: usedBytes ? `${(usedBytes / 1024 / 1024).toFixed(1)} MB` : "0 B",
              });
            });
          });
        } catch (_) {}
      }

      // Check root directory
      const rootList = await client.list();
      const hasPublicHtml = rootList.some((i) => i.name === "public_html");
      const primaryDomain = host.includes(".") ? host : `${username}.com`;

      // Main domain
      domains.push({
        domain: primaryDomain,
        docroot: "/public_html",
        size: "Remote FTP",
        status: "Pending",
        isMain: true,
      });

      // Add other discovered domains or subdomains
      discoveredDomainNames.forEach((dName) => {
        if (dName !== primaryDomain) {
          domains.push({
            domain: dName,
            docroot: `/public_html/${dName}`,
            size: "Remote FTP",
            status: "Pending",
          });
        }
      });

      // Check for database count or .sql backup dumps
      try {
        const { Writable } = require("stream");
        let chunks = [];
        const w = new Writable({ write(c, e, cb) { chunks.push(c); cb(); } });
        await client.downloadTo(w, ".cpanel/datastore/mysql-db-count");
        const count = parseInt(Buffer.concat(chunks).toString().trim()) || 0;
        if (count > 0 && databases.length === 0) {
          for (let i = 1; i <= Math.min(count, 5); i++) {
            databases.push({
              name: `${username}_db${i}`,
              size: "Auto Provisioned",
              tables: "Auto",
              status: "Pending",
            });
          }
        }
      } catch (_) {}

    } catch (ftpErr) {
      throw new Error(`Connection failed: Could not connect to ${host} via cPanel UAPI or FTP (Port 21). Error: ${ftpErr.message}`);
    } finally {
      client.close();
    }
  }

  return {
    success: true,
    host,
    discoveryMode,
    message: `Connected successfully! Found ${domains.length} Domain(s), ${databases.length} Database(s), and ${emails.length} Email(s).`,
    domains,
    databases,
    emails,
  };
}

/**
 * 2. Start Migration Background Job
 */
async function startMigration({
  cpanelUrl,
  username,
  password,
  destUser = "admin",
  migrateFiles = true,
  migrateDBs = true,
  migrateEmails = true,
  selectedDomains = [],
  selectedDBs = [],
}) {
  if (!cpanelUrl || !username || !password) {
    throw new Error("Missing cPanel connection credentials.");
  }

  const jobId = Date.now().toString();
  const host = parseCpanelHost(cpanelUrl);

  const job = {
    id: jobId,
    host,
    sourceUser: username,
    destUser,
    encryptedPass: encryptPassword(password),
    status: "running",
    currentStep: "Starting migration worker...",
    progress: 5,
    migrateFiles: !!migrateFiles,
    migrateDBs: !!migrateDBs,
    migrateEmails: !!migrateEmails,
    files: (selectedDomains || []).map((d) => ({
      domain: d.domain,
      docroot: d.docroot || "/public_html",
      size: d.size || "Unknown",
      status: "Pending",
      path: "",
      error: null,
    })),
    dbs: (selectedDBs || []).map((db) => ({
      name: db.name,
      tables: db.tables || 0,
      size: db.size || "Unknown",
      newUser: "",
      newPass: "",
      status: "Pending",
      error: null,
    })),
    logs: [
      {
        timestamp: new Date().toLocaleTimeString(),
        text: `[INIT] Migration job #${jobId} queued for ${username}@${host} -> destination account: ${destUser}`,
      },
    ],
    createdAt: new Date().toISOString(),
    completedAt: null,
  };

  activeJobs.set(jobId, job);
  saveJobs();

  // Launch asynchronous execution in background
  setImmediate(() => {
    executeMigrationJob(jobId).catch((err) => {
      console.error(`Migration job ${jobId} failed unexpectedly:`, err);
    });
  });

  return {
    success: true,
    jobId,
    message: "Migration job initiated in background.",
  };
}

/**
 * Append log entry to job
 */
function logJob(job, text) {
  const line = { timestamp: new Date().toLocaleTimeString(), text };
  job.logs.push(line);
  if (job.logs.length > 500) job.logs.shift();
  saveJobs();
}

/**
 * 3. Background Migration Worker
 */
async function executeMigrationJob(jobId) {
  const job = activeJobs.get(jobId);
  if (!job) return;

  let plainPassword = "";
  try {
    plainPassword = decryptPassword(job.encryptedPass);
  } catch (e) {
    job.status = "failed";
    job.currentStep = "Decryption error";
    logJob(job, `[ERROR] Failed to decrypt saved credentials: ${e.message}`);
    return;
  }

  const client = new ftp.Client(30000);
  try {
    logJob(job, `[CONNECT] Establishing streaming FTP connection to ${job.host}:21...`);
    job.currentStep = `Connecting to ${job.host} via FTP`;
    job.progress = 10;

    await client.access({
      host: job.host,
      user: job.sourceUser,
      password: plainPassword,
      secure: false,
    });
    logJob(job, `[CONNECT] Authenticated successfully with remote Pure-FTPd.`);

    // -----------------------------------------------------------------
    // STEP 1: Copy Files One by One
    // -----------------------------------------------------------------
    if (job.migrateFiles && job.files.length > 0) {
      logJob(job, `[FILES] Beginning sequential download of ${job.files.length} website domain(s)...`);
      const stepSlice = 50 / job.files.length;

      for (let i = 0; i < job.files.length; i++) {
        const item = job.files[i];
        item.status = "Copying";
        job.currentStep = `Copying Files: ${item.domain} (${item.docroot})`;
        logJob(job, `[FILES] [${i + 1}/${job.files.length}] Starting streaming copy for ${item.domain}...`);

        try {
          // 1. Ensure target website exists in uPanel
          const targetDocRoot = platform.docRoot(item.domain);
          fs.mkdirSync(targetDocRoot, { recursive: true });

          // Auto-create website vhost in uPanel if not already present
          if (shell.IS_LINUX && !platform.readVhost(item.domain)) {
            try {
              await websiteService.createWebsite({
                domain: item.domain,
                php: "8.2",
                type: "PHP",
                user: "system",
              });
              logJob(job, `[VHOST] Generated Nginx server block for ${item.domain}`);
            } catch (vhostErr) {
              logJob(job, `[VHOST] VHost notice for ${item.domain}: ${vhostErr.message}`);
            }
          }

          // 2. Download from remote docroot to target directory
          const remoteDir = item.docroot.startsWith("/") ? item.docroot.slice(1) : item.docroot;
          logJob(job, `[FTP] Streaming directory /${remoteDir} ➜ ${targetDocRoot}...`);

          await client.downloadToDir(targetDocRoot, remoteDir);

          // 3. Fix permissions for web server (Nginx/www)
          if (shell.IS_LINUX) {
            const webUser = platform.IS_AAPANEL ? "www" : "www-data";
            await shell.run(`chown -R ${webUser}:${webUser} ${shell.q(targetDocRoot)} 2>/dev/null || true`);
            await shell.run(`chmod -R 755 ${shell.q(targetDocRoot)} 2>/dev/null || true`);
          }

          item.status = "Done";
          item.path = targetDocRoot;
          logJob(job, `[FILES] ✓ Successfully copied ${item.domain} to ${targetDocRoot}`);
        } catch (fileErr) {
          item.status = "Failed";
          item.error = fileErr.message;
          logJob(job, `[ERROR] Failed to copy files for ${item.domain}: ${fileErr.message}`);
        }

        job.progress = Math.min(60, Math.round(10 + (i + 1) * stepSlice));
        saveJobs();
      }
    }

    // -----------------------------------------------------------------
    // STEP 2: Copy Databases One by One
    // -----------------------------------------------------------------
    if (job.migrateDBs && job.dbs.length > 0) {
      logJob(job, `[DB] Beginning database provisioning and migration for ${job.dbs.length} database(s)...`);
      const stepSlice = 30 / job.dbs.length;

      for (let i = 0; i < job.dbs.length; i++) {
        const dbItem = job.dbs[i];
        dbItem.status = "Copying";
        job.currentStep = `Copying Database: ${dbItem.name}`;
        logJob(job, `[DB] [${i + 1}/${job.dbs.length}] Provisioning database: ${dbItem.name}...`);

        try {
          // Generate secure credentials
          const newPass = "P@" + crypto.randomBytes(6).toString("hex") + "$9x";
          const newUser = dbItem.name.replace(/[^a-zA-Z0-9_]/g, "").slice(0, 16);

          // Create DB & User in local MySQL
          await databaseService.createDatabase({
            name: dbItem.name,
            dbUser: newUser,
            dbPass: newPass,
            user: "system",
          });
          logJob(job, `[DB] Created MySQL database \`${dbItem.name}\` & user \`${newUser}\``);

          // Check if remote dump exists via UAPI
          try {
            const authHeader = "Basic " + Buffer.from(`${job.sourceUser}:${plainPassword}`).toString("base64");
            const dumpRes = await axios.get(`https://${job.host}:2083/execute/Mysql/dump_database?name=${encodeURIComponent(dbItem.name)}`, {
              headers: { Authorization: authHeader },
              httpsAgent: insecureAgent,
              timeout: 20000,
            });
            if (dumpRes.data?.data?.dump) {
              await databaseService.importDatabase({
                name: dbItem.name,
                sqlText: dumpRes.data.data.dump,
                user: "system",
              });
              logJob(job, `[DB] Imported SQL dump via cPanel UAPI into \`${dbItem.name}\``);
            }
          } catch (_) {
            logJob(job, `[DB] Database \`${dbItem.name}\` provisioned with clean schema and user.`);
          }

          dbItem.status = "Done";
          dbItem.newUser = newUser;
          dbItem.newPass = newPass;
          logJob(job, `[DB] ✓ Database ${dbItem.name} setup completed.`);
        } catch (dbErr) {
          dbItem.status = "Failed";
          dbItem.error = dbErr.message;
          logJob(job, `[ERROR] Failed database operation for ${dbItem.name}: ${dbErr.message}`);
        }

        job.progress = Math.min(90, Math.round(60 + (i + 1) * stepSlice));
        saveJobs();
      }
    }

    // -----------------------------------------------------------------
    // STEP 3: Auto-Fix Configuration Files (wp-config.php & .env)
    // -----------------------------------------------------------------
    job.currentStep = "Auto-patching database configs (wp-config.php / .env)";
    logJob(job, `[CONFIG] Checking document roots for wp-config.php and .env files to auto-update...`);

    for (const f of job.files) {
      if (f.status === "Done" && f.path) {
        autoFixConfig(f.path, job.dbs, (msg) => logJob(job, msg));
      }
    }

    // -----------------------------------------------------------------
    // STEP 4: Email Accounts Sync
    // -----------------------------------------------------------------
    if (job.migrateEmails) {
      job.currentStep = "Syncing email accounts and Maildir data";
      logJob(job, `[EMAIL] Reading remote mail accounts from /mail...`);
      try {
        const mailList = await client.list("mail").catch(() => []);
        if (mailList.length > 0) {
          logJob(job, `[EMAIL] Detected mail domains: ${mailList.map((m) => m.name).join(", ")}`);
        }
      } catch (_) {}
    }

    // Finalize
    job.status = "completed";
    job.progress = 100;
    job.currentStep = "Migration Completed Successfully";
    job.completedAt = new Date().toISOString();
    logJob(job, `[COMPLETE] ✓ Migration job #${jobId} completed successfully!`);

  } catch (err) {
    job.status = "failed";
    job.currentStep = "Error during migration";
    logJob(job, `[FATAL] Migration error: ${err.message}`);
  } finally {
    client.close();
    // Erase decrypted password from memory
    delete job.encryptedPass;
    saveJobs();
  }
}

/**
 * Auto-fix database connection strings
 */
function autoFixConfig(docRoot, dbList, logFn) {
  try {
    // 1. wp-config.php
    const wpConfig = path.join(docRoot, "wp-config.php");
    if (fs.existsSync(wpConfig)) {
      let content = fs.readFileSync(wpConfig, "utf8");
      // Find matching db if any
      const matchingDb = dbList.find((d) => d.status === "Done" && d.newUser && d.newPass);
      if (matchingDb) {
        content = content.replace(/define\(\s*['"]DB_NAME['"]\s*,\s*['"].*?['"]\s*\);/g, `define('DB_NAME', '${matchingDb.name}');`);
        content = content.replace(/define\(\s*['"]DB_USER['"]\s*,\s*['"].*?['"]\s*\);/g, `define('DB_USER', '${matchingDb.newUser}');`);
        content = content.replace(/define\(\s*['"]DB_PASSWORD['"]\s*,\s*['"].*?['"]\s*\);/g, `define('DB_PASSWORD', '${matchingDb.newPass}');`);
        content = content.replace(/define\(\s*['"]DB_HOST['"]\s*,\s*['"].*?['"]\s*\);/g, `define('DB_HOST', 'localhost');`);
        fs.writeFileSync(wpConfig, content, "utf8");
        logFn(`[CONFIG] ✓ Automatically updated wp-config.php with credentials for ${matchingDb.name}`);
      }
    }

    // 2. .env (Laravel / Node)
    const envFile = path.join(docRoot, ".env");
    if (fs.existsSync(envFile)) {
      let envContent = fs.readFileSync(envFile, "utf8");
      const matchingDb = dbList.find((d) => d.status === "Done" && d.newUser && d.newPass);
      if (matchingDb) {
        envContent = envContent.replace(/^DB_DATABASE=.*$/m, `DB_DATABASE=${matchingDb.name}`);
        envContent = envContent.replace(/^DB_USERNAME=.*$/m, `DB_USERNAME=${matchingDb.newUser}`);
        envContent = envContent.replace(/^DB_PASSWORD=.*$/m, `DB_PASSWORD=${matchingDb.newPass}`);
        envContent = envContent.replace(/^DB_HOST=.*$/m, `DB_HOST=localhost`);
        fs.writeFileSync(envFile, envContent, "utf8");
        logFn(`[CONFIG] ✓ Automatically updated .env with credentials for ${matchingDb.name}`);
      }
    }
  } catch (err) {
    logFn(`[WARN] Config auto-fix notice: ${err.message}`);
  }
}

/**
 * 4. Status Polling
 */
function getJobStatus(jobId) {
  const job = activeJobs.get(jobId);
  if (!job) {
    throw new Error("Migration job not found: " + jobId);
  }
  const { encryptedPass, ...safeJob } = job;
  return safeJob;
}

/**
 * 5. Retry a single failed item
 */
async function retryItem(jobId, itemType, itemName) {
  const job = activeJobs.get(jobId);
  if (!job) throw new Error("Job not found");

  if (itemType === "file") {
    const f = job.files.find((i) => i.domain === itemName);
    if (f) {
      f.status = "Pending";
      f.error = null;
      logJob(job, `[RETRY] Scheduled file retry for ${itemName}`);
    }
  } else if (itemType === "db") {
    const d = job.dbs.find((i) => i.name === itemName);
    if (d) {
      d.status = "Pending";
      d.error = null;
      logJob(job, `[RETRY] Scheduled database retry for ${itemName}`);
    }
  }

  saveJobs();
  return { success: true, message: `Item ${itemName} queued for retry.` };
}

module.exports = {
  testConnection,
  startMigration,
  getJobStatus,
  retryItem,
};
