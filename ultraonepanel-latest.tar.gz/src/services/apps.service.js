const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const shell = require("./shell.service");
const platform = require("../lib/platform");
const validate = require("../lib/validate");
const websites = require("./website.service");
const databases = require("./database.service");

const CACHE = shell.IS_LINUX ? "/var/cache/facezila" : path.resolve(__dirname, "../../data/cache");
const PMA_VERSION = "5.2.1";
const WEB_USER = platform.IS_AAPANEL ? "www" : "www-data";

function randomString(len, alphabet = "abcdefghijkmnopqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789") {
  const bytes = crypto.randomBytes(len);
  return Array.from(bytes, (b) => alphabet[b % alphabet.length]).join("");
}

function catalog() {
  const composer = shell.hasCommand("composer");
  return [
    { id: "wordpress", name: "WordPress", available: true },
    { id: "phpmyadmin", name: "phpMyAdmin", available: true },
    { id: "laravel", name: "Laravel", available: !shell.IS_LINUX || composer, reason: composer ? null : "Composer is not installed on this server." },
    { id: "nodejs", name: "Node.js Application", available: !shell.IS_LINUX || shell.HAS_SYSTEMD, reason: shell.HAS_SYSTEMD ? null : "Needs systemd to keep the app running." },
    { id: "nextjs", name: "Next.js Standalone", available: false, reason: "Coming soon" },
    { id: "ghost", name: "Ghost CMS", available: false, reason: "Coming soon" },
  ];
}

/** Download a file once per day into the cache directory. */
async function fetchCached(url, name, user) {
  fs.mkdirSync(CACHE, { recursive: true });
  const file = path.join(CACHE, name);
  const fresh = fs.existsSync(file) && Date.now() - fs.statSync(file).mtimeMs < 86400000 && fs.statSync(file).size > 0;
  if (!fresh) await shell.run("curl -fsSL --retry 2 -o " + shell.q(file) + " " + shell.q(url), { timeout: 300000, user });
  return file;
}

/** Document root of a site, refusing to overwrite an existing application. */
async function prepareRoot(domain, marker) {
  const site = await websites.getWebsite(domain);
  if (!site) throw validate.badRequest("Website not found: " + domain);
  if (site.redirect) throw validate.badRequest("Apps cannot be installed on a redirect.");
  const root = platform.docRoot(domain);
  if (marker && fs.existsSync(path.join(root, marker))) throw validate.badRequest("An application is already installed on " + domain + ".");
  const leftovers = fs.existsSync(root)
    ? fs.readdirSync(root).filter((f) => ![".well-known", ".user.ini", "index.html", ".htaccess", "404.html"].includes(f))
    : [];
  return { site, root, leftovers };
}

async function chownRoot(root, user) {
  await shell.run("chown -R " + WEB_USER + ":" + WEB_USER + " " + shell.q(root), { user }).catch(() => {});
}

async function installWordPress({ domain, user }) {
  const { site, root, leftovers } = await prepareRoot(domain, "wp-config.php");
  if (leftovers.length) throw validate.badRequest("The document root of " + domain + " is not empty (" + leftovers.slice(0, 3).join(", ") + "). Remove those files first.");
  if (!/^\d\.\d$/.test(site.php)) throw validate.badRequest("WordPress needs a PHP site.");

  const slug = domain.replace(/[^a-z0-9]/g, "_").slice(0, 20);
  const dbName = "wp_" + slug + "_" + randomString(4, "abcdefghijklmnopqrstuvwxyz0123456789");
  const dbUser = "wp_" + slug.slice(0, 16) + "_" + randomString(4, "abcdefghijklmnopqrstuvwxyz0123456789");
  const dbPass = randomString(24);

  const tarball = await fetchCached("https://wordpress.org/latest.tar.gz", "wordpress-latest.tar.gz", user);
  const tmp = path.join(CACHE, "wp-" + randomString(6));
  fs.mkdirSync(tmp, { recursive: true });
  try {
    await shell.run("tar -xzf " + shell.q(tarball) + " -C " + shell.q(tmp), { timeout: 120000, user });
    fs.rmSync(path.join(root, "index.html"), { force: true });
    await shell.run("cp -a " + shell.q(path.join(tmp, "wordpress") + "/.") + " " + shell.q(root), { user });
  } finally {
    fs.rmSync(tmp, { recursive: true, force: true });
  }

  await databases.createDatabase({ name: dbName, dbUser, dbPass, user });

  const salt = () => crypto.randomBytes(48).toString("base64");
  const config = fs.readFileSync(path.join(root, "wp-config-sample.php"), "utf8")
    .replace("database_name_here", dbName)
    .replace("username_here", dbUser)
    .replace("password_here", dbPass)
    .replace(/'put your unique phrase here'/g, () => "'" + salt() + "'");
  fs.writeFileSync(path.join(root, "wp-config.php"), config, { mode: 0o640 });
  await chownRoot(root, user);

  websites.setMeta(domain, { type: "WordPress", databases: [dbName] });
  return {
    app: "WordPress",
    domain,
    database: dbName,
    dbUser,
    dbPass,
    setupUrl: (site.ssl ? "https://" : "http://") + domain + "/wp-admin/install.php",
  };
}

async function installPhpMyAdmin({ domain, user }) {
  const { site, root } = await prepareRoot(domain);
  if (!/^\d\.\d$/.test(site.php)) throw validate.badRequest("phpMyAdmin needs a PHP site.");
  const target = path.join(root, "phpmyadmin");
  if (fs.existsSync(target)) throw validate.badRequest("phpMyAdmin is already installed on " + domain + ".");
  const name = "phpMyAdmin-" + PMA_VERSION + "-all-languages";
  const tarball = await fetchCached("https://files.phpmyadmin.net/phpMyAdmin/" + PMA_VERSION + "/" + name + ".tar.gz", name + ".tar.gz", user);
  await shell.run("tar -xzf " + shell.q(tarball) + " -C " + shell.q(root), { timeout: 120000, user });
  fs.renameSync(path.join(root, name), target);
  fs.writeFileSync(path.join(target, "config.inc.php"),
    "<?php\n$cfg['blowfish_secret'] = '" + randomString(32) + "';\n" +
    "$i = 1;\n$cfg['Servers'][$i]['auth_type'] = 'cookie';\n$cfg['Servers'][$i]['host'] = 'localhost';\n" +
    "$cfg['Servers'][$i]['AllowNoPassword'] = false;\n$cfg['TempDir'] = '/tmp';\n");
  await chownRoot(target, user);
  return { app: "phpMyAdmin", domain, url: (site.ssl ? "https://" : "http://") + domain + "/phpmyadmin/" };
}

async function installLaravel({ domain, user }) {
  if (!shell.hasCommand("composer")) throw Object.assign(new Error("Composer is not installed on this server."), { status: 409 });
  const { root, leftovers } = await prepareRoot(domain, "artisan");
  if (leftovers.length) throw validate.badRequest("The document root of " + domain + " is not empty.");
  if (!websites.isManaged(domain)) throw validate.badRequest("Laravel needs a website created by Facezila (its web root moves to public/).");
  const tmp = path.join(CACHE, "laravel-" + randomString(6));
  try {
    await shell.run("composer create-project --no-interaction --prefer-dist laravel/laravel " + shell.q(tmp),
      { timeout: 900000, user, env: { COMPOSER_ALLOW_SUPERUSER: "1", HOME: "/root" } });
    fs.rmSync(path.join(root, "index.html"), { force: true });
    await shell.run("cp -a " + shell.q(tmp + "/.") + " " + shell.q(root), { user });
  } finally {
    fs.rmSync(tmp, { recursive: true, force: true });
  }
  await chownRoot(root, user);
  await websites.updateManaged({ domain, patch: { publicDir: "public", type: "Laravel" }, user });
  return { app: "Laravel", domain, url: "http://" + domain + "/" };
}

async function freePort(from = 3001) {
  const out = await shell.tryGet("ss -ltnH", "");
  const used = new Set(out.split("\n").map((l) => (l.trim().split(/\s+/)[3] || "").split(":").pop()));
  const taken = new Set(Object.values(require("../lib/store").read("sites", {})).map((m) => String(m.proxyPort)));
  for (let p = from; p < from + 1000; p++) if (!used.has(String(p)) && !taken.has(String(p))) return p;
  throw new Error("No free port available for the Node.js app.");
}

async function installNode({ domain, user }) {
  if (shell.IS_LINUX && !shell.HAS_SYSTEMD) throw Object.assign(new Error("Node.js apps need systemd."), { status: 409 });
  const { root } = await prepareRoot(domain);
  if (!websites.isManaged(domain)) throw validate.badRequest("Node.js apps need a website created by Facezila.");
  const port = await freePort();
  if (!fs.existsSync(path.join(root, "package.json"))) {
    fs.writeFileSync(path.join(root, "package.json"), JSON.stringify({ name: domain.replace(/\./g, "-"), version: "1.0.0", main: "app.js", scripts: { start: "node app.js" } }, null, 2));
    fs.writeFileSync(path.join(root, "app.js"),
      "const http = require(\"http\");\nconst port = process.env.PORT || " + port + ";\n" +
      "http.createServer((req, res) => {\n  res.writeHead(200, { \"Content-Type\": \"text/html\" });\n" +
      "  res.end(\"<h1>" + domain + "</h1><p>Node.js app running on Facezila.</p>\");\n}).listen(port, \"127.0.0.1\");\n");
    fs.rmSync(path.join(root, "index.html"), { force: true });
  }
  const unit = "fz-node-" + domain.replace(/[^a-z0-9]/g, "-");
  shell.writeFile("/etc/systemd/system/" + unit + ".service", [
    "[Unit]", "Description=Node.js app for " + domain + " (Facezila)", "After=network.target", "",
    "[Service]", "Type=simple", "User=" + WEB_USER, "WorkingDirectory=" + root,
    "Environment=NODE_ENV=production", "Environment=PORT=" + port,
    "ExecStart=" + process.execPath + " " + path.join(root, "app.js"), "Restart=always", "RestartSec=3", "",
    "[Install]", "WantedBy=multi-user.target", "",
  ].join("\n"));
  await chownRoot(root, user);
  await shell.run("systemctl daemon-reload && systemctl enable --now " + unit, { user });
  await websites.updateManaged({ domain, patch: { proxyPort: port, type: "Node.js", nodeService: unit }, user });
  return { app: "Node.js", domain, port, service: unit, url: "http://" + domain + "/" };
}

async function install({ app, domain, user }) {
  domain = validate.domain(domain);
  const entry = catalog().find((a) => a.id === app || a.name === app);
  if (!entry) throw validate.badRequest("Unknown application: " + app);
  if (!entry.available) throw Object.assign(new Error(entry.name + ": " + entry.reason), { status: 409 });
  if (!shell.IS_LINUX) return { app: entry.name, domain, status: "installed (dev-skip)" };
  switch (entry.id) {
    case "wordpress": return installWordPress({ domain, user });
    case "phpmyadmin": return installPhpMyAdmin({ domain, user });
    case "laravel": return installLaravel({ domain, user });
    case "nodejs": return installNode({ domain, user });
    default: throw validate.badRequest("Unsupported application.");
  }
}

module.exports = { catalog, install };
