const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const shell = require("./shell.service");
const store = require("../lib/store");
const validate = require("../lib/validate");

const KEY_RE = /^(ssh-(rsa|ed25519|dss)|ecdsa-sha2-nistp(256|384|521)|sk-(ssh-ed25519|ecdsa-sha2-nistp256)@openssh\.com)\s+([A-Za-z0-9+\/]+={0,3})(\s+.*)?$/;

const AUTH_FILE = shell.IS_LINUX
  ? "/root/.ssh/authorized_keys"
  : path.resolve(__dirname, "../../data/authorized_keys");

/** SHA256 fingerprint of the key blob, formatted like ssh-keygen -l. */
function fingerprint(blob) {
  return "SHA256:" + crypto.createHash("sha256").update(Buffer.from(blob, "base64")).digest("base64").replace(/=+$/, "");
}

function readLines() {
  try { return fs.readFileSync(AUTH_FILE, "utf8").split("\n"); } catch (_) { return []; }
}

function writeLines(lines) {
  fs.mkdirSync(path.dirname(AUTH_FILE), { recursive: true, mode: 0o700 });
  fs.writeFileSync(AUTH_FILE, lines.filter((l, i, a) => l !== "" || i < a.length - 1).join("\n").replace(/\n*$/, "\n"), { mode: 0o600 });
}

function parseLine(line) {
  // Options (from="...",command=...) may precede the key type.
  const start = line.search(/(ssh-|ecdsa-|sk-)/);
  if (start < 0) return null;
  const m = line.slice(start).trim().match(KEY_RE);
  if (!m) return null;
  return { type: m[1], blob: m[5], comment: (m[6] || "").trim() };
}

async function listKeys() {
  const names = store.read("sshkeys", {});
  return readLines().map(parseLine).filter(Boolean).map((k) => {
    const id = fingerprint(k.blob);
    return {
      id,
      fingerprint: id,
      name: (names[id] && names[id].name) || k.comment || k.type,
      type: k.type,
      comment: k.comment,
      key: k.type + " " + k.blob + (k.comment ? " " + k.comment : ""),
      added: (names[id] && names[id].added) || "",
    };
  });
}

async function addKey({ name, key }) {
  const raw = String(key || "").trim().replace(/\r?\n/g, " ");
  const parsed = parseLine(raw);
  if (!parsed || /[\r\n]/.test(raw)) throw validate.badRequest("That does not look like an OpenSSH public key (ssh-ed25519 AAAA... user@host).");
  if (Buffer.from(parsed.blob, "base64").length < 32) throw validate.badRequest("The key data is too short.");
  const id = fingerprint(parsed.blob);
  const lines = readLines();
  if (lines.map(parseLine).some((k) => k && fingerprint(k.blob) === id)) throw validate.badRequest("This key is already authorized.");
  writeLines(lines.concat(parsed.type + " " + parsed.blob + (parsed.comment ? " " + parsed.comment : "")));
  const label = String(name || parsed.comment || parsed.type).replace(/[\r\n]/g, " ").slice(0, 80);
  store.update("sshkeys", {}, (n) => { n[id] = { name: label, added: new Date().toISOString().slice(0, 10) }; });
  return { id, name: label, type: parsed.type };
}

async function deleteKey({ id }) {
  const lines = readLines();
  const next = lines.filter((l) => { const k = parseLine(l); return !k || fingerprint(k.blob) !== id; });
  if (next.length === lines.length) throw validate.badRequest("Key not found.");
  writeLines(next);
  store.update("sshkeys", {}, (n) => { delete n[id]; });
  return { id, status: "deleted" };
}

module.exports = { listKeys, addKey, deleteKey, AUTH_FILE };
