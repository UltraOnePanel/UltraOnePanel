const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const shell = require("./shell.service");
const platform = require("../lib/platform");
const store = require("../lib/store");
const validate = require("../lib/validate");
const websites = require("./website.service");
const databases = require("./database.service");

const DIR = platform.paths.backupDir;
const NAME_RE = /^fz-backup_[a-z0-9._-]+\.tar\.gz$/i;

// Archive layout:  manifest.json, files/<domain>.tar, vhosts/<domain>.conf, databases/<db>.sql
function load() {
  return store.read("backups", {});
}

function save(id, patch) {
  store.update("backups", {}, (all) => { all[id] = { ...(all[id] || {}), ...patch }; });
}

function stamp() {
  return new Date().toISOString().replace(/[:T]/g, "-").slice(0, 19);
}

async function freeBytes(dir) {
  const out = await shell.tryGet("df -B1 --output=avail " + shell.q(dir) + " | tail -1", "0");
  return Number(out) || 0;
}

async function listBackups(user) {
  fs.mkdirSync(DIR, { recursive: true });
  const meta = load();
  const files = fs.readdirSync(DIR).filter((f) => NAME_RE.test(f));
  let rows = files.map((filename) => {
    const st = fs.statSync(path.join(DIR, filename));
    const id = Object.keys(meta).find((k) => meta[k].filename === filename) || filename;
    const m = meta[id] || {};
    return {
      id,
      filename,
      size: websites.formatBytes(st.size),
      sizeBytes: st.size,
      type: m.type || "Full Account",
      scope: m.scope || "unknown",
      status: m.status || "completed",
      createdAt: (m.created || st.mtime.toISOString()).replace("T", " ").slice(0, 16),
    };
  });
  // Jobs still running have no final archive yet.
  for (const [id, m] of Object.entries(meta)) {
    if (m.status === "running" || m.status === "failed") {
      if (!rows.some((r) => r.id === id)) {
        rows.push({ id, filename: m.filename, size: "-", sizeBytes: 0, type: m.type, scope: m.scope, status: m.status, error: m.error, createdAt: m.created.replace("T", " ").slice(0, 16) });
      }
    }
  }
  if (user && user.role !== "admin" && user.username !== "root") {
    const un = (user.username || "").toLowerCase().trim();
    const uDomain = (user.domain || "").toLowerCase().trim();
    rows = rows.filter((r) => {
      const fn = (r.filename || "").toLowerCase();
      const scope = (r.scope || "").toLowerCase();
      const m = meta[r.id] || {};
      return fn.includes(un) || (uDomain && (fn.includes(uDomain) || scope.includes(uDomain))) || (m.user && m.user === un);
    });
  }
  return rows.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
}

/**
 * Start a backup job. Returns immediately; the archive is built in the background.
 * type: "Full Account" (files + databases) | "Databases Only" | "Files Only"
 * domain: a single website, or empty for every site.
 */
async function createBackup({ type = "Full Account", domain, databases: dbList, user = "system", wait = false }) {
  const includeFiles = type !== "Databases Only";
  const includeDbs = type !== "Files Only";
  const all = await websites.listWebsites();
  let sites = [];
  if (includeFiles) {
    sites = domain ? all.filter((w) => w.domain === validate.domain(domain)) : all.filter((w) => !w.redirect);
    if (domain && !sites.length) throw validate.badRequest("Website not found: " + domain);
  }

  let dbs = [];
  if (includeDbs) {
    const existing = (await databases.listDatabases()).map((d) => d.name);
    if (dbList && dbList.length) dbs = dbList.filter((d) => existing.includes(d));
    else if (domain) dbs = ((websites.getMeta(domain) || {}).databases || []).filter((d) => existing.includes(d));
    else dbs = existing;
  }

  fs.mkdirSync(DIR, { recursive: true, mode: 0o700 });
  if (shell.IS_LINUX && includeFiles) {
    const needed = sites.reduce((s, w) => s + (w.diskBytes || 0), 0);
    const free = await freeBytes(DIR);
    if (needed > free * 0.8) {
      throw validate.badRequest("Not enough free disk space: the backup needs about " + websites.formatBytes(needed) +
        " but only " + websites.formatBytes(free) + " is free. Back up a single website instead.");
    }
  }

  const id = crypto.randomBytes(6).toString("hex");
  const scope = domain ? validate.domain(domain) : "all";
  const kind = type === "Databases Only" ? "db" : type === "Files Only" ? "files" : "full";
  const filename = "fz-backup_" + scope + "_" + kind + "_" + stamp() + ".tar.gz";
  save(id, { filename, type, scope, status: "running", created: new Date().toISOString(), sites: sites.map((s) => s.domain), databases: dbs });

  const job = runBackup(id, filename, sites, dbs, user)
    .then(() => save(id, { status: "completed" }))
    .catch((e) => save(id, { status: "failed", error: e.message }));
  if (wait) await job;
  return { id, filename, type, scope, status: wait ? load()[id].status : "running", sites: sites.length, databases: dbs.length };
}

async function runBackup(id, filename, sites, dbs, user) {
  const staging = path.join(DIR, ".staging-" + id);
  fs.mkdirSync(path.join(staging, "files"), { recursive: true });
  fs.mkdirSync(path.join(staging, "vhosts"), { recursive: true });
  fs.mkdirSync(path.join(staging, "databases"), { recursive: true });
  try {
    for (const site of sites) {
      const dir = platform.siteDir(site.domain);
      if (fs.existsSync(dir)) {
        await shell.run("tar -cf " + shell.q(path.join(staging, "files", site.domain + ".tar")) +
          " -C " + shell.q(platform.paths.wwwRoot) + " --exclude=.user.ini " + shell.q(site.domain), { timeout: 3600000, user });
      }
      const vhost = platform.readVhost(site.domain);
      if (vhost) fs.writeFileSync(path.join(staging, "vhosts", site.domain + ".conf"), vhost.content);
    }
    for (const db of dbs) {
      await shell.run("mysqldump -uroot --single-transaction --routines --triggers " + shell.q(db) +
        " > " + shell.q(path.join(staging, "databases", db + ".sql")), { env: platform.mysqlEnv(), timeout: 3600000, user });
    }
    const manifest = {
      version: 1, created: new Date().toISOString(), profile: platform.PROFILE,
      sites: sites.map((s) => ({ domain: s.domain, meta: websites.getMeta(s.domain) })), databases: dbs,
    };
    fs.writeFileSync(path.join(staging, "manifest.json"), JSON.stringify(manifest, null, 2));
    await shell.run("tar -czf " + shell.q(path.join(DIR, filename)) + " -C " + shell.q(staging) + " .", { timeout: 3600000, user });
    if (shell.IS_LINUX) fs.chmodSync(path.join(DIR, filename), 0o600);
  } finally {
    fs.rmSync(staging, { recursive: true, force: true });
  }
}

function resolveBackup(idOrName) {
  const meta = load();
  const filename = meta[idOrName] ? meta[idOrName].filename : idOrName;
  if (!NAME_RE.test(filename || "")) throw validate.badRequest("Invalid backup name.");
  const file = path.join(DIR, filename);
  if (!fs.existsSync(file)) throw validate.badRequest("Backup not found: " + filename);
  return file;
}

/**
 * Restore files, vhosts and databases from an archive (overwrites existing data).
 */
async function restoreBackup({ id, user = "system" }) {
  const file = resolveBackup(id);
  const staging = path.join(DIR, ".restore-" + crypto.randomBytes(4).toString("hex"));
  fs.mkdirSync(staging, { recursive: true });
  try {
    await shell.run("tar -xzf " + shell.q(file) + " -C " + shell.q(staging), { timeout: 3600000, user });
    const manifest = JSON.parse(fs.readFileSync(path.join(staging, "manifest.json"), "utf8"));
    const restored = { sites: [], databases: [] };

    for (const site of manifest.sites || []) {
      const tarFile = path.join(staging, "files", site.domain + ".tar");
      if (fs.existsSync(tarFile)) {
        await shell.run("tar -xf " + shell.q(tarFile) + " -C " + shell.q(platform.paths.wwwRoot), { timeout: 3600000, user });
      }
      const vhostFile = path.join(staging, "vhosts", site.domain + ".conf");
      if (!platform.readVhost(site.domain) && fs.existsSync(vhostFile)) {
        if (site.meta) websites.setMeta(site.domain, site.meta);
        fs.copyFileSync(vhostFile, platform.vhostPath(site.domain));
        if (!platform.IS_AAPANEL) await platform.enableVhost(site.domain, { user });
      }
      restored.sites.push(site.domain);
    }
    if ((manifest.sites || []).length) await platform.reloadNginx({ user });

    for (const db of manifest.databases || []) {
      const dump = path.join(staging, "databases", db + ".sql");
      if (!fs.existsSync(dump)) continue;
      await databases.sql("CREATE DATABASE IF NOT EXISTS `" + validate.identifier(db, "Database", 64) + "`;", { user });
      await shell.run("mysql -uroot " + shell.q(db) + " < " + shell.q(dump), { env: platform.mysqlEnv(), timeout: 3600000, user });
      restored.databases.push(db);
    }
    return { status: "restored", ...restored };
  } finally {
    fs.rmSync(staging, { recursive: true, force: true });
  }
}

async function deleteBackup({ id }) {
  const meta = load();
  if (meta[id] && meta[id].status !== "completed" && !fs.existsSync(path.join(DIR, meta[id].filename))) {
    store.update("backups", {}, (all) => { delete all[id]; });
    return { id, status: "deleted" };
  }
  const file = resolveBackup(id);
  fs.rmSync(file, { force: true });
  store.update("backups", {}, (all) => {
    for (const k of Object.keys(all)) if (all[k].filename === path.basename(file)) delete all[k];
  });
  return { id, status: "deleted" };
}

function downloadPath(idOrName) {
  return resolveBackup(idOrName);
}

/**
 * Delete the oldest archives of a scope beyond `keep`.
 */
async function prune({ scope = "all", keep = 7 }) {
  const rows = (await listBackups()).filter((b) => b.scope === scope && b.status === "completed");
  const extra = rows.slice(Math.max(1, Number(keep) || 7));
  for (const b of extra) await deleteBackup({ id: b.id });
  return { deleted: extra.length };
}

// ---------------------------------------------------------------- schedule

const CLI = path.resolve(__dirname, "../cli.js");

async function getSchedule() {
  const cron = require("./cron.service");
  const job = (await cron.listCrons()).find((j) => j.command.includes(CLI + " backup"));
  return job ? { enabled: job.active, schedule: job.schedule, id: job.id, command: job.command } : { enabled: false };
}

async function setSchedule({ enabled, schedule = "0 3 * * *", type = "Full Account", keep = 7, user }) {
  const cron = require("./cron.service");
  const current = await getSchedule();
  if (current.id) await cron.deleteCron({ id: current.id, user });
  if (!enabled) return { enabled: false };
  const command = process.execPath + " " + CLI + " backup --type " + shell.q(type) + " --keep " + Number(keep || 7) +
    " >> /var/log/facezila/backup.log 2>&1";
  const job = await cron.addCron({ schedule, command, description: "Facezila scheduled backup", user });
  return { enabled: true, schedule: job.schedule, id: job.id };
}

module.exports = { listBackups, createBackup, restoreBackup, deleteBackup, downloadPath, prune, getSchedule, setSchedule };
