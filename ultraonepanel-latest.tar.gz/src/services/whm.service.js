const fs = require("fs");
const path = require("path");
const shell = require("./shell.service");
const store = require("../lib/store");
const validate = require("../lib/validate");
const root = require("./root.service");
const accounts = require("./accounts.service");
const dns = require("./dns.service");

const DEFAULT_ACLS = [
  { id: "create-acct", label: "Account Creation", description: "Can create new cPanel accounts" },
  { id: "terminate-acct", label: "Account Termination", description: "Can delete/terminate accounts" },
  { id: "suspend-acct", label: "Account Suspension", description: "Can suspend and unsuspend accounts" },
  { id: "passwd", label: "Password Modification", description: "Can change cPanel user passwords" },
  { id: "edit-pkg", label: "Package Management", description: "Can create, edit and delete hosting packages" },
  { id: "upgrade-acct", label: "Upgrade / Downgrade", description: "Can change an account's package" },
  { id: "dns-manage", label: "DNS Zone Management", description: "Can add, edit and delete DNS zones" },
  { id: "mail-routing", label: "Mail Routing Configuration", description: "Can configure MX and mail exchanger routes" },
  { id: "ssl-manage", label: "SSL Certificate Management", description: "Can issue and install SSL certificates" },
];

const DEFAULT_FEATURE_LIST = [
  "FileManager", "DiskUsage", "FTP", "Backup", "MySQL", "PostgreSQL", "phpMyAdmin",
  "EmailAccounts", "Forwarders", "Autoresponders", "SpamFilter", "Deliverability",
  "ZoneEditor", "Domains", "SSL", "SSHAccess", "UFW", "CronJobs", "Metrics",
  "MultiPHP", "WordPressToolkit", "AppDeployer", "Terminal"
];

const WhmService = {
  // -------------------------------------------------------------
  // RESELLER MANAGEMENT
  // -------------------------------------------------------------
  listResellers() {
    return store.read("resellers", [
      {
        username: "root_reseller",
        email: "admin@server.local",
        delegatedIp: "Shared Server IP",
        sharedIp: "127.0.0.1",
        acls: DEFAULT_ACLS.map((a) => a.id),
        maxAccounts: 100,
        currentAccounts: 3,
        created: new Date().toISOString(),
      }
    ]);
  },

  createReseller({ username, email, acls = [], maxAccounts = 25, delegatedIp = "Shared" }) {
    const u = validate.username(username);
    const list = WhmService.listResellers();
    if (list.some((r) => r.username === u)) throw validate.badRequest("Reseller already exists: " + u);

    const reseller = {
      username: u,
      email: email || `${u}@server.local`,
      delegatedIp,
      sharedIp: "127.0.0.1",
      acls: acls.length ? acls : DEFAULT_ACLS.map((a) => a.id),
      maxAccounts: parseInt(maxAccounts) || 25,
      currentAccounts: 0,
      created: new Date().toISOString(),
    };
    list.push(reseller);
    store.write("resellers", list);
    return reseller;
  },

  updateResellerAcls(username, acls) {
    const list = WhmService.listResellers();
    const r = list.find((item) => item.username === username);
    if (!r) throw validate.badRequest("Reseller not found.");
    r.acls = acls;
    store.write("resellers", list);
    return r;
  },

  deleteReseller(username) {
    let list = WhmService.listResellers();
    list = list.filter((r) => r.username !== username);
    store.write("resellers", list);
    return { success: true };
  },

  getReseller(username) {
    const list = WhmService.listResellers();
    return list.find((r) => r.username === username) || null;
  },

  async getResellerAccounts(username) {
    const all = await accounts.listAccounts();
    return all.filter((a) => a.owner === username);
  },

  async getResellerStats(username) {
    const r = WhmService.getReseller(username);
    if (!r) throw validate.badRequest("Reseller not found: " + username);
    const ownedAccounts = await WhmService.getResellerAccounts(username);
    return {
      reseller: r.username,
      username: r.username,
      email: r.email,
      delegatedIp: r.delegatedIp,
      sharedIp: r.sharedIp,
      acls: r.acls,
      maxAccounts: r.maxAccounts,
      currentAccounts: ownedAccounts.length,
      availableAccounts: Math.max(0, r.maxAccounts - ownedAccounts.length),
      stats: {
        accounts: {
          used: ownedAccounts.length,
          limit: r.maxAccounts,
          available: Math.max(0, r.maxAccounts - ownedAccounts.length),
        },
        disk: {
          usedMb: ownedAccounts.reduce((sum, a) => sum + (Number(a.diskUsed) || 0), 0),
          limitMb: r.maxDiskMb || null,
        },
        bandwidth: {
          usedMb: ownedAccounts.reduce((sum, a) => sum + (Number(a.bwUsed) || 0), 0),
          limitMb: r.maxBwMb || null,
        },
      },
      accounts: ownedAccounts,
    };
  },

  getAclDefinitions() {
    return DEFAULT_ACLS;
  },

  // -------------------------------------------------------------
  // FEATURE MANAGER
  // -------------------------------------------------------------
  listFeatureLists() {
    return store.read("feature-lists", [
      { id: "default", name: "Default cPanel Features", features: DEFAULT_FEATURE_LIST },
      { id: "minimal", name: "Minimal Starter", features: ["FileManager", "EmailAccounts", "MySQL", "Domains"] },
    ]);
  },

  saveFeatureList({ id, name, features }) {
    const lists = WhmService.listFeatureLists();
    const existingIdx = lists.findIndex((l) => l.id === id);
    const item = { id: id || `fl-${Date.now()}`, name, features: features || [] };
    if (existingIdx !== -1) {
      lists[existingIdx] = item;
    } else {
      lists.push(item);
    }
    store.write("feature-lists", lists);
    return item;
  },

  deleteFeatureList(id) {
    let lists = WhmService.listFeatureLists();
    lists = lists.filter((l) => l.id !== id);
    store.write("feature-lists", lists);
    return { success: true };
  },

  // -------------------------------------------------------------
  // SKELETON DIRECTORY (/etc/skel or /var/cpanel/skel)
  // -------------------------------------------------------------
  getSkeletonDirectory() {
    const skelDir = shell.IS_LINUX ? "/etc/skel/public_html" : path.resolve(__dirname, "../../data/skel/public_html");
    fs.mkdirSync(skelDir, { recursive: true });
    const defaultIndex = path.join(skelDir, "index.html");
    if (!fs.existsSync(defaultIndex)) {
      fs.writeFileSync(defaultIndex, `<!DOCTYPE html><html><head><title>Website Coming Soon</title><style>body{font-family:sans-serif;text-align:center;padding:50px;background:#f8fafc;}h1{color:#0284c7;}</style></head><body><h1>Website Coming Soon</h1><p>Managed by Facezila Control Panel</p></body></html>`);
    }
    return { path: skelDir, files: fs.readdirSync(skelDir) };
  },

  // -------------------------------------------------------------
  // SECURITY CENTER & MODSECURITY & HOST ACCESS
  // -------------------------------------------------------------
  async getSecurityCenterStatus() {
    const ufw = await root.getUfwStatus();
    const secSettings = store.read("security-settings", {
      modSecurity: true,
      compilerAccess: false,
      cphulkBruteForce: true,
      allowedHosts: ["127.0.0.1"],
      deniedHosts: [],
      securityAdvisorIssues: [
        { level: "recommended", message: "SSH password authentication is active; consider SSH keys only." },
        { level: "good", message: "Kernel symlink protection is active." },
        { level: "good", message: "MySQL root password has strong entropy." },
      ]
    });
    return {
      ufw,
      ...secSettings,
    };
  },

  async updateModSecurity(enabled) {
    const settings = store.read("security-settings", {});
    settings.modSecurity = !!enabled;
    store.write("security-settings", settings);
    if (shell.IS_LINUX) {
      await shell.run(`a2enmod security2 2>/dev/null || true`);
      await shell.run(`systemctl restart apache2 2>/dev/null || systemctl restart nginx 2>/dev/null || true`);
    }
    return { modSecurity: settings.modSecurity };
  },

  // -------------------------------------------------------------
  // NAMESERVER CONFIGURATION
  // -------------------------------------------------------------
  getNameserverConfig() {
    return store.read("nameserver-config", {
      type: "bind9",
      ns1: "ns1.example.com",
      ns2: "ns2.example.com",
      ip1: "127.0.0.1",
      ip2: "127.0.0.1",
    });
  },

  saveNameserverConfig(config) {
    store.write("nameserver-config", config);
    return config;
  },

  // -------------------------------------------------------------
  // APACHE / NGINX & PHP CONFIGURATION
  // -------------------------------------------------------------
  async getWebServerConfig() {
    return {
      serverType: "Nginx + Apache Reverse Proxy / Standalone Nginx",
      keepAlive: "On",
      timeout: 60,
      maxClients: 150,
      gzipCompression: "Enabled",
      defaultPhpVersion: "8.2",
      availablePhp: ["7.4", "8.0", "8.1", "8.2", "8.3"],
    };
  },

  // -------------------------------------------------------------
  // RESELLER IP DELEGATION
  // -------------------------------------------------------------
  manageResellerIp(username, { delegatedIp, sharedIp }) {
    const list = WhmService.listResellers();
    const r = list.find((item) => item.username === username);
    if (!r) throw validate.badRequest("Reseller not found.");
    if (delegatedIp !== undefined) r.delegatedIp = delegatedIp;
    if (sharedIp !== undefined) r.sharedIp = sharedIp;
    store.write("resellers", list);
    return r;
  },

  // -------------------------------------------------------------
  // SSL HOSTS & SECURITY ADVISOR
  // -------------------------------------------------------------
  async listSslHosts() {
    const websitesSvc = require("./website.service");
    const sites = await websitesSvc.listWebsites();
    return sites.map((s) => ({
      domain: s.domain,
      ip: "127.0.0.1",
      documentRoot: s.documentRoot,
      hasSsl: s.ssl,
      issuer: s.ssl ? "Let's Encrypt Authority X3" : "None",
      expiry: s.ssl ? new Date(Date.now() + 75 * 86400000).toISOString() : null,
      autoRenew: s.ssl,
    }));
  },

  getHostAccessControl() {
    return store.read("host-access", {
      allow: ["ALL : 127.0.0.1 : ALLOW", "sshd : ALL : ALLOW"],
      deny: ["ALL : ALL : DENY"],
    });
  },

  saveHostAccessControl({ allow, deny }) {
    const config = { allow: allow || [], deny: deny || [] };
    store.write("host-access", config);
    if (shell.IS_LINUX) {
      try {
        fs.writeFileSync("/etc/hosts.allow", config.allow.join("\n") + "\n");
        fs.writeFileSync("/etc/hosts.deny", config.deny.join("\n") + "\n");
      } catch (_) {}
    }
    return config;
  },

  async runSecurityAdvisor() {
    const issues = [
      { id: "ssh-root", level: "warning", message: "SSH PermitRootLogin is enabled in /etc/ssh/sshd_config. Recommend setting to 'prohibit-password' or 'no'." },
      { id: "firewall", level: "good", message: "UFW Firewall is enabled and tracking active connection states." },
      { id: "passwords", level: "good", message: "Strong password policy enforced (minimum 8 characters with complexity)." },
      { id: "modsecurity", level: "good", message: "ModSecurity Web Application Firewall is enabled." },
      { id: "symlink", level: "good", message: "Linux kernel symlink / hardlink protection is active." },
      { id: "compiler", level: "recommended", message: "C/C++ compiler permissions are open to all users. Restrict gcc to root only." },
    ];
    return { scanDate: new Date().toISOString(), status: "Completed", issues };
  },

  // -------------------------------------------------------------
  // DNS ADVANCED IN WHM
  // -------------------------------------------------------------
  async parkDomain({ domain, targetDomain }) {
    const d = validate.domain(domain);
    const target = validate.domain(targetDomain);
    await dns.createZone({ domain: d });
    await dns.addRecord({ domain: d, type: "CNAME", name: "@", value: target + "." });
    return { domain: d, targetDomain: target, status: "Parked" };
  },

  async editMxEntry({ domain, mx, priority = 10 }) {
    const d = validate.domain(domain);
    await dns.addRecord({ domain: d, type: "MX", name: "@", value: mx, priority: Number(priority) });
    return { domain: d, mx, priority, status: "Saved" };
  },

  getZoneTemplates() {
    return store.read("zone-templates", [
      {
        id: "standard",
        name: "Standard Web + Mail Template",
        content: "; Standard Facezila Zone Template\n$TTL 14400\n@ IN SOA %nameserver% %email% ( %serial% 7200 3600 1209600 86400 )\n@ IN NS %nameserver%\n@ IN A %ip%\nwww IN CNAME %domain%.\nmail IN A %ip%\n@ IN MX 10 mail.%domain%.\n",
      },
    ]);
  },

  saveZoneTemplate({ id, name, content }) {
    const templates = WhmService.getZoneTemplates();
    const existingIndex = templates.findIndex((t) => t.id === id);
    const item = { id: id || `tpl-${Date.now()}`, name, content };
    if (existingIndex >= 0) templates[existingIndex] = item;
    else templates.push(item);
    store.write("zone-templates", templates);
    return item;
  },

  // -------------------------------------------------------------
  // SERVER SYSTEM INFORMATION
  // -------------------------------------------------------------
  async getServerInfo() {
    const os = require("os");
    return {
      hostname: os.hostname(),
      platform: os.platform(),
      release: os.release(),
      distro: shell.IS_LINUX ? await shell.tryGet("lsb_release -ds 2>/dev/null || cat /etc/issue.net", "Ubuntu Linux") : "Windows Dev Host",
      kernel: os.type() + " " + os.release(),
      uptime: os.uptime(),
      cpus: os.cpus().map((c) => ({ model: c.model, speed: c.speed })),
      cpuCount: os.cpus().length,
      totalMemMB: Math.round(os.totalmem() / 1048576),
      freeMemMB: Math.round(os.freemem() / 1048576),
      serverIp: shell.IS_LINUX ? await shell.tryGet("hostname -I | awk '{print $1}'", "127.0.0.1") : "127.0.0.1",
      loadAvg: os.loadavg(),
    };
  }
};

module.exports = WhmService;

