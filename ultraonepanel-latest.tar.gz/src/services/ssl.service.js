const fs = require("fs");
const path = require("path");
const shell = require("./shell.service");
const platform = require("../lib/platform");
const websites = require("./website.service");
const validate = require("../lib/validate");

/**
 * Issue a Let's Encrypt certificate using the webroot challenge, then switch
 * the site's vhost to HTTPS. Webroot mode works with any nginx layout and
 * never lets certbot rewrite our configs.
 */
async function issueCert({ domain, email, user = "system" }) {
  domain = validate.domain(domain);
  if (!shell.IS_LINUX) return { domain, status: "issued (dev-skip)", skipped: true };
  if (!shell.hasCommand("certbot")) throw new Error("certbot is not installed on this server.");

  const site = await websites.getWebsite(domain);
  if (!site) throw validate.badRequest("Website not found: " + domain);
  if (!site.managed) {
    throw validate.badRequest("This site was not created by Facezila; manage its certificate in the panel that created it.");
  }

  const names = [domain];
  if (site.domainType !== "Subdomain") names.push("www." + domain);
  const contact = email || process.env.LETSENCRYPT_EMAIL || "admin@" + domain;
  const webroot = site.documentRoot;
  fs.mkdirSync(path.join(webroot, ".well-known", "acme-challenge"), { recursive: true });

  const args = [
    "certbot certonly --webroot -w " + shell.q(webroot),
    ...names.map((n) => "-d " + shell.q(n)),
    "--cert-name " + shell.q(domain),
    "--non-interactive --agree-tos --keep-until-expiring",
    "-m " + shell.q(contact),
  ];
  try {
    await shell.run(args.join(" "), { timeout: 180000, user });
  } catch (e) {
    // www. often has no DNS record; retry for the bare domain only.
    if (names.length > 1 && /www\./.test(e.message)) {
      await shell.run(args.filter((a) => a !== "-d " + shell.q("www." + domain)).join(" "), { timeout: 180000, user });
    } else {
      throw new Error("Let's Encrypt could not verify " + domain + ". Make sure its DNS A record points to this server. " +
        (e.message.split("\n").find((l) => /Detail|Error/i.test(l)) || ""));
    }
  }

  await websites.setSsl({ domain, ssl: true, user });
  return { domain, status: "issued" };
}

async function revokeCert({ domain, user = "system" }) {
  domain = validate.domain(domain);
  if (!shell.IS_LINUX) return { domain, status: "revoked (dev-skip)", skipped: true };
  if (websites.isManaged(domain)) await websites.setSsl({ domain, ssl: false, user });
  await shell.run("certbot delete --cert-name " + shell.q(domain) + " --non-interactive", { user });
  return { domain, status: "revoked" };
}

async function certInfo(certFile) {
  const out = await shell.tryGet("openssl x509 -noout -enddate -issuer -in " + shell.q(certFile));
  const end = (out.match(/notAfter=(.+)/) || [])[1];
  if (!end) return null;
  const expires = new Date(end);
  const daysLeft = Math.floor((expires - Date.now()) / 86400000);
  return {
    expiry: expires.toISOString().slice(0, 10),
    daysLeft,
    issuer: ((out.match(/O\s*=\s*([^,\n]+)/) || [])[1] || "").trim(),
    status: daysLeft < 0 ? "expired" : "valid",
  };
}

/**
 * Certificates from certbot plus any certs the host panel manages itself.
 */
async function listCerts(user) {
  if (!shell.IS_LINUX) return [];
  const dirs = new Map();
  if (fs.existsSync("/etc/letsencrypt/live")) {
    for (const d of fs.readdirSync("/etc/letsencrypt/live")) {
      const f = path.join("/etc/letsencrypt/live", d, "fullchain.pem");
      if (fs.existsSync(f)) dirs.set(d, { file: f, source: "certbot" });
    }
  }
  if (platform.IS_AAPANEL && fs.existsSync(platform.paths.certDir)) {
    for (const d of fs.readdirSync(platform.paths.certDir)) {
      const f = path.join(platform.paths.certDir, d, "fullchain.pem");
      if (!dirs.has(d) && fs.existsSync(f)) dirs.set(d, { file: f, source: "aapanel" });
    }
  }
  let certs = [];
  for (const [domain, { file, source }] of dirs) {
    const info = await certInfo(file);
    if (info) certs.push({ domain, source, ...info });
  }
  if (user && user.role !== "admin" && user.username !== "root") {
    certs = certs.filter((c) => websites.isUserAllowedSite(c.domain, {}, user));
  }
  return certs.sort((a, b) => a.domain.localeCompare(b.domain));
}

async function renewAll({ user = "system" } = {}) {
  if (!shell.IS_LINUX) return { status: "renewed (dev-skip)" };
  const r = await shell.run("certbot renew --non-interactive --deploy-hook 'nginx -s reload'", { timeout: 600000, user });
  return { status: "renewed", output: r.stdout.split("\n").slice(-10).join("\n") };
}

module.exports = { issueCert, revokeCert, listCerts, renewAll };
