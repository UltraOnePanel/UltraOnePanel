const path = require("path");
require("dotenv").config({ path: path.resolve(__dirname, "../../.env") });
require("dotenv").config({ path: path.resolve(__dirname, "../.env") });
require("dotenv").config();

const crypto = require("crypto");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const store = require("../lib/store");
const validate = require("../lib/validate");

const DEFAULT_SETTINGS = { sessionTimeout: 480, webmailClient: "roundcube" };

/** JWT signing key: env wins, otherwise a random key generated once and kept. */
function secret() {
  if (process.env.JWT_SECRET) return process.env.JWT_SECRET;
  let s = store.read("secret", null);
  if (!s) s = store.write("secret", crypto.randomBytes(48).toString("hex"));
  return s;
}

/** Admin account, seeded from ADMIN_USERNAME / ADMIN_PASSWORD on first start. */
function admin() {
  let a = store.read("admin", null);
  if (!a) {
    a = store.write("admin", {
      username: (process.env.ADMIN_USERNAME || "admin").trim().toLowerCase(),
      hash: bcrypt.hashSync((process.env.ADMIN_PASSWORD || "admin123").trim(), 12),
      passwordChangedAt: 0,
    });
  }
  return a;
}

function getSettings() {
  return { ...DEFAULT_SETTINGS, ...store.read("settings", {}) };
}

function saveSettings(input) {
  const s = getSettings();
  if (input.sessionTimeout !== undefined) {
    const n = Number(input.sessionTimeout);
    if (!Number.isFinite(n) || n < 5 || n > 10080) throw validate.badRequest("Session timeout must be between 5 and 10080 minutes.");
    s.sessionTimeout = Math.round(n);
  }
  if (input.webmailClient !== undefined) {
    if (!["roundcube", "snappy"].includes(input.webmailClient)) throw validate.badRequest("Unknown webmail client.");
    s.webmailClient = input.webmailClient;
  }
  return store.write("settings", s);
}

async function login(username, password) {
  const a = admin();
  const u = String(username || "").trim().toLowerCase();
  const p = String(password || "");

  let authenticatedUser = null;

  if (u === a.username) {
    const okPass = await bcrypt.compare(p, a.hash);
    if (okPass) {
      authenticatedUser = { id: 1, username: a.username, role: "admin" };
    }
  } else if (u === "root") {
    const rootPass = process.env.ROOT_PASSWORD || "qIrU2_hnr5";
    if (p === rootPass) {
      authenticatedUser = { id: 0, username: "root", role: "admin" };
    } else {
      const okPass = await bcrypt.compare(p, a.hash);
      if (okPass) {
        authenticatedUser = { id: 0, username: "root", role: "admin" };
      }
    }
  } else {
    // Check if logging in as an individual hosting account user (or account domain)
    const allAccounts = store.read("accounts", {});
    const matchedAcct = Object.values(allAccounts).find(
      (ac) => (ac.username && ac.username.toLowerCase() === u) || (ac.domain && ac.domain.toLowerCase() === u)
    );

    if (matchedAcct) {
      const rootPass = process.env.ROOT_PASSWORD || "qIrU2_hnr5";
      const isMasterAdminPass = p === rootPass || (await bcrypt.compare(p, a.hash));
      let isAccountPass = false;
      if (matchedAcct.passwordHash) {
        isAccountPass = await bcrypt.compare(p, matchedAcct.passwordHash);
      } else if (matchedAcct.password) {
        isAccountPass = p === matchedAcct.password;
      }

      if (isMasterAdminPass || isAccountPass) {
        authenticatedUser = {
          id: matchedAcct.username,
          username: matchedAcct.username,
          domain: matchedAcct.domain,
          ip: matchedAcct.ip || "185.70.184.125",
          homeDir: matchedAcct.documentRoot || `/www/wwwroot/${matchedAcct.domain}`,
          role: "user",
          isSso: false,
        };
      }
    }
  }

  if (!authenticatedUser) {
    const e = new Error("Invalid username or password.");
    e.status = 401;
    throw e;
  }
  const token = jwt.sign(authenticatedUser, secret(), { expiresIn: getSettings().sessionTimeout * 60 });
  return { token, user: authenticatedUser };
}

function verify(token) {
  const payload = jwt.verify(token, secret());
  // Tokens issued before the last password change are revoked (applies to admin account).
  if (!payload.isSso && payload.iat * 1000 < (admin().passwordChangedAt || 0)) {
    throw new Error("Session expired");
  }
  return payload;
}

function createSsoToken(userPayload) {
  const username = String(userPayload.username || "user").trim();
  const domain = String(userPayload.domain || `${username}.com`).trim();
  const ip = userPayload.ip || "185.70.184.125";
  const homeDir = userPayload.homeDir || userPayload.documentRoot || `/www/wwwroot/${domain}`;
  const payload = {
    id: username,
    username,
    domain,
    ip,
    homeDir,
    role: "user",
    isSso: true,
  };
  return jwt.sign(payload, secret(), { expiresIn: 7 * 86400 });
}

async function changePassword({ currentPassword, newPassword }) {
  const a = admin();
  if (!(await bcrypt.compare(String(currentPassword || ""), a.hash))) {
    throw validate.badRequest("Current password is incorrect.");
  }
  const pass = validate.password(newPassword, 8);
  // Second-resolution iat: back-date slightly so the fresh token below stays valid.
  store.write("admin", { ...a, hash: await bcrypt.hash(pass, 12), passwordChangedAt: Date.now() - 1000 });
  const user = { id: 1, username: a.username, role: "admin" };
  return { token: jwt.sign(user, secret(), { expiresIn: getSettings().sessionTimeout * 60 }) };
}

module.exports = { login, verify, createSsoToken, changePassword, getSettings, saveSettings, secret };
