const fs = require("fs");
const path = require("path");
require("dotenv").config({ path: path.resolve(__dirname, "../../.env") });
require("dotenv").config({ path: path.resolve(__dirname, "../.env") });
require("dotenv").config();

const crypto = require("crypto");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const store = require("../lib/store");
const validate = require("../lib/validate");
const shell = require("./shell.service");

const DEFAULT_SETTINGS = { sessionTimeout: 480, webmailClient: "roundcube" };
const USER_SERVICES = ["email", "ftp", "files", "websites", "databases"];

function generateSecurePassword(length = 16) {
  const charset = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$%^&*";
  const bytes = crypto.randomBytes(length);
  let pass = "";
  for (let i = 0; i < length; i++) {
    pass += charset[bytes[i] % charset.length];
  }
  return pass;
}

function syncAdminCredentialsRecord(username, password) {
  try {
    const defaultPlPath = path.join(store.DATA_DIR, "default.pl");
    fs.mkdirSync(store.DATA_DIR, { recursive: true, mode: 0o700 });
    fs.writeFileSync(defaultPlPath, password.trim(), { mode: 0o600 });
  } catch (_) {}

  try {
    const serverIp = process.env.SERVER_IP || "185.70.184.125";
    const loginTxt = "/root/upanel_login.txt";
    const content = `========================================================================
                   UltraOnePanel Access Details
========================================================================
Public IP Address : ${serverIp}

[ Web Interface URLs & Ports ]
  * UHM Reseller/Admin Panel (SSL)  : https://${serverIp}:2087
    UHM Reseller/Admin Panel (HTTP) : http://${serverIp}:2086

  * uPanel End-User Panel (SSL)     : https://${serverIp}:2083
    uPanel End-User Panel (HTTP)    : http://${serverIp}:2082

  * Webmail Client (SSL)            : https://${serverIp}:2096
    Webmail Client (HTTP)           : http://${serverIp}:2095

  * phpMyAdmin (Database Manager)   : https://${serverIp}:2083/phpmyadmin/
  * phpPgAdmin (PostgreSQL Manager) : https://${serverIp}:2083/phppgadmin/

[ Administrator Credentials ]
  * Username : ${username}
  * Password : ${password}

[ Quick Management Commands ]
  * View this info anytime  : upanel info
  * Reset admin password    : upanel password <new_password>
  * View port status        : upanel ports
  * Check panel status      : upanel status
  * Restart panel service   : upanel restart
  * Update panel software   : upanel update
========================================================================
`;
    fs.writeFileSync(loginTxt, content, { mode: 0o600 });
  } catch (_) {}
}

function ownerKey(user) {
  return String(user?.owner || user?.username || "").trim().toLowerCase();
}

function findSubuser(username) {
  const wanted = String(username || "").trim().toLowerCase();
  const allUsers = store.read("panel-users", {});
  for (const [owner, users] of Object.entries(allUsers)) {
    const record = Object.values(users || {}).find(
      (candidate) => candidate.username?.toLowerCase() === wanted
    );
    if (record) return { owner, record };
  }
  return null;
}

function publicSubuser(record) {
  return {
    username: record.username,
    fullName: record.fullName,
    email: record.email,
    services: record.services,
    createdAt: record.createdAt,
  };
}

/** JWT signing key: env wins, otherwise a random key generated once and kept. */
function secret() {
  if (process.env.JWT_SECRET) return process.env.JWT_SECRET;
  let s = store.read("secret", null);
  if (!s) s = store.write("secret", crypto.randomBytes(48).toString("hex"));
  return s;
}

/** Admin account, seeded with random password on first start if not present. */
function admin() {
  let a = store.read("admin", null);
  if (!a) {
    const uname = (process.env.ADMIN_USERNAME || "admin").trim().toLowerCase();
    let pass = process.env.ADMIN_PASSWORD;
    if (!pass) {
      try {
        const defaultPl = path.join(store.DATA_DIR, "default.pl");
        if (fs.existsSync(defaultPl)) {
          pass = fs.readFileSync(defaultPl, "utf8").trim();
        }
      } catch (_) {}
    }
    if (!pass) {
      pass = generateSecurePassword(16);
    }
    a = store.write("admin", {
      username: uname,
      hash: bcrypt.hashSync(pass.trim(), 12),
      passwordChangedAt: 0,
    });
    syncAdminCredentialsRecord(uname, pass);
  }
  return a;
}

function getSettings() {
  return { ...DEFAULT_SETTINGS, ...store.read("settings", {}) };
}

function saveSettings(input) {
  const s = getSettings();
  if (input.sessionTimeout !== undefined) {
    const n = Number(input.sessionTimeout);
    if (!Number.isFinite(n) || n < 5 || n > 10080) throw validate.badRequest("Session timeout must be between 5 and 10080 minutes.");
    s.sessionTimeout = Math.round(n);
  }
  if (input.webmailClient !== undefined) {
    if (!["roundcube", "snappy"].includes(input.webmailClient)) throw validate.badRequest("Unknown webmail client.");
    s.webmailClient = input.webmailClient;
  }
  return store.write("settings", s);
}

async function login(username, password) {
  const a = admin();
  const u = String(username || "").trim().toLowerCase();
  const p = String(password || "");

  let authenticatedUser = null;

  if (u === a.username) {
    const okPass = await bcrypt.compare(p, a.hash);
    if (okPass) {
      authenticatedUser = { id: 1, username: a.username, role: "admin" };
    }
  } else if (u === "root") {
    const rootPass = process.env.ROOT_PASSWORD;
    if (rootPass && p === rootPass) {
      authenticatedUser = { id: 0, username: "root", role: "admin" };
    } else {
      const okPass = await bcrypt.compare(p, a.hash);
      if (okPass) {
        authenticatedUser = { id: 0, username: "root", role: "admin" };
      }
    }
  } else {
    // Check if logging in as an individual hosting account user (or account domain)
    const allAccounts = store.read("accounts", {});
    const matchedAcct = Object.values(allAccounts).find(
      (ac) => (ac.username && ac.username.toLowerCase() === u) || (ac.domain && ac.domain.toLowerCase() === u)
    );

    if (matchedAcct) {
      const rootPass = process.env.ROOT_PASSWORD;
      const isMasterAdminPass = (rootPass && p === rootPass) || (await bcrypt.compare(p, a.hash));
      let isAccountPass = false;
      if (matchedAcct.passwordHash) {
        isAccountPass = await bcrypt.compare(p, matchedAcct.passwordHash);
      } else if (matchedAcct.password) {
        isAccountPass = p === matchedAcct.password;
      }

      if (isMasterAdminPass || isAccountPass) {
        authenticatedUser = {
          id: matchedAcct.username,
          username: matchedAcct.username,
          domain: matchedAcct.domain,
          ip: matchedAcct.ip || "185.70.184.125",
          homeDir: matchedAcct.documentRoot || `/www/wwwroot/${matchedAcct.domain}`,
          role: "user",
          isSso: false,
        };
      }
    }
  }

  if (!authenticatedUser) {
    const matchedSubuser = findSubuser(u);
    if (matchedSubuser && await bcrypt.compare(p, matchedSubuser.record.passwordHash)) {
      authenticatedUser = {
        id: matchedSubuser.record.username,
        username: matchedSubuser.record.username,
        role: "subuser",
        owner: matchedSubuser.owner,
        services: matchedSubuser.record.services,
      };
    }
  }

  if (!authenticatedUser) {
    const e = new Error("Invalid username or password.");
    e.status = 401;
    throw e;
  }
  const token = jwt.sign(authenticatedUser, secret(), { expiresIn: getSettings().sessionTimeout * 60 });
  return { token, user: authenticatedUser };
}

function verify(token) {
  const payload = jwt.verify(token, secret());
  // Tokens issued before the last password change are revoked (applies to admin account).
  if (!payload.isSso && payload.iat * 1000 < (admin().passwordChangedAt || 0)) {
    throw new Error("Session expired");
  }
  return payload;
}

function createSsoToken(userPayload) {
  const username = String(userPayload.username || "user").trim();
  const domain = String(userPayload.domain || `${username}.com`).trim();
  const ip = userPayload.ip || "185.70.184.125";
  const homeDir = userPayload.homeDir || userPayload.documentRoot || `/www/wwwroot/${domain}`;
  const payload = {
    id: username,
    username,
    domain,
    ip,
    homeDir,
    role: "user",
    isSso: true,
  };
  return jwt.sign(payload, secret(), { expiresIn: 7 * 86400 });
}

async function changePassword({ currentPassword, newPassword, user }) {
  const username = String(user?.username || "").trim().toLowerCase();
  const current = String(currentPassword || "");
  const pass = validate.password(newPassword, 8);
  const a = admin();

  if (user?.role === "subuser") {
    const owner = ownerKey(user);
    const allUsers = store.read("panel-users", {});
    const record = allUsers[owner]?.[username];
    if (!record || !(await bcrypt.compare(current, record.passwordHash))) {
      throw validate.badRequest("Current password is incorrect.");
    }
    record.passwordHash = await bcrypt.hash(pass, 12);
    store.write("panel-users", allUsers);
    const tokenUser = { ...user, services: record.services };
    return { token: jwt.sign(tokenUser, secret(), { expiresIn: getSettings().sessionTimeout * 60 }) };
  }

  if (user?.role === "admin" || username === a.username) {
    const rootPassword = username === "root" ? process.env.ROOT_PASSWORD : null;
    const validCurrent = (await bcrypt.compare(current, a.hash)) || (rootPassword && current === rootPassword);
    if (!validCurrent) throw validate.badRequest("Current password is incorrect.");
    // Back-date slightly so the replacement token remains valid at second precision.
    store.write("admin", { ...a, hash: await bcrypt.hash(pass, 12), passwordChangedAt: Date.now() - 1000 });
    syncAdminCredentialsRecord(username || a.username, pass);
    const tokenUser = { id: user?.id || 1, username: username || a.username, role: "admin" };
    return { token: jwt.sign(tokenUser, secret(), { expiresIn: getSettings().sessionTimeout * 60 }) };
  }

  const accounts = store.read("accounts", {});
  const account = accounts[username];
  if (!account) throw validate.badRequest("This account cannot change its password here.");
  const validCurrent = account.passwordHash
    ? await bcrypt.compare(current, account.passwordHash)
    : current === String(account.password || "");
  if (!validCurrent) throw validate.badRequest("Current password is incorrect.");
  if (shell.IS_LINUX) {
    await shell.run("chpasswd", { input: username + ":" + pass + "\n", user: username });
  }
  account.passwordHash = await bcrypt.hash(pass, 10);
  delete account.password;
  store.write("accounts", accounts);
  return { token: jwt.sign(user, secret(), { expiresIn: getSettings().sessionTimeout * 60 }) };
}

function getProfile(user) {
  const username = String(user?.username || "").trim().toLowerCase();
  const profiles = store.read("profiles", {});
  return profiles[username] || { name: "", email: "" };
}

function saveProfile(user, input = {}) {
  const username = String(user?.username || "").trim().toLowerCase();
  if (!username) throw validate.badRequest("A signed-in user is required.");
  const name = String(input.name || "").trim();
  if (name.length > 100) throw validate.badRequest("Name must be 100 characters or fewer.");
  const email = String(input.email || "").trim() ? validate.email(input.email).address : "";
  const profiles = store.read("profiles", {});
  profiles[username] = { name, email };
  return store.write("profiles", profiles)[username];
}

function listManagedUsers(user) {
  if (user?.role === "subuser") throw validate.badRequest("Only the account owner can manage users.");
  const users = store.read("panel-users", {})[ownerKey(user)] || {};
  return Object.values(users).map(publicSubuser);
}

async function createManagedUser(user, input = {}) {
  if (user?.role === "subuser") throw validate.badRequest("Only the account owner can manage users.");
  const username = String(input.username || "").trim().toLowerCase();
  if (!/^[a-z][a-z0-9_]{2,31}$/.test(username)) {
    throw validate.badRequest("Username must start with a letter and contain 3-32 lowercase letters, digits or underscores.");
  }
  const fullName = String(input.fullName || "").trim();
  if (!fullName || fullName.length > 100) throw validate.badRequest("Enter a name of 1-100 characters.");
  const email = validate.email(input.email).address;
  const pass = validate.password(input.password, 8);
  const services = {};
  for (const service of USER_SERVICES) services[service] = input.services?.[service] === true;

  const a = admin();
  if (username === a.username || username === "root" || store.read("accounts", {})[username] || findSubuser(username)) {
    throw validate.badRequest("That username is already in use.");
  }
  const owner = ownerKey(user);
  if (!owner) throw validate.badRequest("A signed-in user is required.");
  const allUsers = store.read("panel-users", {});
  const ownerUsers = allUsers[owner] || {};
  ownerUsers[username] = {
    username,
    fullName,
    email,
    passwordHash: await bcrypt.hash(pass, 12),
    services,
    createdAt: new Date().toISOString(),
  };
  allUsers[owner] = ownerUsers;
  store.write("panel-users", allUsers);
  return publicSubuser(ownerUsers[username]);
}

async function updateManagedUser(user, username, input = {}) {
  if (user?.role === "subuser") throw validate.badRequest("Only the account owner can manage users.");
  const owner = ownerKey(user);
  const target = String(username || "").trim().toLowerCase();
  const allUsers = store.read("panel-users", {});
  const record = allUsers[owner]?.[target];
  if (!record) throw Object.assign(new Error("User not found."), { status: 404 });

  if (input.fullName !== undefined) {
    const fullName = String(input.fullName || "").trim();
    if (!fullName || fullName.length > 100) throw validate.badRequest("Enter a name of 1-100 characters.");
    record.fullName = fullName;
  }
  if (input.email !== undefined) record.email = validate.email(input.email).address;
  if (input.services !== undefined) {
    record.services = { ...record.services };
    for (const service of USER_SERVICES) {
      if (input.services[service] !== undefined) {
        if (typeof input.services[service] !== "boolean") {
          throw validate.badRequest("Service permissions must be true or false.");
        }
        record.services[service] = input.services[service];
      }
    }
  }
  if (input.password) record.passwordHash = await bcrypt.hash(validate.password(input.password, 8), 12);
  store.write("panel-users", allUsers);
  return publicSubuser(record);
}

function deleteManagedUser(user, username) {
  if (user?.role === "subuser") throw validate.badRequest("Only the account owner can manage users.");
  const owner = ownerKey(user);
  const allUsers = store.read("panel-users", {});
  const ownerUsers = allUsers[owner] || {};
  const target = String(username || "").trim().toLowerCase();
  if (!ownerUsers[target]) throw Object.assign(new Error("User not found."), { status: 404 });
  delete ownerUsers[target];
  allUsers[owner] = ownerUsers;
  store.write("panel-users", allUsers);
  return { username: target };
}

function getSubuser(owner, username) {
  const record = store.read("panel-users", {})[String(owner || "").toLowerCase()]?.[String(username || "").toLowerCase()];
  return record || null;
}

module.exports = {
  login,
  verify,
  createSsoToken,
  changePassword,
  getSettings,
  saveSettings,
  getProfile,
  saveProfile,
  listManagedUsers,
  createManagedUser,
  updateManagedUser,
  deleteManagedUser,
  getSubuser,
  USER_SERVICES,
  secret,
};
