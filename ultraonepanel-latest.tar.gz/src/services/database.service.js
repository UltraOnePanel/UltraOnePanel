const shell = require("./shell.service");
const platform = require("../lib/platform");
const store = require("../lib/store");
const validate = require("../lib/validate");

const SYSTEM_DATABASES = new Set(["information_schema", "mysql", "performance_schema", "sys"]);
const SYSTEM_USERS = ["root", "mysql.session", "mysql.sys", "mysql.infoschema", "debian-sys-maint", "mariadb.sys", ""];

function lit(value) {
  return "'" + String(value).replace(/\\/g, "\\\\").replace(/'/g, "\\'") + "'";
}

function host(value) {
  const h = String(value || "localhost").trim();
  if (!/^[a-zA-Z0-9.%_:-]{1,255}$/.test(h)) throw validate.badRequest("Invalid host: " + value);
  return h;
}

async function sql(statements, opts = {}) {
  try {
    const out = await shell.runGet("mysql " + platform.MYSQL_ARGS, {
      ...opts,
      input: statements,
      env: platform.mysqlEnv(),
    });
    return out ? out.split("\n").map((l) => l.split("\t")) : [];
  } catch (e) {
    if (/Access denied/i.test(e.message)) {
      throw new Error("MySQL rejected the panel's root login. Set MYSQL_ROOT_PASSWORD in the panel .env file.");
    }
    throw e;
  }
}

// Local dev store
const dev = {
  get: () => store.read("dev-mysql", {
    databases: {},
    users: {},
    remoteHosts: ["192.168.1.%", "10.0.0.%"],
    postgresDbs: { "app_production": { owner: "app_user", size: "12 MB" } },
    postgresUsers: { "app_user": { created: new Date().toISOString() } },
  }),
  set: (fn) => store.update("dev-mysql", { databases: {}, users: {}, remoteHosts: [], postgresDbs: {}, postgresUsers: {} }, fn),
};

function formatSize(bytes) {
  bytes = Number(bytes) || 0;
  if (bytes >= 1073741824) return (bytes / 1073741824).toFixed(1) + " GB";
  if (bytes >= 1048576) return (bytes / 1048576).toFixed(1) + " MB";
  return Math.round(bytes / 1024) + " KB";
}

// -------------------------------------------------------------
// MYSQL DATABASES
// -------------------------------------------------------------
function isUserAllowedDatabase(dbName, dbUsers = [], user) {
  if (!user || user.role === "admin" || user.username === "root") return true;
  const username = (user.username || "").toLowerCase().trim();
  const name = (dbName || "").toLowerCase().trim();
  const uDomain = (user.domain || "").toLowerCase().trim();
  const safeDomain = uDomain.replace(/[^a-z0-9]/gi, "_");

  // 1. Explicit owner in meta store
  const meta = store.read("databases", {});
  if (meta[name] && meta[name].owner && meta[name].owner.toLowerCase() === username) {
    return true;
  }
  // 2. Prefix with username
  if (name.startsWith(username + "_") || name === username) {
    return true;
  }
  // 3. 8-char username prefix
  if (username.length >= 4 && name.startsWith(username.slice(0, 8) + "_")) {
    return true;
  }
  // 4. Domain-based matching (e.g. sql_sunvexaenergy_in)
  if (safeDomain && (name === "sql_" + safeDomain || name.includes(safeDomain))) {
    return true;
  }
  const domainPart = uDomain.split(".")[0];
  if (domainPart && domainPart.length >= 4 && name.includes(domainPart)) {
    return true;
  }
  // 5. Associated db users
  if (dbUsers.some((u) => {
    const uLower = (u || "").toLowerCase();
    return uLower === username || uLower.startsWith(username + "_") || (username.length >= 4 && uLower.startsWith(username.slice(0, 8) + "_"));
  })) {
    return true;
  }
  return false;
}

async function listDatabases(user) {
  let list = [];
  if (!shell.IS_LINUX) {
    const d = dev.get();
    list = Object.keys(d.databases).map((name) => ({
      name, size: "0 KB", sizeBytes: 0, tables: 0,
      users: Object.keys(d.users).filter((u) => d.users[u].databases.includes(name)),
    }));
  } else {
    const [names, sizes, grants] = await Promise.all([
      sql("SHOW DATABASES;"),
      sql("SELECT table_schema, COALESCE(SUM(data_length + index_length),0), COUNT(*) FROM information_schema.tables GROUP BY table_schema;"),
      sql("SELECT Db, User FROM mysql.db;"),
    ]);
    const sizeMap = new Map(sizes.map(([db, bytes, count]) => [db, { bytes: Number(bytes), count: Number(count) }]));
    list = names
      .map(([name]) => name)
      .filter((name) => name && !SYSTEM_DATABASES.has(name))
      .map((name) => {
        const s = sizeMap.get(name) || { bytes: 0, count: 0 };
        const users = grants
          .filter(([db]) => db.replace(/\\_/g, "_") === name)
          .map(([, u]) => u)
          .filter((u, i, all) => all.indexOf(u) === i);
        return { name, size: formatSize(s.bytes), sizeBytes: s.bytes, tables: s.count, users };
      });
  }
  if (user && user.role !== "admin" && user.username !== "root") {
    list = list.filter((db) => isUserAllowedDatabase(db.name, db.users, user));
  }
  return list;
}

async function createDatabase({ name, dbUser, dbPass, user = "system", currentUser }) {
  const db = validate.identifier(name, "Database name", 64);
  if (SYSTEM_DATABASES.has(db.toLowerCase())) throw validate.badRequest("Reserved database name.");

  if (currentUser && currentUser.role !== "admin" && currentUser.username !== "root") {
    store.update("databases", {}, (dbs) => {
      dbs[db.toLowerCase()] = { owner: currentUser.username, created: new Date().toISOString() };
    });
  }

  if (!shell.IS_LINUX) {
    if (dev.get().databases[db]) throw validate.badRequest("Database " + db + " already exists.");
    dev.set((d) => { d.databases[db] = { created: new Date().toISOString() }; });
  } else {
    const exists = await sql("SHOW DATABASES LIKE " + lit(db) + ";");
    if (exists.length) throw validate.badRequest("Database " + db + " already exists.");
    await sql("CREATE DATABASE `" + db + "` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;", { user });
  }
  if (dbUser) await createDatabaseUser({ username: dbUser, password: dbPass, database: db, user, currentUser });
  return { name: db, user: dbUser || null, status: "created" };
}

async function deleteDatabase({ name, user = "system", currentUser }) {
  const db = validate.identifier(name, "Database name", 64);
  if (SYSTEM_DATABASES.has(db.toLowerCase())) throw validate.badRequest("System databases cannot be dropped.");
  if (currentUser && currentUser.role !== "admin" && currentUser.username !== "root") {
    if (!isUserAllowedDatabase(db, [], currentUser)) {
      throw validate.badRequest("Permission denied: You do not have permission to delete this database.");
    }
  }
  if (!shell.IS_LINUX) {
    dev.set((d) => {
      delete d.databases[db];
      Object.values(d.users).forEach((u) => { u.databases = u.databases.filter((x) => x !== db); });
    });
    return { name: db, status: "deleted" };
  }
  await sql("DROP DATABASE IF EXISTS `" + db + "`; DELETE FROM mysql.db WHERE Db = " + lit(db) + "; FLUSH PRIVILEGES;", { user });
  return { name: db, status: "deleted" };
}

async function listDatabaseUsers(user) {
  let list = [];
  if (!shell.IS_LINUX) {
    const d = dev.get();
    list = Object.keys(d.users).map((u) => ({ user: u, username: u, host: d.users[u].host, databases: d.users[u].databases }));
  } else {
    const [users, grants] = await Promise.all([
      sql("SELECT User, Host FROM mysql.user WHERE User NOT IN (" + SYSTEM_USERS.map(lit).join(",") + ");"),
      sql("SELECT User, Host, Db FROM mysql.db;"),
    ]);
    list = users.map(([u, h]) => ({
      user: u,
      username: u,
      host: h,
      databases: grants.filter(([gu, gh]) => gu === u && gh === h).map(([, , db]) => db.replace(/\\_/g, "_")),
    }));
  }
  if (user && user.role !== "admin" && user.username !== "root") {
    const username = (user.username || "").toLowerCase().trim();
    list = list.filter((u) => {
      const un = (u.username || "").toLowerCase().trim();
      return un === username || un.startsWith(username + "_") || (username.length >= 4 && un.startsWith(username.slice(0, 8) + "_"));
    });
  }
  return list;
}

async function createDatabaseUser({ username, password, host: h = "localhost", database, user = "system" }) {
  const u = validate.identifier(username, "Username", 32);
  if (SYSTEM_USERS.includes(u)) throw validate.badRequest("Reserved username.");
  const pass = validate.password(password, 8);
  h = host(h);

  if (!shell.IS_LINUX) {
    dev.set((d) => {
      d.users[u] = d.users[u] || { host: h, databases: [] };
      if (database && !d.users[u].databases.includes(database)) d.users[u].databases.push(database);
    });
    return { user: u, host: h, database: database || null, status: "created" };
  }

  const existing = await sql("SELECT COUNT(*) FROM mysql.user WHERE User = " + lit(u) + " AND Host = " + lit(h) + ";");
  if (Number(existing[0][0]) > 0) throw validate.badRequest("User " + u + "@" + h + " already exists.");
  let statements = "CREATE USER " + lit(u) + "@" + lit(h) + " IDENTIFIED BY " + lit(pass) + ";";
  if (database) {
    const db = validate.identifier(database, "Database name", 64);
    statements += " GRANT ALL PRIVILEGES ON `" + db + "`.* TO " + lit(u) + "@" + lit(h) + ";";
  }
  await sql(statements + " FLUSH PRIVILEGES;", { user });
  return { user: u, host: h, database: database || null, status: "created" };
}

async function grantDatabase({ username, host: h = "localhost", database, privileges = ["ALL"], user = "system" }) {
  const u = validate.identifier(username, "Username", 32);
  const db = validate.identifier(database, "Database name", 64);
  h = host(h);
  if (!shell.IS_LINUX) {
    dev.set((d) => { if (d.users[u] && !d.users[u].databases.includes(db)) d.users[u].databases.push(db); });
    return { user: u, database: db, status: "granted" };
  }
  const privList = Array.isArray(privileges) ? privileges : [privileges || "ALL"];
  const privStr = privList.includes("ALL") || privList.includes("ALL PRIVILEGES") ? "ALL PRIVILEGES" : privList.join(", ");
  await sql(`GRANT ${privStr} ON \`${db}\`.* TO ` + lit(u) + "@" + lit(h) + "; FLUSH PRIVILEGES;", { user });
  if (h === "localhost") {
    try {
      await sql(`GRANT ${privStr} ON \`${db}\`.* TO ` + lit(u) + "@'127.0.0.1'; FLUSH PRIVILEGES;", { user });
    } catch (_) {}
  }
  return { user: u, database: db, status: "granted" };
}

async function deleteDatabaseUser({ username, host: h = "localhost", user = "system" }) {
  const u = validate.identifier(username, "Username", 32);
  if (SYSTEM_USERS.includes(u)) throw validate.badRequest("System users cannot be deleted.");
  h = host(h);
  if (!shell.IS_LINUX) {
    dev.set((d) => { delete d.users[u]; });
    return { user: u, status: "deleted" };
  }
  await sql("DROP USER IF EXISTS " + lit(u) + "@" + lit(h) + "; FLUSH PRIVILEGES;", { user });
  if (h === "localhost") {
    try {
      await sql("DROP USER IF EXISTS " + lit(u) + "@'127.0.0.1'; FLUSH PRIVILEGES;", { user });
    } catch (_) {}
  }
  return { user: u, status: "deleted" };
}

async function changeUserPassword({ username, password, host: h = "localhost", user = "system" }) {
  const u = validate.identifier(username, "Username", 32);
  if (SYSTEM_USERS.includes(u)) throw validate.badRequest("System users cannot be changed here.");
  const pass = validate.password(password, 8);
  h = host(h);
  if (!shell.IS_LINUX) return { user: u, status: "password changed" };
  await sql("ALTER USER " + lit(u) + "@" + lit(h) + " IDENTIFIED BY " + lit(pass) + "; FLUSH PRIVILEGES;", { user });
  if (h === "localhost") {
    try {
      await sql("ALTER USER " + lit(u) + "@'127.0.0.1' IDENTIFIED BY " + lit(pass) + "; FLUSH PRIVILEGES;", { user });
    } catch (_) {}
  }
  return { user: u, status: "password changed" };
}

// -------------------------------------------------------------
// REMOTE MYSQL
// -------------------------------------------------------------
async function listRemoteHosts() {
  if (!shell.IS_LINUX) {
    return dev.get().remoteHosts || [];
  }
  try {
    const rows = await sql("SELECT DISTINCT Host FROM mysql.user WHERE Host NOT IN ('localhost', '127.0.0.1', '::1');");
    return rows.map(([h]) => h).filter(Boolean);
  } catch (_) {
    return [];
  }
}

async function addRemoteHost({ host: remoteHost, user = "system" }) {
  remoteHost = host(remoteHost);
  if (!shell.IS_LINUX) {
    dev.set((d) => {
      d.remoteHosts = d.remoteHosts || [];
      if (!d.remoteHosts.includes(remoteHost)) d.remoteHosts.push(remoteHost);
    });
    return { host: remoteHost, status: "added" };
  }
  // Enable bind-address = 0.0.0.0 in my.cnf if needed
  try {
    await shell.run(`sed -i 's/^bind-address.*/bind-address = 0.0.0.0/' /etc/mysql/mysql.conf.d/mysqld.cnf 2>/dev/null || true`, { user });
  } catch (_) {}
  return { host: remoteHost, status: "added" };
}

async function deleteRemoteHost({ host: remoteHost, user = "system" }) {
  remoteHost = host(remoteHost);
  if (!shell.IS_LINUX) {
    dev.set((d) => {
      d.remoteHosts = (d.remoteHosts || []).filter((h) => h !== remoteHost);
    });
    return { host: remoteHost, status: "deleted" };
  }
  await sql(`DELETE FROM mysql.user WHERE Host = ${lit(remoteHost)}; FLUSH PRIVILEGES;`, { user });
  return { host: remoteHost, status: "deleted" };
}

// -------------------------------------------------------------
// POSTGRESQL DATABASES & WIZARD
// -------------------------------------------------------------
async function listPostgresDatabases() {
  if (!shell.IS_LINUX) {
    const d = dev.get();
    return Object.entries(d.postgresDbs || {}).map(([name, info]) => ({
      name,
      owner: info.owner || "postgres",
      size: info.size || "10 MB",
      encoding: "UTF8",
    }));
  }
  try {
    const out = await shell.tryGet("sudo -u postgres psql -t -A -F ',' -c 'SELECT datname, pg_get_userbyid(datdba), pg_size_pretty(pg_database_size(datname)), pg_encoding_to_char(encoding) FROM pg_database WHERE datistemplate = false;'");
    const lines = out.split("\n").filter(Boolean);
    return lines.map((l) => {
      const [name, owner, size, encoding] = l.split(",");
      return { name, owner, size, encoding };
    });
  } catch (_) {
    return [];
  }
}

async function createPostgresDatabase({ name, user: pgUser, password: pgPassword }) {
  const dbName = validate.identifier(name, "Database name", 64);
  if (!shell.IS_LINUX) {
    dev.set((d) => {
      d.postgresDbs = d.postgresDbs || {};
      d.postgresDbs[dbName] = { owner: pgUser || "postgres", size: "8 KB" };
      if (pgUser) {
        d.postgresUsers = d.postgresUsers || {};
        d.postgresUsers[pgUser] = { created: new Date().toISOString() };
      }
    });
    return { name: dbName, user: pgUser, status: "created" };
  }

  if (pgUser && pgPassword) {
    const u = validate.identifier(pgUser, "Username", 32);
    await shell.run(`sudo -u postgres psql -c "CREATE USER \\"${u}\\" WITH ENCRYPTED PASSWORD '${pgPassword}';" 2>/dev/null || true`);
    await shell.run(`sudo -u postgres psql -c "CREATE DATABASE \\"${dbName}\\" OWNER \\"${u}\\";"`);
  } else {
    await shell.run(`sudo -u postgres psql -c "CREATE DATABASE \\"${dbName}\\";"`);
  }
  return { name: dbName, user: pgUser, status: "created" };
}

async function deletePostgresDatabase(name) {
  const dbName = validate.identifier(name, "Database name", 64);
  if (!shell.IS_LINUX) {
    dev.set((d) => {
      delete (d.postgresDbs || {})[dbName];
    });
    return { name: dbName, status: "deleted" };
  }
  await shell.run(`sudo -u postgres psql -c "DROP DATABASE IF EXISTS \\"${dbName}\\";"`);
  return { name: dbName, status: "deleted" };
}

async function listPostgresUsers() {
  if (!shell.IS_LINUX) {
    const d = dev.get();
    return Object.keys(d.postgresUsers || {}).map((u) => ({ username: u }));
  }
  try {
    const out = await shell.tryGet("sudo -u postgres psql -t -A -c 'SELECT usename FROM pg_user;'");
    return out.split("\n").filter(Boolean).map((u) => ({ username: u }));
  } catch (_) {
    return [];
  }
}

function exportDatabase(name) {
  const db = validate.identifier(name, "Database name", 64);
  if (!shell.IS_LINUX) throw new Error("Database export is only available on the server.");
  return shell.spawnStream("mysqldump", ["-uroot", "--single-transaction", "--routines", "--triggers", db], { env: platform.mysqlEnv() });
}

async function importDatabase({ name, sqlText, user = "system" }) {
  const db = validate.identifier(name, "Database name", 64);
  if (!sqlText || !sqlText.length) throw validate.badRequest("The uploaded SQL file is empty.");
  if (!shell.IS_LINUX) return { name: db, status: "imported (dev-skip)" };
  await shell.run("mysql -uroot " + shell.q(db), { input: sqlText, env: platform.mysqlEnv(), timeout: 600000, user });
  return { name: db, status: "imported", bytes: sqlText.length };
}

function phpMyAdminUrl(hostHeader) {
  if (process.env.PHPMYADMIN_URL) return process.env.PHPMYADMIN_URL;
  return "/phpmyadmin/";
}

function phpPgAdminUrl(hostHeader) {
  if (process.env.PHPPGADMIN_URL) return process.env.PHPPGADMIN_URL;
  return "/phppgadmin/";
}

module.exports = {
  listDatabases,
  createDatabase,
  deleteDatabase,
  listDatabaseUsers,
  createDatabaseUser,
  grantDatabase,
  deleteDatabaseUser,
  changeUserPassword,
  exportDatabase,
  importDatabase,
  phpMyAdminUrl,
  phpPgAdminUrl,
  sql,
  // Remote MySQL
  listRemoteHosts,
  addRemoteHost,
  deleteRemoteHost,
  // PostgreSQL
  listPostgresDatabases,
  createPostgresDatabase,
  deletePostgresDatabase,
  listPostgresUsers,
};
