const crypto = require("crypto");
const shell = require("./shell.service");
const platform = require("../lib/platform");
const store = require("../lib/store");
const validate = require("../lib/validate");

const SYSTEM_DATABASES = new Set(["information_schema", "mysql", "performance_schema", "sys"]);
const SYSTEM_USERS = ["root", "mysql.session", "mysql.sys", "mysql.infoschema", "debian-sys-maint", "mariadb.sys", ""];

function lit(value) {
  return "'" + String(value).replace(/\\/g, "\\\\").replace(/'/g, "\\'") + "'";
}

function host(value) {
  const h = String(value || "localhost").trim();
  if (!/^[a-zA-Z0-9.%_:-]{1,255}$/.test(h)) throw validate.badRequest("Invalid host: " + value);
  return h;
}

async function sql(statements, opts = {}) {
  try {
    const out = await shell.runGet("mysql " + platform.MYSQL_ARGS, {
      ...opts,
      input: statements,
      env: platform.mysqlEnv(),
    });
    return out ? out.split("\n").map((l) => l.split("\t")) : [];
  } catch (e) {
    if (/Access denied/i.test(e.message)) {
      throw new Error("MySQL rejected the panel's root login. Set MYSQL_ROOT_PASSWORD in the panel .env file.");
    }
    throw e;
  }
}

// Local dev store
const dev = {
  get: () => store.read("dev-mysql", {
    databases: {},
    users: {},
    remoteHosts: ["192.168.1.%", "10.0.0.%"],
    postgresDbs: { "app_production": { owner: "app_user", size: "12 MB" } },
    postgresUsers: { "app_user": { created: new Date().toISOString() } },
  }),
  set: (fn) => store.update("dev-mysql", { databases: {}, users: {}, remoteHosts: [], postgresDbs: {}, postgresUsers: {} }, fn),
};

function formatSize(bytes) {
  bytes = Number(bytes) || 0;
  if (bytes >= 1073741824) return (bytes / 1073741824).toFixed(1) + " GB";
  if (bytes >= 1048576) return (bytes / 1048576).toFixed(1) + " MB";
  return Math.round(bytes / 1024) + " KB";
}

// -------------------------------------------------------------
// MYSQL DATABASES
// -------------------------------------------------------------
function isUserAllowedDatabase(dbName, dbUsers = [], user) {
  if (!user || user.role === "admin" || user.username === "root") return true;
  const username = (user.username || "").toLowerCase().trim();
  const name = (dbName || "").toLowerCase().trim();
  const uDomain = (user.domain || "").toLowerCase().trim();
  const safeDomain = uDomain.replace(/[^a-z0-9]/gi, "_");

  // 1. Explicit owner in meta store
  const meta = store.read("databases", {});
  if (meta[name] && meta[name].owner && meta[name].owner.toLowerCase() === username) {
    return true;
  }
  // 2. Prefix with username
  if (name.startsWith(username + "_") || name === username) {
    return true;
  }
  // 3. 8-char username prefix
  if (username.length >= 4 && name.startsWith(username.slice(0, 8) + "_")) {
    return true;
  }
  // 4. Domain-based matching (e.g. sql_sunvexaenergy_in)
  if (safeDomain && (name === "sql_" + safeDomain || name.includes(safeDomain))) {
    return true;
  }
  const domainPart = uDomain.split(".")[0];
  if (domainPart && domainPart.length >= 4 && name.includes(domainPart)) {
    return true;
  }
  // 5. Associated db users
  if (dbUsers.some((u) => {
    const uLower = (u || "").toLowerCase();
    return uLower === username || uLower.startsWith(username + "_") || (username.length >= 4 && uLower.startsWith(username.slice(0, 8) + "_"));
  })) {
    return true;
  }
  return false;
}

async function listDatabases(user) {
  let list = [];
  if (!shell.IS_LINUX) {
    const d = dev.get();
    list = Object.keys(d.databases).map((name) => ({
      name, size: "0 KB", sizeBytes: 0, tables: 0,
      users: Object.keys(d.users).filter((u) => d.users[u].databases.includes(name)),
    }));
  } else {
    const [names, sizes, grants] = await Promise.all([
      sql("SHOW DATABASES;"),
      sql("SELECT table_schema, COALESCE(SUM(data_length + index_length),0), COUNT(*) FROM information_schema.tables GROUP BY table_schema;"),
      sql("SELECT Db, User FROM mysql.db;"),
    ]);
    const sizeMap = new Map(sizes.map(([db, bytes, count]) => [db, { bytes: Number(bytes), count: Number(count) }]));
    list = names
      .map(([name]) => name)
      .filter((name) => name && !SYSTEM_DATABASES.has(name))
      .map((name) => {
        const s = sizeMap.get(name) || { bytes: 0, count: 0 };
        const users = grants
          .filter(([db]) => db.replace(/\\_/g, "_") === name)
          .map(([, u]) => u)
          .filter((u, i, all) => all.indexOf(u) === i);
        return { name, size: formatSize(s.bytes), sizeBytes: s.bytes, tables: s.count, users };
      });
  }
  if (user && user.role !== "admin" && user.username !== "root") {
    list = list.filter((db) => isUserAllowedDatabase(db.name, db.users, user));
  }
  return list;
}

async function createDatabase({ name, dbUser, dbPass, user = "system", currentUser }) {
  const db = validate.identifier(name, "Database name", 64);
  if (SYSTEM_DATABASES.has(db.toLowerCase())) throw validate.badRequest("Reserved database name.");

  if (currentUser && currentUser.role !== "admin" && currentUser.username !== "root") {
    store.update("databases", {}, (dbs) => {
      dbs[db.toLowerCase()] = { owner: currentUser.username, created: new Date().toISOString() };
    });
  }

  if (!shell.IS_LINUX) {
    if (dev.get().databases[db]) throw validate.badRequest("Database " + db + " already exists.");
    dev.set((d) => { d.databases[db] = { created: new Date().toISOString() }; });
  } else {
    const exists = await sql("SHOW DATABASES LIKE " + lit(db) + ";");
    if (exists.length) throw validate.badRequest("Database " + db + " already exists.");
    await sql("CREATE DATABASE `" + db + "` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;", { user });
  }
  if (dbUser) await createDatabaseUser({ username: dbUser, password: dbPass, database: db, user, currentUser });
  return { name: db, user: dbUser || null, status: "created" };
}

async function deleteDatabase({ name, user = "system", currentUser }) {
  const db = validate.identifier(name, "Database name", 64);
  if (SYSTEM_DATABASES.has(db.toLowerCase())) throw validate.badRequest("System databases cannot be dropped.");
  if (currentUser && currentUser.role !== "admin" && currentUser.username !== "root") {
    if (!isUserAllowedDatabase(db, [], currentUser)) {
      throw validate.badRequest("Permission denied: You do not have permission to delete this database.");
    }
  }
  if (!shell.IS_LINUX) {
    dev.set((d) => {
      delete d.databases[db];
      Object.values(d.users).forEach((u) => { u.databases = u.databases.filter((x) => x !== db); });
    });
    return { name: db, status: "deleted" };
  }
  await sql("DROP DATABASE IF EXISTS `" + db + "`; DELETE FROM mysql.db WHERE Db = " + lit(db) + "; FLUSH PRIVILEGES;", { user });
  return { name: db, status: "deleted" };
}

async function listDatabaseUsers(user) {
  let list = [];
  if (!shell.IS_LINUX) {
    const d = dev.get();
    list = Object.keys(d.users).map((u) => ({ user: u, username: u, host: d.users[u].host, databases: d.users[u].databases }));
  } else {
    const [users, grants] = await Promise.all([
      sql("SELECT User, Host FROM mysql.user WHERE User NOT IN (" + SYSTEM_USERS.map(lit).join(",") + ");"),
      sql("SELECT User, Host, Db FROM mysql.db;"),
    ]);
    list = users.map(([u, h]) => ({
      user: u,
      username: u,
      host: h,
      databases: grants.filter(([gu, gh]) => gu === u && gh === h).map(([, , db]) => db.replace(/\\_/g, "_")),
    }));
  }
  if (user && user.role !== "admin" && user.username !== "root") {
    const username = (user.username || "").toLowerCase().trim();
    list = list.filter((u) => {
      const un = (u.username || "").toLowerCase().trim();
      return un === username || un.startsWith(username + "_") || (username.length >= 4 && un.startsWith(username.slice(0, 8) + "_"));
    });
  }
  return list;
}

async function createDatabaseUser({ username, password, host: h = "localhost", database, user = "system" }) {
  const u = validate.identifier(username, "Username", 32);
  if (SYSTEM_USERS.includes(u)) throw validate.badRequest("Reserved username.");
  const pass = validate.password(password, 8);
  h = host(h);

  if (!shell.IS_LINUX) {
    dev.set((d) => {
      d.users[u] = d.users[u] || { host: h, databases: [] };
      if (database && !d.users[u].databases.includes(database)) d.users[u].databases.push(database);
    });
    return { user: u, host: h, database: database || null, status: "created" };
  }

  const existing = await sql("SELECT COUNT(*) FROM mysql.user WHERE User = " + lit(u) + " AND Host = " + lit(h) + ";");
  if (Number(existing[0][0]) > 0) throw validate.badRequest("User " + u + "@" + h + " already exists.");
  let statements = "CREATE USER " + lit(u) + "@" + lit(h) + " IDENTIFIED BY " + lit(pass) + ";";
  if (database) {
    const db = validate.identifier(database, "Database name", 64);
    statements += " GRANT ALL PRIVILEGES ON `" + db + "`.* TO " + lit(u) + "@" + lit(h) + ";";
  }
  await sql(statements + " FLUSH PRIVILEGES;", { user });
  return { user: u, host: h, database: database || null, status: "created" };
}

async function grantDatabase({ username, host: h = "localhost", database, privileges = ["ALL"], user = "system" }) {
  const u = validate.identifier(username, "Username", 32);
  const db = validate.identifier(database, "Database name", 64);
  h = host(h);
  if (!shell.IS_LINUX) {
    dev.set((d) => { if (d.users[u] && !d.users[u].databases.includes(db)) d.users[u].databases.push(db); });
    return { user: u, database: db, status: "granted" };
  }
  const privList = Array.isArray(privileges) ? privileges : [privileges || "ALL"];
  const privStr = privList.includes("ALL") || privList.includes("ALL PRIVILEGES") ? "ALL PRIVILEGES" : privList.join(", ");
  await sql(`GRANT ${privStr} ON \`${db}\`.* TO ` + lit(u) + "@" + lit(h) + "; FLUSH PRIVILEGES;", { user });
  if (h === "localhost") {
    try {
      await sql(`GRANT ${privStr} ON \`${db}\`.* TO ` + lit(u) + "@'127.0.0.1'; FLUSH PRIVILEGES;", { user });
    } catch (_) {}
  }
  return { user: u, database: db, status: "granted" };
}

async function deleteDatabaseUser({ username, host: h = "localhost", user = "system" }) {
  const u = validate.identifier(username, "Username", 32);
  if (SYSTEM_USERS.includes(u)) throw validate.badRequest("System users cannot be deleted.");
  h = host(h);
  if (!shell.IS_LINUX) {
    dev.set((d) => { delete d.users[u]; });
    return { user: u, status: "deleted" };
  }
  await sql("DROP USER IF EXISTS " + lit(u) + "@" + lit(h) + "; FLUSH PRIVILEGES;", { user });
  if (h === "localhost") {
    try {
      await sql("DROP USER IF EXISTS " + lit(u) + "@'127.0.0.1'; FLUSH PRIVILEGES;", { user });
    } catch (_) {}
  }
  return { user: u, status: "deleted" };
}

async function changeUserPassword({ username, password, host: h = "localhost", user = "system" }) {
  const u = validate.identifier(username, "Username", 32);
  if (SYSTEM_USERS.includes(u)) throw validate.badRequest("System users cannot be changed here.");
  const pass = validate.password(password, 8);
  h = host(h);
  if (!shell.IS_LINUX) return { user: u, status: "password changed" };
  await sql("ALTER USER " + lit(u) + "@" + lit(h) + " IDENTIFIED BY " + lit(pass) + "; FLUSH PRIVILEGES;", { user });
  if (h === "localhost") {
    try {
      await sql("ALTER USER " + lit(u) + "@'127.0.0.1' IDENTIFIED BY " + lit(pass) + "; FLUSH PRIVILEGES;", { user });
    } catch (_) {}
  }
  return { user: u, status: "password changed" };
}

// -------------------------------------------------------------
// REMOTE MYSQL
// -------------------------------------------------------------
async function listRemoteHosts() {
  if (!shell.IS_LINUX) {
    return dev.get().remoteHosts || [];
  }
  try {
    const rows = await sql("SELECT DISTINCT Host FROM mysql.user WHERE Host NOT IN ('localhost', '127.0.0.1', '::1');");
    return rows.map(([h]) => h).filter(Boolean);
  } catch (_) {
    return [];
  }
}

async function addRemoteHost({ host: remoteHost, user = "system" }) {
  remoteHost = host(remoteHost);
  if (!shell.IS_LINUX) {
    dev.set((d) => {
      d.remoteHosts = d.remoteHosts || [];
      if (!d.remoteHosts.includes(remoteHost)) d.remoteHosts.push(remoteHost);
    });
    return { host: remoteHost, status: "added" };
  }
  // Enable bind-address = 0.0.0.0 in my.cnf if needed
  try {
    await shell.run(`sed -i 's/^bind-address.*/bind-address = 0.0.0.0/' /etc/mysql/mysql.conf.d/mysqld.cnf 2>/dev/null || true`, { user });
  } catch (_) {}
  return { host: remoteHost, status: "added" };
}

async function deleteRemoteHost({ host: remoteHost, user = "system" }) {
  remoteHost = host(remoteHost);
  if (!shell.IS_LINUX) {
    dev.set((d) => {
      d.remoteHosts = (d.remoteHosts || []).filter((h) => h !== remoteHost);
    });
    return { host: remoteHost, status: "deleted" };
  }
  await sql(`DELETE FROM mysql.user WHERE Host = ${lit(remoteHost)}; FLUSH PRIVILEGES;`, { user });
  return { host: remoteHost, status: "deleted" };
}

// -------------------------------------------------------------
// POSTGRESQL DATABASES & USERS
// -------------------------------------------------------------
async function pgSql(statements, opts = {}) {
  try {
    const out = await shell.runGet("cd /tmp && sudo -u postgres psql -v ON_ERROR_STOP=1 -t -A", {
      ...opts,
      cwd: "/tmp",
      input: statements,
    });
    return out ? out.split("\n").map((l) => l.trim()).filter(Boolean) : [];
  } catch (e) {
    const msg = (e.stderr || e.message || "").trim();
    if (/database .* already exists/i.test(msg)) {
      throw validate.badRequest("Database already exists.");
    }
    if (/role .* already exists/i.test(msg)) {
      throw validate.badRequest("Database user already exists.");
    }
    if (/database .* does not exist/i.test(msg)) {
      throw validate.badRequest("Database does not exist.");
    }
    throw new Error(msg || "PostgreSQL command failed.");
  }
}

async function listPostgresDatabases(currentUser) {
  let list = [];
  if (!shell.IS_LINUX) {
    const d = dev.get();
    list = Object.entries(d.postgresDbs || {}).map(([name, info]) => ({
      name,
      owner: info.owner || "postgres",
      size: info.size || "10 MB",
      encoding: "UTF8",
    }));
  } else {
    try {
      const out = await shell.runGet("cd /tmp && sudo -u postgres psql -v ON_ERROR_STOP=1 -t -A -F ','", {
        cwd: "/tmp",
        input: "SELECT datname, pg_get_userbyid(datdba), pg_size_pretty(pg_database_size(datname)), pg_encoding_to_char(encoding) FROM pg_database WHERE datistemplate = false;",
      });
      const lines = (out || "").split("\n").map((l) => l.trim()).filter(Boolean);
      list = lines.map((l) => {
        const [name, owner, size, encoding] = l.split(",");
        return { name, owner: owner || "postgres", size: size || "8 KB", encoding: encoding || "UTF8" };
      });
    } catch (_) {
      list = [];
    }
  }

  // Multi-tenant isolation for normal account users
  if (currentUser && currentUser.role !== "admin" && currentUser.username !== "root") {
    const uname = (currentUser.username || "").toLowerCase().trim();
    const meta = store.read("postgres-databases", {});
    list = list.filter((db) => {
      const dbLower = (db.name || "").toLowerCase();
      if (dbLower.startsWith(uname + "_") || dbLower === uname) return true;
      if (db.owner && db.owner.toLowerCase() === uname) return true;
      if (meta[dbLower] && meta[dbLower].owner && meta[dbLower].owner.toLowerCase() === uname) return true;
      return false;
    });
  }

  return list;
}

async function createPostgresDatabase({ name, user: pgUser, password: pgPassword, currentUser, auditUser = "system" }) {
  if (!name || typeof name !== "string") throw validate.badRequest("Database name is required.");

  let cleanName = name.trim().toLowerCase();
  // Auto prefix for regular users if not already prefixed
  if (currentUser && currentUser.role !== "admin" && currentUser.username !== "root") {
    const prefix = currentUser.username.toLowerCase() + "_";
    if (!cleanName.startsWith(prefix)) {
      cleanName = prefix + cleanName;
    }
  }

  const dbName = validate.identifier(cleanName, "Database name", 64);
  const reserved = new Set(["postgres", "template0", "template1"]);
  if (reserved.has(dbName)) throw validate.badRequest("Reserved database name.");

  let cleanUser = (pgUser || "").trim().toLowerCase();
  if (cleanUser && currentUser && currentUser.role !== "admin" && currentUser.username !== "root") {
    const prefix = currentUser.username.toLowerCase() + "_";
    if (!cleanUser.startsWith(prefix) && cleanUser !== currentUser.username.toLowerCase()) {
      cleanUser = prefix + cleanUser;
    }
  }
  const u = cleanUser ? validate.identifier(cleanUser, "Username", 32) : null;
  const pw = pgPassword ? String(pgPassword) : null;

  if (!shell.IS_LINUX) {
    dev.set((d) => {
      d.postgresDbs = d.postgresDbs || {};
      d.postgresDbs[dbName] = { owner: u || "postgres", size: "8 KB" };
      if (u) {
        d.postgresUsers = d.postgresUsers || {};
        d.postgresUsers[u] = { created: new Date().toISOString() };
      }
    });
    store.update("postgres-databases", {}, (dbs) => {
      dbs[dbName] = {
        owner: (currentUser && currentUser.username) || u || "postgres",
        created: new Date().toISOString(),
      };
    });
    return { name: dbName, user: u, status: "created" };
  }

  // 1. Check if database already exists
  const checkOut = await shell.runGet("cd /tmp && sudo -u postgres psql -v ON_ERROR_STOP=1 -t -A", {
    cwd: "/tmp",
    input: `SELECT 1 FROM pg_database WHERE datname = '${dbName}';`,
  }).catch(() => "");
  if (checkOut.trim() === "1") {
    throw validate.badRequest(`Database '${dbName}' already exists.`);
  }

  // 2. Prepare SQL commands with dollar quoting to prevent any escaping issues
  const sqlCommands = [];
  if (u && pw) {
    sqlCommands.push(`
DO $$
BEGIN
  IF NOT EXISTS (SELECT FROM pg_catalog.pg_roles WHERE rolname = '${u}') THEN
    CREATE ROLE "${u}" WITH LOGIN PASSWORD $pwd$${pw}$pwd$;
  ELSE
    ALTER ROLE "${u}" WITH LOGIN PASSWORD $pwd$${pw}$pwd$;
  END IF;
END
$$;
    `);
  } else if (u) {
    sqlCommands.push(`
DO $$
BEGIN
  IF NOT EXISTS (SELECT FROM pg_catalog.pg_roles WHERE rolname = '${u}') THEN
    CREATE ROLE "${u}" WITH LOGIN;
  END IF;
END
$$;
    `);
  }

  sqlCommands.push(`CREATE DATABASE "${dbName}" ${u ? `OWNER "${u}"` : ""} ENCODING 'UTF8';`);
  if (u) {
    sqlCommands.push(`GRANT ALL PRIVILEGES ON DATABASE "${dbName}" TO "${u}";`);
  }

  await pgSql(sqlCommands.join("\n"), { user: auditUser });

  // Store metadata
  store.update("postgres-databases", {}, (dbs) => {
    dbs[dbName] = {
      owner: (currentUser && currentUser.username) || u || "postgres",
      created: new Date().toISOString(),
    };
  });

  return { name: dbName, user: u, status: "created" };
}

async function deletePostgresDatabase({ name, currentUser, auditUser = "system" }) {
  if (!name || typeof name !== "string") throw validate.badRequest("Database name is required.");
  const dbName = validate.identifier(name.trim().toLowerCase(), "Database name", 64);
  const reserved = new Set(["postgres", "template0", "template1"]);
  if (reserved.has(dbName)) throw validate.badRequest("System database cannot be dropped.");

  if (currentUser && currentUser.role !== "admin" && currentUser.username !== "root") {
    const uname = currentUser.username.toLowerCase();
    const meta = store.read("postgres-databases", {});
    const isOwner = (meta[dbName] && meta[dbName].owner && meta[dbName].owner.toLowerCase() === uname) ||
      dbName.startsWith(uname + "_");
    if (!isOwner) throw validate.badRequest("Permission denied: You do not have permission to delete this database.");
  }

  if (!shell.IS_LINUX) {
    dev.set((d) => {
      delete (d.postgresDbs || {})[dbName];
    });
    store.update("postgres-databases", {}, (dbs) => {
      delete dbs[dbName];
    });
    return { name: dbName, status: "deleted" };
  }

  // Terminate any active connections and drop with force
  await pgSql(`SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE datname = '${dbName}' AND pid <> pg_backend_pid();`, { user: auditUser }).catch(() => {});
  await pgSql(`DROP DATABASE IF EXISTS "${dbName}" WITH (FORCE);`, { user: auditUser });

  store.update("postgres-databases", {}, (dbs) => {
    delete dbs[dbName];
  });

  return { name: dbName, status: "deleted" };
}

async function listPostgresUsers(currentUser) {
  let list = [];
  if (!shell.IS_LINUX) {
    const d = dev.get();
    list = Object.keys(d.postgresUsers || {}).map((u) => ({ username: u }));
  } else {
    try {
      const out = await shell.runGet("cd /tmp && sudo -u postgres psql -v ON_ERROR_STOP=1 -t -A", {
        cwd: "/tmp",
        input: "SELECT rolname FROM pg_roles WHERE rolcanlogin = true AND rolname NOT IN ('postgres');",
      });
      list = (out || "").split("\n").map((u) => u.trim()).filter(Boolean).map((u) => ({ username: u }));
    } catch (_) {
      list = [];
    }
  }

  if (currentUser && currentUser.role !== "admin" && currentUser.username !== "root") {
    const uname = currentUser.username.toLowerCase();
    list = list.filter((u) => u.username.toLowerCase().startsWith(uname + "_") || u.username.toLowerCase() === uname);
  }

  return list;
}

async function createPostgresUser({ username, password, currentUser, auditUser = "system" }) {
  if (!username) throw validate.badRequest("Username is required.");
  if (!password) throw validate.badRequest("Password is required.");

  let cleanUser = username.trim().toLowerCase();
  if (currentUser && currentUser.role !== "admin" && currentUser.username !== "root") {
    const prefix = currentUser.username.toLowerCase() + "_";
    if (!cleanUser.startsWith(prefix)) {
      cleanUser = prefix + cleanUser;
    }
  }
  const u = validate.identifier(cleanUser, "Username", 32);

  if (!shell.IS_LINUX) {
    dev.set((d) => {
      d.postgresUsers = d.postgresUsers || {};
      d.postgresUsers[u] = { created: new Date().toISOString() };
    });
    return { username: u, status: "created" };
  }

  const sql = `
DO $$
BEGIN
  IF NOT EXISTS (SELECT FROM pg_catalog.pg_roles WHERE rolname = '${u}') THEN
    CREATE ROLE "${u}" WITH LOGIN PASSWORD $pwd$${password}$pwd$;
  ELSE
    ALTER ROLE "${u}" WITH LOGIN PASSWORD $pwd$${password}$pwd$;
  END IF;
END
$$;
  `;
  await pgSql(sql, { user: auditUser });
  return { username: u, status: "created" };
}

async function deletePostgresUser({ username, currentUser, auditUser = "system" }) {
  if (!username) throw validate.badRequest("Username is required.");
  const u = validate.identifier(username.trim().toLowerCase(), "Username", 32);
  if (u === "postgres") throw validate.badRequest("Cannot delete postgres superuser.");

  if (currentUser && currentUser.role !== "admin" && currentUser.username !== "root") {
    const uname = currentUser.username.toLowerCase();
    if (!u.startsWith(uname + "_") && u !== uname) {
      throw validate.badRequest("Permission denied to delete this user.");
    }
  }

  if (!shell.IS_LINUX) {
    dev.set((d) => {
      delete (d.postgresUsers || {})[u];
    });
    return { username: u, status: "deleted" };
  }

  const sql = `
REASSIGN OWNED BY "${u}" TO "postgres";
DROP OWNED BY "${u}";
DROP ROLE IF EXISTS "${u}";
  `;
  await pgSql(sql, { user: auditUser });
  return { username: u, status: "deleted" };
}

function exportDatabase(name) {
  const db = validate.identifier(name, "Database name", 64);
  if (!shell.IS_LINUX) throw new Error("Database export is only available on the server.");
  return shell.spawnStream("mysqldump", ["-uroot", "--single-transaction", "--routines", "--triggers", db], { env: platform.mysqlEnv() });
}

async function importDatabase({ name, sqlText, user = "system" }) {
  const db = validate.identifier(name, "Database name", 64);
  if (!sqlText || !sqlText.length) throw validate.badRequest("The uploaded SQL file is empty.");
  if (!shell.IS_LINUX) return { name: db, status: "imported (dev-skip)" };
  await shell.run("mysql -uroot " + shell.q(db), { input: sqlText, env: platform.mysqlEnv(), timeout: 600000, user });
  return { name: db, status: "imported", bytes: sqlText.length };
}

function phpMyAdminUrl(hostHeader) {
  if (process.env.PHPMYADMIN_URL) return process.env.PHPMYADMIN_URL;
  return "/phpmyadmin/";
}

const PPA_SSO_SECRET = process.env.PPA_SSO_SECRET || "UltraOnePanel_PPA_Secret_Key_2026_Secure";

function getPhpPgAdminSsoUrl({ db = "", currentUser } = {}) {
  const cleanDb = (db || "").trim();
  if (cleanDb && currentUser && currentUser.role !== "admin" && currentUser.username !== "root") {
    const uname = currentUser.username.toLowerCase();
    const cdb = cleanDb.toLowerCase();
    if (!cdb.startsWith(uname + "_") && cdb !== uname) {
      const meta = store.read("postgres-databases", {});
      const isOwner = meta[cdb] && meta[cdb].owner && meta[cdb].owner.toLowerCase() === uname;
      if (!isOwner) throw validate.badRequest("Permission denied: You do not own this database.");
    }
  }

  let owner = (currentUser && currentUser.username) || "";
  if (cleanDb) {
    const meta = store.read("postgres-databases", {});
    if (meta[cleanDb.toLowerCase()] && meta[cleanDb.toLowerCase()].owner) {
      owner = meta[cleanDb.toLowerCase()].owner;
    }
  }

  const payload = cleanDb ? `${cleanDb}:${owner}` : "";
  const exp = Math.floor(Date.now() / 1000) + 120; // 2 minutes validity
  const b64Payload = Buffer.from(payload).toString("base64");
  const sig = crypto.createHmac("sha256", PPA_SSO_SECRET).update(`${exp}.${b64Payload}`).digest("hex");
  const token = `${exp}.${b64Payload}.${sig}`;
  return `/phppgadmin/sso.php?token=${encodeURIComponent(token)}${cleanDb ? `&db=${encodeURIComponent(cleanDb)}` : ""}${owner ? `&user=${encodeURIComponent(owner)}` : ""}`;
}

function phpPgAdminUrl(hostHeader, currentUser) {
  if (process.env.PHPPGADMIN_URL) return process.env.PHPPGADMIN_URL;
  return getPhpPgAdminSsoUrl({ db: "", currentUser });
}

module.exports = {
  listDatabases,
  createDatabase,
  deleteDatabase,
  listDatabaseUsers,
  createDatabaseUser,
  grantDatabase,
  deleteDatabaseUser,
  changeUserPassword,
  exportDatabase,
  importDatabase,
  phpMyAdminUrl,
  phpPgAdminUrl,
  getPhpPgAdminSsoUrl,
  sql,
  // Remote MySQL
  listRemoteHosts,
  addRemoteHost,
  deleteRemoteHost,
  // PostgreSQL
  listPostgresDatabases,
  createPostgresDatabase,
  deletePostgresDatabase,
  listPostgresUsers,
  createPostgresUser,
  deletePostgresUser,
};
