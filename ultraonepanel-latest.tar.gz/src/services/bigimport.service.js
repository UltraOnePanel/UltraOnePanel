// Staggered import of very large SQL dumps (a server-side port of BigDump 0.37b).
//
// The dump is read line by line and split into queries exactly like BigDump:
// comment markers skip lines, quote counting keeps ";" inside strings from ending a
// query, DELIMITER lines switch the delimiter, and a query may not span more than
// maxQueryLines lines. Every `linesPerSession` lines the collected queries run through
// the mysql CLI, then the job sleeps `delayPerSession` ms. Jobs run in the background
// and can be paused, resumed and cancelled from the panel.
const fs = require("fs");
const path = require("path");
const zlib = require("zlib");
const readline = require("readline");
const crypto = require("crypto");
const shell = require("./shell.service");
const platform = require("../lib/platform");
const store = require("../lib/store");
const validate = require("../lib/validate");

const IMPORT_DIR = path.join(store.DATA_DIR, "imports");
const FILE_RE = /^[A-Za-z0-9._ -]{1,200}\.(sql|gz|csv)$/i;
const CHARSETS = ["utf8mb4", "utf8", "latin1", "cp1251", "cp1250", "koi8r", "gbk", "big5", "sjis", "euckr", "ascii"];
// Custom delimiters are re-wrapped with this marker when sent to the mysql CLI.
const CLI_DELIMITER = "$$FZDELIM$$";

const DEFAULTS = {
  linesPerSession: 3000,
  delayPerSession: 0,
  // BigDump used 300; MariaDB dumps put one row per line, so one INSERT can span thousands of lines.
  maxQueryLines: 100000,
  charset: "utf8mb4",
  stringQuotes: "'",
  commentMarkers: ["#", "-- ", "DELIMITER", "/*!"],
  preQueries: [],
  disableForeignKeys: true,
  // One COMMIT per session instead of per query: far fewer disk flushes on InnoDB.
  commitPerSession: true,
  onError: "stop",
  csvTable: "",
  csvPreempty: false,
  csvDelimiter: ",",
  csvAddQuotes: true,
  csvAddSlashes: true,
};

const running = new Map(); // id -> { pause, cancel }

function jobs() {
  return store.read("bigimport-jobs", {});
}

function saveJob(job) {
  store.update("bigimport-jobs", {}, (all) => { all[job.id] = job; });
  return job;
}

// Jobs that were running when the panel stopped can be resumed from their last line.
store.update("bigimport-jobs", {}, (all) => {
  for (const j of Object.values(all)) if (j.status === "running" || j.status === "paused") j.status = "interrupted";
});

// ---------------------------------------------------------------- files

function listFiles() {
  fs.mkdirSync(IMPORT_DIR, { recursive: true });
  return fs.readdirSync(IMPORT_DIR)
    .filter((f) => FILE_RE.test(f))
    .map((name) => {
      const st = fs.statSync(path.join(IMPORT_DIR, name));
      return { name, size: st.size, modified: st.mtime.toISOString() };
    })
    .sort((a, b) => b.modified.localeCompare(a.modified));
}

/** Stream an upload straight to disk (no buffering, so multi-GB dumps are fine). */
function receiveUpload(req, name) {
  if (!FILE_RE.test(String(name || ""))) {
    throw validate.badRequest("Only .sql, .gz and .csv files can be imported (letters, digits, . _ - and spaces in the name).");
  }
  fs.mkdirSync(IMPORT_DIR, { recursive: true });
  const target = path.join(IMPORT_DIR, name);
  const tmp = target + ".part";
  return new Promise((resolve, reject) => {
    const out = fs.createWriteStream(tmp);
    let bytes = 0;
    req.on("data", (c) => { bytes += c.length; });
    req.on("aborted", () => { out.destroy(); fs.rmSync(tmp, { force: true }); reject(validate.badRequest("Upload was interrupted.")); });
    out.on("error", (e) => { fs.rmSync(tmp, { force: true }); reject(e); });
    out.on("finish", () => {
      fs.renameSync(tmp, target);
      resolve({ name, size: bytes });
    });
    req.pipe(out);
  });
}

function deleteFile(name) {
  if (!FILE_RE.test(String(name || ""))) throw validate.badRequest("Invalid file name.");
  if ([...running.keys()].some((id) => jobs()[id] && jobs()[id].file === name)) {
    throw validate.badRequest("This file is being imported right now.");
  }
  fs.rmSync(path.join(IMPORT_DIR, name), { force: true });
  return { name, status: "deleted" };
}

/** Uploaded file name, or an absolute path inside the hosting folders. */
function resolveSource(source) {
  const s = String(source || "");
  if (FILE_RE.test(s) && fs.existsSync(path.join(IMPORT_DIR, s))) return path.join(IMPORT_DIR, s);
  if (path.isAbsolute(s)) {
    const p = path.resolve(s);
    const roots = [platform.paths.wwwRoot, "/home", platform.paths.backupDir, IMPORT_DIR];
    const inside = roots.some((r) => p === r || p.startsWith(r + path.sep));
    if (!inside) throw validate.badRequest("Server files must be inside " + roots.join(", "));
    if (!/\.(sql|gz|csv)$/i.test(p)) throw validate.badRequest("Only .sql, .gz and .csv files can be imported.");
    if (!fs.existsSync(p) || !fs.statSync(p).isFile()) throw validate.badRequest("File not found: " + p);
    return p;
  }
  throw validate.badRequest("Choose an uploaded file or enter a server path.");
}

// ---------------------------------------------------------------- settings

function cleanSettings(input = {}) {
  const s = { ...DEFAULTS, ...input };
  const int = (v, min, max, label) => {
    const n = Number(v);
    if (!Number.isInteger(n) || n < min || n > max) throw validate.badRequest(label + " must be a whole number between " + min + " and " + max + ".");
    return n;
  };
  s.linesPerSession = int(s.linesPerSession, 10, 1000000, "Lines per session");
  s.delayPerSession = int(s.delayPerSession, 0, 600000, "Delay per session");
  s.maxQueryLines = int(s.maxQueryLines, 1, 1000000, "Max query lines");
  if (!CHARSETS.includes(s.charset)) throw validate.badRequest("Unsupported charset: " + s.charset);
  if (!["'", "\""].includes(s.stringQuotes)) throw validate.badRequest("String quotes must be ' or \".");
  if (!["stop", "continue"].includes(s.onError)) throw validate.badRequest("On error must be stop or continue.");
  const list = (v) => (Array.isArray(v) ? v : String(v || "").split("\n")).map((x) => String(x).replace(/\r/g, "")).filter((x) => x.trim());
  s.commentMarkers = list(s.commentMarkers);
  s.preQueries = list(s.preQueries).map((q) => q.trim().replace(/;+$/, ""));
  if (s.csvTable) s.csvTable = validate.identifier(s.csvTable, "CSV table", 64);
  if (String(s.csvDelimiter).length !== 1) throw validate.badRequest("CSV delimiter must be a single character.");
  s.csvPreempty = !!s.csvPreempty;
  s.csvAddQuotes = !!s.csvAddQuotes;
  s.csvAddSlashes = !!s.csvAddSlashes;
  s.disableForeignKeys = !!s.disableForeignKeys;
  s.commitPerSession = !!s.commitPerSession;
  return s;
}

// ---------------------------------------------------------------- execution

/** SQL text for one session: pre-queries, then each statement with the delimiter it was written for. */
function buildBatch(statements, settings) {
  const head = [`SET NAMES ${settings.charset}`];
  if (settings.disableForeignKeys) head.push("SET foreign_key_checks = 0");
  head.push(...settings.preQueries);
  if (settings.commitPerSession) head.push("SET autocommit = 0");
  let text = head.map((q) => q + ";\n").join("");
  let line = text.split("\n").length; // 1-based line where the next statement starts
  const map = [];
  for (const st of statements) {
    let chunk = st.delimiter === ";"
      ? st.sql + ";\n"
      : "DELIMITER " + CLI_DELIMITER + "\n" + st.sql + CLI_DELIMITER + "\nDELIMITER ;\n";
    const startLine = line + (st.delimiter === ";" ? 0 : 1);
    const lines = chunk.split("\n").length - 1;
    map.push({ from: startLine, to: line + lines - 1, fileLine: st.line, endLine: st.endLine, delimiter: st.delimiter, index: map.length, sql: st.sql });
    text += chunk;
    line += lines;
  }
  if (settings.commitPerSession) text += "COMMIT;\n";
  return { text, map };
}

// Statements that commit on their own (implicit commit), so a rollback never undoes them.
const IMPLICIT_COMMIT = /^\s*(\/\*.*?\*\/\s*)*(CREATE|DROP|ALTER|TRUNCATE|RENAME|LOCK\s+TABLES?|UNLOCK\s+TABLES?|GRANT|REVOKE|START\s+TRANSACTION|BEGIN|COMMIT|ANALYZE|OPTIMIZE|REPAIR)\b/i;

/**
 * In commit-per-session mode an aborted batch rolls back the data statements run since
 * the last implicit commit. Re-run exactly those so "stop on error" keeps everything
 * before the failing query, as in BigDump.
 */
async function replayRolledBack(job, statements, failedIndex, settings) {
  let from = 0;
  for (let i = 0; i < failedIndex; i++) if (IMPLICIT_COMMIT.test(statements[i].sql)) from = i + 1;
  const redo = statements.slice(from, failedIndex);
  if (!redo.length) return [];
  return runBatch(job, redo, settings);
}

async function runBatch(job, statements, settings) {
  if (!statements.length) return [];
  if (!shell.IS_LINUX) return [];
  const { text, map } = buildBatch(statements, settings);
  const args = "mysql -uroot --batch --default-character-set=" + settings.charset +
    (settings.onError === "continue" ? " --force" : "") + " " + shell.q(job.database);
  // mysql reports "ERROR 1064 (42000) at line 12: ..." for each failing statement.
  // With --force it still exits 0, so stderr is parsed on success too.
  const parse = (stderr) => {
    const errs = [];
    for (const m of String(stderr || "").matchAll(/ERROR (\d+)(?: \(\w+\))? at line (\d+)[^:]*: (.*)/g)) {
      const at = Number(m[2]);
      const st = map.find((x) => at >= x.from && at <= x.to) || map[map.length - 1];
      errs.push({ code: Number(m[1]), message: m[3].trim(), fileLine: st ? st.fileLine : null, endLine: st ? st.endLine : null, delimiter: st ? st.delimiter : ";", index: st ? st.index : 0, sql: st ? st.sql.slice(0, 300) : "" });
    }
    return errs;
  };
  try {
    const r = await shell.run(args, { input: text, env: platform.mysqlEnv(), timeout: 3600000, user: job.user });
    return parse(r.stderr);
  } catch (e) {
    const errs = parse(e.stderr || e.message);
    if (!errs.length) errs.push({ code: 0, message: (e.stderr || e.message).trim().slice(0, 500), fileLine: statements[0].line, endLine: statements[0].endLine, index: 0, sql: "" });
    return errs;
  }
}

function log(job, level, message) {
  job.log = (job.log || []).concat({ at: new Date().toISOString(), level, message }).slice(-200);
}

function csvToInsert(line, s) {
  let fields = line.replace(/\n$/, "");
  if (s.csvAddSlashes) fields = fields.replace(/[\\'"\0]/g, (c) => (c === "\0" ? "\\0" : "\\" + c));
  const parts = fields.split(s.csvDelimiter);
  const values = s.csvAddQuotes ? "'" + parts.join("','") + "'" : parts.join(",");
  return "INSERT INTO `" + s.csvTable + "` VALUES (" + values + ");\n";
}

async function runJob(id) {
  const ctl = { paused: false, cancelled: false };
  running.set(id, ctl);
  let job = jobs()[id];
  const s = job.settings;
  const isGz = /\.gz$/i.test(job.sourcePath);
  const isCsv = /\.csv$/i.test(job.sourcePath) || /\.csv\.gz$/i.test(job.sourcePath);

  const raw = fs.createReadStream(job.sourcePath);
  raw.on("data", (c) => { job.bytesRead += c.length; });
  const input = isGz ? raw.pipe(zlib.createGunzip()) : raw;
  const rl = readline.createInterface({ input, crlfDelay: Infinity });

  const resumeFrom = job.lineNumber; // lines already processed in an earlier run
  job.bytesRead = 0;
  job.status = "running";
  job.startedAt = job.startedAt || new Date().toISOString();
  job.lineNumber = 0;
  if (resumeFrom) log(job, "info", "Resuming after line " + resumeFrom);
  saveJob(job);

  let query = "";
  let queryStart = 0;
  let queryLines = 0;
  let inQuotes = false;
  let delimiter = job.delimiter || ";";
  let statements = [];
  let sessionLines = 0;
  let fatal = null;
  const quote = s.stringQuotes;
  const t0 = Date.now();

  const flush = async () => {
    const errs = await runBatch(job, statements, s);
    job.sessions += 1;
    if (errs.length && s.onError === "stop") {
      // mysql stopped at the failing statement: everything before it ran, nothing after.
      if (s.commitPerSession && errs[0].index > 0) {
        const again = await replayRolledBack(job, statements, errs[0].index, s);
        if (again.length) log(job, "error", "Re-applying the queries before the error failed: " + again[0].message);
      }
      job.queries += errs[0].index;
      job.errors = (job.errors || 0) + 1;
      fatal = errs[0];
      log(job, "error", "Line " + fatal.fileLine + ": MySQL " + fatal.code + " " + fatal.message + (fatal.sql ? " | " + fatal.sql : ""));
      // Resuming continues right after the failing query.
      job.resumeLine = fatal.endLine;
    } else {
      job.queries += statements.length - errs.length;
      job.errors = (job.errors || 0) + errs.length;
      for (const e of errs.slice(0, 20)) log(job, "error", "Line " + e.fileLine + ": MySQL " + e.code + " " + e.message + (e.sql ? " | " + e.sql : ""));
    }
    statements = [];
    sessionLines = 0;
    job.delimiter = delimiter;
    job.elapsedMs = Date.now() - t0;
    saveJob(job);
  };

  try {
    if (isCsv && s.csvTable && s.csvPreempty && !resumeFrom) {
      statements.push({ sql: "DELETE FROM `" + s.csvTable + "`", line: 0, delimiter: ";" });
    }
    for await (let dumpline of rl) {
      job.lineNumber += 1;
      if (job.lineNumber <= resumeFrom) continue;
      if (job.lineNumber === 1) dumpline = dumpline.replace(/^﻿/, "");
      dumpline += "\n";

      if (isCsv && s.csvTable) dumpline = csvToInsert(dumpline, s);

      if (!inQuotes && dumpline.startsWith("DELIMITER ")) delimiter = dumpline.slice(10).trim();

      sessionLines += 1;
      if (!inQuotes) {
        const t = dumpline.trim();
        // Like BigDump: the trimmed line starts with a marker ("-- " also matches a bare "--").
        if (t === "" || s.commentMarkers.some((c) => t.startsWith(c) || t === c.trim())) {
          if (sessionLines >= s.linesPerSession && !query) await endSession();
          if (fatal || ctl.cancelled) break;
          continue;
        }
      }

      // "\\" only occurs inside strings; drop it before counting quotes.
      const deslashed = dumpline.split("\\\\").join("");
      const quotes = deslashed.split(quote).length - 1 - (deslashed.split("\\" + quote).length - 1);
      if (quotes % 2 !== 0) inQuotes = !inQuotes;

      if (!query) queryStart = job.lineNumber;
      query += dumpline;
      if (!inQuotes) queryLines += 1;

      if (queryLines > s.maxQueryLines) {
        // Run what was collected so far, then stop at the start of the oversized query.
        await flush();
        if (fatal) break;
        fatal = { fileLine: queryStart, message: "The query starting at line " + queryStart + " spans more than " + s.maxQueryLines + " lines. Raise \"Max query lines\" (MariaDB dumps put one row per line), or check that every statement ends with \"" + delimiter + "\" at the end of a line." };
        job.resumeLine = queryStart - 1;
        log(job, "error", fatal.message);
        break;
      }

      if (!inQuotes && (delimiter === "" || dumpline.trim().endsWith(delimiter))) {
        const sql = query.trim().slice(0, delimiter ? -delimiter.length : undefined).trim();
        if (sql) statements.push({ sql, line: queryStart, endLine: job.lineNumber, delimiter });
        query = "";
        queryLines = 0;
      }

      if (sessionLines >= s.linesPerSession && !query) await endSession();
      if (fatal || ctl.cancelled) break;
    }
    if (!fatal && !ctl.cancelled && query.trim()) {
      log(job, "warning", "File ended inside an unfinished query starting at line " + queryStart + "; it was not executed.");
    }
    if (!fatal && !ctl.cancelled && statements.length) await flush();
  } catch (e) {
    fatal = { message: e.message, fileLine: job.lineNumber };
    log(job, "error", e.message);
  } finally {
    rl.close();
    raw.destroy();
    running.delete(id);
  }

  job.elapsedMs = Date.now() - t0;
  job.finishedAt = new Date().toISOString();
  if (ctl.cancelled) { job.status = "cancelled"; log(job, "info", "Cancelled at line " + job.lineNumber); }
  else if (fatal) {
    job.status = "failed";
    job.error = fatal;
    if (job.resumeLine !== undefined) job.lineNumber = job.resumeLine;
    if (fatal.delimiter) job.delimiter = fatal.delimiter;
    log(job, "info", "Fix the problem (or adjust the settings) and press Resume to continue after line " + job.lineNumber + ".");
  }
  else {
    job.status = "completed";
    job.bytesRead = job.size;
    log(job, "success", "Import finished: " + job.queries + " queries from " + job.lineNumber + " lines" + (job.errors ? ", " + job.errors + " errors skipped" : "") + ".");
  }
  saveJob(job);

  async function endSession() {
    await flush();
    log(job, "info", "Session " + job.sessions + " done: line " + job.lineNumber + ", " + job.queries + " queries");
    saveJob(job);
    if (s.delayPerSession) await new Promise((r) => setTimeout(r, s.delayPerSession));
    while (ctl.paused && !ctl.cancelled) {
      if (job.status !== "paused") { job.status = "paused"; saveJob(job); }
      await new Promise((r) => setTimeout(r, 500));
    }
    if (job.status === "paused") { job.status = "running"; saveJob(job); }
  }
}

// ---------------------------------------------------------------- public API

async function startImport({ source, database, settings, user }) {
  const db = validate.identifier(database, "Database", 64);
  const existing = (await require("./database.service").listDatabases()).map((d) => d.name);
  if (!existing.includes(db)) throw validate.badRequest("Database not found: " + db);
  if (running.size) throw validate.badRequest("Another import is already running. Wait for it to finish or cancel it.");
  const sourcePath = resolveSource(source);
  const clean = cleanSettings(settings);
  if (/\.csv(\.gz)?$/i.test(sourcePath) && !clean.csvTable) throw validate.badRequest("CSV files need a destination table.");

  const id = crypto.randomBytes(6).toString("hex");
  const job = saveJob({
    id,
    file: path.basename(sourcePath),
    sourcePath,
    database: db,
    size: fs.statSync(sourcePath).size,
    settings: clean,
    status: "queued",
    lineNumber: 0,
    queries: 0,
    sessions: 0,
    errors: 0,
    bytesRead: 0,
    delimiter: ";",
    created: new Date().toISOString(),
    user,
    log: [],
  });
  setImmediate(() => runJob(id));
  return publicJob(job);
}

function publicJob(j) {
  const { sourcePath, ...rest } = j;
  const pct = j.status === "completed" ? 100 : j.size ? Math.min(99.9, (j.bytesRead / j.size) * 100) : 0;
  const rate = j.elapsedMs ? j.bytesRead / (j.elapsedMs / 1000) : 0;
  return {
    ...rest,
    source: sourcePath,
    percent: Math.round(pct * 10) / 10,
    bytesPerSecond: Math.round(rate),
    etaSeconds: rate && j.status === "running" ? Math.round((j.size - j.bytesRead) / rate) : null,
  };
}

/** Whether an import into this database is running or paused. */
function isImporting(database) {
  return [...running.keys()].some((id) => jobs()[id] && jobs()[id].database === database);
}

function listJobs() {
  return Object.values(jobs()).sort((a, b) => b.created.localeCompare(a.created)).slice(0, 20).map(publicJob);
}

function getJob(id) {
  const j = jobs()[id];
  if (!j) throw validate.badRequest("Import job not found.");
  return publicJob(j);
}

function control({ id, action, settings }) {
  const j = jobs()[id];
  if (!j) throw validate.badRequest("Import job not found.");
  const ctl = running.get(id);
  if (action === "pause" && ctl) ctl.paused = true;
  else if (action === "resume" && ctl) ctl.paused = false;
  else if (action === "cancel" && ctl) { ctl.cancelled = true; ctl.paused = false; }
  else if (action === "resume" && ["interrupted", "failed"].includes(j.status) && j.lineNumber) {
    if (running.size) throw validate.badRequest("Another import is already running.");
    // Settings may be changed before resuming (e.g. a larger "Max query lines").
    if (settings) j.settings = cleanSettings({ ...j.settings, ...settings });
    log(j, "info", "Restarting after line " + j.lineNumber);
    j.status = "queued";
    delete j.resumeLine;
    delete j.error;
    saveJob(j);
    setImmediate(() => runJob(id));
  } else if (action === "delete" && !ctl) {
    store.update("bigimport-jobs", {}, (all) => { delete all[id]; });
    return { id, status: "deleted" };
  } else {
    throw validate.badRequest("Cannot " + action + " a job that is " + j.status + ".");
  }
  return { id, action };
}

module.exports = { DEFAULTS, CHARSETS, IMPORT_DIR, isImporting, listFiles, receiveUpload, deleteFile, startImport, listJobs, getJob, control, cleanSettings, buildBatch };
