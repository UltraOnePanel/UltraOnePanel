const shell = require("./shell.service");

/**
 * Root Agent Service
 * Executes privileged system tasks on Ubuntu 22.04 / 24.04 via sudo/root wrappers
 * Controls: Postfix, Dovecot, BIND/PowerDNS, Nginx, Apache, MySQL/MariaDB, PureFTPD, UFW
 */
const RootService = {
  // -------------------------------------------------------------
  // SERVICE STATUS & CONTROL
  // -------------------------------------------------------------
  async getServiceStatus(serviceName, aliases = [], processFilter = null) {
    if (!shell.IS_LINUX) {
      return { service: serviceName, active: true, running: true, status: "active" };
    }
    const candidates = [serviceName, ...(aliases || [])];
    // 1. Try systemctl is-active
    for (const name of candidates) {
      try {
        const output = await shell.tryGet(`systemctl is-active ${shell.q(name)}`);
        if (output && output.trim() === "active") {
          return { service: name, active: true, running: true, status: "active" };
        }
      } catch (_) {}
    }
    // 2. Try process check (pgrep)
    const procNames = processFilter ? [processFilter] : candidates;
    for (const proc of procNames) {
      try {
        const pids = await shell.tryGet(`pgrep -f ${shell.q(proc)}`);
        if (pids && pids.trim().length > 0) {
          return { service: serviceName, active: true, running: true, status: "active" };
        }
      } catch (_) {}
    }
    return { service: serviceName, active: false, running: false, status: "inactive" };
  },

  async restartService(serviceName, user = "root") {
    if (!shell.IS_LINUX) {
      return { success: true, service: serviceName, message: `[Dev] Restarted ${serviceName}` };
    }
    let unit = serviceName;
    const isHttpd = await shell.tryGet("systemctl is-active httpd").catch(() => "");
    if ((serviceName === "apache2" || serviceName === "httpd") && isHttpd.trim() === "active") unit = "httpd";
    const isMysqld = await shell.tryGet("systemctl is-active mysqld").catch(() => "");
    if ((serviceName === "mysql" || serviceName === "mysqld") && isMysqld.trim() === "active") unit = "mysqld";
    const isPhp84 = await shell.tryGet("systemctl is-active php-fpm-84").catch(() => "");
    if ((serviceName.includes("php") || serviceName.includes("fpm")) && isPhp84.trim() === "active") unit = "php-fpm-84";

    await shell.run(`systemctl restart ${shell.q(unit)} || service ${shell.q(unit)} restart || systemctl restart ${shell.q(serviceName)}`, { user }).catch(() => {});
    return { success: true, service: unit, message: `Restarted ${unit}` };
  },

  async reloadService(serviceName, user = "root") {
    if (!shell.IS_LINUX) {
      return { success: true, service: serviceName, message: `[Dev] Reloaded ${serviceName}` };
    }
    await shell.run(`systemctl reload ${shell.q(serviceName)} 2>/dev/null || systemctl restart ${shell.q(serviceName)}`, { user }).catch(() => {});
    return { success: true, service: serviceName, message: `Reloaded ${serviceName}` };
  },

  async listAllServices() {
    const tracked = [
      {
        service: "nginx",
        aliases: ["nginx", "openresty"],
        processFilter: "nginx",
        name: "Nginx Web Server",
        description: "High-performance reverse proxy & HTTP web server",
        type: "web",
      },
      {
        service: "httpd",
        aliases: ["httpd", "apache2"],
        processFilter: "httpd",
        name: "Apache HTTP Server",
        description: "Apache HTTP Web Server daemon engine",
        type: "web",
      },
      {
        service: "mysqld",
        aliases: ["mysqld", "mysql", "mariadb"],
        processFilter: "mariadbd",
        name: "MySQL / MariaDB",
        description: "Relational SQL database engine",
        type: "database",
      },
      {
        service: "pure-ftpd",
        aliases: ["pure-ftpd", "vsftpd"],
        processFilter: "pure-ftpd",
        name: "Pure-FTPD FTP Server",
        description: "Secure FTP file transfer daemon",
        type: "ftp",
      },
      {
        service: "postfix",
        aliases: ["postfix", "exim4"],
        processFilter: "master",
        name: "Postfix Mail Server (SMTP)",
        description: "Mail Transfer Agent for sending and receiving emails",
        type: "mail",
      },
      {
        service: "dovecot",
        aliases: ["dovecot"],
        processFilter: "dovecot",
        name: "Dovecot Mail Server (IMAP/POP3)",
        description: "Secure IMAP and POP3 mailbox access daemon",
        type: "mail",
      },
      {
        service: "php-fpm-84",
        aliases: ["php-fpm-84", "php-fpm", "php8.2-fpm", "php8.1-fpm", "php8.3-fpm"],
        processFilter: "php-fpm",
        name: "PHP FastCGI (PHP-FPM)",
        description: "PHP 8.2 / 8.4 website script execution runtime",
        type: "php",
      },
      {
        service: "ufw",
        aliases: ["ufw", "BT-FirewallServices"],
        processFilter: "ufw",
        name: "UFW Firewall & Security",
        description: "Kernel packet filtering and intrusion protection",
        type: "security",
      },
      {
        service: "named",
        aliases: ["named", "bind9", "pdns"],
        processFilter: "named",
        name: "BIND9 DNS Nameserver",
        description: "Domain Name System authoritative resolver",
        type: "dns",
      },
      {
        service: "facezila",
        aliases: ["facezila"],
        processFilter: "node",
        name: "cPanel & WHM Jupiter Core",
        description: "Facezila Cloud Hosting Platform engine (ports 2083/2087)",
        type: "system",
      },
      {
        service: "yourpanel-license",
        aliases: ["yourpanel-license"],
        name: "Central Licensing Agent",
        description: "Central License verification & tier manager (port 9000)",
        type: "system",
      },
      {
        service: "cron",
        aliases: ["cron", "crond"],
        processFilter: "cron",
        name: "Cron Task Scheduler",
        description: "Automated scheduled cron jobs and system maintenance",
        type: "system",
      },
    ];

    const results = await Promise.all(
      tracked.map(async (svc) => {
        const st = await RootService.getServiceStatus(svc.service, svc.aliases, svc.processFilter);
        const isRunning = st.active || st.running;
        return {
          service: st.service || svc.service,
          name: svc.name,
          label: svc.name,
          systemName: svc.service,
          description: svc.description,
          type: svc.type,
          active: isRunning,
          running: isRunning,
          status: isRunning ? "active" : "inactive",
          enabled: isRunning,
        };
      })
    );
    return results;
  },

  // -------------------------------------------------------------
  // POSTFIX & DOVECOT ROOT ACTIONS
  // -------------------------------------------------------------
  async flushMailQueue(user = "root") {
    if (!shell.IS_LINUX) return { success: true, message: "Queue flushed" };
    await shell.run("postfix flush", { user });
    return { success: true, message: "Mail queue flushed" };
  },

  async getMailQueue() {
    if (!shell.IS_LINUX) return [];
    try {
      const out = await shell.tryGet("mailq");
      if (out.includes("Mail queue is empty")) return [];
      const lines = out.split("\n").filter(Boolean);
      return lines.map((l, i) => ({ id: `queue-${i}`, raw: l }));
    } catch (_) {
      return [];
    }
  },

  // -------------------------------------------------------------
  // BIND9 / POWERDNS ROOT ACTIONS
  // -------------------------------------------------------------
  async reloadDNS(user = "root") {
    if (!shell.IS_LINUX) return { success: true };
    await shell.run("rndc reload 2>/dev/null || systemctl reload named 2>/dev/null || systemctl reload bind9 2>/dev/null || true", { user });
    return { success: true, message: "DNS zones reloaded" };
  },

  async checkDNSZone(domain, zoneFile) {
    if (!shell.IS_LINUX) return { valid: true };
    try {
      const out = await shell.runGet(`named-checkzone ${shell.q(domain)} ${shell.q(zoneFile)}`);
      return { valid: out.includes("OK"), output: out };
    } catch (e) {
      return { valid: false, error: e.message };
    }
  },

  // -------------------------------------------------------------
  // NGINX & APACHE ROOT ACTIONS
  // -------------------------------------------------------------
  async testWebServerConfig(serverType = "nginx") {
    if (!shell.IS_LINUX) return { success: true, message: "Config syntax is OK" };
    try {
      const cmd = serverType === "nginx" ? "nginx -t" : "apache2ctl configtest";
      const out = await shell.runGet(cmd);
      return { success: true, message: out };
    } catch (err) {
      return { success: false, message: err.stderr || err.message };
    }
  },

  async reloadWebServer(serverType = "nginx", user = "root") {
    if (!shell.IS_LINUX) return { success: true };
    const svc = serverType === "nginx" ? "nginx" : "apache2";
    await shell.run(`systemctl reload ${svc} 2>/dev/null || systemctl restart ${svc}`, { user });
    return { success: true, message: `${serverType} reloaded` };
  },

  // -------------------------------------------------------------
  // MYSQL ROOT ACTIONS
  // -------------------------------------------------------------
  async executeMySqlQuery(sql, user = "root") {
    if (!shell.IS_LINUX) return "";
    return await shell.runGet(`mysql -Bse ${shell.q(sql)}`, { user });
  },

  // -------------------------------------------------------------
  // PURE-FTPD ROOT ACTIONS
  // -------------------------------------------------------------
  async syncPureFtpDb(user = "root") {
    if (!shell.IS_LINUX) return { success: true };
    await shell.run("pure-pw mkdb /etc/pure-ftpd/pureftpd.pdb 2>/dev/null || true", { user });
    return { success: true };
  },

  async getActiveFtpSessions() {
    if (!shell.IS_LINUX) {
      return [
        { user: "ftpdemo", ip: "192.168.1.105", status: "Idle", duration: "12m", file: "/public_html/index.php" }
      ];
    }
    try {
      const out = await shell.tryGet("pure-ftpwho -v 2>/dev/null || netstat -tnp | grep ':21 '");
      const sessions = [];
      const lines = out.split("\n").filter(Boolean);
      for (const line of lines) {
        if (line.includes("ESTABLISHED")) {
          const parts = line.split(/\s+/);
          sessions.push({
            user: "ftp-user",
            ip: parts[4] || "Unknown",
            status: "Connected",
            duration: "Active",
            file: "-",
          });
        }
      }
      return sessions;
    } catch (_) {
      return [];
    }
  },

  // -------------------------------------------------------------
  // UFW FIREWALL ROOT ACTIONS
  // -------------------------------------------------------------
  async getUfwStatus() {
    if (!shell.IS_LINUX) {
      return {
        enabled: true,
        rules: [
          { number: 1, to: "22/tcp", action: "ALLOW", from: "Anywhere", comment: "SSH" },
          { number: 2, to: "80/tcp", action: "ALLOW", from: "Anywhere", comment: "HTTP" },
          { number: 3, to: "443/tcp", action: "ALLOW", from: "Anywhere", comment: "HTTPS" },
          { number: 4, to: "2087/tcp", action: "ALLOW", from: "Anywhere", comment: "WHM Port" },
          { number: 5, to: "2083/tcp", action: "ALLOW", from: "Anywhere", comment: "cPanel Port" },
          { number: 6, to: "25/tcp", action: "ALLOW", from: "Anywhere", comment: "SMTP" },
          { number: 7, to: "587/tcp", action: "ALLOW", from: "Anywhere", comment: "Submission" },
          { number: 8, to: "993/tcp", action: "ALLOW", from: "Anywhere", comment: "IMAPS" },
          { number: 9, to: "53", action: "ALLOW", from: "Anywhere", comment: "DNS" },
          { number: 10, to: "21/tcp", action: "ALLOW", from: "Anywhere", comment: "FTP" },
        ]
      };
    }
    try {
      const out = await shell.runGet("ufw status numbered");
      const enabled = out.toLowerCase().includes("status: active");
      const rules = [];
      const lines = out.split("\n");
      for (const l of lines) {
        const m = l.match(/^\[\s*(\d+)\]\s+(.*?)\s+(ALLOW|DENY|REJECT)\s+(IN|OUT)?\s*(.*?)(?:\s+#\s*(.*))?$/i);
        if (m) {
          rules.push({
            number: parseInt(m[1]),
            to: m[2].trim(),
            action: m[3].trim().toUpperCase(),
            direction: (m[4] || "IN").trim(),
            from: m[5].trim(),
            comment: (m[6] || "").trim(),
          });
        }
      }
      return { enabled, rules };
    } catch (_) {
      return { enabled: false, rules: [] };
    }
  },

  async addUfwRule({ port, protocol = "tcp", action = "allow", from = "any", comment = "" }, user = "root") {
    if (!shell.IS_LINUX) {
      return { success: true, message: `Rule added for port ${port}` };
    }
    let cmd = `ufw ${action.toLowerCase()} proto ${protocol.toLowerCase()} to any port ${port}`;
    if (from && from !== "any") {
      cmd = `ufw ${action.toLowerCase()} from ${shell.q(from)} to any port ${port} proto ${protocol.toLowerCase()}`;
    }
    if (comment) {
      cmd += ` comment ${shell.q(comment)}`;
    }
    await shell.run(cmd, { user });
    return { success: true, message: `Firewall rule applied: ${action} ${port}/${protocol}` };
  },

  async deleteUfwRule(ruleNumber, user = "root") {
    if (!shell.IS_LINUX) {
      return { success: true, message: `Rule ${ruleNumber} deleted` };
    }
    await shell.run(`echo "y" | ufw delete ${parseInt(ruleNumber)}`, { user });
    return { success: true, message: `Deleted rule ${ruleNumber}` };
  },

  async rebootServer(user = "root") {
    if (!shell.IS_LINUX) {
      return { success: true, message: "[Dev] Reboot triggered" };
    }
    shell.run("sleep 1 && reboot", { user }).catch(() => {});
    return { success: true, message: "Server is rebooting now..." };
  }
};

module.exports = RootService;

