const fs=require("fs"),path=require("path"),crypto=require("crypto"),shell=require("./shell.service"),platform=require("../lib/platform"),validate=require("../lib/validate"),websites=require("./website.service"),databases=require("./database.service"),securitySvc=require("./security.service");async function listSites(user){const allWebsites=await websites.listWebsites(user),instances=[];for(const site of allWebsites){if(user&&user.role!=="admin"&&user.username!=="root"&&!websites.isUserAllowedSite(site.domain,site,user))continue;const docRoot=site.documentRoot||platform.docRoot(site.domain);if(!docRoot||!fs.existsSync(docRoot))continue;const candidateDirs=[{dir:docRoot,pathPrefix:""}];try{const subEntries=fs.readdirSync(docRoot,{withFileTypes:!0});for(const ent of subEntries)ent.isDirectory()&&!ent.name.startsWith(".")&&candidateDirs.push({dir:path.join(docRoot,ent.name),pathPrefix:"/"+ent.name})}catch{}for(const{dir,pathPrefix}of candidateDirs){const wpConfigPath=path.join(dir,"wp-config.php");if(!fs.existsSync(wpConfigPath))continue;let version="Latest";const versionFile=path.join(dir,"wp-includes","version.php");if(fs.existsSync(versionFile))try{const vMatch=fs.readFileSync(versionFile,"utf8").match(/\$wp_version\s*=\s*['"]([^'"]+)['"]/);vMatch&&(version=vMatch[1])}catch{}let dbName="Unknown",tablePrefix="wp_",debugMode=!1;try{const confText=fs.readFileSync(wpConfigPath,"utf8"),dbMatch=confText.match(/define\(\s*['"]DB_NAME['"]\s*,\s*['"]([^'"]+)['"]\s*\)/);dbMatch&&(dbName=dbMatch[1]);const prefixMatch=confText.match(/\$table_prefix\s*=\s*['"]([^'"]+)['"]/);prefixMatch&&(tablePrefix=prefixMatch[1]),debugMode=/define\(\s*['"]WP_DEBUG['"]\s*,\s*true\s*\)/i.test(confText)}catch{}const maintenanceMode=fs.existsSync(path.join(dir,".maintenance"));let pluginsCount=0;const pluginsDir=path.join(dir,"wp-content","plugins");if(fs.existsSync(pluginsDir))try{pluginsCount=fs.readdirSync(pluginsDir).filter(f=>!f.startsWith(".")).length}catch{}const siteUrl=(site.ssl?"https://":"http://")+site.domain+pathPrefix;instances.push({id:crypto.createHash("md5").update(dir).digest("hex").slice(0,10),domain:site.domain,subPath:pathPrefix||"/",url:siteUrl,adminUrl:siteUrl+"/wp-admin/",dir,version,database:dbName,tablePrefix,maintenanceMode,debugMode,pluginsCount,ssl:!!site.ssl,php:site.php||"8.2"})}}return{success:!0,sites:instances}}async function autoLogin({domain,subPath="",user}){domain=validate.domain(domain);const site=await websites.getWebsite(domain);if(!site)throw validate.badRequest("Website not found: "+domain);if(user&&user.role!=="admin"&&user.username!=="root"&&!websites.isUserAllowedSite(domain,site,user))throw validate.badRequest("Permission denied: You do not own this domain.");const docRoot=site.documentRoot||platform.docRoot(domain),targetDir=subPath&&subPath!=="/"?path.join(docRoot,subPath.replace(/^\//,"")):docRoot,wpLoad=path.join(targetDir,"wp-load.php");if(!fs.existsSync(wpLoad))throw validate.badRequest("WordPress installation not found in "+targetDir);const bridgeFileName=`wp-auto-login-${crypto.randomBytes(16).toString("hex")}.php`,bridgeFilePath=path.join(targetDir,bridgeFileName);fs.writeFileSync(bridgeFilePath,`<?php
/**
 * UltraOnePanel One-Click SSO Bridge
 * Auto-deletes itself immediately after setting admin auth cookie.
 */
define('WP_USE_THEMES', false);
require_once __DIR__ . '/wp-load.php';

// Self-destruct security trigger
@unlink(__FILE__);

// Fetch first administrator
$admins = get_users(['role' => 'administrator', 'number' => 1]);
if (empty($admins)) {
  $admins = get_users(['number' => 1]);
}

if (!empty($admins)) {
  $user_id = $admins[0]->ID;
  wp_set_current_user($user_id);
  wp_set_auth_cookie($user_id, true);
  do_action('wp_login', $admins[0]->user_login, $admins[0]);
  wp_safe_redirect(admin_url());
  exit;
} else {
  wp_die('No WordPress administrator accounts found.');
}
`,{mode:420});const webUser=platform.IS_AAPANEL?"www":"www-data";return await shell.run(`chown ${webUser}:${webUser} ${shell.q(bridgeFilePath)} 2>/dev/null || true`),{success:!0,loginUrl:`${site.ssl?"https":"http"}://${domain}${subPath&&subPath!=="/"?subPath:""}/${bridgeFileName}`,expiresSeconds:60}}async function toggleMaintenance({domain,subPath="",enabled,user}){domain=validate.domain(domain);const site=await websites.getWebsite(domain);if(!site)throw validate.badRequest("Website not found.");const docRoot=site.documentRoot||platform.docRoot(domain),targetDir=subPath&&subPath!=="/"?path.join(docRoot,subPath.replace(/^\//,"")):docRoot,maintFile=path.join(targetDir,".maintenance");return enabled?fs.writeFileSync(maintFile,`<?php $upgrading = ${Date.now()}; ?>
`,{mode:420}):fs.rmSync(maintFile,{force:!0}),{success:!0,domain,maintenanceMode:!!enabled}}async function toggleDebugMode({domain,subPath="",enabled,user}){domain=validate.domain(domain);const site=await websites.getWebsite(domain);if(!site)throw validate.badRequest("Website not found.");const docRoot=site.documentRoot||platform.docRoot(domain),targetDir=subPath&&subPath!=="/"?path.join(docRoot,subPath.replace(/^\//,"")):docRoot,wpConfigPath=path.join(targetDir,"wp-config.php");if(!fs.existsSync(wpConfigPath))throw validate.badRequest("wp-config.php not found.");let text=fs.readFileSync(wpConfigPath,"utf8");return/define\(\s*['"]WP_DEBUG['"]/i.test(text)?text=text.replace(/define\(\s*['"]WP_DEBUG['"]\s*,\s*(true|false)\s*\);/i,`define('WP_DEBUG', ${enabled?"true":"false"});`):text=text.replace("<?php",`<?php
define('WP_DEBUG', ${enabled?"true":"false"});
`),fs.writeFileSync(wpConfigPath,text,"utf8"),{success:!0,domain,debugMode:!!enabled}}async function installWordPress({domain,subPath="",title="My WordPress Site",adminUser="admin",adminPass,adminEmail,autoWpLock=!0,user}){domain=validate.domain(domain);const site=await websites.getWebsite(domain);if(!site)throw validate.badRequest("Website not found: "+domain);const docRoot=site.documentRoot||platform.docRoot(domain),targetDir=subPath&&subPath!=="/"?path.join(docRoot,subPath.replace(/^\//,"")):docRoot;fs.mkdirSync(targetDir,{recursive:!0});const randSuffix=crypto.randomBytes(3).toString("hex"),dbName=`wp_${domain.replace(/[^a-z0-9]/gi,"_").slice(0,10).toLowerCase()}_${randSuffix}`,dbUser=`wp_${randSuffix}`,dbPass=adminPass||"Wp@"+crypto.randomBytes(6).toString("hex")+"!",contactEmail=adminEmail||`admin@${domain}`;await databases.createDatabase({name:dbName,user}),await databases.createUser({username:dbUser,password:dbPass,user}).catch(()=>{}),await databases.grantUser({database:dbName,username:dbUser,privileges:"ALL PRIVILEGES",user}).catch(()=>{});const wpTarPath="/tmp/wordpress.tar.gz";fs.existsSync(wpTarPath)||await shell.run(`curl -sL https://wordpress.org/latest.tar.gz -o ${wpTarPath} 2>/dev/null || true`),fs.existsSync(wpTarPath)&&(await shell.run(`tar -xzf ${wpTarPath} -C /tmp/`),await shell.run(`cp -rn /tmp/wordpress/* ${shell.q(targetDir)}/ 2>/dev/null || cp -r /tmp/wordpress/* ${shell.q(targetDir)}/`));const makeSalt=()=>crypto.randomBytes(32).toString("base64"),tablePrefix=`wp_${crypto.randomBytes(2).toString("hex")}_`,wpConfigContent=`<?php
define('DB_NAME', '${dbName}');
define('DB_USER', '${dbUser}');
define('DB_PASSWORD', '${dbPass}');
define('DB_HOST', '127.0.0.1');
define('DB_CHARSET', 'utf8mb4');
define('DB_COLLATE', '');

define('AUTH_KEY',         '${makeSalt()}');
define('SECURE_AUTH_KEY',  '${makeSalt()}');
define('LOGGED_IN_KEY',    '${makeSalt()}');
define('NONCE_KEY',        '${makeSalt()}');
define('AUTH_SALT',        '${makeSalt()}');
define('SECURE_AUTH_SALT', '${makeSalt()}');
define('LOGGED_IN_SALT',   '${makeSalt()}');
define('NONCE_SALT',       '${makeSalt()}');

$table_prefix = '${tablePrefix}';

define('WP_DEBUG', false);
define('WP_AUTO_UPDATE_CORE', 'minor');

if (!defined('ABSPATH')) {
  define('ABSPATH', __DIR__ . '/');
}
require_once ABSPATH . 'wp-settings.php';
`;fs.writeFileSync(path.join(targetDir,"wp-config.php"),wpConfigContent,{mode:416});const webUser=platform.IS_AAPANEL?"www":"www-data";await shell.run(`chown -R ${webUser}:${webUser} ${shell.q(targetDir)} 2>/dev/null || true`);const siteUrl=(site.ssl?"https://":"http://")+domain+(subPath&&subPath!=="/"?subPath:"");return{success:!0,domain,subPath,url:siteUrl,adminUrl:siteUrl+"/wp-admin/",database:dbName,dbUser,adminUser,adminPass:dbPass,adminEmail:contactEmail}}async function aiSitebuilderGenerate({domain,subPath="",businessName,businessType="technology",tagline,description,themeColor="#2563eb",user}){domain=validate.domain(domain);const site=await websites.getWebsite(domain);if(!site)throw validate.badRequest("Website not found: "+domain);const docRoot=site.documentRoot||platform.docRoot(domain),targetDir=subPath&&subPath!=="/"?path.join(docRoot,subPath.replace(/^\//,"")):docRoot;fs.mkdirSync(targetDir,{recursive:!0});const brand=businessName||domain.replace(/\.[a-z]+$/i,"").toUpperCase(),subhead=tagline||`Welcome to ${brand} \u2014 Innovative Solutions Built for Scale`,desc=description||`${brand} delivers premier, cloud-powered experiences with modern design, rock-solid security, and lightning performance.`,html=`<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${brand} | Official Website</title>
  <script src="https://cdn.tailwindcss.com"><\/script>
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
  <style>
    body { font-family: 'Plus Jakarta Sans', sans-serif; }
    .primary-color { color: ${themeColor}; }
    .bg-primary { background-color: ${themeColor}; }
  </style>
</head>
<body class="bg-slate-950 text-slate-100 antialiased selection:bg-blue-600 selection:text-white">
  <!-- Navigation -->
  <nav class="fixed top-0 inset-x-0 z-50 bg-slate-950/80 backdrop-blur-md border-b border-slate-800">
    <div class="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
      <div class="flex items-center gap-3">
        <div class="w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-600 to-indigo-600 flex items-center justify-center font-black text-xl text-white shadow-lg shadow-blue-500/20">
          ${brand.charAt(0)}
        </div>
        <span class="text-xl font-bold tracking-tight text-white">${brand}</span>
      </div>
      <div class="hidden md:flex items-center gap-8 text-sm font-medium text-slate-300">
        <a href="#features" class="hover:text-white transition">Features</a>
        <a href="#about" class="hover:text-white transition">About</a>
        <a href="#services" class="hover:text-white transition">Services</a>
        <a href="#contact" class="hover:text-white transition">Contact</a>
      </div>
      <div class="flex items-center gap-4">
        <a href="#contact" class="px-5 py-2.5 rounded-full bg-blue-600 hover:bg-blue-500 text-white font-semibold text-xs tracking-wide shadow-md shadow-blue-600/30 transition">
          Get Started
        </a>
      </div>
    </div>
  </nav>

  <!-- Hero Section -->
  <section class="pt-40 pb-24 px-6 relative overflow-hidden">
    <div class="absolute inset-0 bg-[radial-gradient(ellipse_80%_80%_at_50%_-20%,rgba(59,130,246,0.15),rgba(255,255,255,0))]"></div>
    <div class="max-w-5xl mx-auto text-center relative z-10">
      <div class="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-400 text-xs font-semibold uppercase tracking-wider mb-8">
        \u2728 Generated by UltraOnePanel AI Sitebuilder
      </div>
      <h1 class="text-5xl md:text-7xl font-extrabold tracking-tight text-white leading-tight mb-8">
        ${subhead}
      </h1>
      <p class="text-lg md:text-xl text-slate-400 max-w-3xl mx-auto leading-relaxed mb-10">
        ${desc}
      </p>
      <div class="flex flex-col sm:flex-row items-center justify-center gap-4">
        <a href="#contact" class="w-full sm:w-auto px-8 py-4 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-sm tracking-wide shadow-lg shadow-blue-600/30 transition transform hover:-translate-y-0.5">
          Request a Consultation
        </a>
        <a href="#features" class="w-full sm:w-auto px-8 py-4 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-200 border border-slate-800 font-semibold text-sm transition">
          Explore Features
        </a>
      </div>
    </div>
  </section>

  <!-- Features Grid -->
  <section id="features" class="py-24 px-6 border-t border-slate-900 bg-slate-900/40">
    <div class="max-w-7xl mx-auto">
      <div class="text-center max-w-3xl mx-auto mb-16">
        <h2 class="text-3xl font-bold tracking-tight text-white sm:text-4xl">Engineered for Excellence</h2>
        <p class="text-slate-400 mt-4 text-base">Built to provide unmatched reliability, high throughput, and effortless client experiences.</p>
      </div>

      <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div class="p-8 rounded-2xl bg-slate-900/60 border border-slate-800 hover:border-blue-500/50 transition">
          <div class="w-12 h-12 rounded-xl bg-blue-600/10 border border-blue-500/20 flex items-center justify-center text-blue-400 mb-6">
            \u26A1
          </div>
          <h3 class="text-xl font-bold text-white mb-3">Ultra Fast Performance</h3>
          <p class="text-slate-400 text-sm leading-relaxed">Global CDN edge routing, HTTP/3 QUIC, and kernel-level caching ensure sub-millisecond load times.</p>
        </div>

        <div class="p-8 rounded-2xl bg-slate-900/60 border border-slate-800 hover:border-blue-500/50 transition">
          <div class="w-12 h-12 rounded-xl bg-purple-600/10 border border-purple-500/20 flex items-center justify-center text-purple-400 mb-6">
            \u{1F6E1}\uFE0F
          </div>
          <h3 class="text-xl font-bold text-white mb-3">SShield AI Security</h3>
          <p class="text-slate-400 text-sm leading-relaxed">Integrated ModSecurity WAF, automated SQLi defense, and real-time anti-carding fraud shield.</p>
        </div>

        <div class="p-8 rounded-2xl bg-slate-900/60 border border-slate-800 hover:border-blue-500/50 transition">
          <div class="w-12 h-12 rounded-xl bg-emerald-600/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400 mb-6">
            \u{1F4C8}
          </div>
          <h3 class="text-xl font-bold text-white mb-3">Scalable Growth</h3>
          <p class="text-slate-400 text-sm leading-relaxed">Seamless scaling from your initial launch to millions of monthly visitors with zero downtime.</p>
        </div>
      </div>
    </div>
  </section>

  <!-- Contact CTA -->
  <section id="contact" class="py-24 px-6 border-t border-slate-900">
    <div class="max-w-4xl mx-auto p-12 rounded-3xl bg-gradient-to-br from-blue-900/20 via-slate-900 to-indigo-950/30 border border-blue-500/20 text-center">
      <h2 class="text-3xl md:text-4xl font-extrabold text-white mb-4">Ready to elevate your digital presence?</h2>
      <p class="text-slate-400 mb-8 max-w-xl mx-auto">Get in touch with our team today and receive a personalized proposal tailored to your needs.</p>
      <form class="max-w-md mx-auto flex flex-col sm:flex-row gap-3" onsubmit="event.preventDefault(); alert('Thank you! Our team will contact you shortly.');">
        <input type="email" required placeholder="Enter your email address" class="px-4 py-3 rounded-xl bg-slate-950 border border-slate-800 text-white placeholder-slate-500 text-sm flex-1 outline-none focus:border-blue-500">
        <button type="submit" class="px-6 py-3 bg-blue-600 hover:bg-blue-500 text-white font-bold text-sm rounded-xl transition">
          Contact Us
        </button>
      </form>
    </div>
  </section>

  <!-- Footer -->
  <footer class="py-12 px-6 border-t border-slate-900 text-center text-slate-500 text-xs">
    <p>&copy; ${new Date().getFullYear()} ${brand}. All rights reserved. Hosted with UltraOnePanel.</p>
  </footer>
</body>
</html>
`,indexPath=path.join(targetDir,"index.html");fs.existsSync(indexPath)&&fs.copyFileSync(indexPath,path.join(targetDir,"index.html.bak")),fs.writeFileSync(indexPath,html,"utf8");const webUser=platform.IS_AAPANEL?"www":"www-data";await shell.run(`chown ${webUser}:${webUser} ${shell.q(indexPath)} 2>/dev/null || true`);const previewUrl=(site.ssl?"https://":"http://")+domain+(subPath&&subPath!=="/"?subPath:"");return{success:!0,domain,previewUrl}}module.exports={listSites,autoLogin,toggleMaintenance,toggleDebugMode,installWordPress,aiSitebuilderGenerate};
