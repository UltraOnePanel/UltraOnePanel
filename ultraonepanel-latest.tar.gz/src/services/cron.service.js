const crypto = require("crypto");
const shell = require("./shell.service");
const store = require("../lib/store");
const validate = require("../lib/validate");

// Jobs live in root's real crontab. A "# fz: <description>" line above a job
// holds its description; disabled jobs are commented out with "#FZOFF ".
const DESC_PREFIX = "# fz: ";
const OFF_PREFIX = "#FZOFF ";
const SPECIALS = ["@reboot", "@yearly", "@annually", "@monthly", "@weekly", "@daily", "@midnight", "@hourly"];

function jobId(schedule, command) {
  return crypto.createHash("sha1").update(schedule + " " + command).digest("hex").slice(0, 12);
}

async function readCrontab() {
  if (!shell.IS_LINUX) return store.read("dev-crontab", "");
  return shell.tryGet("crontab -l 2>/dev/null", "");
}

async function writeCrontab(text, user) {
  if (!shell.IS_LINUX) return store.write("dev-crontab", text);
  // No jobs left: remove the crontab instead of leaving an empty one behind.
  if (!text.trim()) return shell.run("crontab -r 2>/dev/null || true", { user });
  await shell.run("crontab -", { input: text.replace(/\n*$/, "\n"), user });
}

function splitJob(line) {
  const t = line.trim();
  const special = SPECIALS.find((s) => t.startsWith(s + " "));
  if (special) return { schedule: special, command: t.slice(special.length).trim() };
  const m = t.match(/^(\S+\s+\S+\s+\S+\s+\S+\s+\S+)\s+(.+)$/);
  if (!m || !m[1].split(/\s+/).every((f) => /^[\d*\/,\-A-Za-z]+$/.test(f))) return null;
  return { schedule: m[1].replace(/\s+/g, " "), command: m[2] };
}

/** Parse crontab text into lines, tagging the ones that are jobs. */
function parse(text) {
  const lines = text.split("\n");
  const jobs = [];
  lines.forEach((line, i) => {
    let active = true;
    let body = line;
    if (line.startsWith(OFF_PREFIX)) { active = false; body = line.slice(OFF_PREFIX.length); }
    else if (/^\s*#/.test(line) || /^\s*$/.test(line) || /^\s*[A-Z_]+=/.test(line)) return;
    const job = splitJob(body);
    if (!job) return;
    const prev = lines[i - 1] || "";
    const description = prev.startsWith(DESC_PREFIX) ? prev.slice(DESC_PREFIX.length) : "";
    jobs.push({
      id: jobId(job.schedule, job.command),
      schedule: job.schedule,
      command: job.command,
      description,
      active,
      enabled: active,
      managed: !!description,
      line: i,
    });
  });
  return { lines, jobs };
}

function validateSchedule(schedule) {
  const s = String(schedule || "").trim().replace(/\s+/g, " ");
  if (SPECIALS.includes(s)) return s;
  const fields = s.split(" ");
  if (fields.length !== 5 || !fields.every((f) => /^[\d*\/,\-A-Za-z]+$/.test(f))) {
    throw validate.badRequest("Schedule must have 5 fields, e.g. */5 * * * *");
  }
  return s;
}

async function listCrons(user) {
  let jobs = parse(await readCrontab()).jobs.map(({ line, ...j }) => j);
  if (user && user.role !== "admin" && user.username !== "root") {
    const un = (user.username || "").toLowerCase().trim();
    const uDomain = (user.domain || "").toLowerCase().trim();
    jobs = jobs.filter((j) => {
      const desc = (j.description || "").toLowerCase();
      const cmd = (j.command || "").toLowerCase();
      return desc.includes(`[user:${un}]`) || cmd.includes(un) || (uDomain && cmd.includes(uDomain));
    });
  }
  return jobs;
}

async function addCron({ schedule, command, description, user, currentUser }) {
  schedule = validateSchedule(schedule);
  command = String(command || "").trim();
  if (!command || /[\r\n]/.test(command)) throw validate.badRequest("Command is required and must be a single line.");
  let desc = String(description || "Custom cron job").replace(/[\r\n]/g, " ").trim();
  if (currentUser && currentUser.role !== "admin" && currentUser.username !== "root") {
    desc += ` [user:${currentUser.username}]`;
  }

  const text = await readCrontab();
  if (parse(text).jobs.some((j) => j.id === jobId(schedule, command))) {
    throw validate.badRequest("An identical cron job already exists.");
  }
  const next = text.replace(/\n*$/, "") + (text.trim() ? "\n" : "") + DESC_PREFIX + desc + "\n" + schedule + " " + command + "\n";
  await writeCrontab(next, user);
  return { id: jobId(schedule, command), schedule, command, description: desc, active: true, enabled: true, managed: true };
}

async function mutate(id, user, fn) {
  const { lines, jobs } = parse(await readCrontab());
  const job = jobs.find((j) => j.id === String(id));
  if (!job) throw validate.badRequest("Cron job not found.");
  fn(lines, job);
  await writeCrontab(lines.filter((l) => l !== null).join("\n"), user);
  return job;
}

async function deleteCron({ id, user }) {
  await mutate(id, user, (lines, job) => {
    lines[job.line] = null;
    if (job.description) lines[job.line - 1] = null;
  });
  return { id, status: "deleted" };
}

async function toggleCron({ id, user }) {
  const job = await mutate(id, user, (lines, j) => {
    const body = j.schedule + " " + j.command;
    lines[j.line] = j.active ? OFF_PREFIX + body : body;
  });
  return { ...job, active: !job.active, enabled: !job.active };
}

module.exports = { listCrons, addCron, deleteCron, toggleCron };
