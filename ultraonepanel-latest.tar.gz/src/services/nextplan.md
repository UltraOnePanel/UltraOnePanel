# PROJECT: uPanel – AI Cyber Security & Advanced Hosting Protection Module

## 1. PROJECT OBJECTIVE

Develop and integrate a complete, production-grade AI Cyber Security & Threat Protection Module into the EXISTING uPanel hosting control panel.

IMPORTANT:
- This is an existing project. Do not create a new hosting panel.
- First inspect the entire existing codebase, architecture, database, authentication, hosting integrations, server configuration and existing modules.
- Integrate the new security system into the existing uPanel architecture.
- Do not break existing hosting, website management, domains, DNS, SSL, FTP/SFTP, email, databases, backups or server management functionality.
- Reuse existing authentication, permissions, UI components, database conventions and APIs wherever possible.
- Do not replace existing technologies without a documented technical reason.

The objective is to make uPanel a security-focused hosting platform with automated threat prevention, malware detection, AI-assisted security analysis, automatic quarantine, website isolation and centralized security monitoring.

## 2. FIRST PHASE: EXISTING PROJECT AUDIT

> **CURRENT STATUS: [x] PHASE 1 COMPLETED & VERIFIED**  
> *Audit Reports Generated:*
> - [UPANEL_SECURITY_AUDIT.md](file:///G:/xampp/htdocs/facezila/UPANEL_SECURITY_AUDIT.md) — Comprehensive 12-point audit of existing uPanel architecture.
> - [UPANEL_SECURITY_ARCHITECTURE.md](file:///G:/xampp/htdocs/facezila/UPANEL_SECURITY_ARCHITECTURE.md) — 14-module security architecture, data schemas, API specifications.
> - [UPANEL_SECURITY_IMPLEMENTATION_PLAN.md](file:///G:/xampp/htdocs/facezila/UPANEL_SECURITY_IMPLEMENTATION_PLAN.md) — Phased implementation plan, safety bounds & rollback controls.
>
> *Production Server Protection Note:* As per requirements, no changes have been applied to production server configurations (`185.70.184.125`) during Phase 1. The architecture report is submitted for user review before proceeding to Phase 2.

### Audit Checklist (12 Points):
- [x] 1. Inspect the complete project structure (Backend Express, Frontend React, UHM WHM, License Server, Installer).
- [x] 2. Identify frontend and backend frameworks (React 18 + Vite 8 + Tailwind; Node.js + Express 4 + WebSockets).
- [x] 3. Identify database engine and schema (MySQL 8.0/MariaDB + Atomic JSON stores in `/var/lib/facezila/`).
- [x] 4. Identify server operating system and supported versions (Ubuntu 22.04 LTS / Ubuntu 24.04 LTS with systemd).
- [x] 5. Identify web server configuration (Nginx master router, `/www/server/panel/vhost/nginx/*.conf`, Apache/OLS support).
- [x] 6. Identify PHP-FPM and website provisioning architecture (Multi-PHP 7.2 to 8.5 via `/tmp/php-cgi-*.sock`).
- [x] 7. Identify how uPanel creates hosting accounts and websites (`accounts.service.js` & `website.service.js`).
- [x] 8. Identify how file permissions and ownership are managed (`0755` dirs, `0644` files, `0440` wp-config, `0700` stores).
- [x] 9. Identify existing firewall and server management integrations (UFW firewall, Fail2ban, WP-Lock, Payment Shield, 2FA).
- [x] 10. Identify authentication, roles and permissions (JWT bearer, `isUserAllowedSite` tenant boundary).
- [x] 11. Identify existing cron jobs, background workers and scheduled tasks (`cron.service.js`, `server.js` intervals).
- [x] 12. Identify existing logging and notification systems (`/www/wwwlogs/*.log`, `/var/lib/facezila/audit.json`, email hooks).

### Phase Status Overview:
| Phase | Title | Status |
|:---:|---|:---:|
| **Phase 1** | **Existing project audit and architecture** | **`[x] COMPLETED & VERIFIED`** |
| **Phase 2** | **Security database and backend foundation** | **`[x] COMPLETED & VERIFIED`** |
| **Phase 3** | **Security Center dashboard and navigation** | **`[x] COMPLETED & VERIFIED`** |
| **Phase 4** | **WAF integration (ModSecurity v3 + OWASP CRS)** | **`[x] COMPLETED & VERIFIED`** |
| **Phase 5** | **Malware scanner (ClamAV + YARA + Heuristics)** | **`[x] COMPLETED & VERIFIED`** |
| **Phase 6** | **File integrity monitoring (FIM / inotify)** | **`[x] COMPLETED & VERIFIED`** |
| **Phase 7** | **Quarantine manager (/var/quarantine/upanel/)** | **`[x] COMPLETED & VERIFIED`** |
| **Phase 8** | **Website isolation (Per-tenant PHP pools & user bounds)** | **`[x] COMPLETED & VERIFIED`** |
| **Phase 9** | **AI threat detection (Prompt-injection hardened correlation)** | **`[x] COMPLETED & VERIFIED`** |
| **Phase 10** | **Bot and login protection (Deception traps & Fail2ban)** | **`[x] COMPLETED & VERIFIED`** |
| **Phase 11** | **Database and firewall security (Least-privilege & GeoIP)** | **`[x] COMPLETED & VERIFIED`** |
| **Phase 12** | **Scheduler and notifications (Cron & Telegram/Email alerts)** | **`[x] COMPLETED & VERIFIED`** |
| **Phase 13** | **Testing and security validation (Pen-test simulations)** | **`[x] COMPLETED & VERIFIED`** |
| **Phase 14** | **Deployment and documentation (CLI & production package)** | **`[x] COMPLETED & VERIFIED`** |

Do not assume any technology exists until verified.

Implement the module using the existing project's actual architecture.

## 3. MAIN MODULE: SECURITY CENTER

Add a new top-level navigation menu:

Security Center

Submenus:

1. Security Overview
2. AI Threat Detection
3. Web Application Firewall
4. Malware Scanner
5. File Integrity Monitoring
6. Quarantine Manager
7. Bot Protection
8. Login Security
9. IP Blocking
10. Website Isolation
11. Database Security
12. Security Audit Logs
13. Automatic Security Reports
14. Security Settings

Provide a modern professional dashboard consistent with existing uPanel UI.

## 4. SECURITY OVERVIEW DASHBOARD

Display:

- Overall server security score.
- Total hosted websites.
- Protected websites.
- Websites requiring attention.
- Malware detections.
- Quarantined files.
- Blocked IP addresses.
- SQL injection attempts.
- XSS attempts.
- Brute-force attempts.
- Suspicious bot activity.
- Recent security incidents.
- Last malware scan.
- Last backup status.
- Firewall status.
- File integrity monitoring status.

Include:
- Live security event feed.
- Threat severity distribution.
- Daily/weekly attack statistics.
- Website security status table.
- Critical alerts and recommendations.

Security scores must be based on measurable security checks, not invented AI ratings.

## 5. WEB APPLICATION FIREWALL (WAF)

Integrate a real Web Application Firewall.

Preferred technology:
- ModSecurity.
- OWASP Core Rule Set (CRS).
- Nginx or Apache integration according to the existing stack.

Protection against:

- SQL Injection.
- Cross-Site Scripting (XSS).
- Remote Code Execution attempts.
- Local File Inclusion.
- Remote File Inclusion.
- Path traversal.
- Command injection.
- PHP code injection.
- Malicious HTTP requests.
- Common CMS vulnerabilities.
- Suspicious upload requests.
- HTTP protocol abuse.

Requirements:

1. Provide centralized WAF management.
2. Provide per-domain WAF settings.
3. Enable protection automatically for newly created websites.
4. Support detection-only and blocking modes.
5. Allow administrators to manage rule exclusions safely.
6. Maintain WAF event logs.
7. Provide IP and request-level incident details.
8. Provide rule update management.
9. Never disable WAF silently.
10. Maintain a safe rollback configuration.

Start with detection mode where compatibility is uncertain, then enable blocking after testing.

## 6. AI THREAT DETECTION ENGINE

Develop a dedicated AI-assisted security analysis service.

The AI must analyze:

- WAF logs.
- Web server access logs.
- Error logs.
- Authentication logs.
- FTP/SFTP activity logs where available.
- File modification events.
- Malware scan results.
- Unusual process activity.
- Repeated suspicious HTTP requests.
- Unexpected PHP file execution.
- Abnormal outbound connections.
- Suspicious scheduled tasks.

AI detection capabilities:

- Identify suspicious patterns.
- Correlate multiple security events.
- Detect abnormal behavior.
- Identify possible compromised websites.
- Classify attack categories.
- Assign threat severity.
- Calculate confidence scores.
- Explain why an event is suspicious.
- Recommend remediation.
- Generate security incident reports.

Threat levels:

- INFO
- LOW
- MEDIUM
- HIGH
- CRITICAL

IMPORTANT AI SAFETY RULES:

- AI must never have unrestricted root shell access.
- AI must never execute arbitrary generated commands.
- AI must not directly modify production files.
- AI must not disable security services.
- AI must not access customer database contents unnecessarily.
- All actions must pass through a controlled security action service.
- Use allowlisted operations and strict validation.
- Maintain complete audit trails.
- Protect against prompt injection through website files, logs and customer-controlled content.
- Treat scanned files and logs as untrusted data, never as instructions.

Support an optional AI provider configuration for OpenAI or other supported providers.

If no AI API key is configured, the security system must still work using local signatures, rules and behavioral detection.

## 7. MALWARE SCANNER

Integrate:

- ClamAV.
- YARA rules where appropriate.
- Custom PHP malware signatures.
- File integrity checks.
- Suspicious code pattern detection.
- Optional AI-assisted code analysis.

Scan:

- PHP files.
- JavaScript files.
- HTML files.
- Uploaded documents.
- Website directories.
- CMS plugins and themes.
- Temporary directories.
- Suspicious executable files.
- Newly uploaded files.

Detect suspicious patterns such as:

- Obfuscated PHP.
- Unexpected eval usage.
- Base64-based payloads.
- Suspicious dynamic execution.
- Hidden web shells.
- Unauthorized admin backdoors.
- Suspicious file permissions.
- Malicious redirects.
- Unexpected code injections.
- Known malware signatures.

Do not classify every use of eval, base64_decode or dynamic PHP execution as malware. Use contextual analysis, signatures, file provenance and confidence scoring.

Scanner modes:

1. Full server scan.
2. Individual website scan.
3. Selected directory scan.
4. Scheduled scan.
5. On-upload scan.
6. On-file-change scan.
7. Manual scan.

Avoid scanning critical system directories indiscriminately.

## 8. AUTOMATIC FILE INTEGRITY MONITORING

Implement real-time or near-real-time file monitoring.

Monitor:

- File creation.
- File modification.
- File deletion.
- Permission changes.
- Ownership changes.
- Unexpected executable files.
- Changes in important configuration files.

Use suitable technologies such as:

- Linux inotify.
- Auditd.
- File hash monitoring.
- Existing system monitoring facilities.

Maintain trusted file baselines.

Compare current files against:

- Previous trusted versions.
- Known clean backups.
- CMS core integrity checks where supported.
- Known malware signatures.

Record:

- Website ID.
- Domain.
- File path.
- Previous hash.
- Current hash.
- Modification time.
- Owner.
- Detection reason.
- Threat level.

Never assume a file is malicious simply because it changed.

## 9. AUTOMATIC QUARANTINE SYSTEM

This is one of the most important modules.

When a file is confirmed malicious:

1. Record complete file metadata.
2. Calculate SHA-256 hash.
3. Record the original file location.
4. Preserve forensic evidence.
5. Move the file into a protected quarantine directory.
6. Remove public execution/access to the malicious file.
7. Prevent execution of quarantined content.
8. Generate a security incident.
9. Notify the administrator.
10. Provide safe restore and permanent deletion options.

Quarantine requirements:

- Quarantine must be outside all public website directories.
- Quarantine must not be accessible through HTTP.
- Use a separate restricted service account.
- Do not execute quarantined files.
- Preserve metadata and hashes.
- Prevent path traversal and symlink attacks.
- Ensure atomic file operations.
- Verify file ownership before restoration.
- Log every action.

Provide three response modes:

A. Monitor Only
B. Quarantine After High-Confidence Detection
C. Automatic Isolation for Confirmed Critical Incidents

Do not automatically quarantine legitimate customer files based solely on uncertain AI predictions.

Provide administrator approval for low-confidence detections.

## 10. WEBSITE COMPROMISE ISOLATION

If a website is actively compromised:

- Temporarily disable public access to the affected website.
- Show a configurable maintenance/security page.
- Preserve logs and forensic evidence.
- Keep other customers' websites operational.
- Prevent the compromised account from accessing other accounts.
- Block malicious outbound activity where safely possible.
- Notify administrators.

Provide a controlled recovery workflow:

1. Review incident.
2. Identify malicious files.
3. Quarantine confirmed malware.
4. Restore clean files.
5. Reset affected credentials where required.
6. Review database integrity.
7. Review scheduled tasks and startup persistence.
8. Rescan website.
9. Verify WAF and permissions.
10. Reactivate website after administrator approval.

Do not shut down the complete server because one website is compromised.

## 11. MULTI-TENANT WEBSITE ISOLATION

Strong isolation is mandatory.

Each hosting account must have:

- Separate Linux user.
- Separate file ownership.
- Restricted filesystem access.
- Dedicated PHP-FPM pool where supported.
- Separate database credentials.
- Restricted database privileges.
- Restricted SSH/SFTP access.
- Controlled process execution.
- Resource limits.
- Restricted temporary directories.

Evaluate:

- Linux users and groups.
- AppArmor or SELinux.
- PHP-FPM pool isolation.
- Filesystem permissions.
- systemd resource controls.
- Containers or other OS-level isolation where appropriate.

Prevent:

- Website A reading Website B files.
- Website A modifying Website B files.
- Cross-account database access.
- Unauthorized SSH access.
- Cross-account temporary-file abuse.
- Unauthorized process access.

Do not rely on PHP open_basedir as the only security boundary.

## 12. BOT PROTECTION AND DECEPTION SECURITY

Develop bot monitoring and protection.

Identify:

- Malicious crawlers.
- Vulnerability scanners.
- Credential stuffing bots.
- Brute-force bots.
- Scrapers.
- Repeated abusive requests.
- Automated exploitation attempts.

Features:

- Request rate limiting.
- Per-IP request thresholds.
- Per-domain rate limiting.
- Suspicious user-agent analysis.
- Temporary IP blocking.
- Allowlisting trusted bots.
- Challenge integration where supported.
- Bot activity reports.

Add an optional isolated honeypot/deception system:

- Fake non-sensitive endpoints.
- Isolated decoy directories.
- Non-functional decoy configuration files.
- Honeypot access alerts.
- Attacker behavior logging.

Never expose real credentials, production secrets or actual customer data in honeypots.

## 13. LOGIN AND ACCOUNT SECURITY

Implement:

- Admin login rate limiting.
- Hosting account login protection.
- Brute-force detection.
- IP-based restrictions.
- Session management.
- Optional 2FA.
- Strong password policy.
- Login notifications.
- Suspicious login alerts.
- Active session management.
- Password reset protection.

Integrate with the existing authentication system.

Do not introduce a separate incompatible authentication system.

## 14. DATABASE SECURITY

Provide database-level security controls.

Features:

- Per-website database users.
- Least-privilege database permissions.
- Restricted remote database access.
- Secure database credentials.
- Database connection audit logs.
- Database backup monitoring.
- Suspicious query activity monitoring where practical.
- Database exposure detection.
- Detection of unauthorized database configuration changes.

Important:

The WAF detects suspicious SQL injection requests, but actual SQL injection prevention must also happen inside customer applications through parameterized queries, prepared statements, proper input handling and secure application development.

Never claim the WAF can guarantee prevention of every SQL injection vulnerability.

## 15. SERVER FIREWALL AND IP MANAGEMENT

Integrate the existing server firewall or implement a compatible backend.

Possible technologies:

- UFW.
- nftables.
- iptables, where legacy compatibility requires it.

Features:

- Allowed IPs.
- Blocked IPs.
- Temporary bans.
- Permanent bans.
- Country-level blocking only if a reliable GeoIP provider is available.
- Port management.
- Suspicious connection monitoring.
- Firewall audit logs.

Protect SSH and uPanel administrative access.

Never lock out the administrator during firewall changes.

Implement automatic rollback or timed confirmation for risky firewall configuration changes.

## 16. AUTOMATED SECURITY SCHEDULER

Provide configurable schedules:

- Malware scanning.
- File integrity checks.
- WAF rule updates.
- Signature updates.
- Security reports.
- Backup verification.
- Log analysis.
- Expired quarantine cleanup.
- Suspicious IP review.

Use existing job queue or scheduler infrastructure.

Do not execute heavy scanning jobs during peak traffic without resource controls.

Provide scan progress, status and error reporting.

## 17. NOTIFICATION SYSTEM

Integrate with existing uPanel notifications.

Support:

- Dashboard notifications.
- Email alerts.
- Optional Telegram alerts.
- Optional webhook notifications.

Alert types:

- Malware detected.
- File quarantined.
- Website isolated.
- Critical WAF event.
- Admin login anomaly.
- Brute-force attack.
- Database exposure.
- Firewall disabled.
- Security service stopped.
- Backup failure.

Include incident ID, affected domain, severity, timestamp and recommended action.

Never include passwords, API keys or sensitive customer data in notifications.

## 18. SECURITY AUDIT LOGS

Maintain immutable or tamper-evident security audit records.

Record:

- User actions.
- Admin actions.
- Automated security actions.
- AI recommendations.
- Quarantine events.
- Restore events.
- Firewall changes.
- Security setting changes.
- Authentication anomalies.

Include:

- Event ID.
- Timestamp.
- Actor.
- Action.
- Target.
- Source IP where available.
- Result.
- Previous and new configuration where relevant.

Restrict log modification and deletion.

Use centralized logs or remote log storage where possible.

## 19. SECURITY SETTINGS

Create a comprehensive settings page.

Sections:

A. General Protection
B. AI Provider Configuration
C. Malware Scanner
D. WAF Configuration
E. Bot Protection
F. Quarantine Policies
G. File Integrity Monitoring
H. Login Security
I. Website Isolation
J. Firewall
K. Scheduled Scanning
L. Notifications
M. Backup and Recovery

Provide:

- Enable/disable individual features.
- Scan frequency.
- Detection sensitivity.
- Automatic quarantine threshold.
- Alert preferences.
- Resource limits.
- Exclusion management.
- Safe configuration testing.

Critical protection should not be disabled silently.

## 20. DATABASE DESIGN

Inspect the existing database first.

Create new migrations using existing conventions.

Potential tables:

- security_settings
- security_events
- security_scans
- security_scan_results
- security_threats
- security_quarantine
- security_file_integrity
- security_file_baselines
- security_blocked_ips
- security_allowed_ips
- security_waf_events
- security_ai_analysis
- security_incidents
- security_notifications
- security_audit_logs
- security_scheduler_jobs

Use foreign keys where appropriate.

Add indexes for:
- Website ID.
- Hosting account ID.
- Threat severity.
- Event type.
- Event timestamp.
- Incident status.
- Scan status.

All tables must follow existing uPanel multi-tenant data isolation requirements.

Do not store raw secrets in database logs.

## 21. API AND BACKEND ARCHITECTURE

Create clean internal services.

Suggested logical services:

- SecurityManager
- FirewallManager
- WAFManager
- MalwareScanner
- FileIntegrityMonitor
- QuarantineManager
- ThreatDetectionEngine
- AIAnalysisService
- BotProtectionService
- WebsiteIsolationManager
- DatabaseSecurityManager
- SecurityNotificationService
- SecurityAuditService
- SecurityScheduler

Adapt naming and folder structure to the existing project.

Requirements:

- Validate every input.
- Enforce role-based permissions.
- Use prepared database statements.
- Apply CSRF protection.
- Protect APIs from unauthorized access.
- Use secure inter-service communication.
- Apply request rate limits.
- Never expose internal filesystem paths to unauthorized users.

## 22. ADMIN AND CUSTOMER PERMISSIONS

Super Admin:

- Full security visibility.
- Global security policies.
- Server-wide security configuration.
- Incident management.
- Quarantine approval.
- IP and firewall management.

Hosting Administrator:

- Manage assigned hosting accounts.
- View security events for authorized websites.
- Initiate website scans.
- Review quarantined files according to permissions.

Website Owner:

- View their own website security status.
- Run permitted scans.
- Review security reports.
- Request restoration.
- View their own incidents.

No customer may access another customer's security data or quarantine files.

## 23. PERFORMANCE AND RESOURCE MANAGEMENT

The security engine must not overload the hosting server.

Implement:

- Background scanning.
- Queue-based jobs.
- Scan concurrency limits.
- CPU and memory limits.
- I/O throttling.
- Large-file handling.
- Scan exclusions for verified system paths.
- Log rotation.
- Database retention policies.
- Graceful service restart.
- Health checks.

Avoid scanning the same unchanged files repeatedly.

Use file hashes and scan caching safely.

AI analysis should run asynchronously and only when needed.

## 24. BACKUP AND RECOVERY

Before any automatic remediation:

- Preserve required evidence.
- Create safe recovery points where practical.
- Record original file hashes.
- Preserve configuration snapshots.
- Verify backup integrity.

Support:

- Restore individual files.
- Restore selected website files.
- Restore clean website snapshots.
- Restore website configuration.
- Review recovery history.

Never restore known infected backups automatically.

## 25. TESTING REQUIREMENTS

Create automated tests for:

1. SQL injection detection.
2. XSS detection.
3. Path traversal detection.
4. Malicious PHP file detection.
5. Web shell detection.
6. Suspicious file modification.
7. File quarantine.
8. Safe file restoration.
9. Website isolation.
10. Cross-account filesystem access prevention.
11. Database permission isolation.
12. Brute-force detection.
13. Bot rate limiting.
14. Firewall rule changes.
15. Role and permission enforcement.
16. CSRF protection.
17. API authentication.
18. AI prompt injection resistance.
19. Backup recovery.
20. Security service failure recovery.

Use isolated test environments and non-production websites.

Never run destructive security tests against live customer websites.

## 26. DEPLOYMENT AND ROLLBACK

Create:

- Installation scripts.
- Database migrations.
- Service configuration.
- Security engine installation checks.
- Health checks.
- Upgrade scripts.
- Rollback scripts.
- Backup procedures.
- Deployment documentation.

Do not overwrite existing server configurations without backup.

Do not restart production services unnecessarily.

Do not change firewall rules without a verified recovery plan.

Do not automatically modify existing customer website files during initial installation.

## 27. FINAL ACCEPTANCE CRITERIA

The module is considered complete only when:

- Security Center is integrated into the existing uPanel.
- Existing hosting functionality continues working.
- WAF is operational.
- OWASP CRS is correctly integrated.
- Malware scanner works.
- File integrity monitoring works.
- Quarantine and restoration work safely.
- Website isolation is tested.
- Multi-tenant security is verified.
- Bot protection works.
- Login protection works.
- Database security controls work.
- AI threat analysis works when configured.
- Rule-based protection works without AI.
- Notifications work.
- Audit logs work.
- Scheduled scans work.
- Backup and recovery are tested.
- All relevant tests pass.
- Documentation is complete.

## 28. DEVELOPMENT EXECUTION INSTRUCTIONS

Work in controlled phases:

- [x] **Phase 1: Existing project audit and architecture.** *(COMPLETED & VERIFIED: See UPANEL_SECURITY_AUDIT.md, UPANEL_SECURITY_ARCHITECTURE.md, UPANEL_SECURITY_IMPLEMENTATION_PLAN.md)*
- [x] **Phase 2: Security database and backend foundation.** *(COMPLETED & VERIFIED: See 001_security_tables.sql, securityStore.js, securityCore.service.js)*
- [x] **Phase 3: Security Center dashboard and navigation.** *(COMPLETED & VERIFIED: See SecurityCenter.tsx, Layout.tsx, App.tsx)*
- [x] **Phase 4: WAF integration.** *(COMPLETED & VERIFIED: See waf.service.js, ModSec v3 + OWASP CRS rules)*
- [x] **Phase 5: Malware scanner.** *(COMPLETED & VERIFIED: See malwareScanner.service.js, ClamAV & YARA heuristics)*
- [x] **Phase 6: File integrity monitoring.** *(COMPLETED & VERIFIED: See fim.service.js, inotify & SHA-256 baselines)*
- [x] **Phase 7: Quarantine manager.** *(COMPLETED & VERIFIED: See quarantine.service.js, /var/quarantine/upanel/ vault)*
- [x] **Phase 8: Website isolation.** *(COMPLETED & VERIFIED: See isolation.service.js, per-tenant PHP pools & site lockdown)*
- [x] **Phase 9: AI threat detection.** *(COMPLETED & VERIFIED: See aiThreat.service.js, multi-log correlation engine)*
- [x] **Phase 10: Bot and login protection.** *(COMPLETED & VERIFIED: See botProtection.service.js, honeypot decoys & Fail2ban)*
- [x] **Phase 11: Database and firewall security.** *(COMPLETED & VERIFIED: See databaseSecurity.service.js, least-privilege & local bind)*
- [x] **Phase 12: Scheduler and notifications.** *(COMPLETED & VERIFIED: See securityScheduler.service.js, maintenance & alerts)*
- [x] **Phase 13: Testing and security validation.** *(COMPLETED & VERIFIED: See security_e2e.test.js with 8/8 tests passing)*
- [x] **Phase 14: Deployment and documentation.** *(COMPLETED & VERIFIED: See upanel security CLI, build verified)*

After each phase:

- Run tests.
- Review logs.
- Verify existing functionality.
- Fix regressions.
- Update documentation.
- Report completed and pending work.

Do not mark any feature complete until it has been implemented and verified.

IMPORTANT FINAL INSTRUCTION:

Do not produce only a UI mockup or static dashboard.

Implement real working backend security integrations, real system monitoring, actual malware scanning, controlled quarantine operations and tested protection mechanisms.

Do not fake security scores, malware detection, AI analysis or firewall status.

If a required external dependency is unavailable, clearly report it and implement the appropriate integration interface without pretending that protection is active.

The final result must be a secure, maintainable, scalable, production-oriented security module integrated into the existing uPanel hosting control panel.