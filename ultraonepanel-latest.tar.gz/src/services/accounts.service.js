const fs = require("fs");
const path = require("path");
const bcrypt = require("bcryptjs");
const shell = require("./shell.service");
const store = require("../lib/store");
const validate = require("../lib/validate");
const websites = require("./website.service");
const platform = require("../lib/platform");
const authService = require("./auth.service");

const DEFAULT_PACKAGES = [
  {
    id: "standard",
    name: "Standard Hosting",
    diskMB: 10240,
    bandwidthGB: 100,
    bandwidthMB: 102400,
    maxWebsites: 2,
    maxDatabases: 5,
    maxEmails: 10,
    maxFtp: 5,
    maxLists: 2,
    maxSubdomains: 10,
    maxParked: 5,
    maxAddons: 2,
    maxEmailPerHour: 200,
    maxDeferFailPercentage: 100,
    maxEmailQuotaMB: 1024,
    maxTeamUsers: 7,
    dedicatedIp: false,
    shellAccess: false,
    cgiAccess: true,
    digestAuth: false,
    cpanelTheme: "jupiter",
    featureList: "default",
    locale: "English",
    wpToolkit: false,
    cpuPercent: 100,
    ramMB: 2048,
    ioLimit: 20,
  },
  {
    id: "starter",
    name: "Starter Plan (5 GB)",
    diskMB: 5120,
    bandwidthGB: 50,
    bandwidthMB: 51200,
    maxWebsites: 1,
    maxDatabases: 2,
    maxEmails: 5,
    maxFtp: 2,
    maxLists: 1,
    maxSubdomains: 5,
    maxParked: 2,
    maxAddons: 1,
    maxEmailPerHour: 100,
    maxDeferFailPercentage: 100,
    maxEmailQuotaMB: 1024,
    maxTeamUsers: 7,
    dedicatedIp: false,
    shellAccess: false,
    cgiAccess: true,
    digestAuth: false,
    cpanelTheme: "jupiter",
    featureList: "default",
    locale: "English",
    wpToolkit: false,
    cpuPercent: 50,
    ramMB: 1024,
    ioLimit: 10,
  },
  {
    id: "business",
    name: "Business Plan (20 GB)",
    diskMB: 20480,
    bandwidthGB: 200,
    bandwidthMB: 204800,
    maxWebsites: 5,
    maxDatabases: 10,
    maxEmails: 25,
    maxFtp: 10,
    maxLists: 5,
    maxSubdomains: 20,
    maxParked: 10,
    maxAddons: 5,
    maxEmailPerHour: 500,
    maxDeferFailPercentage: 100,
    maxEmailQuotaMB: 1024,
    maxTeamUsers: 7,
    dedicatedIp: false,
    shellAccess: false,
    cgiAccess: true,
    digestAuth: false,
    cpanelTheme: "jupiter",
    featureList: "default",
    locale: "English",
    wpToolkit: false,
    cpuPercent: 100,
    ramMB: 4096,
    ioLimit: 25,
  },
  {
    id: "enterprise",
    name: "Enterprise (Unlimited)",
    diskMB: 0,
    bandwidthGB: 0,
    bandwidthMB: 0,
    maxWebsites: 0,
    maxDatabases: 0,
    maxEmails: 0,
    maxFtp: 0,
    maxLists: 0,
    maxSubdomains: 0,
    maxParked: 0,
    maxAddons: 0,
    maxEmailPerHour: 0,
    maxDeferFailPercentage: 100,
    maxEmailQuotaMB: 0,
    maxTeamUsers: 15,
    dedicatedIp: false,
    shellAccess: true,
    cgiAccess: true,
    digestAuth: false,
    cpanelTheme: "jupiter",
    featureList: "default",
    locale: "English",
    wpToolkit: false,
    cpuPercent: 200,
    ramMB: 8192,
    ioLimit: 50,
  },
];

function listPackages() {
  const pkgs = store.read("packages", DEFAULT_PACKAGES);
  if (!Array.isArray(pkgs) || pkgs.length === 0) return DEFAULT_PACKAGES;
  // Ensure Standard Hosting is present in list if missing
  if (!pkgs.some((p) => p.id === "standard" || String(p.name).toLowerCase() === "standard hosting")) {
    const std = DEFAULT_PACKAGES.find((p) => p.id === "standard");
    if (std) pkgs.unshift(std);
  }
  return pkgs;
}

function findPackage(idOrName) {
  if (!idOrName) return null;
  const target = String(idOrName).trim().toLowerCase();
  const list = listPackages();
  return (
    list.find(
      (p) =>
        String(p.id).toLowerCase() === target ||
        String(p.name).toLowerCase() === target
    ) || null
  );
}

function createPackage(input) {
  const name = String(input.name || "").trim();
  if (!name || name.length > 60) throw validate.badRequest("Package name is required.");
  const id = (input.id || name).toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
  if (!id) throw validate.badRequest("Package name must contain a letter or number.");
  
  const num = (value, label, integer = false) => {
    if (value === undefined || value === null || value === "") return 0;
    const n = Number(value);
    if (!Number.isFinite(n) || n < 0 || (integer && !Number.isInteger(n))) {
      return 0;
    }
    return n;
  };

  const bwMb = num(input.bandwidthMB || (input.bandwidthGB ? input.bandwidthGB * 1024 : 0), "Bandwidth limit MB", true);
  const bwGb = num(input.bandwidthGB || (input.bandwidthMB ? input.bandwidthMB / 1024 : 0), "Bandwidth limit GB");

  const pkg = {
    id,
    name,
    diskMB: num(input.diskMB, "Disk limit", true),
    bandwidthMB: bwMb,
    bandwidthGB: bwGb,
    maxWebsites: num(input.maxWebsites || input.maxAddons, "Website limit", true),
    maxDatabases: num(input.maxDatabases || input.maxSql, "Database limit", true),
    maxEmails: num(input.maxEmails, "Email limit", true),
    maxFtp: num(input.maxFtp, "Max FTP", true),
    maxLists: num(input.maxLists, "Max Mailing Lists", true),
    maxSubdomains: num(input.maxSubdomains, "Max Subdomains", true),
    maxParked: num(input.maxParked, "Max Parked Domains", true),
    maxAddons: num(input.maxAddons, "Max Addon Domains", true),
    maxEmailPerHour: num(input.maxEmailPerHour, "Max Email Per Hour", true),
    maxDeferFailPercentage: num(input.maxDeferFailPercentage !== undefined ? input.maxDeferFailPercentage : 100, "Defer Fail %", true),
    maxEmailQuotaMB: num(input.maxEmailQuotaMB, "Max Quota Per Email MB", true),
    maxTeamUsers: num(input.maxTeamUsers !== undefined ? input.maxTeamUsers : 7, "Max Team Users", true),

    // Settings & Options
    dedicatedIp: Boolean(input.dedicatedIp),
    shellAccess: Boolean(input.shellAccess),
    cgiAccess: input.cgiAccess !== undefined ? Boolean(input.cgiAccess) : true,
    digestAuth: Boolean(input.digestAuth),
    cpanelTheme: String(input.cpanelTheme || "jupiter"),
    featureList: String(input.featureList || "default"),
    locale: String(input.locale || "en"),
    wpToolkit: Boolean(input.wpToolkit),

    cpuPercent: num(input.cpuPercent, "CPU %", true) || 100,
    ramMB: num(input.ramMB, "RAM MB", true) || 2048,
    ioLimit: num(input.ioLimit, "IO limit", true) || 20,
  };

  const list = listPackages();
  const existingIndex = list.findIndex((p) => p.id === id);
  if (existingIndex >= 0) {
    list[existingIndex] = pkg;
  } else {
    list.push(pkg);
  }
  store.write("packages", list);
  return pkg;
}

function deletePackage(id) {
  if (!findPackage(id)) throw validate.badRequest("Hosting package not found.");
  if (Object.values(store.read("accounts", {})).some((a) => a.package === id)) {
    throw validate.badRequest("This package is still assigned to accounts.");
  }
  store.write("packages", listPackages().filter((p) => p.id !== id));
  return { id, status: "deleted" };
}

async function syncExistingServerAccounts() {
  const accounts = store.read("accounts", {});
  const serverIp = "185.70.184.125";
  let modified = false;

  // Purge any subdomains from accounts store (they are managed in cPanel, not WHM)
  for (const [u, a] of Object.entries(accounts)) {
    if (validate.isSubdomain(a.domain)) {
      delete accounts[u];
      modified = true;
    }
  }

  const discovered = [];

  // 1. Check aaPanel SQLite default.db
  const dbPath = "/www/server/panel/data/default.db";
  if (shell.IS_LINUX && fs.existsSync(dbPath)) {
    try {
      const out = require("child_process").execSync(`sqlite3 ${dbPath} "SELECT id, name, path, status, ps, addtime FROM sites;"`, { encoding: "utf8" });
      const lines = out.trim().split("\n").filter(Boolean);
      for (const line of lines) {
        const [id, name, p, status, ps, addtime] = line.split("|");
        const domain = (name || "").trim().toLowerCase();
        if (domain && domain !== "default" && !domain.startsWith(".")) {
          discovered.push({
            domain,
            path: p ? p.trim() : "/www/wwwroot/" + domain,
            status: Number(status),
            addtime: (addtime || "").trim(),
          });
        }
      }
    } catch (e) {
      console.warn("[Sync Accounts] SQLite read error:", e.message);
    }
  }

  // 2. Check /www/wwwroot directories
  if (shell.IS_LINUX && fs.existsSync("/www/wwwroot")) {
    try {
      for (const d of fs.readdirSync("/www/wwwroot")) {
        const domain = d.toLowerCase().trim();
        if (domain.includes(".") && !domain.startsWith(".") && domain !== "default") {
          if (!discovered.some((s) => s.domain === domain)) {
            discovered.push({
              domain,
              path: "/www/wwwroot/" + domain,
              status: 1,
              addtime: new Date().toISOString().slice(0, 10),
            });
          }
        }
      }
    } catch (e) {
      console.warn("[Sync Accounts] wwwroot scan error:", e.message);
    }
  }

  // 3. Check vhosts from platform.listVhostDomains()
  if (shell.IS_LINUX) {
    try {
      const vhostDomains = platform.listVhostDomains();
      for (const domain of vhostDomains) {
        const d = domain.toLowerCase().trim();
        if (!discovered.some((s) => s.domain === d)) {
          discovered.push({
            domain: d,
            path: platform.docRoot(d),
            status: 1,
            addtime: new Date().toISOString().slice(0, 10),
          });
        }
      }
    } catch {}
  }

  // Separate discovered into root domains and subdomains
  const rootDomains = discovered.filter((item) => !validate.isSubdomain(item.domain));
  const subdomains = discovered.filter((item) => validate.isSubdomain(item.domain));

  // Ensure each root domain is in accounts store
  for (const item of rootDomains) {
    const existing = Object.entries(accounts).find(([u, a]) => a.domain === item.domain);
    if (!existing) {
      let baseUser = item.domain
        .replace(/\.[a-z]{2,}$/i, "")
        .replace(/[^a-z0-9]/gi, "")
        .toLowerCase()
        .slice(0, 8);

      if (baseUser.length < 3 || !/^[a-z]/.test(baseUser)) {
        baseUser = "u" + baseUser;
      }

      let username = baseUser;
      let counter = 1;
      while (accounts[username]) {
        username = baseUser.slice(0, 6) + counter;
        counter++;
      }

      accounts[username] = {
        username,
        domain: item.domain,
        ip: serverIp,
        owner: "root",
        email: `admin@${item.domain}`,
        package: "Standard Hosting",
        documentRoot: item.path,
        status: item.status === 0 ? "Suspended" : "Active",
        suspended: item.status === 0,
        cgi: true,
        spf: true,
        dkim: true,
        created: (item.addtime || new Date().toISOString()).slice(0, 10),
      };

      store.update("sites", {}, (sites) => {
        sites[item.domain] = {
          owner: username,
          type: "PHP",
          created: (item.addtime || new Date().toISOString()).slice(0, 10),
        };
      });

      modified = true;
    }
  }

  // Link subdomains to their parent account in `sites` store (visible in cPanel)
  for (const sub of subdomains) {
    const parentRoot = validate.getRootDomain(sub.domain);
    const parentAcct = Object.values(accounts).find((a) => a.domain === parentRoot);
    const parentOwner = parentAcct ? parentAcct.username : "root";

    store.update("sites", {}, (sites) => {
      sites[sub.domain] = {
        ...(sites[sub.domain] || {}),
        owner: parentOwner,
        parent: parentRoot,
        type: "Subdomain",
        created: (sub.addtime || new Date().toISOString()).slice(0, 10),
      };
    });
  }

  if (modified) {
    store.write("accounts", accounts);
  }

  return Object.values(accounts);
}

async function listAccounts() {
  await syncExistingServerAccounts();
  const accounts = store.read("accounts", {});
  const sites = await websites.listWebsites();

  // Exclude any subdomains: in WHM, only show primary domain accounts
  const validAccountEntries = Object.entries(accounts).filter(([_, a]) => !validate.isSubdomain(a.domain));

  return Promise.all(validAccountEntries.map(async ([username, a]) => {
    // All websites owned by this account or subdomains of this account's primary domain
    const owned = sites.filter((s) =>
      s.owner === username ||
      s.domain === a.domain ||
      (s.domain && s.domain.endsWith("." + a.domain))
    );
    const homeBytes = shell.IS_LINUX ? await websites.diskUsageBytes("/home/" + username) : 0;
    const docRootBytes = (a.documentRoot && fs.existsSync(a.documentRoot))
      ? await websites.diskUsageBytes(a.documentRoot)
      : 0;
    const siteDiskBytes = owned.reduce((s, w) => s + (w.diskBytes || 0), 0);
    const diskBytes = Math.max(siteDiskBytes, docRootBytes) + homeBytes;
    const bwBytes = owned.reduce((s, w) => s + (w.bandwidthBytes || 0), 0);
    const pkg = findPackage(a.package) || { name: a.package || "Standard Hosting", diskMB: 10240 };
    const targetIp = a.ip || "185.70.184.125";
    const ssoToken = authService.createSsoToken({
      username,
      domain: a.domain,
      ip: targetIp,
      homeDir: a.documentRoot || `/www/wwwroot/${a.domain}`,
    });
    const cpanelUrl = `https://${targetIp}:2083/?sso=${encodeURIComponent(ssoToken)}&user=${encodeURIComponent(username)}&domain=${encodeURIComponent(a.domain)}`;
    return {
      id: username,
      username,
      domain: a.domain,
      ip: targetIp,
      owner: a.owner || "root",
      email: a.email || `${username}@${a.domain}`,
      pkg: pkg.name,
      packageId: pkg.id,
      package: pkg.name,
      disk: websites.formatBytes(diskBytes),
      diskUsed: websites.formatBytes(diskBytes),
      diskLimit: pkg.diskMB ? websites.formatBytes(pkg.diskMB * 1048576) : "Unlimited",
      overQuota: !!pkg.diskMB && diskBytes > pkg.diskMB * 1048576,
      bandwidth: websites.formatBytes(bwBytes),
      websites: owned.map((w) => w.domain),
      status: a.suspended ? "Suspended" : "Active",
      suspendReason: a.suspendReason || "",
      forcePasswordChange: !!a.forcePasswordChange,
      cgi: a.cgi ?? true,
      spf: a.spf ?? true,
      dkim: a.dkim ?? true,
      created: (a.created || "").slice(0, 10),
      ssoToken,
      cpanelUrl,
    };
  }));
}

async function createAccount({ username, domain, password, email, package: pkgId, cgi = true, spf = true, dkim = true, nameservers, user }) {
  username = validate.username(username);
  domain = validate.domain(domain);
  if (validate.isSubdomain(domain)) {
    throw validate.badRequest("Subdomains must be added inside cPanel under Domains / Subdomains, not as a root WHM account.");
  }
  const pass = validate.password(password, 8);
  const availablePackages = listPackages();
  const pkg = pkgId ? findPackage(pkgId) : availablePackages[0];
  if (!pkg) throw validate.badRequest("Select a valid hosting package.");
  const accounts = store.read("accounts", {});
  if (accounts[username]) throw validate.badRequest("Account already exists: " + username);

  // 1. Central License Limit Enforcement
  try {
    const licenseService = require("./license.service");
    const licStatus = await licenseService.getLocalStatus();
    if (licStatus && !licStatus.isValid) {
      throw validate.badRequest("Cannot create account: Panel license is invalid or expired. Activate license in WHM.");
    }
    const currentTotal = Object.keys(accounts).length;
    if (licStatus && licStatus.maxAccounts > 0 && currentTotal >= licStatus.maxAccounts) {
      throw validate.badRequest(
        `License limit reached: Current tier allows up to ${licStatus.maxAccounts} accounts (currently ${currentTotal}). Please upgrade your license.`
      );
    }
  } catch (err) {
    if (err.status) throw err;
  }

  // 2. Reseller Limit & ACL Enforcement
  if (user && (user.role === "reseller" || user.isReseller)) {
    const resellers = store.read("resellers", []);
    const r = resellers.find((item) => item.username === user.username);
    if (r) {
      if (!r.acls.includes("create-acct") && !r.acls.includes("*")) {
        throw validate.badRequest("Permission denied: Reseller account does not have ACL privilege 'Account Creation'.");
      }
      const ownedCount = Object.values(accounts).filter((a) => a.owner === user.username).length;
      if (r.maxAccounts > 0 && ownedCount >= r.maxAccounts) {
        throw validate.badRequest(
          `Reseller quota exceeded: You have used ${ownedCount}/${r.maxAccounts} allocated accounts.`
        );
      }
    }
  }

  if (shell.IS_LINUX) {
    if (await shell.tryGet("id -u " + shell.q(username), "")) throw validate.badRequest("A system user named " + username + " already exists.");
    await shell.run("useradd -m -d " + shell.q("/home/" + username) + " -s /usr/sbin/nologin " + shell.q(username), { user });
    await shell.run("chpasswd", { input: username + ":" + pass + "\n", user });
  }
  try {
    await websites.createWebsite({ domain, owner: username, user });
  } catch (e) {
    if (shell.IS_LINUX) await shell.run("userdel -r " + shell.q(username), { user }).catch(() => {});
    throw e;
  }
  const passwordHash = await bcrypt.hash(pass, 10);
  store.update("accounts", {}, (all) => {
    all[username] = {
      domain,
      email: email || `admin@${domain}`,
      package: pkg.id,
      ip: "127.0.0.1",
      owner: user?.username || "root",
      cgi: !!cgi,
      spf: !!spf,
      dkim: !!dkim,
      passwordHash,
      nameservers: nameservers || ["ns1." + domain, "ns2." + domain],
      created: new Date().toISOString(),
      suspended: false,
    };
  });
  return { username, domain, package: pkg.name };
}

async function changePassword({ username, password, user }) {
  username = validate.username(username);
  const pass = validate.password(password, 8);
  const accounts = store.read("accounts", {});
  if (!accounts[username]) throw validate.badRequest("Account not found: " + username);
  if (shell.IS_LINUX) {
    await shell.run("chpasswd", { input: username + ":" + pass + "\n", user });
  }
  const passwordHash = await bcrypt.hash(pass, 10);
  store.update("accounts", {}, (all) => {
    if (all[username]) {
      all[username].forcePasswordChange = false;
      all[username].passwordHash = passwordHash;
    }
  });
  return { username, message: "Password updated successfully" };
}

async function forcePasswordChange({ username, user }) {
  username = validate.username(username);
  store.update("accounts", {}, (all) => {
    if (all[username]) all[username].forcePasswordChange = true;
  });
  if (shell.IS_LINUX) {
    await shell.run("chage -d 0 " + shell.q(username) + " 2>/dev/null || true", { user });
  }
  return { username, forcePasswordChange: true };
}

async function upgradeAccount({ username, package: pkgId, user }) {
  username = validate.username(username);
  const pkg = findPackage(pkgId);
  if (!pkg) throw validate.badRequest("Target package does not exist.");
  store.update("accounts", {}, (all) => {
    if (!all[username]) throw validate.badRequest("Account not found: " + username);
    all[username].package = pkg.name;
  });
  return {
    username,
    package: pkg.name,
    packageId: pkg.id,
    diskLimit: pkg.diskMB ? websites.formatBytes(pkg.diskMB * 1048576) : "Unlimited",
  };
}

async function modifyAccount({ username, domain, email, package: pkgId, user }) {
  username = validate.username(username);
  store.update("accounts", {}, (all) => {
    if (!all[username]) throw validate.badRequest("Account not found: " + username);
    if (domain) all[username].domain = domain;
    if (email) all[username].email = email;
    if (pkgId) {
      const p = findPackage(pkgId);
      if (p) all[username].package = p.name;
    }
  });
  return { username, account: store.read("accounts", {})[username] };
}

async function ownedDomains(username, account) {
  const sites = await websites.listWebsites();
  return sites
    .filter(
      (s) =>
        s.owner === username ||
        s.domain === account.domain ||
        (s.domain && s.domain.endsWith("." + account.domain))
    )
    .map((s) => s.domain);
}

async function setSuspended({ username, suspended, user }) {
  username = validate.username(username);
  const accounts = store.read("accounts", {});
  const a = accounts[username];
  if (!a) throw validate.badRequest("Account not found: " + username);
  for (const domain of await ownedDomains(username, a)) {
    if (suspended) await websites.suspendWebsite({ domain, user });
    else await websites.unsuspendWebsite({ domain, user });
  }
  if (shell.IS_LINUX) await shell.run("usermod " + (suspended ? "-L" : "-U") + " " + shell.q(username), { user }).catch(() => {});
  store.update("accounts", {}, (all) => { all[username].suspended = !!suspended; });
  return { username, status: suspended ? "Suspended" : "Active" };
}

async function toggleAccount({ username, user }) {
  const a = store.read("accounts", {})[username];
  if (!a) throw validate.badRequest("Account not found: " + username);
  return setSuspended({ username, suspended: !a.suspended, user });
}

async function deleteAccount({ username, user }) {
  username = validate.username(username);
  const accounts = store.read("accounts", {});
  const a = accounts[username];
  if (!a) throw validate.badRequest("Account not found: " + username);
  for (const domain of await ownedDomains(username, a)) {
    await websites.deleteWebsite({ domain, removeFiles: true, user });
  }
  if (shell.IS_LINUX) await shell.run("userdel -r " + shell.q(username) + " 2>/dev/null || true", { user });
  store.update("accounts", {}, (all) => { delete all[username]; });
  return { username, status: "deleted" };
}

module.exports = {
  listPackages,
  findPackage,
  createPackage,
  deletePackage,
  listAccounts,
  syncExistingServerAccounts,
  createAccount,
  toggleAccount,
  deleteAccount,
  changePassword,
  forcePasswordChange,
  upgradeAccount,
  modifyAccount,
  setSuspended,
};
