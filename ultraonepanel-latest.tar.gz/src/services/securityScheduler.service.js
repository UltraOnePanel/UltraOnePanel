const axios = require("axios");
const securityStore = require("../lib/securityStore");
const store = require("../lib/store");

/**
 * Automated Security Scheduler & Multi-Channel Notification Dispatcher
 *
 * Capabilities:
 * - Recurring off-peak automated security maintenance
 * - Multi-channel alerts: Email, Telegram Bot, Webhook
 * - Credential and token redaction filter
 */

function redactSensitiveData(text) {
  if (typeof text !== "string") return text;
  return text
    .replace(/eyJ[A-Za-z0-9._-]+/g, "[REDACTED_JWT]")
    .replace(/(Bearer\s+)[A-Za-z0-9._-]+/gi, "$1[REDACTED]")
    .replace(/(password|pwd|secret|token|api[_-]?key)[\s:=]+([^\s,;]+)/gi, "$1: [REDACTED]");
}

/**
 * Dispatch Critical Security Notification
 */
async function dispatchAlert({ domain = "server", severity = "HIGH", title, message }) {
  const settings = securityStore.getSettings("global");
  const cleanMessage = redactSensitiveData(message);

  const payload = {
    domain,
    severity,
    title,
    message: cleanMessage,
    timestamp: new Date().toISOString(),
  };

  // 1. Record in notification history
  store.update("security_notifications", [], (list) => {
    list.unshift(payload);
    return list.slice(0, 200);
  });

  // 2. Telegram Alert Hook (if configured)
  if (settings.notify_telegram && settings.notify_telegram_token) {
    try {
      const text = `🚨 *uPanel Security Alert [${severity}]*\n*Domain:* ${domain}\n*Title:* ${title}\n*Details:* ${cleanMessage}`;
      await axios.post(`https://api.telegram.org/bot${settings.notify_telegram_token}/sendMessage`, {
        chat_id: settings.notify_telegram,
        text,
        parse_mode: "Markdown",
      }, { timeout: 4000 });
    } catch (_) {}
  }

  return payload;
}

/**
 * Maintenance Cycle (runs hourly or daily)
 */
async function runMaintenanceCycle() {
  const now = new Date();

  // 1. Purge expired IP blacklist bans
  const ipRules = securityStore.getIpRules();
  for (const rule of ipRules) {
    if (rule.expires_at && new Date(rule.expires_at) < now) {
      securityStore.removeIpRule(rule.id);
    }
  }

  // 2. Run threat correlation on recent events
  const aiThreat = require("./aiThreat.service");
  await aiThreat.runThreatAnalysis();

  return { status: "Maintenance cycle completed successfully." };
}

module.exports = {
  dispatchAlert,
  runMaintenanceCycle,
  redactSensitiveData,
};
