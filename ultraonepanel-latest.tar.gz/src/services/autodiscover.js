function extractEmail(req){if(req.query&&(req.query.email||req.query.emailaddress||req.query.Email))return String(req.query.email||req.query.emailaddress||req.query.Email).trim().toLowerCase();const bodyText=typeof req.body=="string"?req.body:JSON.stringify(req.body||""),match=bodyText.match(/<EMailAddress>(.*?)<\/EMailAddress>/i)||bodyText.match(/<EmailAddress>(.*?)<\/EmailAddress>/i);if(match&&match[1])return match[1].trim().toLowerCase();const domain=(req.headers.host||"").split(":")[0].toLowerCase().replace(/^autodiscover\./,"").replace(/^autoconfig\./,"").replace(/^mail\./,"");return domain&&domain!=="localhost"&&!/^\d+\.\d+\.\d+\.\d+$/.test(domain)?`user@${domain}`:"user@sunvexaenergy.in"}function buildAutodiscoverXml({email,domain,host}){const mailHost=host||`mail.${domain}`;return`<?xml version="1.0" encoding="utf-8"?>
<Autodiscover xmlns="http://schemas.microsoft.com/exchange/autodiscover/responseschema/2006">
  <Response xmlns="http://schemas.microsoft.com/exchange/autodiscover/outlook/responseschema/2006a">
    <User>
      <DisplayName>${escapeXml(email)}</DisplayName>
      <EMailAddress>${escapeXml(email)}</EMailAddress>
    </User>
    <Account>
      <AccountType>email</AccountType>
      <Action>settings</Action>

      <!-- Protocol: IMAP (SSL) -->
      <Protocol>
        <Type>IMAP</Type>
        <Server>${escapeXml(mailHost)}</Server>
        <Port>993</Port>
        <DomainRequired>off</DomainRequired>
        <LoginName>${escapeXml(email)}</LoginName>
        <SPA>off</SPA>
        <SSL>on</SSL>
        <AuthRequired>on</AuthRequired>
      </Protocol>

      <!-- Protocol: POP3 (SSL) -->
      <Protocol>
        <Type>POP3</Type>
        <Server>${escapeXml(mailHost)}</Server>
        <Port>995</Port>
        <DomainRequired>off</DomainRequired>
        <LoginName>${escapeXml(email)}</LoginName>
        <SPA>off</SPA>
        <SSL>on</SSL>
        <AuthRequired>on</AuthRequired>
      </Protocol>

      <!-- Protocol: SMTP (SSL 465) -->
      <Protocol>
        <Type>SMTP</Type>
        <Server>${escapeXml(mailHost)}</Server>
        <Port>465</Port>
        <DomainRequired>off</DomainRequired>
        <LoginName>${escapeXml(email)}</LoginName>
        <SPA>off</SPA>
        <SSL>on</SSL>
        <AuthRequired>on</AuthRequired>
        <UsePOPAuth>off</UsePOPAuth>
        <SMTPLast>off</SMTPLast>
      </Protocol>

      <!-- Protocol: SMTP (STARTTLS 587) -->
      <Protocol>
        <Type>SMTP</Type>
        <Server>${escapeXml(mailHost)}</Server>
        <Port>587</Port>
        <DomainRequired>off</DomainRequired>
        <LoginName>${escapeXml(email)}</LoginName>
        <SPA>off</SPA>
        <Encryption>TLS</Encryption>
        <SSL>off</SSL>
        <AuthRequired>on</AuthRequired>
        <UsePOPAuth>off</UsePOPAuth>
        <SMTPLast>off</SMTPLast>
      </Protocol>
    </Account>
  </Response>
</Autodiscover>`}function escapeXml(str){return String(str||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&apos;")}function handleAutodiscoverRequest(req,res){const email=extractEmail(req),domain=email.includes("@")?email.split("@")[1]:"sunvexaenergy.in",host=`mail.${domain}`,xml=buildAutodiscoverXml({email,domain,host});return res.setHeader("Content-Type","application/xml; charset=utf-8"),res.setHeader("Access-Control-Allow-Origin","*"),res.setHeader("Cache-Control","public, max-age=3600"),res.status(200).send(xml)}module.exports={extractEmail,buildAutodiscoverXml,handleAutodiscoverRequest};
