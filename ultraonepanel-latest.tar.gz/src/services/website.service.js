const fs    = require("fs");
const path  = require("path");
const shell = require("./shell.service");
const platform = require("../lib/platform");
const store = require("../lib/store");
const validate = require("../lib/validate");

const MANAGED_MARK = "# managed-by: facezila";

// ---------------------------------------------------------------- metadata

function getMeta(domain) {
  return store.read("sites", {})[domain] || null;
}

function isUserAllowedSite(domain, siteMeta, user) {
  if (!user || user.role === "admin" || user.username === "root") return true;
  const username = (user.username || "").toLowerCase().trim();
  const uDomain = (user.domain || "").toLowerCase().trim();
  const d = (domain || "").toLowerCase().trim();

  // 1. Direct owner match in meta
  if (siteMeta && siteMeta.owner && siteMeta.owner.toLowerCase().trim() === username) {
    return true;
  }
  // 2. Exact domain match with user's primary domain
  if (uDomain && d === uDomain) {
    return true;
  }
  // 3. Subdomain of user's primary domain (e.g. mail.sunvexaenergy.in)
  if (uDomain && d.endsWith("." + uDomain)) {
    return true;
  }
  // 4. Parent domain matches user's primary domain
  if (siteMeta && siteMeta.parent) {
    const parent = siteMeta.parent.toLowerCase().trim();
    if (parent === uDomain || parent.endsWith("." + uDomain)) return true;
  }
  // 5. Check if user's account in store owns this site
  const accounts = store.read("accounts", {});
  const acc = accounts[username];
  if (acc) {
    const accDomain = (acc.domain || "").toLowerCase().trim();
    if (accDomain && (d === accDomain || d.endsWith("." + accDomain))) return true;
  }
  return false;
}

function setMeta(domain, patch) {
  return store.update("sites", {}, (sites) => {
    sites[domain] = { ...(sites[domain] || {}), ...patch };
  })[domain];
}

function dropMeta(domain) {
  store.update("sites", {}, (sites) => { delete sites[domain]; });
}

// ---------------------------------------------------------------- vhost template

/**
 * Build an Nginx server config for a Facezila-managed site.
 *
 * meta: { php, type, aliases[], redirect, proxyPort, ssl }
 */
function buildVhostConfig(domain, meta) {
  const names = [domain];
  if (meta.type !== "Subdomain" && !domain.startsWith("www.")) names.push("www." + domain);
  (meta.aliases || []).forEach((a) => names.push(a, "www." + a));

  const certDir = "/etc/letsencrypt/live/" + domain;
  // Frameworks like Laravel serve from a subfolder (public/).
  const webRoot = platform.docRoot(domain) + (meta.publicDir ? "/" + meta.publicDir : "");
  const body = [
    "    server_name " + names.join(" ") + ";",
    "    root " + webRoot + ";",
    "    index index.php index.html index.htm;",
    "",
    "    # Custom Error Pages (UltraOnePanel)",
    "    error_page 404 /404.html;",
    "    error_page 403 /403.html;",
    "    error_page 500 502 503 504 /500.html;",
    "",
    "    access_log " + platform.accessLog(domain) + ";",
    "    error_log  " + platform.errorLog(domain) + ";",
    "",
    "    location ^~ /.well-known/acme-challenge/ { allow all; default_type text/plain; }",
    "    location ~ /\\.(?!well-known) { deny all; }",
    "",
  ];

  if (meta.redirect) {
    body.push("    location / { return " + (meta.redirectCode || 301) + " " + meta.redirect.replace(/\/$/, "") + "$request_uri; }");
  } else if (meta.proxyPort) {
    body.push(
      "    location / {",
      "        proxy_pass http://127.0.0.1:" + meta.proxyPort + ";",
      "        proxy_http_version 1.1;",
      "        proxy_set_header Upgrade $http_upgrade;",
      "        proxy_set_header Connection \"upgrade\";",
      "        proxy_set_header Host $host;",
      "        proxy_set_header X-Real-IP $remote_addr;",
      "        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;",
      "        proxy_set_header X-Forwarded-Proto $scheme;",
      "    }"
    );
  } else {
    if (meta.php && meta.fastcgiCache) {
      // Server-level so it also applies inside aaPanel's enable-php include.
      body.push(
        "    set $fz_skip 0;",
        "    if ($request_method = POST) { set $fz_skip 1; }",
        "    if ($query_string != \"\") { set $fz_skip 1; }",
        "    if ($http_cookie ~* \"wordpress_logged_in|comment_author|wp-postpass|PHPSESSID|laravel_session\") { set $fz_skip 1; }",
        "    if ($request_uri ~* \"/wp-admin/|/wp-login.php|/admin\") { set $fz_skip 1; }",
        "    fastcgi_cache FZCACHE;",
        "    fastcgi_cache_key \"$scheme$request_method$host$request_uri\";",
        "    fastcgi_cache_valid 200 301 302 1m;",
        "    fastcgi_cache_bypass $fz_skip;",
        "    fastcgi_no_cache $fz_skip;",
        "    add_header X-FZ-Cache $upstream_cache_status;",
        ""
      );
    }
    body.push("    location / {", "        try_files $uri $uri/ /index.php?$query_string;", "    }");
    if (meta.php) body.push(...platform.phpDirective(meta.php));
  }

  const listen80 = platform.IS_AAPANEL ? ["    listen 80;"] : ["    listen 80;", "    listen [::]:80;"];
  const lines = [MANAGED_MARK, "server {", ...listen80];

  if (meta.ssl) {
    // Keep ACME challenges reachable over HTTP, send everything else to HTTPS.
    lines.push(
      "    server_name " + names.join(" ") + ";",
      "    root " + webRoot + ";",
      "    location ^~ /.well-known/acme-challenge/ { allow all; default_type text/plain; }",
      "    location / { return 301 https://$host$request_uri; }",
      "}",
      "server {",
      "    listen 443 ssl http2;",
      ...(platform.IS_AAPANEL ? [] : ["    listen [::]:443 ssl http2;"]),
      "    ssl_certificate " + certDir + "/fullchain.pem;",
      "    ssl_certificate_key " + certDir + "/privkey.pem;",
      "    ssl_protocols TLSv1.2 TLSv1.3;",
      "    ssl_session_cache shared:FZSSL:10m;",
      "    add_header Strict-Transport-Security \"max-age=31536000\";",
    );
  }
  lines.push(...body, "}", "");
  return lines.join("\n");
}

function isManaged(domain) {
  const v = platform.readVhost(domain);
  return !!v && v.content.startsWith(MANAGED_MARK);
}

/**
 * Rewrite a managed site's vhost from its metadata and reload nginx.
 * Rolls back to the previous config if nginx rejects the new one.
 */
async function writeVhost(domain, meta, opts = {}) {
  // A brand-new site has no vhost yet, so isEnabled() is false; opts.enable says it should go live.
  const enabled = opts.enable || platform.isEnabled(domain);
  const target = enabled || !platform.IS_AAPANEL ? platform.vhostPath(domain) : platform.disabledVhostPath(domain);
  const previous = fs.existsSync(target) ? fs.readFileSync(target, "utf8") : null;
  shell.writeFile(target, buildVhostConfig(domain, meta));
  try {
    await platform.reloadNginx(opts);
  } catch (e) {
    if (previous !== null) fs.writeFileSync(target, previous);
    else fs.rmSync(target, { force: true });
    await platform.reloadNginx(opts).catch(() => {});
    throw new Error("Nginx rejected the configuration: " + e.message);
  }
}

// ---------------------------------------------------------------- usage stats

const usageCache = new Map();

async function cached(key, ttlMs, fn) {
  const hit = usageCache.get(key);
  if (hit && Date.now() - hit.at < ttlMs) return hit.value;
  const value = await fn();
  usageCache.set(key, { at: Date.now(), value });
  return value;
}

function formatBytes(bytes) {
  if (!bytes || bytes < 0) return "0 B";
  const units = ["B", "KB", "MB", "GB", "TB"];
  let i = 0;
  while (bytes >= 1024 && i < units.length - 1) { bytes /= 1024; i++; }
  return (i === 0 ? bytes : bytes.toFixed(1)) + " " + units[i];
}

async function diskUsageBytes(dir) {
  if (!shell.IS_LINUX || !fs.existsSync(dir)) return 0;
  return cached("du:" + dir, 5 * 60 * 1000, async () => {
    const out = await shell.tryGet("du -sb " + shell.q(dir) + " 2>/dev/null | cut -f1", "0", { timeout: 20000 });
    return Number(out) || 0;
  });
}

/** Bytes served, summed from the access log's body_bytes_sent column. */
async function bandwidthBytes(domain) {
  const log = platform.accessLog(domain);
  if (!shell.IS_LINUX || !fs.existsSync(log)) return 0;
  return cached("bw:" + domain, 5 * 60 * 1000, async () => {
    const out = await shell.tryGet("awk '{ if ($10 ~ /^[0-9]+$/) s += $10 } END { printf \"%d\", s }' " + shell.q(log), "0", { timeout: 15000 });
    return Number(out) || 0;
  });
}

function detectType(dir) {
  const has = (f) => fs.existsSync(path.join(dir, f));
  if (has("wp-config.php") || has("wp-login.php")) return "WordPress";
  if (has("artisan")) return "Laravel";
  if (has("package.json")) return "Node.js";
  if (has("index.php")) return "PHP";
  return "Static";
}

// ---------------------------------------------------------------- public API

async function getWebsite(domain) {
  const vhost = platform.readVhost(domain);
  if (!vhost) return null;
  const meta = getMeta(domain) || {};
  const root = platform.IS_AAPANEL
    ? ((vhost.content.match(/^\s*root\s+([^;]+);/m) || [])[1] || platform.docRoot(domain))
    : platform.docRoot(domain);
  const managed = vhost.content.startsWith(MANAGED_MARK);
  const enabled = platform.isEnabled(domain);
  let created = meta.created;
  if (!created) {
    try { created = fs.statSync(root).birthtime.toISOString(); } catch (_) { created = null; }
  }
  const [disk, bw] = await Promise.all([diskUsageBytes(root), bandwidthBytes(domain)]);
  return {
    domain,
    type: meta.type && meta.type !== "Addon" && meta.type !== "Subdomain" ? meta.type : detectType(root),
    domainType: meta.redirect ? "Redirect" : (meta.type === "Subdomain" ? "Subdomain" : (meta.domainType || "Addon")),
    php: platform.phpFromVhost(vhost.content) || (meta.proxyPort ? "Node" : "-"),
    status: enabled ? "Active" : "Suspended",
    ssl: /ssl_certificate\s/.test(vhost.content),
    documentRoot: root,
    redirect: meta.redirect || null,
    aliases: meta.aliases || [],
    owner: meta.owner || null,
    managed,
    disk: formatBytes(disk),
    diskBytes: disk,
    bandwidth: formatBytes(bw),
    bandwidthBytes: bw,
    created,
  };
}

/**
 * List all websites (Facezila-managed and pre-existing vhosts).
 */
async function listWebsites(user) {
  if (!shell.IS_LINUX) {
    const sites = store.read("sites", {});
    const list = Object.keys(sites).map((domain) => ({
      domain,
      ...sites[domain],
      type: sites[domain].type || "PHP",
      domainType: sites[domain].redirect ? "Redirect" : (sites[domain].type === "Subdomain" ? "Subdomain" : "Addon"),
      status: sites[domain].suspended ? "Suspended" : "Active",
      ssl: !!sites[domain].ssl,
      documentRoot: platform.docRoot(domain),
      managed: true,
      disk: "0 B",
      bandwidth: "0 B",
    }));
    return list.filter((s) => isUserAllowedSite(s.domain, s, user));
  }
  const domains = platform.listVhostDomains();
  const sites = await Promise.all(domains.map((d) => getWebsite(d).catch(() => null)));
  return sites.filter((s) => s && isUserAllowedSite(s.domain, s, user));
}

function deployDefaultSiteFiles(docRoot, domain) {
  try {
    fs.mkdirSync(docRoot, { recursive: true });
    const skelCandidates = [
      path.resolve(__dirname, "../templates/skel"),
      path.resolve(__dirname, "./templates/skel"),
      path.resolve(__dirname, "../../templates/skel"),
      "/opt/facezila/src/templates/skel",
    ];
    const skelDir = skelCandidates.find((d) => fs.existsSync(d) && fs.existsSync(path.join(d, "index.html")));
    const files = ["index.html", "404.html", "403.html", "500.html"];
    if (skelDir) {
      for (const f of files) {
        const srcPath = path.join(skelDir, f);
        const destPath = path.join(docRoot, f);
        if (fs.existsSync(srcPath)) {
          let content = fs.readFileSync(srcPath, "utf8");
          content = content.replace(/\{\{DOMAIN\}\}/g, domain);
          fs.writeFileSync(destPath, content, "utf8");
        }
      }
    } else {
      fs.writeFileSync(path.join(docRoot, "index.html"), `<!doctype html><html><head><meta charset="utf-8"><title>${domain}</title></head><body style="font-family:sans-serif;text-align:center;padding-top:15vh"><h1>${domain}</h1><p>This domain is parked with UltraOnePanel.</p></body></html>\n`);
    }
  } catch (err) {
    console.warn(`[Website] Could not deploy default site templates to ${docRoot}:`, err.message);
  }
}

/**
 * Create a new website (vhost config + document root).
 */
async function createWebsite({ domain, php, type = "PHP", redirect, redirectCode, proxyPort, owner, user = "system", currentUser }) {
  domain = validate.domain(domain);
  if (platform.RESERVED_VHOSTS.has(domain)) throw validate.badRequest("Reserved name: " + domain);
  if (redirect && !/^https?:\/\/[^\s;'"{}]+$/i.test(redirect)) throw validate.badRequest("Redirect target must be an http(s) URL.");

  if (currentUser && currentUser.role !== "admin" && currentUser.username !== "root") {
    owner = currentUser.username;
    const uDomain = (currentUser.domain || "").toLowerCase().trim();
    const d = domain.toLowerCase().trim();
    if (type === "Subdomain" && uDomain && !d.endsWith("." + uDomain)) {
      throw validate.badRequest(`Subdomain must belong to your domain: .${uDomain}`);
    }
  }

  const versions = platform.phpVersions();
  if (!redirect && !proxyPort) {
    php = php ? validate.phpVersion(php) : versions[versions.length - 1];
    if (!php) throw new Error("No PHP-FPM version is installed on this server.");
    if (shell.IS_LINUX && !versions.includes(php)) {
      throw validate.badRequest("PHP " + php + " is not installed. Available: " + versions.join(", "));
    }
  } else {
    php = null;
  }

  const meta = {
    type, php, redirect: redirect || null, redirectCode: redirectCode || 301,
    proxyPort: proxyPort || null, owner: owner || null, aliases: [], ssl: false,
    created: new Date().toISOString(),
  };

  if (!shell.IS_LINUX) {
    if (getMeta(domain)) throw validate.badRequest("Website already exists: " + domain);
    const docRoot = platform.docRoot(domain);
    fs.mkdirSync(docRoot, { recursive: true });
    if (!redirect) deployDefaultSiteFiles(docRoot, domain);
    setMeta(domain, meta);
    return { domain, php, docRoot, status: "created (dev-skip)" };
  }

  const allVhosts = platform.listVhostDomains().map((v) => v.toLowerCase());
  if (allVhosts.includes(domain.toLowerCase()) || platform.readVhost(domain) || getMeta(domain)) {
    throw validate.badRequest("Website already exists: " + domain);
  }

  const docRoot = platform.docRoot(domain);
  const fresh = !fs.existsSync(docRoot);
  fs.mkdirSync(docRoot, { recursive: true });
  if (fresh && !redirect) {
    deployDefaultSiteFiles(docRoot, domain);
  }
  const webUser = platform.IS_AAPANEL ? "www" : "www-data";
  await shell.run("chown -R " + webUser + ":" + webUser + " " + shell.q(platform.siteDir(domain)) + " 2>/dev/null || true", { user });
  fs.mkdirSync(platform.paths.logDir, { recursive: true });

  setMeta(domain, meta);
  if (!platform.IS_AAPANEL) await platform.enableVhost(domain, { user });
  try {
    await writeVhost(domain, meta, { user, enable: true });
  } catch (e) {
    await platform.disableVhost(domain);
    dropMeta(domain);
    throw e;
  }

  return { domain, php, docRoot, status: "created" };
}

/**
 * Delete a website. Managed sites lose their files too; pre-existing sites keep
 * their document root so nothing created outside Facezila is destroyed.
 */
async function deleteWebsite({ domain, removeFiles, user = "system", currentUser }) {
  domain = validate.domain(domain);
  if (currentUser && currentUser.role !== "admin" && currentUser.username !== "root") {
    const meta = getMeta(domain) || {};
    if (!isUserAllowedSite(domain, meta, currentUser)) {
      throw validate.badRequest("Permission denied: You do not have permission to delete this domain.");
    }
  }
  if (!shell.IS_LINUX) {
    dropMeta(domain);
    fs.rmSync(platform.siteDir(domain), { recursive: true, force: true });
    return { domain, status: "deleted (dev-skip)" };
  }

  const vhost = platform.readVhost(domain);
  if (!vhost) throw validate.badRequest("Website not found: " + domain);
  const managed = vhost.content.startsWith(MANAGED_MARK);

  if (platform.paths.enabledDir) shell.remove(path.join(platform.paths.enabledDir, domain + ".conf"));
  shell.remove(platform.vhostPath(domain));
  shell.remove(platform.disabledVhostPath(domain));

  const meta = getMeta(domain) || {};
  if (meta.nodeService) {
    await shell.run("systemctl disable --now " + shell.q(meta.nodeService), { user }).catch(() => {});
    shell.remove("/etc/systemd/system/" + meta.nodeService + ".service");
  }

  const filesRemoved = removeFiles !== undefined ? !!removeFiles : managed;
  if (filesRemoved) shell.remove(platform.siteDir(domain));
  dropMeta(domain);

  await platform.reloadNginx({ user });
  return { domain, status: "deleted", filesRemoved };
}

/**
 * Suspend a website (disable its Nginx config).
 */
async function suspendWebsite({ domain, user = "system", currentUser }) {
  domain = validate.domain(domain);
  if (currentUser && currentUser.role !== "admin" && currentUser.username !== "root") {
    const meta = getMeta(domain) || {};
    if (!isUserAllowedSite(domain, meta, currentUser)) {
      throw validate.badRequest("Permission denied: You do not have permission to modify this domain.");
    }
  }
  if (!shell.IS_LINUX) { setMeta(domain, { suspended: true }); return { domain, status: "suspended (dev-skip)" }; }
  if (!platform.readVhost(domain)) throw validate.badRequest("Website not found: " + domain);
  await platform.disableVhost(domain);
  await platform.reloadNginx({ user });
  return { domain, status: "suspended" };
}

/**
 * Unsuspend a website (re-enable Nginx config).
 */
async function unsuspendWebsite({ domain, user = "system", currentUser }) {
  domain = validate.domain(domain);
  if (currentUser && currentUser.role !== "admin" && currentUser.username !== "root") {
    const meta = getMeta(domain) || {};
    if (!isUserAllowedSite(domain, meta, currentUser)) {
      throw validate.badRequest("Permission denied: You do not have permission to modify this domain.");
    }
  }
  if (!shell.IS_LINUX) { setMeta(domain, { suspended: false }); return { domain, status: "active (dev-skip)" }; }
  if (!platform.readVhost(domain)) throw validate.badRequest("Website not found: " + domain);
  await platform.enableVhost(domain, { user });
  await platform.reloadNginx({ user });
  return { domain, status: "active" };
}

/**
 * Switch the PHP-FPM version a site runs on.
 */
async function changePhp({ domain, php, user = "system", currentUser }) {
  domain = validate.domain(domain);
  if (currentUser && currentUser.role !== "admin" && currentUser.username !== "root") {
    const meta = getMeta(domain) || {};
    if (!isUserAllowedSite(domain, meta, currentUser)) {
      throw validate.badRequest("Permission denied: You do not have permission to modify this domain.");
    }
  }
  php = validate.phpVersion(php);
  if (!shell.IS_LINUX) { setMeta(domain, { php }); return { domain, php, status: "updated (dev-skip)" }; }
  if (!platform.phpVersions().includes(php)) {
    throw validate.badRequest("PHP " + php + " is not installed. Available: " + platform.phpVersions().join(", "));
  }
  const vhost = platform.readVhost(domain);
  if (!vhost) throw validate.badRequest("Website not found: " + domain);

  if (vhost.content.startsWith(MANAGED_MARK)) {
    const meta = { ...(getMeta(domain) || {}), php };
    if (meta.redirect || meta.proxyPort) throw validate.badRequest("Redirect and proxy sites do not run PHP.");
    await writeVhost(domain, meta, { user });
    setMeta(domain, { php });
    return { domain, php, status: "updated" };
  }

  // Pre-existing vhost: swap the PHP include/socket in place.
  const next = vhost.content
    .replace(/enable-php-\d\d\.conf/g, "enable-php-" + php.replace(".", "") + ".conf")
    .replace(/php\d\.\d-fpm\.sock/g, "php" + php + "-fpm.sock");
  if (next === vhost.content) throw validate.badRequest("Could not find a PHP handler in this site's config.");
  fs.writeFileSync(vhost.path, next);
  try {
    await platform.reloadNginx({ user });
  } catch (e) {
    fs.writeFileSync(vhost.path, vhost.content);
    await platform.reloadNginx({ user }).catch(() => {});
    throw e;
  }
  return { domain, php, status: "updated" };
}

/**
 * Point extra (parked) domains at an existing managed site.
 */
async function setAliases({ domain, aliases, user = "system" }) {
  domain = validate.domain(domain);
  const clean = [...new Set((aliases || []).map(validate.domain))].filter((a) => a !== domain);
  const meta = getMeta(domain);
  if (!meta || (shell.IS_LINUX && !isManaged(domain))) {
    throw validate.badRequest("Aliases can only be added to websites created with Facezila.");
  }
  if (shell.IS_LINUX) await writeVhost(domain, { ...meta, aliases: clean }, { user });
  setMeta(domain, { aliases: clean });
  return { domain, aliases: clean };
}

/**
 * Enable/disable the HTTPS server block for a managed site (cert must exist).
 */
async function setSsl({ domain, ssl, user = "system" }) {
  const meta = getMeta(domain);
  if (!meta || !isManaged(domain)) return false;
  await writeVhost(domain, { ...meta, ssl }, { user });
  setMeta(domain, { ssl });
  return true;
}

/**
 * Apply a metadata patch to a managed site and regenerate its vhost.
 */
async function updateManaged({ domain, patch, user = "system" }) {
  const meta = getMeta(domain);
  if (!meta || (shell.IS_LINUX && !isManaged(domain))) {
    throw validate.badRequest(domain + " was not created by Facezila and cannot be reconfigured automatically.");
  }
  const next = { ...meta, ...patch };
  if (shell.IS_LINUX) await writeVhost(domain, next, { user });
  return setMeta(domain, patch);
}

module.exports = {
  createWebsite, listWebsites, getWebsite, deleteWebsite, suspendWebsite, unsuspendWebsite,
  changePhp, setAliases, setSsl, updateManaged, isManaged, getMeta, setMeta, formatBytes, diskUsageBytes, isUserAllowedSite,
  deployDefaultSiteFiles,
};
