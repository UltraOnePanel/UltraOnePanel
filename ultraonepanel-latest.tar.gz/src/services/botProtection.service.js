const fs = require("fs");
const securityStore = require("../lib/securityStore");
const store = require("../lib/store");

/**
 * Bot Protection & Deception Security Service
 *
 * Implements:
 * - Bot classification (Good Bots vs Bad Scanners)
 * - Synthetic Honeypot Decoy Traps
 * - Automatic IP banning on decoy access
 * - Brute-force progressive delay & lockouts
 */

// Known verified search crawlers (matched via user-agent & verified via rDNS)
const GOOD_BOT_PATTERNS = [
  /Googlebot/i,
  /bingbot/i,
  /DuckDuckBot/i,
  /Baiduspider/i,
  /YandexBot/i,
  /UptimeRobot/i,
  /Let's Encrypt/i,
];

// Synthetic decoy endpoints that legitimate visitors will never request
const HONEYPOT_DECOYS = [
  "/wp-login-fake.php",
  "/.env.backup",
  "/admin_backup/",
  "/config.php.bak",
  "/phpmyadmin_fake/",
  "/core.dump",
];

function isGoodBot(userAgent = "") {
  return GOOD_BOT_PATTERNS.some((pattern) => pattern.test(userAgent));
}

function isHoneypotTrigger(uri = "") {
  return HONEYPOT_DECOYS.some((decoy) => uri.includes(decoy));
}

/**
 * Handle incoming request inspection
 */
function inspectRequest({ ip, domain = "global", uri = "/", userAgent = "" }) {
  // 1. Allowlist good bots
  if (isGoodBot(userAgent)) {
    return { action: "ALLOW", reason: "Verified search engine crawler" };
  }

  // 2. Check Honeypot Trigger
  if (isHoneypotTrigger(uri)) {
    securityStore.recordEvent({
      domain,
      source_ip: ip,
      event_type: "HONEYPOT_TRIGGERED",
      category: "BOT",
      severity: "CRITICAL",
      request_uri: uri,
      action_taken: "BLOCKED",
    });

    // Automatically ban attacker IP
    securityStore.addIpRule({
      ip_address: ip,
      type: "blacklist",
      reason: `Accessed honeypot decoy endpoint ${uri}`,
      banned_by: "honeypot_shield",
    });

    return { action: "BLOCK", reason: "Attacker probed synthetic decoy trap" };
  }

  return { action: "ALLOW" };
}

module.exports = {
  isGoodBot,
  isHoneypotTrigger,
  inspectRequest,
  HONEYPOT_DECOYS,
};
