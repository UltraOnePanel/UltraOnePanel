const crypto = require("crypto");
const store = require("../lib/store");

const PERMISSIONS = [
  { id: "*", label: "Full Administrator Access", description: "Complete access to all WHM and cPanel features" },
  { id: "accounts:read", label: "Read Accounts", description: "List and view hosting accounts" },
  { id: "accounts:create", label: "Create Accounts", description: "Provision new cPanel accounts" },
  { id: "accounts:modify", label: "Modify Accounts", description: "Change packages and account settings" },
  { id: "accounts:suspend", label: "Suspend Accounts", description: "Suspend and unsuspend accounts" },
  { id: "accounts:terminate", label: "Terminate Accounts", description: "Permanently delete accounts" },
  { id: "dns:manage", label: "DNS Zone Management", description: "Create, edit, and delete DNS zones and records" },
  { id: "reseller:manage", label: "Reseller Management", description: "Manage resellers, IP delegation, and quotas" },
  { id: "packages:manage", label: "Package Management", description: "Create and modify hosting packages" },
  { id: "system:status", label: "System Status & Metrics", description: "View server metrics and service states" },
];

function generateTokenString() {
  const rand = crypto.randomBytes(24).toString("hex");
  return `YP_tok_${rand}`;
}

const TokensService = {
  PERMISSIONS,

  listTokens({ owner, role } = {}) {
    const tokens = store.read("api-tokens", []);
    return tokens
      .filter((t) => role === "admin" || !owner || t.owner === owner)
      .map((t) => ({
        id: t.id,
        name: t.name,
        maskedToken: t.token ? `${t.token.slice(0, 10)}...${t.token.slice(-4)}` : "YP_tok_****",
        owner: t.owner,
        role: t.role,
        permissions: t.permissions || ["*"],
        createdAt: t.createdAt,
        expiresAt: t.expiresAt,
        lastUsedAt: t.lastUsedAt || null,
        status: t.expiresAt && new Date(t.expiresAt) < new Date() ? "Expired" : "Active",
      }));
  },

  createToken({ name, owner = "root", role = "admin", permissions = ["*"], expiresInDays = 365 }) {
    if (!name || typeof name !== "string" || name.trim().length === 0) {
      throw new Error("Token name / label is required.");
    }
    const tokenStr = generateTokenString();
    const id = `tok_${Date.now()}_${crypto.randomBytes(4).toString("hex")}`;
    
    let expiresAt = null;
    if (expiresInDays && Number(expiresInDays) > 0) {
      const exp = new Date();
      exp.setDate(exp.getDate() + Number(expiresInDays));
      expiresAt = exp.toISOString();
    }

    const newRecord = {
      id,
      name: name.trim(),
      token: tokenStr,
      owner,
      role,
      permissions: Array.isArray(permissions) && permissions.length ? permissions : ["*"],
      createdAt: new Date().toISOString(),
      expiresAt,
      lastUsedAt: null,
    };

    const tokens = store.read("api-tokens", []);
    tokens.unshift(newRecord);
    store.write("api-tokens", tokens);

    return {
      id: newRecord.id,
      name: newRecord.name,
      token: tokenStr, // Returned ONLY on creation
      owner: newRecord.owner,
      role: newRecord.role,
      permissions: newRecord.permissions,
      createdAt: newRecord.createdAt,
      expiresAt: newRecord.expiresAt,
    };
  },

  verifyApiToken(tokenStr) {
    if (!tokenStr || typeof tokenStr !== "string") return null;
    const clean = tokenStr.trim();
    const tokens = store.read("api-tokens", []);
    const match = tokens.find((t) => t.token === clean);

    if (!match) return null;

    // Check expiration
    if (match.expiresAt && new Date(match.expiresAt) < new Date()) {
      return null;
    }

    // Update last used timestamp asynchronously
    setTimeout(() => {
      try {
        const curTokens = store.read("api-tokens", []);
        const idx = curTokens.findIndex((t) => t.id === match.id);
        if (idx !== -1) {
          curTokens[idx].lastUsedAt = new Date().toISOString();
          store.write("api-tokens", curTokens);
        }
      } catch (_) {}
    }, 0);

    return {
      id: match.id,
      username: match.owner,
      role: match.role,
      isApiToken: true,
      permissions: match.permissions || ["*"],
    };
  },

  revokeToken(id, { owner, role } = {}) {
    let tokens = store.read("api-tokens", []);
    const match = tokens.find((t) => t.id === id);
    if (!match) throw new Error("API Token not found.");

    if (role !== "admin" && owner && match.owner !== owner) {
      throw new Error("You do not have permission to revoke this token.");
    }

    tokens = tokens.filter((t) => t.id !== id);
    store.write("api-tokens", tokens);
    return { success: true, id };
  },
};

module.exports = TokensService;

