const { exec, spawn } = require("child_process");
const fs = require("fs");
const path = require("path");

const IS_LINUX = process.platform === "linux";

// Audit log path ? only used on Linux
const LOG_DIR  = "/var/log/facezila";
const LOG_FILE = path.join(LOG_DIR, "commands.log");

function writeAuditLog(user, command, exitCode) {
  if (!IS_LINUX) return;
  try {
    if (!fs.existsSync(LOG_DIR)) fs.mkdirSync(LOG_DIR, { recursive: true });
    var line = JSON.stringify({ ts: new Date().toISOString(), user, command, exitCode }) + "\n";
    fs.appendFileSync(LOG_FILE, line);
  } catch (e) { /* non-fatal */ }
}

/**
 * Quote a value for safe interpolation into a POSIX shell command.
 */
function q(value) {
  return "'" + String(value).replace(/'/g, "'\\''") + "'";
}

/**
 * Run a shell command.
 * On non-Linux (dev machine) commands are skipped and a mock result is returned.
 *
 * @param {string} command   Shell command to run
 * @param {object} opts
 * @param {number} opts.timeout   Timeout in ms (default 30000)
 * @param {string} opts.user      Username for audit log (default 'system')
 * @param {string} opts.input     Data written to the command's stdin (never logged)
 * @param {object} opts.env       Extra environment variables
 * @returns {Promise<{ stdout: string, stderr: string, code: number }>}
 */
function run(command, opts = {}) {
  const { timeout = 30000, user = "system", input, env, cwd } = opts;

  if (!IS_LINUX) {
    console.log("[shell:dev-skip] " + command);
    return Promise.resolve({ stdout: "", stderr: "", code: 0, skipped: true });
  }

  return new Promise((resolve, reject) => {
    const child = exec(command, {
      timeout,
      cwd,
      maxBuffer: 16 * 1024 * 1024,
      env: env ? { ...process.env, ...env } : process.env,
    }, (err, stdout, stderr) => {
      const code = err ? (err.code || 1) : 0;
      writeAuditLog(user, command, code);
      if (err && code !== 0) {
        const e = new Error((stderr || "").trim() || err.message);
        e.code = code;
        e.stderr = stderr;
        e.stdout = stdout;
        return reject(e);
      }
      resolve({ stdout: stdout.trim(), stderr: stderr.trim(), code });
    });
    if (input !== undefined) {
      child.stdin.on("error", () => {});
      child.stdin.end(input);
    }
  });
}

/**
 * Run a command and return stdout as trimmed string.
 * Throws on non-zero exit.
 */
async function runGet(command, opts = {}) {
  const r = await run(command, opts);
  return r.stdout;
}

/**
 * Run a command, returning stdout or a fallback value instead of throwing.
 */
async function tryGet(command, fallback = "", opts = {}) {
  try {
    return await runGet(command, opts);
  } catch (_) {
    return fallback;
  }
}

/**
 * Spawn a command and return its stdout stream (for downloads like mysqldump).
 */
function spawnStream(cmd, args, opts = {}) {
  return spawn(cmd, args, { env: opts.env ? { ...process.env, ...opts.env } : process.env });
}

/**
 * Whether a binary is available on PATH.
 */
function hasCommand(name) {
  if (!IS_LINUX) return false;
  const dirs = (process.env.PATH || "/usr/sbin:/usr/bin:/sbin:/bin").split(":")
    .concat(["/usr/sbin", "/usr/bin", "/sbin", "/bin", "/usr/local/bin"]);
  return dirs.some((d) => fs.existsSync(path.join(d, name)));
}

/**
 * Test whether a file or directory exists on disk.
 */
function exists(filePath) {
  return fs.existsSync(filePath);
}

/**
 * Write a file to disk (used for Nginx configs, zone files, etc.)
 */
function writeFile(filePath, content, mode) {
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  fs.writeFileSync(filePath, content, "utf8");
  if (mode) fs.chmodSync(filePath, mode);
}

/**
 * Read a file from disk.
 */
function readFile(filePath) {
  return fs.readFileSync(filePath, "utf8");
}

/**
 * Delete a file or directory recursively.
 */
function remove(targetPath) {
  if (!IS_LINUX) { console.log("[shell:dev-skip] remove: " + targetPath); return; }
  if (fs.existsSync(targetPath)) fs.rmSync(targetPath, { recursive: true, force: true });
}

// systemd is not running inside containers; fall back to SysV `service` there.
const HAS_SYSTEMD = IS_LINUX && fs.existsSync("/run/systemd/system");

function serviceAction(name, action, opts = {}) {
  const cmd = HAS_SYSTEMD
    ? "systemctl " + action + " " + q(name)
    : "service " + q(name) + " " + action;
  return run(cmd, opts);
}

/**
 * Reload a service.
 */
function reloadService(name, opts = {}) {
  return serviceAction(name, "reload", opts);
}

/**
 * Restart a service.
 */
function restartService(name, opts = {}) {
  return serviceAction(name, "restart", opts);
}

/**
 * Returns "active", "inactive", "failed" or "not-installed".
 */
async function serviceStatus(name) {
  if (!IS_LINUX) return "inactive";
  if (HAS_SYSTEMD) {
    const out = await tryGet("systemctl is-active " + q(name) + " 2>/dev/null", "");
    if (out === "active") return "active";
    const known = await tryGet("systemctl list-unit-files " + q(name + ".service") + " --no-legend 2>/dev/null", "");
    if (!known) return "not-installed";
    return out || "inactive";
  }
  if (!fs.existsSync("/etc/init.d/" + name)) return "not-installed";
  try {
    await run("service " + q(name) + " status");
    return "active";
  } catch (_) {
    return "inactive";
  }
}

module.exports = {
  run, runGet, tryGet, spawnStream, hasCommand, q,
  exists, writeFile, readFile, remove,
  serviceAction, reloadService, restartService, serviceStatus,
  IS_LINUX, HAS_SYSTEMD,
};
