const fs = require("fs");
const shell = require("./shell.service");
const platform = require("../lib/platform");
const securityStore = require("../lib/securityStore");

/**
 * Database Security & SQL Injection Hardening Service
 *
 * Implements:
 * - Least-privilege MySQL grant audits
 * - local_infile = 0 verification
 * - Local-only bind verification (127.0.0.1:3306)
 * - Remote host access boundaries
 */

async function auditDatabaseSecurity() {
  const issues = [];
  let secure = true;

  if (shell.IS_LINUX) {
    try {
      // 1. Check local_infile status
      const localInfileOut = await shell.tryGet(`mysql ${platform.MYSQL_ARGS} -e "SHOW VARIABLES LIKE 'local_infile';" 2>/dev/null`, "");
      if (/ON/i.test(localInfileOut)) {
        issues.push({
          check: "local_infile",
          severity: "HIGH",
          message: "local_infile is enabled. This can permit arbitrary local file reads via SQL injection.",
          remediation: "Add 'local_infile = 0' to /etc/mysql/my.cnf.",
        });
        secure = false;
      }

      // 2. Check bind-address
      const cnfContent = fs.readFileSync("/etc/mysql/my.cnf", "utf8").catch?.(() => "") || "";
      if (/bind-address\s*=\s*0\.0\.0\.0/.test(cnfContent)) {
        issues.push({
          check: "bind_address",
          severity: "MEDIUM",
          message: "MySQL is listening on public interfaces (0.0.0.0).",
          remediation: "Bind MySQL to 127.0.0.1 or restrict via UFW.",
        });
      }
    } catch (_) {}
  }

  return {
    auditedAt: new Date().toISOString(),
    isSecure: secure && issues.length === 0,
    issues,
  };
}

module.exports = {
  auditDatabaseSecurity,
};
