function resolveEmailAndDomain(req){let email=req.query.emailaddress||req.query.email||req.params.email||"",domain="";return email&&email.includes("@")?(domain=email.split("@")[1].trim().toLowerCase(),email=email.trim().toLowerCase()):(domain=(req.headers.host||"").split(":")[0].toLowerCase().replace(/^autoconfig\./,"").replace(/^autodiscover\./,"").replace(/^mail\./,""),(!domain||domain==="localhost"||/^\d+\.\d+\.\d+\.\d+$/.test(domain))&&(domain=process.env.PRIMARY_DOMAIN||"sunvexaenergy.in"),email||(email=`user@${domain}`)),{email,domain}}function resolveMailHost(domain,req){const reqHost=(req&&req.headers&&req.headers.host?req.headers.host.split(":")[0]:"").toLowerCase();return/^\d+\.\d+\.\d+\.\d+$/.test(reqHost)?`mail.${domain}`:`mail.${domain}`}function buildAutoconfigXml({email,domain,host,displayName}){const mailHost=host||`mail.${domain}`,providerName=displayName||`${domain} Mail`;return`<?xml version="1.0" encoding="UTF-8"?>
<clientConfig version="1.1">
  <emailProvider id="${escapeXml(domain)}">
    <domain>${escapeXml(domain)}</domain>
    <displayName>${escapeXml(providerName)}</displayName>
    <displayShortName>${escapeXml(domain)}</displayShortName>

    <!-- Incoming IMAP (Recommended) -->
    <incomingServer type="imap">
      <hostname>${escapeXml(mailHost)}</hostname>
      <port>993</port>
      <socketType>SSL</socketType>
      <authentication>password-cleartext</authentication>
      <username>%EMAILADDRESS%</username>
    </incomingServer>

    <!-- Incoming POP3 (Alternative) -->
    <incomingServer type="pop3">
      <hostname>${escapeXml(mailHost)}</hostname>
      <port>995</port>
      <socketType>SSL</socketType>
      <authentication>password-cleartext</authentication>
      <username>%EMAILADDRESS%</username>
    </incomingServer>

    <!-- Outgoing SMTP with SSL (Port 465) -->
    <outgoingServer type="smtp">
      <hostname>${escapeXml(mailHost)}</hostname>
      <port>465</port>
      <socketType>SSL</socketType>
      <authentication>password-cleartext</authentication>
      <username>%EMAILADDRESS%</username>
    </outgoingServer>

    <!-- Outgoing SMTP with STARTTLS (Port 587) -->
    <outgoingServer type="smtp">
      <hostname>${escapeXml(mailHost)}</hostname>
      <port>587</port>
      <socketType>STARTTLS</socketType>
      <authentication>password-cleartext</authentication>
      <username>%EMAILADDRESS%</username>
    </outgoingServer>
  </emailProvider>
</clientConfig>`}function escapeXml(str){return String(str||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&apos;")}function handleAutoconfigRequest(req,res){const{email,domain}=resolveEmailAndDomain(req),host=resolveMailHost(domain,req),xml=buildAutoconfigXml({email,domain,host});return res.setHeader("Content-Type","application/xml; charset=utf-8"),res.setHeader("Access-Control-Allow-Origin","*"),res.setHeader("Cache-Control","public, max-age=3600"),res.status(200).send(xml)}module.exports={resolveEmailAndDomain,resolveMailHost,buildAutoconfigXml,handleAutoconfigRequest};
