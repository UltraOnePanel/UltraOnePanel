const fs = require("fs");
const path = require("path");
const shell = require("./shell.service");
const platform = require("../lib/platform");
const websites = require("./website.service");
const validate = require("../lib/validate");
const store = require("../lib/store");

const NGINX_CONF = platform.IS_AAPANEL ? "/www/server/nginx/conf/nginx.conf" : "/etc/nginx/nginx.conf";
// Picked up by the http{} block: aaPanel includes vhost/nginx/*.conf, Debian includes conf.d/*.conf.
const CACHE_ZONE_CONF = platform.IS_AAPANEL
  ? path.join(platform.paths.vhostDir, "0.facezila-cache.conf")
  : "/etc/nginx/conf.d/facezila-cache.conf";
const CACHE_DIR = "/var/cache/nginx/facezila";

// ---------------------------------------------------------------- OPcache

function phpIni(version) {
  return platform.IS_AAPANEL
    ? "/www/server/php/" + version.replace(".", "") + "/etc/php.ini"
    : "/etc/php/" + version + "/fpm/conf.d/99-facezila.ini";
}

function opcacheState(version) {
  if (platform.IS_AAPANEL) {
    const ini = fs.existsSync(phpIni(version)) ? fs.readFileSync(phpIni(version), "utf8") : "";
    const installed = /^\s*zend_extension\s*=.*opcache/m.test(ini);
    const enabled = installed && /^\s*opcache\.enable\s*=\s*1/m.test(ini);
    return { version, installed, enabled };
  }
  const installed = fs.existsSync("/etc/php/" + version + "/fpm/conf.d/10-opcache.ini");
  const override = fs.existsSync(phpIni(version)) ? fs.readFileSync(phpIni(version), "utf8") : "";
  return { version, installed, enabled: installed && !/opcache\.enable\s*=\s*0/.test(override) };
}

async function setOpcache(enabled, user) {
  const changed = [];
  for (const v of platform.phpVersions()) {
    const st = opcacheState(v);
    if (!st.installed) continue;
    const file = phpIni(v);
    if (platform.IS_AAPANEL) {
      const ini = fs.readFileSync(file, "utf8");
      const next = /^\s*;?\s*opcache\.enable\s*=.*$/m.test(ini)
        ? ini.replace(/^\s*;?\s*opcache\.enable\s*=.*$/m, "opcache.enable=" + (enabled ? 1 : 0))
        : ini + "\nopcache.enable=" + (enabled ? 1 : 0) + "\n";
      fs.writeFileSync(file, next);
    } else {
      shell.writeFile(file, "; Managed by Facezila\nopcache.enable=" + (enabled ? 1 : 0) + "\n");
    }
    await shell.serviceAction(platform.phpFpmService(v), "reload", { user }).catch(() => {});
    changed.push(v);
  }
  if (!changed.length) throw validate.badRequest("The OPcache extension is not installed for any PHP version on this server.");
  return changed;
}

// ---------------------------------------------------------------- Redis

async function redisUnit() {
  for (const name of ["redis-server", "redis"]) {
    const st = await shell.serviceStatus(name);
    if (st !== "not-installed") return { name, state: st };
  }
  return { name: null, state: "not-installed" };
}

// ---------------------------------------------------------------- Gzip / Brotli

function readNginxConf() {
  return fs.existsSync(NGINX_CONF) ? fs.readFileSync(NGINX_CONF, "utf8") : "";
}

async function setGzip(enabled, user) {
  const conf = readNginxConf();
  if (!/^\s*gzip\s+(on|off)\s*;/m.test(conf)) throw validate.badRequest("No gzip directive found in " + NGINX_CONF);
  fs.writeFileSync(NGINX_CONF, conf.replace(/^(\s*)gzip\s+(on|off)\s*;/m, "$1gzip " + (enabled ? "on" : "off") + ";"));
  try {
    await platform.reloadNginx({ user });
  } catch (e) {
    fs.writeFileSync(NGINX_CONF, conf);
    throw e;
  }
}

// ---------------------------------------------------------------- FastCGI micro-cache

async function managedPhpSites() {
  return (await websites.listWebsites()).filter((w) => w.managed && /^\d\.\d$/.test(w.php));
}

async function setFastcgiCache(enabled, user) {
  const sites = await managedPhpSites();
  if (enabled && !sites.length) throw validate.badRequest("No Facezila-managed PHP sites to cache yet.");
  const hadZone = fs.existsSync(CACHE_ZONE_CONF);
  if (enabled) {
    fs.mkdirSync(CACHE_DIR, { recursive: true });
    shell.writeFile(CACHE_ZONE_CONF, "# Managed by Facezila\nfastcgi_cache_path " + CACHE_DIR +
      " levels=1:2 keys_zone=FZCACHE:32m max_size=512m inactive=30m use_temp_path=off;\n");
  }
  try {
    for (const s of sites) await websites.updateManaged({ domain: s.domain, patch: { fastcgiCache: enabled }, user });
    if (!enabled) {
      fs.rmSync(CACHE_ZONE_CONF, { force: true });
      await platform.reloadNginx({ user });
    }
  } catch (e) {
    if (enabled && !hadZone) fs.rmSync(CACHE_ZONE_CONF, { force: true });
    throw e;
  }
  return sites.map((s) => s.domain);
}

// ---------------------------------------------------------------- public

async function getStatus() {
  if (!shell.IS_LINUX) {
    return { fastcgiCache: { enabled: false, sites: 0 }, opcache: { enabled: false, versions: [] }, redis: { enabled: false, installed: false }, compression: { gzip: false, brotli: false } };
  }
  const conf = readNginxConf();
  const nginxV = await shell.tryGet("nginx -V 2>&1", "");
  const opc = platform.phpVersions().map(opcacheState);
  const redis = await redisUnit();
  const sites = await managedPhpSites();
  return {
    fastcgiCache: {
      enabled: fs.existsSync(CACHE_ZONE_CONF) && sites.some((s) => (websites.getMeta(s.domain) || {}).fastcgiCache),
      sites: sites.length,
    },
    opcache: { enabled: opc.some((o) => o.enabled), installed: opc.some((o) => o.installed), versions: opc },
    redis: { enabled: redis.state === "active", installed: redis.state !== "not-installed", state: redis.state },
    compression: {
      gzip: /^\s*gzip\s+on\s*;/m.test(conf),
      brotli: /brotli/.test(nginxV) && /^\s*brotli\s+on\s*;/m.test(conf),
      brotliAvailable: /brotli/.test(nginxV),
    },
  };
}

async function toggle({ module: name, enabled, user }) {
  enabled = !!enabled;
  switch (name) {
    case "opcache":
      return { module: name, enabled, versions: await setOpcache(enabled, user) };
    case "redis": {
      const unit = await redisUnit();
      if (!unit.name) throw validate.badRequest("Redis is not installed on this server.");
      await shell.serviceAction(unit.name, enabled ? "start" : "stop", { user });
      if (shell.HAS_SYSTEMD) await shell.run("systemctl " + (enabled ? "enable" : "disable") + " " + unit.name, { user }).catch(() => {});
      return { module: name, enabled };
    }
    case "compression":
      await setGzip(enabled, user);
      return { module: name, enabled };
    case "fastcgiCache": {
      return { module: name, enabled, sites: await setFastcgiCache(enabled, user) };
    }
    default:
      throw validate.badRequest("Unknown module: " + name);
  }
}

/**
 * Flush FastCGI cache files and reset OPcache by gracefully reloading PHP-FPM.
 */
async function purge({ user } = {}) {
  const cleared = [];
  for (const dir of [CACHE_DIR, "/www/server/fastcgi_cache"]) {
    if (shell.IS_LINUX && fs.existsSync(dir)) {
      await shell.run("find " + shell.q(dir) + " -mindepth 1 -delete", { user });
      cleared.push(dir);
    }
  }
  const reloaded = [];
  for (const v of platform.phpVersions()) {
    try {
      await shell.serviceAction(platform.phpFpmService(v), "reload", { user });
      reloaded.push(v);
    } catch (_) { /* version not running */ }
  }
  return { cleared, phpReloaded: reloaded };
}

// ---------------------------------------------------------------- MultiPHP INI Editor

function defaultDirectives() {
  return {
    upload_max_filesize: "128M",
    post_max_size: "128M",
    memory_limit: "256M",
    max_execution_time: "300",
    max_input_time: "300",
    max_input_vars: "3000",
    display_errors: "Off",
    allow_url_fopen: "On",
    "session.gc_maxlifetime": "1440",
  };
}

function parseIniDirectives(text) {
  const dirs = defaultDirectives();
  for (const line of (text || "").split("\n")) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith(";") || trimmed.startsWith("#")) continue;
    const eqIdx = trimmed.indexOf("=");
    if (eqIdx > 0) {
      const key = trimmed.slice(0, eqIdx).trim();
      const val = trimmed.slice(eqIdx + 1).trim();
      dirs[key] = val;
    }
  }
  return dirs;
}

async function getPhpIni({ domain, version }) {
  if (domain) {
    const site = await websites.getWebsite(domain);
    if (!site) throw validate.badRequest("Website not found: " + domain);
    const docRoot = site.documentRoot || platform.docRoot(domain);
    const iniPath = path.join(docRoot, ".user.ini");
    const content = fs.existsSync(iniPath) ? fs.readFileSync(iniPath, "utf8") : "";
    return {
      scope: "domain",
      domain,
      filePath: iniPath,
      content,
      directives: parseIniDirectives(content),
    };
  }

  const v = version || platform.phpVersions()[0] || "8.2";
  const file = phpIni(v);
  const content = fs.existsSync(file) ? fs.readFileSync(file, "utf8") : "";
  return {
    scope: "global",
    version: v,
    filePath: file,
    content,
    directives: parseIniDirectives(content),
  };
}

async function savePhpIni({ domain, version, content, directives, user }) {
  let textToWrite = content;
  if (!textToWrite && directives) {
    textToWrite = Object.entries(directives)
      .map(([k, v]) => `${k} = ${v}`)
      .join("\n") + "\n";
  }

  if (domain) {
    const site = await websites.getWebsite(domain);
    if (!site) throw validate.badRequest("Website not found: " + domain);
    const docRoot = site.documentRoot || platform.docRoot(domain);
    const iniPath = path.join(docRoot, ".user.ini");
    fs.writeFileSync(iniPath, textToWrite || "", "utf8");
    if (site.php) {
      await shell.serviceAction(platform.phpFpmService(site.php), "reload", { user }).catch(() => {});
    }
    return { success: true, filePath: iniPath };
  }

  const v = version || platform.phpVersions()[0] || "8.2";
  const file = phpIni(v);
  fs.writeFileSync(file, textToWrite || "", "utf8");
  await shell.serviceAction(platform.phpFpmService(v), "reload", { user }).catch(() => {});
  return { success: true, filePath: file };
}

// ---------------------------------------------------------------- PHP Selector & Extensions

async function getPhpExtensions({ version }) {
  const v = version || platform.phpVersions()[0] || "8.2";
  const activeExts = new Set();

  try {
    const out = await shell.tryGet(`php${v} -m 2>/dev/null || php -m 2>/dev/null`, "");
    for (const line of out.split("\n")) {
      const trimmed = line.trim().toLowerCase();
      if (trimmed && !trimmed.startsWith("[")) activeExts.add(trimmed);
    }
  } catch (_) {}

  const standardExts = [
    { name: "mysqli", desc: "MySQL Database Improved Driver", category: "Database" },
    { name: "pdo_mysql", desc: "PHP Data Objects MySQL Driver", category: "Database" },
    { name: "curl", desc: "Client URL Library", category: "Network" },
    { name: "mbstring", desc: "Multibyte String Utilities", category: "Core" },
    { name: "zip", desc: "ZIP Archive Compression", category: "Compression" },
    { name: "gd", desc: "GD Graphics Library", category: "Media" },
    { name: "intl", desc: "Internationalization Functions", category: "Core" },
    { name: "xml", desc: "XML Parsing Support", category: "Data" },
    { name: "bcmath", desc: "Arbitrary Precision Mathematics", category: "Math" },
    { name: "fileinfo", desc: "File MIME Information Detection", category: "Core" },
    { name: "opcache", desc: "Zend Bytecode Cache", category: "Performance" },
    { name: "redis", desc: "Redis In-Memory Connector", category: "Database" },
    { name: "imagick", desc: "ImageMagick Image Processing", category: "Media" },
    { name: "soap", desc: "SOAP Protocol Client/Server", category: "Network" },
    { name: "exif", desc: "Image Metadata Reader", category: "Media" },
    { name: "openssl", desc: "OpenSSL Encryption Support", category: "Security" },
  ];

  const extensions = standardExts.map((e) => ({
    ...e,
    enabled: activeExts.has(e.name.toLowerCase()),
  }));

  return {
    version: v,
    installedVersions: platform.phpVersions(),
    defaultVersion: platform.phpVersions()[0] || "8.2",
    extensions,
  };
}

async function installPhpVersion({ version, user }) {
  const v = String(version || "").trim();
  if (!/^\d+\.\d+$/.test(v)) throw validate.badRequest("Invalid PHP version format: " + v);

  if (shell.IS_LINUX) {
    if (platform.IS_AAPANEL) {
      await shell.run(`/bin/bash /www/server/panel/install/public.sh install_php ${v.replace(".", "")}`, { timeout: 600000, user }).catch(() => {});
    } else {
      await shell.run(`apt-get update && apt-get install -y php${v}-fpm php${v}-cli php${v}-mysql php${v}-curl php${v}-mbstring php${v}-xml php${v}-zip php${v}-gd`, { timeout: 600000, user });
    }
  }
  return { success: true, version: v };
}

// ---------------------------------------------------------------- Applications Manager

function getAppsStore() {
  return store.read("apps_manager", []);
}

function updateAppsStore(updater) {
  return store.update("apps_manager", [], updater);
}

async function listApplications(user) {
  let appsList = getAppsStore();
  if (user && user.role !== "admin" && user.username !== "root") {
    appsList = appsList.filter((a) => {
      if (a.domain) {
        return websites.isUserAllowedSite(a.domain, null, user);
      }
      return false;
    });
  }
  const nodeInstalled = shell.hasCommand("node");
  const pythonInstalled = shell.hasCommand("python3");
  const rubyInstalled = shell.hasCommand("ruby");

  const nodeVer = nodeInstalled ? await shell.tryGet("node -v", "v20.0.0") : null;
  const pythonVer = pythonInstalled ? await shell.tryGet("python3 -V", "Python 3.10") : null;
  const rubyVer = rubyInstalled ? await shell.tryGet("ruby -v", "") : null;

  return {
    applications: appsList,
    environments: {
      node: { installed: nodeInstalled, version: nodeVer ? nodeVer.trim() : null },
      python: { installed: pythonInstalled, version: pythonVer ? pythonVer.trim() : null },
      ruby: { installed: rubyInstalled, version: rubyVer ? rubyVer.trim() : null },
    },
  };
}

async function createApplication({ name, type = "Node.js", domain, path: appPath = "/", startupFile = "server.js", port = 3000, envMode = "Production", user }) {
  if (!name) throw validate.badRequest("Application name is required.");
  const app = {
    id: "app_" + Date.now().toString(36) + "_" + Math.random().toString(36).slice(2, 6),
    name: String(name).trim(),
    type: String(type).trim(),
    domain: String(domain || "").trim(),
    path: String(appPath).trim(),
    startupFile: String(startupFile).trim(),
    port: Number(port) || 3000,
    envMode: envMode === "Development" ? "Development" : "Production",
    status: "running",
    createdAt: new Date().toISOString().slice(0, 10),
  };

  updateAppsStore((list) => {
    return (list || []).concat(app);
  });

  return { success: true, application: app };
}

async function deleteApplication({ id, user }) {
  updateAppsStore((list) => {
    return (list || []).filter((a) => a.id !== id);
  });
  return { success: true, id };
}

async function toggleApplication({ id, action = "restart", user }) {
  let updated = null;
  updateAppsStore((list) => {
    return (list || []).map((a) => {
      if (a.id === id) {
        a.status = action === "stop" ? "stopped" : "running";
        updated = a;
      }
      return a;
    });
  });
  return { success: true, application: updated };
}

async function installEnvironment({ type = "node", user }) {
  if (!shell.IS_LINUX) return { success: true, simulated: true };
  if (type === "node") {
    await shell.run("curl -fsSL https://deb.nodesource.com/setup_20.x | bash - && apt-get install -y nodejs", { timeout: 300000, user });
  } else if (type === "python") {
    await shell.run("apt-get update && apt-get install -y python3 python3-pip python3-venv", { timeout: 300000, user });
  } else if (type === "ruby") {
    await shell.run("apt-get update && apt-get install -y ruby-full", { timeout: 300000, user });
  }
  return { success: true, type };
}

// ---------------------------------------------------------------- Optimize Website (Gzip)

async function getGzipConfig() {
  const conf = readNginxConf();
  const gzipOn = /^\s*gzip\s+on\s*;/m.test(conf);
  const typesMatch = conf.match(/^\s*gzip_types\s+([^;]+);/m);
  const types = typesMatch ? typesMatch[1].trim().split(/\s+/) : [
    "text/plain", "text/css", "application/json", "application/javascript",
    "text/xml", "application/xml", "application/xml+rss", "text/javascript", "image/svg+xml"
  ];

  let mode = "disabled";
  if (gzipOn) {
    mode = typesMatch ? "types" : "all";
  }

  const nginxV = await shell.tryGet("nginx -V 2>&1", "");
  return {
    mode,
    gzipEnabled: gzipOn,
    types,
    brotliAvailable: /brotli/.test(nginxV),
    brotliEnabled: /^\s*brotli\s+on\s*;/m.test(conf),
  };
}

async function saveGzipConfig({ mode = "all", types = [], user }) {
  let conf = readNginxConf();
  if (mode === "disabled") {
    conf = conf.replace(/^\s*gzip\s+(on|off)\s*;/m, "gzip off;");
  } else if (mode === "all") {
    conf = conf.replace(/^\s*gzip\s+(on|off)\s*;/m, "gzip on;");
    const standardTypes = "text/plain text/css application/json application/javascript text/xml application/xml application/xml+rss text/javascript image/svg+xml";
    if (/^\s*gzip_types\s+[^;]+;/m.test(conf)) {
      conf = conf.replace(/^\s*gzip_types\s+[^;]+;/m, `gzip_types ${standardTypes};`);
    } else {
      conf = conf.replace(/^(\s*gzip\s+on\s*;)/m, `$1\n    gzip_types ${standardTypes};`);
    }
  } else if (mode === "types") {
    conf = conf.replace(/^\s*gzip\s+(on|off)\s*;/m, "gzip on;");
    const customTypes = (types && types.length ? types.join(" ") : "text/plain text/css application/javascript");
    if (/^\s*gzip_types\s+[^;]+;/m.test(conf)) {
      conf = conf.replace(/^\s*gzip_types\s+[^;]+;/m, `gzip_types ${customTypes};`);
    } else {
      conf = conf.replace(/^(\s*gzip\s+on\s*;)/m, `$1\n    gzip_types ${customTypes};`);
    }
  }

  fs.writeFileSync(NGINX_CONF, conf, "utf8");
  try {
    await platform.reloadNginx({ user });
  } catch (e) {
    throw new Error("Failed to reload Nginx with new compression settings: " + e.message);
  }
  return { success: true, mode };
}

// ---------------------------------------------------------------- WordPress Toolkit Lite

async function listWordPressSites(params = {}) {
  const user = params?.user || (params?.username || params?.role ? params : null);
  const filterDomain = (params?.domain || "").toLowerCase().trim();

  const allSites = await websites.listWebsites(user);
  const wpInstances = [];

  for (const site of allSites) {
    if (filterDomain && site.domain.toLowerCase() !== filterDomain) continue;

    // Strict ownership verification for non-admin accounts
    if (user && user.role !== "admin" && user.username !== "root") {
      if (!websites.isUserAllowedSite(site.domain, site, user)) continue;
    }

    const docRoot = site.documentRoot || platform.docRoot(site.domain);
    if (!docRoot || !fs.existsSync(docRoot)) continue;

    const checkDirs = [{ dir: docRoot, pathPrefix: "" }];
    try {
      const subEntries = fs.readdirSync(docRoot, { withFileTypes: true });
      for (const ent of subEntries) {
        if (ent.isDirectory() && !ent.name.startsWith(".")) {
          checkDirs.push({ dir: path.join(docRoot, ent.name), pathPrefix: "/" + ent.name });
        }
      }
    } catch (_) {}

    for (const { dir, pathPrefix } of checkDirs) {
      const wpConfigPath = path.join(dir, "wp-config.php");
      if (!fs.existsSync(wpConfigPath)) continue;

      let wpVersion = "Latest";
      const versionFile = path.join(dir, "wp-includes", "version.php");
      if (fs.existsSync(versionFile)) {
        const vMatch = fs.readFileSync(versionFile, "utf8").match(/\$wp_version\s*=\s*['"]([^'"]+)['"]/);
        if (vMatch) wpVersion = vMatch[1];
      }

      let dbName = "Unknown";
      try {
        const confText = fs.readFileSync(wpConfigPath, "utf8");
        const dbMatch = confText.match(/define\(\s*['"]DB_NAME['"]\s*,\s*['"]([^'"]+)['"]\s*\)/);
        if (dbMatch) dbName = dbMatch[1];
      } catch (_) {}

      let pluginsCount = 0;
      const pluginsDir = path.join(dir, "wp-content", "plugins");
      if (fs.existsSync(pluginsDir)) {
        try {
          pluginsCount = fs.readdirSync(pluginsDir).filter(f => !f.startsWith(".")).length;
        } catch (_) {}
      }

      const siteUrl = (site.ssl ? "https://" : "http://") + site.domain + pathPrefix;
      wpInstances.push({
        domain: site.domain,
        subPath: pathPrefix || "/",
        url: siteUrl,
        adminUrl: siteUrl + "/wp-admin/",
        dir,
        version: wpVersion,
        database: dbName,
        php: site.php || "8.2",
        ssl: site.ssl,
        pluginsCount,
      });
    }
  }

  return { success: true, sites: wpInstances };
}

async function installWordPressDirect({ domain, subPath = "", title, adminUser = "admin", adminPass, adminEmail, user }) {
  if (user && user.role !== "admin" && user.username !== "root") {
    if (!websites.isUserAllowedSite(domain, null, user)) {
      throw validate.badRequest("Permission denied: You do not have permission to install WordPress on " + domain);
    }
  }
  const site = await websites.getWebsite(domain);
  if (!site) throw validate.badRequest("Website not found: " + domain);

  const docRoot = site.documentRoot || platform.docRoot(domain);
  const targetDir = subPath && subPath !== "/" ? path.join(docRoot, subPath.replace(/^\//, "")) : docRoot;
  fs.mkdirSync(targetDir, { recursive: true });

  const slug = domain.replace(/[^a-z0-9]/g, "_").slice(0, 16);
  const rand = Math.random().toString(36).slice(2, 6);
  const dbName = "wp_" + slug + "_" + rand;
  const dbUser = "wp_" + slug.slice(0, 12) + "_" + rand;
  const dbPass = adminPass || Math.random().toString(36).slice(2, 14) + "A1!";

  const CACHE = shell.IS_LINUX ? "/var/cache/facezila" : path.resolve(__dirname, "../../data/cache");
  fs.mkdirSync(CACHE, { recursive: true });
  const tarball = path.join(CACHE, "wordpress-latest.tar.gz");
  if (!fs.existsSync(tarball) || Date.now() - fs.statSync(tarball).mtimeMs > 86400000) {
    await shell.run("curl -fsSL --retry 2 -o " + shell.q(tarball) + " https://wordpress.org/latest.tar.gz", { timeout: 300000, user });
  }

  const tmp = path.join(CACHE, "wp-" + rand);
  fs.mkdirSync(tmp, { recursive: true });
  try {
    await shell.run("tar -xzf " + shell.q(tarball) + " -C " + shell.q(tmp), { timeout: 120000, user });
    if (fs.existsSync(path.join(targetDir, "index.html"))) fs.rmSync(path.join(targetDir, "index.html"), { force: true });
    await shell.run("cp -a " + shell.q(path.join(tmp, "wordpress") + "/.") + " " + shell.q(targetDir), { user });
  } finally {
    fs.rmSync(tmp, { recursive: true, force: true });
  }

  const databases = require("./database.service");
  await databases.createDatabase({ name: dbName, dbUser, dbPass, user }).catch((e) => {
    console.warn("Database creation note:", e.message);
  });

  const salt = () => require("crypto").randomBytes(48).toString("base64");
  const sampleConfig = path.join(targetDir, "wp-config-sample.php");
  if (fs.existsSync(sampleConfig)) {
    const config = fs.readFileSync(sampleConfig, "utf8")
      .replace("database_name_here", dbName)
      .replace("username_here", dbUser)
      .replace("password_here", dbPass)
      .replace(/'put your unique phrase here'/g, () => "'" + salt() + "'");
    fs.writeFileSync(path.join(targetDir, "wp-config.php"), config, { mode: 0o640 });
  }

  const WEB_USER = platform.IS_AAPANEL ? "www" : "www-data";
  await shell.run("chown -R " + WEB_USER + ":" + WEB_USER + " " + shell.q(targetDir), { user }).catch(() => {});

  const urlPrefix = subPath && subPath !== "/" ? (subPath.startsWith("/") ? subPath : "/" + subPath) : "";
  const siteUrl = (site.ssl ? "https://" : "http://") + domain + urlPrefix;

  return {
    success: true,
    domain,
    url: siteUrl,
    adminUrl: siteUrl + "/wp-admin/install.php",
    database: dbName,
    dbUser,
    dbPass,
  };
}

module.exports = {
  getStatus,
  toggle,
  purge,
  getPhpIni,
  savePhpIni,
  getPhpExtensions,
  installPhpVersion,
  listApplications,
  createApplication,
  deleteApplication,
  toggleApplication,
  installEnvironment,
  getGzipConfig,
  saveGzipConfig,
  listWordPressSites,
  installWordPressDirect,
};
