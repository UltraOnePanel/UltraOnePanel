const fs = require("fs");
const path = require("path");
const shell = require("./shell.service");
const platform = require("../lib/platform");
const websites = require("./website.service");
const validate = require("../lib/validate");
const store = require("../lib/store");

const NGINX_CONF = platform.IS_AAPANEL ? "/www/server/nginx/conf/nginx.conf" : "/etc/nginx/nginx.conf";
// Picked up by the http{} block: aaPanel includes vhost/nginx/*.conf, Debian includes conf.d/*.conf.
const CACHE_ZONE_CONF = platform.IS_AAPANEL
  ? path.join(platform.paths.vhostDir, "0.facezila-cache.conf")
  : "/etc/nginx/conf.d/facezila-cache.conf";
const CACHE_DIR = "/var/cache/nginx/facezila";

// ---------------------------------------------------------------- OPcache

function phpIni(version) {
  return platform.IS_AAPANEL
    ? "/www/server/php/" + version.replace(".", "") + "/etc/php.ini"
    : "/etc/php/" + version + "/fpm/conf.d/99-facezila.ini";
}

function opcacheState(version) {
  if (platform.IS_AAPANEL) {
    const ini = fs.existsSync(phpIni(version)) ? fs.readFileSync(phpIni(version), "utf8") : "";
    const installed = /^\s*zend_extension\s*=.*opcache/m.test(ini);
    const enabled = installed && /^\s*opcache\.enable\s*=\s*1/m.test(ini);
    return { version, installed, enabled };
  }
  const installed = fs.existsSync("/etc/php/" + version + "/fpm/conf.d/10-opcache.ini");
  const override = fs.existsSync(phpIni(version)) ? fs.readFileSync(phpIni(version), "utf8") : "";
  return { version, installed, enabled: installed && !/opcache\.enable\s*=\s*0/.test(override) };
}

async function setOpcache(enabled, user) {
  const changed = [];
  for (const v of platform.phpVersions()) {
    const st = opcacheState(v);
    if (!st.installed) continue;
    const file = phpIni(v);
    if (platform.IS_AAPANEL) {
      const ini = fs.readFileSync(file, "utf8");
      const next = /^\s*;?\s*opcache\.enable\s*=.*$/m.test(ini)
        ? ini.replace(/^\s*;?\s*opcache\.enable\s*=.*$/m, "opcache.enable=" + (enabled ? 1 : 0))
        : ini + "\nopcache.enable=" + (enabled ? 1 : 0) + "\n";
      fs.writeFileSync(file, next);
    } else {
      shell.writeFile(file, "; Managed by Facezila\nopcache.enable=" + (enabled ? 1 : 0) + "\n");
    }
    await shell.serviceAction(platform.phpFpmService(v), "reload", { user }).catch(() => {});
    changed.push(v);
  }
  if (!changed.length) throw validate.badRequest("The OPcache extension is not installed for any PHP version on this server.");
  return changed;
}

// ---------------------------------------------------------------- Redis

async function redisUnit() {
  for (const name of ["redis-server", "redis"]) {
    const st = await shell.serviceStatus(name);
    if (st !== "not-installed") return { name, state: st };
  }
  return { name: null, state: "not-installed" };
}

// ---------------------------------------------------------------- Gzip / Brotli

function readNginxConf() {
  return fs.existsSync(NGINX_CONF) ? fs.readFileSync(NGINX_CONF, "utf8") : "";
}

async function setGzip(enabled, user) {
  const conf = readNginxConf();
  if (!/^\s*gzip\s+(on|off)\s*;/m.test(conf)) throw validate.badRequest("No gzip directive found in " + NGINX_CONF);
  fs.writeFileSync(NGINX_CONF, conf.replace(/^(\s*)gzip\s+(on|off)\s*;/m, "$1gzip " + (enabled ? "on" : "off") + ";"));
  try {
    await platform.reloadNginx({ user });
  } catch (e) {
    fs.writeFileSync(NGINX_CONF, conf);
    throw e;
  }
}

// ---------------------------------------------------------------- FastCGI micro-cache

async function managedPhpSites() {
  return (await websites.listWebsites()).filter((w) => w.managed && /^\d\.\d$/.test(w.php));
}

async function setFastcgiCache(enabled, user) {
  const sites = await managedPhpSites();
  if (enabled && !sites.length) throw validate.badRequest("No Facezila-managed PHP sites to cache yet.");
  const hadZone = fs.existsSync(CACHE_ZONE_CONF);
  if (enabled) {
    fs.mkdirSync(CACHE_DIR, { recursive: true });
    shell.writeFile(CACHE_ZONE_CONF, "# Managed by Facezila\nfastcgi_cache_path " + CACHE_DIR +
      " levels=1:2 keys_zone=FZCACHE:32m max_size=512m inactive=30m use_temp_path=off;\n");
  }
  try {
    for (const s of sites) await websites.updateManaged({ domain: s.domain, patch: { fastcgiCache: enabled }, user });
    if (!enabled) {
      fs.rmSync(CACHE_ZONE_CONF, { force: true });
      await platform.reloadNginx({ user });
    }
  } catch (e) {
    if (enabled && !hadZone) fs.rmSync(CACHE_ZONE_CONF, { force: true });
    throw e;
  }
  return sites.map((s) => s.domain);
}

// ---------------------------------------------------------------- public

async function getStatus() {
  if (!shell.IS_LINUX) {
    return { fastcgiCache: { enabled: false, sites: 0 }, opcache: { enabled: false, versions: [] }, redis: { enabled: false, installed: false }, compression: { gzip: false, brotli: false } };
  }
  const conf = readNginxConf();
  const nginxV = await shell.tryGet("nginx -V 2>&1", "");
  const opc = platform.phpVersions().map(opcacheState);
  const redis = await redisUnit();
  const sites = await managedPhpSites();
  return {
    fastcgiCache: {
      enabled: fs.existsSync(CACHE_ZONE_CONF) && sites.some((s) => (websites.getMeta(s.domain) || {}).fastcgiCache),
      sites: sites.length,
    },
    opcache: { enabled: opc.some((o) => o.enabled), installed: opc.some((o) => o.installed), versions: opc },
    redis: { enabled: redis.state === "active", installed: redis.state !== "not-installed", state: redis.state },
    compression: {
      gzip: /^\s*gzip\s+on\s*;/m.test(conf),
      brotli: /brotli/.test(nginxV) && /^\s*brotli\s+on\s*;/m.test(conf),
      brotliAvailable: /brotli/.test(nginxV),
    },
  };
}

async function toggle({ module: name, enabled, user }) {
  enabled = !!enabled;
  switch (name) {
    case "opcache":
      return { module: name, enabled, versions: await setOpcache(enabled, user) };
    case "redis": {
      const unit = await redisUnit();
      if (!unit.name) throw validate.badRequest("Redis is not installed on this server.");
      await shell.serviceAction(unit.name, enabled ? "start" : "stop", { user });
      if (shell.HAS_SYSTEMD) await shell.run("systemctl " + (enabled ? "enable" : "disable") + " " + unit.name, { user }).catch(() => {});
      return { module: name, enabled };
    }
    case "compression":
      await setGzip(enabled, user);
      return { module: name, enabled };
    case "fastcgiCache": {
      return { module: name, enabled, sites: await setFastcgiCache(enabled, user) };
    }
    default:
      throw validate.badRequest("Unknown module: " + name);
  }
}

/**
 * Flush FastCGI cache files and reset OPcache by gracefully reloading PHP-FPM.
 */
async function purge({ user } = {}) {
  const cleared = [];
  for (const dir of [CACHE_DIR, "/www/server/fastcgi_cache"]) {
    if (shell.IS_LINUX && fs.existsSync(dir)) {
      await shell.run("find " + shell.q(dir) + " -mindepth 1 -delete", { user });
      cleared.push(dir);
    }
  }
  const reloaded = [];
  for (const v of platform.phpVersions()) {
    try {
      await shell.serviceAction(platform.phpFpmService(v), "reload", { user });
      reloaded.push(v);
    } catch (_) { /* version not running */ }
  }
  return { cleared, phpReloaded: reloaded };
}

// ---------------------------------------------------------------- MultiPHP INI Editor

function defaultDirectives() {
  return {
    upload_max_filesize: "128M",
    post_max_size: "128M",
    memory_limit: "256M",
    max_execution_time: "300",
    max_input_time: "300",
    max_input_vars: "3000",
    display_errors: "Off",
    allow_url_fopen: "On",
    "session.gc_maxlifetime": "1440",
  };
}

function parseIniDirectives(text) {
  const dirs = defaultDirectives();
  for (const line of (text || "").split("\n")) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith(";") || trimmed.startsWith("#")) continue;
    const eqIdx = trimmed.indexOf("=");
    if (eqIdx > 0) {
      const key = trimmed.slice(0, eqIdx).trim();
      const val = trimmed.slice(eqIdx + 1).trim();
      dirs[key] = val;
    }
  }
  return dirs;
}

async function getPhpIni({ domain, version }) {
  if (domain) {
    const site = await websites.getWebsite(domain);
    if (!site) throw validate.badRequest("Website not found: " + domain);
    const docRoot = site.documentRoot || platform.docRoot(domain);
    const iniPath = path.join(docRoot, ".user.ini");
    const content = fs.existsSync(iniPath) ? fs.readFileSync(iniPath, "utf8") : "";
    return {
      scope: "domain",
      domain,
      filePath: iniPath,
      content,
      directives: parseIniDirectives(content),
    };
  }

  const v = version || platform.phpVersions()[0] || "8.2";
  const file = phpIni(v);
  const content = fs.existsSync(file) ? fs.readFileSync(file, "utf8") : "";
  return {
    scope: "global",
    version: v,
    filePath: file,
    content,
    directives: parseIniDirectives(content),
  };
}

async function savePhpIni({ domain, version, content, directives, user }) {
  let textToWrite = content;
  if (!textToWrite && directives) {
    textToWrite = Object.entries(directives)
      .map(([k, v]) => `${k} = ${v}`)
      .join("\n") + "\n";
  }

  if (domain) {
    const site = await websites.getWebsite(domain);
    if (!site) throw validate.badRequest("Website not found: " + domain);
    const docRoot = site.documentRoot || platform.docRoot(domain);
    const iniPath = path.join(docRoot, ".user.ini");
    fs.writeFileSync(iniPath, textToWrite || "", "utf8");
    if (site.php) {
      await shell.serviceAction(platform.phpFpmService(site.php), "reload", { user }).catch(() => {});
    }
    return { success: true, filePath: iniPath };
  }

  const v = version || platform.phpVersions()[0] || "8.2";
  const file = phpIni(v);
  fs.writeFileSync(file, textToWrite || "", "utf8");
  await shell.serviceAction(platform.phpFpmService(v), "reload", { user }).catch(() => {});
  return { success: true, filePath: file };
}

// ---------------------------------------------------------------- PHP Selector & Extensions

const ALL_EXTENSIONS_CATALOG = [
  // A
  { name: "amqp", desc: "Advanced Message Queuing Protocol", letter: "A" },
  { name: "apcu", desc: "APC User Cache in-memory key-value store", letter: "A" },
  // B
  { name: "bcmath", desc: "Arbitrary Precision Mathematics", letter: "B" },
  { name: "bitset", desc: "Bitset Data Structure Manipulation", letter: "B" },
  { name: "brotli", desc: "Brotli Data Compression Algorithm", letter: "B" },
  { name: "bz2", desc: "Bzip2 Data Compression", letter: "B" },
  // C
  { name: "calendar", desc: "Calendar Conversion Support", letter: "C" },
  { name: "core", desc: "PHP Core Language Features", letter: "C" },
  { name: "ctype", desc: "Character Type Checking", letter: "C" },
  { name: "curl", desc: "Client URL Library", letter: "C" },
  // D
  { name: "date", desc: "Date and Time Functions", letter: "D" },
  { name: "dba", desc: "Database Abstraction Layer", letter: "D" },
  { name: "dbase", desc: "dBase Database Support", letter: "D" },
  { name: "dom", desc: "Document Object Model XML Parser", letter: "D" },
  // E
  { name: "eio", desc: "Asynchronous POSIX I/O", letter: "E" },
  { name: "elastic_apm", desc: "Elastic APM Performance Agent", letter: "E" },
  { name: "enchant", desc: "Enchant Spelling Library", letter: "E" },
  { name: "exif", desc: "Exchangeable Image Information", letter: "E" },
  // F
  { name: "ffi", desc: "Foreign Function Interface", letter: "F" },
  { name: "fileinfo", desc: "File MIME Information Detection", letter: "F" },
  { name: "filter", desc: "Data Filtering Utilities", letter: "F" },
  { name: "ftp", desc: "File Transfer Protocol Client", letter: "F" },
  // G
  { name: "gd", desc: "GD Graphics Library", letter: "G" },
  { name: "gearman", desc: "Gearman Distributed Job System", letter: "G" },
  { name: "gender", desc: "Gender Profiling Support", letter: "G" },
  { name: "geoip", desc: "GeoIP IP Location Lookup", letter: "G" },
  { name: "geos", desc: "Geometry Engine Open Source", letter: "G" },
  { name: "gettext", desc: "Native Language Translation Support", letter: "G" },
  { name: "gmagick", desc: "GraphicsMagick Image Processing", letter: "G" },
  { name: "gmp", desc: "GNU Multiple Precision Numbers", letter: "G" },
  { name: "grpc", desc: "Google High Performance RPC", letter: "G" },
  // H
  { name: "hash", desc: "HASH Message Digest Framework", letter: "H" },
  { name: "htscanner", desc: "htaccess Configuration for PHP-FPM", letter: "H" },
  { name: "http", desc: "Extended HTTP Protocol Functions", letter: "H" },
  // I
  { name: "iconv", desc: "Character Set Conversion", letter: "I" },
  { name: "igbinary", desc: "Compact Binary Serializer", letter: "I" },
  { name: "imagick", desc: "ImageMagick Image Processing", letter: "I" },
  { name: "imap", desc: "Internet Message Access Protocol", letter: "I" },
  { name: "inotify", desc: "File System Event Monitoring", letter: "I" },
  { name: "intl", desc: "Internationalization Functions", letter: "I" },
  { name: "ioncube_loader", desc: "ionCube Bytecode Loader", letter: "I" },
  // J
  { name: "jsmin", desc: "JavaScript Minification", letter: "J" },
  { name: "json", desc: "JavaScript Object Notation", letter: "J" },
  // L
  { name: "ldap", desc: "Lightweight Directory Access Protocol", letter: "L" },
  { name: "leveldb", desc: "Google LevelDB Fast Storage", letter: "L" },
  { name: "libxml", desc: "LibXML Document Support", letter: "L" },
  { name: "luasandbox", desc: "Lua Script Execution Sandbox", letter: "L" },
  { name: "lzf", desc: "Fast LZF Compression", letter: "L" },
  // M
  { name: "mailparse", desc: "Email Message Parser", letter: "M" },
  { name: "mbstring", desc: "Multibyte String Utilities", letter: "M" },
  { name: "mcrypt", desc: "Legacy Encryption Library", letter: "M" },
  { name: "memcache", desc: "Memcached Client (PECL)", letter: "M" },
  { name: "memcached", desc: "High-Performance Memcached", letter: "M" },
  { name: "mongodb", desc: "MongoDB NoSQL Driver", letter: "M" },
  { name: "msgpack", desc: "MessagePack Serialization", letter: "M" },
  { name: "mysqli", desc: "MySQL Database Improved Driver", letter: "M" },
  { name: "mysqlnd", desc: "MySQL Native Driver", letter: "M" },
  // N
  { name: "nd_mysqli", desc: "Native Driver MySQLi", letter: "N" },
  { name: "nd_pdo_mysql", desc: "Native Driver PDO MySQL", letter: "N" },
  { name: "newrelic", desc: "New Relic APM Agent", letter: "N" },
  // O
  { name: "oauth", desc: "OAuth 1.0/2.0 Protocol", letter: "O" },
  { name: "oci8", desc: "Oracle Database 11g/12c/19c", letter: "O" },
  { name: "odbc", desc: "Open Database Connectivity", letter: "O" },
  { name: "opcache", desc: "Zend Bytecode Cache", letter: "O" },
  { name: "openssl", desc: "OpenSSL Encryption Support", letter: "O" },
  // P
  { name: "pcntl", desc: "Process Control Support", letter: "P" },
  { name: "pcre", desc: "Perl Compatible Regular Expressions", letter: "P" },
  { name: "pdf", desc: "PDFlib Document Generation", letter: "P" },
  { name: "pdo", desc: "PHP Data Objects Database Abstraction", letter: "P" },
  { name: "pdo_dblib", desc: "Microsoft SQL / Sybase PDO", letter: "P" },
  { name: "pdo_firebird", desc: "Firebird / Interbase PDO", letter: "P" },
  { name: "pdo_mysql", desc: "PHP Data Objects MySQL Driver", letter: "P" },
  { name: "pdo_oci", desc: "Oracle Driver for PDO", letter: "P" },
  { name: "pdo_odbc", desc: "ODBC Driver for PDO", letter: "P" },
  { name: "pdo_pgsql", desc: "PostgreSQL Driver for PDO", letter: "P" },
  { name: "pdo_sqlite", desc: "SQLite Driver for PDO", letter: "P" },
  { name: "pdo_sqlsrv", desc: "Microsoft SQL Server PDO", letter: "P" },
  { name: "pgsql", desc: "PostgreSQL Database Client", letter: "P" },
  { name: "phalcon5", desc: "Phalcon 5 High-Speed Framework", letter: "P" },
  { name: "phar", desc: "PHP Archive Execution", letter: "P" },
  { name: "phpiredis", desc: "Hiredis C Client for Redis", letter: "P" },
  { name: "posix", desc: "POSIX Process Functions", letter: "P" },
  { name: "protobuf", desc: "Protocol Buffers Data Format", letter: "P" },
  { name: "pspell", desc: "GNU Aspell Spell Checking", letter: "P" },
  { name: "psr", desc: "PHP Standard Recommendations", letter: "P" },
  // Q
  { name: "quickhash", desc: "Fast In-Memory Hash Tables", letter: "Q" },
  // R
  { name: "radius", desc: "RADIUS Authentication Client", letter: "R" },
  { name: "raphf", desc: "Resource and Persistent Handles", letter: "R" },
  { name: "rar", desc: "RAR Archive Reader", letter: "R" },
  { name: "readline", desc: "GNU Readline CLI Editing", letter: "R" },
  { name: "redis", desc: "Redis In-Memory Connector", letter: "R" },
  { name: "reflection", desc: "Class and Method Introspection", letter: "R" },
  { name: "rrd", desc: "RRDtool Round Robin Database", letter: "R" },
  // S
  { name: "scoutapm", desc: "Scout APM Performance Agent", letter: "S" },
  { name: "session", desc: "User Session Management", letter: "S" },
  { name: "shmop", desc: "Shared Memory Operations", letter: "S" },
  { name: "simplexml", desc: "SimpleXML Parsing Utilities", letter: "S" },
  { name: "snmp", desc: "Simple Network Management", letter: "S" },
  { name: "snuffleupagus", desc: "Security Hardening Engine", letter: "S" },
  { name: "soap", desc: "SOAP Protocol Client/Server", letter: "S" },
  { name: "sockets", desc: "Low-Level Network Sockets", letter: "S" },
  { name: "sodium", desc: "Modern Libsodium Cryptography", letter: "S" },
  { name: "solr", desc: "Apache Solr Search Client", letter: "S" },
  { name: "sourceguardian", desc: "SourceGuardian Bytecode Loader", letter: "S" },
  { name: "spl", desc: "Standard PHP Library", letter: "S" },
  { name: "sqlite3", desc: "SQLite3 Embedded Database", letter: "S" },
  { name: "sqlsrv", desc: "Microsoft SQL Server Driver", letter: "S" },
  { name: "ssh2", desc: "Secure Shell v2 Protocol", letter: "S" },
  { name: "standard", desc: "Standard Functions Library", letter: "S" },
  { name: "stats", desc: "Statistical Computation Functions", letter: "S" },
  { name: "stomp", desc: "Streaming Text Oriented Protocol", letter: "S" },
  { name: "swoole", desc: "Coroutine-Based Async Framework", letter: "S" },
  { name: "sysvmsg", desc: "System V Message Queues", letter: "S" },
  { name: "sysvsem", desc: "System V Semaphores", letter: "S" },
  { name: "sysvshm", desc: "System V Shared Memory", letter: "S" },
  // T
  { name: "tideways_xhprof", desc: "Tideways XHProf Profiler", letter: "T" },
  { name: "tidy", desc: "HTML Tidy Cleaner and Parser", letter: "T" },
  { name: "timezonedb", desc: "Updated Timezone Database", letter: "T" },
  { name: "tokenizer", desc: "PHP Source Code Tokenizer", letter: "T" },
  { name: "trader", desc: "Technical Analysis for Financial Data", letter: "T" },
  { name: "translit", desc: "String Transliteration Utilities", letter: "T" },
  // U
  { name: "uploadprogress", desc: "File Upload Progress Tracking", letter: "U" },
  { name: "uuid", desc: "Universally Unique Identifier", letter: "U" },
  { name: "uv", desc: "libuv Asynchronous I/O Loop", letter: "U" },
  // V
  { name: "v8js", desc: "V8 JavaScript Engine Embedded", letter: "V" },
  { name: "vld", desc: "Vulcan Logic Dumper (Opcode Viewer)", letter: "V" },
  // X
  { name: "xdebug", desc: "Step Debugger and Profiler", letter: "X" },
  { name: "xdiff", desc: "File Differences Engine", letter: "X" },
  { name: "xml", desc: "XML Parsing Support", letter: "X" },
  { name: "xmlreader", desc: "Streaming XML Pull Parser", letter: "X" },
  { name: "xmlrpc", desc: "XML-RPC Web Services Protocol", letter: "X" },
  { name: "xmlwriter", desc: "Streaming XML Document Writer", letter: "X" },
  { name: "xsl", desc: "Extensible Stylesheet Transformations", letter: "X" },
  // Y
  { name: "yaf", desc: "Yet Another Framework (C extension)", letter: "Y" },
  { name: "yaml", desc: "YAML Data Serialization Format", letter: "Y" },
  { name: "yaz", desc: "Z39.50 Information Retrieval", letter: "Y" },
  // Z
  { name: "zip", desc: "ZIP Archive Compression", letter: "Z" },
  { name: "zlib", desc: "Gzip and Deflate Compression", letter: "Z" },
  { name: "zmq", desc: "ZeroMQ Distributed Messaging", letter: "Z" },
];

async function getPhpExtensions({ version }) {
  const v = version || platform.getGlobalPhpVersion();
  const activeExts = new Set();
  const bin = platform.IS_AAPANEL
    ? `/www/server/php/${v.replace(".", "")}/bin/php`
    : `php${v}`;

  try {
    const out = await shell.tryGet(`${bin} -m 2>/dev/null || php -m 2>/dev/null`, "");
    for (const line of out.split("\n")) {
      const trimmed = line.trim().toLowerCase();
      if (trimmed && !trimmed.startsWith("[") && !trimmed.startsWith("php warning")) activeExts.add(trimmed);
    }
  } catch (_) {}

  // Fallback defaults if running on dev environment without php cli
  if (activeExts.size === 0) {
    ["bcmath", "calendar", "ctype", "curl", "date", "dom", "exif", "fileinfo", "filter", "ftp", "gd", "hash", "iconv", "intl", "json", "libxml", "mbstring", "mysqli", "mysqlnd", "opcache", "openssl", "pcre", "pdo", "pdo_mysql", "phar", "posix", "readline", "reflection", "session", "shmop", "simplexml", "sockets", "sodium", "spl", "standard", "sysvmsg", "sysvsem", "sysvshm", "tokenizer", "xml", "xmlreader", "xmlwriter", "xsl", "zip", "zlib"].forEach((e) => activeExts.add(e));
  }

  const extensions = ALL_EXTENSIONS_CATALOG.map((e) => ({
    ...e,
    enabled: activeExts.has(e.name.toLowerCase()),
  }));

  return {
    success: true,
    version: v,
    installedVersions: platform.phpVersions(),
    defaultVersion: platform.getGlobalPhpVersion(),
    extensions,
  };
}

async function togglePhpExtension({ version, extension, enabled, user }) {
  const v = version || platform.getGlobalPhpVersion();
  const ext = String(extension || "").trim().toLowerCase();
  if (!ext) throw validate.badRequest("Extension name is required");

  if (shell.IS_LINUX) {
    if (platform.IS_AAPANEL) {
      const ini = `/www/server/php/${v.replace(".", "")}/etc/php.ini`;
      if (fs.existsSync(ini)) {
        let content = fs.readFileSync(ini, "utf8");
        if (enabled) {
          content = content.replace(new RegExp(`;\\s*extension\\s*=\\s*${ext}`, "i"), `extension = ${ext}`);
        } else {
          content = content.replace(new RegExp(`^\\s*extension\\s*=\\s*${ext}`, "im"), `;extension = ${ext}`);
        }
        fs.writeFileSync(ini, content);
      }
    } else {
      const cmd = enabled ? `phpenmod -v ${v} ${ext}` : `phpdismod -v ${v} ${ext}`;
      await shell.run(cmd, { user }).catch(() => {});
    }
    await shell.serviceAction(platform.phpFpmService(v), "reload", { user }).catch(() => {});
  }
  return { success: true, version: v, extension: ext, enabled: !!enabled };
}

async function resetPhpExtensions({ version, user }) {
  const v = version || platform.getGlobalPhpVersion();
  const defaultExts = ["bcmath", "calendar", "ctype", "curl", "dom", "exif", "fileinfo", "ftp", "gd", "iconv", "intl", "json", "mbstring", "mysqli", "mysqlnd", "opcache", "openssl", "pdo", "pdo_mysql", "phar", "posix", "readline", "shmop", "simplexml", "sockets", "sodium", "sysvmsg", "sysvsem", "sysvshm", "tokenizer", "xml", "xmlreader", "xmlwriter", "xsl", "zip"];

  if (shell.IS_LINUX && !platform.IS_AAPANEL) {
    for (const ext of defaultExts) {
      await shell.run(`phpenmod -v ${v} ${ext}`, { user }).catch(() => {});
    }
    await shell.serviceAction(platform.phpFpmService(v), "reload", { user }).catch(() => {});
  }
  return { success: true, version: v, message: "Reset PHP extensions to default set" };
}

async function installPhpVersion({ version, user }) {
  const v = String(version || "").trim();
  if (!/^\d+\.\d+$/.test(v)) throw validate.badRequest("Invalid PHP version format: " + v);

  if (shell.IS_LINUX) {
    if (platform.IS_AAPANEL) {
      await shell.run(`/bin/bash /www/server/panel/install/public.sh install_php ${v.replace(".", "")}`, { timeout: 600000, user }).catch(() => {});
    } else {
      await shell.run(`apt-get update && apt-get install -y php${v}-fpm php${v}-cli php${v}-mysql php${v}-curl php${v}-mbstring php${v}-xml php${v}-zip php${v}-gd`, { timeout: 600000, user });
    }
  }
  return { success: true, version: v };
}

// ---------------------------------------------------------------- Applications Manager

function getAppsStore() {
  return store.read("apps_manager", []);
}

function updateAppsStore(updater) {
  return store.update("apps_manager", [], updater);
}

async function listApplications(user) {
  let appsList = getAppsStore();
  if (user && user.role !== "admin" && user.username !== "root") {
    appsList = appsList.filter((a) => {
      if (a.domain) {
        return websites.isUserAllowedSite(a.domain, null, user);
      }
      return false;
    });
  }
  const nodeInstalled = shell.hasCommand("node");
  const pythonInstalled = shell.hasCommand("python3");
  const rubyInstalled = shell.hasCommand("ruby");

  const nodeVer = nodeInstalled ? await shell.tryGet("node -v", "v20.0.0") : null;
  const pythonVer = pythonInstalled ? await shell.tryGet("python3 -V", "Python 3.10") : null;
  const rubyVer = rubyInstalled ? await shell.tryGet("ruby -v", "") : null;

  return {
    applications: appsList,
    environments: {
      node: { installed: nodeInstalled, version: nodeVer ? nodeVer.trim() : null },
      python: { installed: pythonInstalled, version: pythonVer ? pythonVer.trim() : null },
      ruby: { installed: rubyInstalled, version: rubyVer ? rubyVer.trim() : null },
    },
  };
}

async function createApplication({ name, type = "Node.js", domain, path: appPath = "/", startupFile = "server.js", port = 3000, envMode = "Production", user }) {
  if (!name) throw validate.badRequest("Application name is required.");
  const app = {
    id: "app_" + Date.now().toString(36) + "_" + Math.random().toString(36).slice(2, 6),
    name: String(name).trim(),
    type: String(type).trim(),
    domain: String(domain || "").trim(),
    path: String(appPath).trim(),
    startupFile: String(startupFile).trim(),
    port: Number(port) || 3000,
    envMode: envMode === "Development" ? "Development" : "Production",
    status: "running",
    createdAt: new Date().toISOString().slice(0, 10),
  };

  updateAppsStore((list) => {
    return (list || []).concat(app);
  });

  return { success: true, application: app };
}

async function deleteApplication({ id, user }) {
  updateAppsStore((list) => {
    return (list || []).filter((a) => a.id !== id);
  });
  return { success: true, id };
}

async function toggleApplication({ id, action = "restart", user }) {
  let updated = null;
  updateAppsStore((list) => {
    return (list || []).map((a) => {
      if (a.id === id) {
        a.status = action === "stop" ? "stopped" : "running";
        updated = a;
      }
      return a;
    });
  });
  return { success: true, application: updated };
}

async function installEnvironment({ type = "node", user }) {
  if (!shell.IS_LINUX) return { success: true, simulated: true };
  if (type === "node") {
    await shell.run("curl -fsSL https://deb.nodesource.com/setup_20.x | bash - && apt-get install -y nodejs", { timeout: 300000, user });
  } else if (type === "python") {
    await shell.run("apt-get update && apt-get install -y python3 python3-pip python3-venv", { timeout: 300000, user });
  } else if (type === "ruby") {
    await shell.run("apt-get update && apt-get install -y ruby-full", { timeout: 300000, user });
  }
  return { success: true, type };
}

// ---------------------------------------------------------------- Optimize Website (Gzip)

async function getGzipConfig() {
  const conf = readNginxConf();
  const gzipOn = /^\s*gzip\s+on\s*;/m.test(conf);
  const typesMatch = conf.match(/^\s*gzip_types\s+([^;]+);/m);
  const types = typesMatch ? typesMatch[1].trim().split(/\s+/) : [
    "text/plain", "text/css", "application/json", "application/javascript",
    "text/xml", "application/xml", "application/xml+rss", "text/javascript", "image/svg+xml"
  ];

  let mode = "disabled";
  if (gzipOn) {
    mode = typesMatch ? "types" : "all";
  }

  const nginxV = await shell.tryGet("nginx -V 2>&1", "");
  return {
    mode,
    gzipEnabled: gzipOn,
    types,
    brotliAvailable: /brotli/.test(nginxV),
    brotliEnabled: /^\s*brotli\s+on\s*;/m.test(conf),
  };
}

async function saveGzipConfig({ mode = "all", types = [], user }) {
  let conf = readNginxConf();
  if (mode === "disabled") {
    conf = conf.replace(/^\s*gzip\s+(on|off)\s*;/m, "gzip off;");
  } else if (mode === "all") {
    conf = conf.replace(/^\s*gzip\s+(on|off)\s*;/m, "gzip on;");
    const standardTypes = "text/plain text/css application/json application/javascript text/xml application/xml application/xml+rss text/javascript image/svg+xml";
    if (/^\s*gzip_types\s+[^;]+;/m.test(conf)) {
      conf = conf.replace(/^\s*gzip_types\s+[^;]+;/m, `gzip_types ${standardTypes};`);
    } else {
      conf = conf.replace(/^(\s*gzip\s+on\s*;)/m, `$1\n    gzip_types ${standardTypes};`);
    }
  } else if (mode === "types") {
    conf = conf.replace(/^\s*gzip\s+(on|off)\s*;/m, "gzip on;");
    const customTypes = (types && types.length ? types.join(" ") : "text/plain text/css application/javascript");
    if (/^\s*gzip_types\s+[^;]+;/m.test(conf)) {
      conf = conf.replace(/^\s*gzip_types\s+[^;]+;/m, `gzip_types ${customTypes};`);
    } else {
      conf = conf.replace(/^(\s*gzip\s+on\s*;)/m, `$1\n    gzip_types ${customTypes};`);
    }
  }

  fs.writeFileSync(NGINX_CONF, conf, "utf8");
  try {
    await platform.reloadNginx({ user });
  } catch (e) {
    throw new Error("Failed to reload Nginx with new compression settings: " + e.message);
  }
  return { success: true, mode };
}

// ---------------------------------------------------------------- WordPress Toolkit Lite

async function listWordPressSites(params = {}) {
  const user = params?.user || (params?.username || params?.role ? params : null);
  const filterDomain = (params?.domain || "").toLowerCase().trim();

  const allSites = await websites.listWebsites(user);
  const wpInstances = [];

  for (const site of allSites) {
    if (filterDomain && site.domain.toLowerCase() !== filterDomain) continue;

    // Strict ownership verification for non-admin accounts
    if (user && user.role !== "admin" && user.username !== "root") {
      if (!websites.isUserAllowedSite(site.domain, site, user)) continue;
    }

    const docRoot = site.documentRoot || platform.docRoot(site.domain);
    if (!docRoot || !fs.existsSync(docRoot)) continue;

    const checkDirs = [{ dir: docRoot, pathPrefix: "" }];
    try {
      const subEntries = fs.readdirSync(docRoot, { withFileTypes: true });
      for (const ent of subEntries) {
        if (ent.isDirectory() && !ent.name.startsWith(".")) {
          checkDirs.push({ dir: path.join(docRoot, ent.name), pathPrefix: "/" + ent.name });
        }
      }
    } catch (_) {}

    for (const { dir, pathPrefix } of checkDirs) {
      const wpConfigPath = path.join(dir, "wp-config.php");
      if (!fs.existsSync(wpConfigPath)) continue;

      let wpVersion = "Latest";
      const versionFile = path.join(dir, "wp-includes", "version.php");
      if (fs.existsSync(versionFile)) {
        const vMatch = fs.readFileSync(versionFile, "utf8").match(/\$wp_version\s*=\s*['"]([^'"]+)['"]/);
        if (vMatch) wpVersion = vMatch[1];
      }

      let dbName = "Unknown";
      try {
        const confText = fs.readFileSync(wpConfigPath, "utf8");
        const dbMatch = confText.match(/define\(\s*['"]DB_NAME['"]\s*,\s*['"]([^'"]+)['"]\s*\)/);
        if (dbMatch) dbName = dbMatch[1];
      } catch (_) {}

      let pluginsCount = 0;
      const pluginsDir = path.join(dir, "wp-content", "plugins");
      if (fs.existsSync(pluginsDir)) {
        try {
          pluginsCount = fs.readdirSync(pluginsDir).filter(f => !f.startsWith(".")).length;
        } catch (_) {}
      }

      const siteUrl = (site.ssl ? "https://" : "http://") + site.domain + pathPrefix;
      wpInstances.push({
        domain: site.domain,
        subPath: pathPrefix || "/",
        url: siteUrl,
        adminUrl: siteUrl + "/wp-admin/",
        dir,
        version: wpVersion,
        database: dbName,
        php: site.php || "8.2",
        ssl: site.ssl,
        pluginsCount,
      });
    }
  }

  return { success: true, sites: wpInstances };
}

async function installWordPressDirect({ domain, subPath = "", title, adminUser = "admin", adminPass, adminEmail, user }) {
  if (user && user.role !== "admin" && user.username !== "root") {
    if (!websites.isUserAllowedSite(domain, null, user)) {
      throw validate.badRequest("Permission denied: You do not have permission to install WordPress on " + domain);
    }
  }
  const site = await websites.getWebsite(domain);
  if (!site) throw validate.badRequest("Website not found: " + domain);

  const docRoot = site.documentRoot || platform.docRoot(domain);
  const targetDir = subPath && subPath !== "/" ? path.join(docRoot, subPath.replace(/^\//, "")) : docRoot;
  fs.mkdirSync(targetDir, { recursive: true });

  const slug = domain.replace(/[^a-z0-9]/g, "_").slice(0, 16);
  const rand = Math.random().toString(36).slice(2, 6);
  const dbName = "wp_" + slug + "_" + rand;
  const dbUser = "wp_" + slug.slice(0, 12) + "_" + rand;
  const dbPass = adminPass || Math.random().toString(36).slice(2, 14) + "A1!";

  const CACHE = shell.IS_LINUX ? "/var/cache/facezila" : path.resolve(__dirname, "../../data/cache");
  fs.mkdirSync(CACHE, { recursive: true });
  const tarball = path.join(CACHE, "wordpress-latest.tar.gz");
  if (!fs.existsSync(tarball) || Date.now() - fs.statSync(tarball).mtimeMs > 86400000) {
    await shell.run("curl -fsSL --retry 2 -o " + shell.q(tarball) + " https://wordpress.org/latest.tar.gz", { timeout: 300000, user });
  }

  const tmp = path.join(CACHE, "wp-" + rand);
  fs.mkdirSync(tmp, { recursive: true });
  try {
    await shell.run("tar -xzf " + shell.q(tarball) + " -C " + shell.q(tmp), { timeout: 120000, user });
    if (fs.existsSync(path.join(targetDir, "index.html"))) fs.rmSync(path.join(targetDir, "index.html"), { force: true });
    await shell.run("cp -a " + shell.q(path.join(tmp, "wordpress") + "/.") + " " + shell.q(targetDir), { user });
  } finally {
    fs.rmSync(tmp, { recursive: true, force: true });
  }

  const databases = require("./database.service");
  await databases.createDatabase({ name: dbName, dbUser, dbPass, user }).catch((e) => {
    console.warn("Database creation note:", e.message);
  });

  const salt = () => require("crypto").randomBytes(48).toString("base64");
  const sampleConfig = path.join(targetDir, "wp-config-sample.php");
  if (fs.existsSync(sampleConfig)) {
    const config = fs.readFileSync(sampleConfig, "utf8")
      .replace("database_name_here", dbName)
      .replace("username_here", dbUser)
      .replace("password_here", dbPass)
      .replace(/'put your unique phrase here'/g, () => "'" + salt() + "'");
    fs.writeFileSync(path.join(targetDir, "wp-config.php"), config, { mode: 0o640 });
  }

  const WEB_USER = platform.IS_AAPANEL ? "www" : "www-data";
  await shell.run("chown -R " + WEB_USER + ":" + WEB_USER + " " + shell.q(targetDir), { user }).catch(() => {});

  const urlPrefix = subPath && subPath !== "/" ? (subPath.startsWith("/") ? subPath : "/" + subPath) : "";
  const siteUrl = (site.ssl ? "https://" : "http://") + domain + urlPrefix;

  return {
    success: true,
    domain,
    url: siteUrl,
    adminUrl: siteUrl + "/wp-admin/install.php",
    database: dbName,
    dbUser,
    dbPass,
  };
}

module.exports = {
  getStatus,
  toggle,
  purge,
  getPhpIni,
  savePhpIni,
  getPhpExtensions,
  togglePhpExtension,
  resetPhpExtensions,
  getGlobalPhpVersion: platform.getGlobalPhpVersion,
  setGlobalPhpVersion: platform.setGlobalPhpVersion,
  installPhpVersion,
  listApplications,
  createApplication,
  deleteApplication,
  toggleApplication,
  installEnvironment,
  getGzipConfig,
  saveGzipConfig,
  listWordPressSites,
  installWordPressDirect,
};
