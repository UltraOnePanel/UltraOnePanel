const fs = require("fs");
const path = require("path");
const shell = require("./shell.service");
const platform = require("../lib/platform");
const store = require("../lib/store");
const validate = require("../lib/validate");

// aaPanel ships its own pure-ftpd; standard installs use vsftpd with system users.
const PURE = {
  bin: "/www/server/pure-ftpd/bin/pure-pw",
  passwd: "/www/server/pure-ftpd/etc/pureftpd.passwd",
  pdb: "/www/server/pure-ftpd/etc/pureftpd.pdb",
};
const VSFTPD_USERLIST = "/etc/vsftpd.userlist";

function assertEngine() {
  if (platform.ftpEngine() !== "none") return platform.ftpEngine();
  const e = new Error("No FTP server is installed. Run the Facezila installer to set up vsftpd.");
  e.status = 409;
  throw e;
}

/** FTP homes must live inside the web root or /home. */
function cleanDir(dir) {
  const resolved = path.resolve(String(dir || ""));
  const allowed = [platform.paths.wwwRoot, "/home"];
  if (shell.IS_LINUX && !allowed.some((a) => resolved === a || resolved.startsWith(a + "/"))) {
    throw validate.badRequest("FTP directory must be inside " + allowed.join(" or "));
  }
  return resolved;
}

function pureArgs() {
  return " -f " + shell.q(PURE.passwd) + " -F " + shell.q(PURE.pdb) + " -m";
}

async function listAccounts(user) {
  const meta = store.read("ftp", {});
  let list = [];
  if (!shell.IS_LINUX) {
    list = Object.entries(meta).map(([username, m]) => ({ username, ...m, engine: "vsftpd" }));
  } else {
    const engine = platform.ftpEngine();
    if (engine === "pure-ftpd") {
      const out = await shell.tryGet(PURE.bin + " list -f " + shell.q(PURE.passwd));
      list = out.split("\n").filter(Boolean).map((line) => {
        const [username, dir] = line.trim().split(/\s+/);
        return { username, directory: (dir || "").replace(/\/\.\/$/, "").replace(/\/\.$/, ""), engine, managed: !!meta[username], created: meta[username] && meta[username].created };
      });
    } else {
      list = Object.entries(meta).map(([username, m]) => ({ username, directory: m.directory, engine, managed: true, created: m.created }));
    }
  }
  if (user && user.role !== "admin" && user.username !== "root") {
    const un = (user.username || "").toLowerCase().trim();
    const uDomain = (user.domain || "").toLowerCase().trim();
    list = list.filter((a) => {
      const au = (a.username || "").toLowerCase().trim();
      return au === un || au.startsWith(un + "_") || (uDomain && a.directory && a.directory.toLowerCase().includes(uDomain));
    });
  }
  return list;
}

async function createAccount({ username, password, directory, user }) {
  const engine = assertEngine();
  const name = validate.username(username);
  const pass = validate.password(password, 8);
  const dir = cleanDir(directory);
  const meta = store.read("ftp", {});
  if (meta[name]) throw validate.badRequest("FTP account already exists: " + name);

  if (shell.IS_LINUX) {
    fs.mkdirSync(dir, { recursive: true });
    if (engine === "pure-ftpd") {
      await shell.run(PURE.bin + " useradd " + shell.q(name) + " -u www -g www -d " + shell.q(dir) + pureArgs(),
        { input: pass + "\n" + pass + "\n", user });
    } else {
      const exists = await shell.tryGet("id -u " + shell.q(name), "");
      if (exists) throw validate.badRequest("A system user named " + name + " already exists.");
      await shell.run("useradd -d " + shell.q(dir) + " -M -s /usr/sbin/nologin -g www-data " + shell.q(name), { user });
      await shell.run("chpasswd", { input: name + ":" + pass + "\n", user });
      await shell.run("chown " + shell.q(name) + ":www-data " + shell.q(dir), { user });
      const list = fs.existsSync(VSFTPD_USERLIST) ? fs.readFileSync(VSFTPD_USERLIST, "utf8").split("\n").filter(Boolean) : [];
      if (!list.includes(name)) fs.writeFileSync(VSFTPD_USERLIST, list.concat(name).join("\n") + "\n");
    }
  }
  store.update("ftp", {}, (m) => { m[name] = { directory: dir, created: new Date().toISOString() }; });
  return { username: name, directory: dir, engine };
}

async function deleteAccount({ username, user }) {
  const engine = assertEngine();
  const name = validate.username(username);
  const meta = store.read("ftp", {});
  if (shell.IS_LINUX) {
    if (engine === "pure-ftpd") {
      await shell.run(PURE.bin + " userdel " + shell.q(name) + pureArgs(), { user });
    } else {
      if (!meta[name]) throw validate.badRequest("Only FTP accounts created by Facezila can be deleted here.");
      await shell.run("userdel " + shell.q(name), { user });
      if (fs.existsSync(VSFTPD_USERLIST)) {
        const list = fs.readFileSync(VSFTPD_USERLIST, "utf8").split("\n").filter((l) => l && l !== name);
        fs.writeFileSync(VSFTPD_USERLIST, list.join("\n") + "\n");
      }
    }
  }
  store.update("ftp", {}, (m) => { delete m[name]; });
  return { username: name, status: "deleted" };
}

async function changePassword({ username, password, user }) {
  const engine = assertEngine();
  const name = validate.username(username);
  const pass = validate.password(password, 8);
  if (shell.IS_LINUX) {
    if (engine === "pure-ftpd") {
      await shell.run(PURE.bin + " passwd " + shell.q(name) + pureArgs(), { input: pass + "\n" + pass + "\n", user });
    } else {
      if (!store.read("ftp", {})[name]) throw validate.badRequest("Only FTP accounts created by Facezila can be changed here.");
      await shell.run("chpasswd", { input: name + ":" + pass + "\n", user });
    }
  }
  return { username: name, status: "password changed" };
}

module.exports = { listAccounts, createAccount, deleteAccount, changePassword };
