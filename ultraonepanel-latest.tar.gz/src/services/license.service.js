const fs = require("fs");
const path = require("path");
const shell = require("./shell.service");
const { LicenseModel } = require("../lib/db");

const LICENSE_FILE = shell.IS_LINUX
  ? "/etc/facezila/license.json"
  : path.join(__dirname, "../../.license.json");

const LICENSE_TYPES = {
  "Trial": { maxAccounts: 5, defaultDays: 14, label: "Trial Edition (14-Day Free Trial)" },
  "Starter-5": { maxAccounts: 5, defaultDays: 365, label: "Starter Edition (5 accounts)" },
  "VPS-25": { maxAccounts: 25, defaultDays: 365, label: "VPS Edition (25 accounts)" },
  "Dedicated-100": { maxAccounts: 100, defaultDays: 365, label: "Dedicated Edition (100 accounts)" },
  "Unlimited": { maxAccounts: 0, defaultDays: 365, label: "Enterprise Unlimited" },
};

function generateKey(type = "VPS-25", days = 365) {
  const prefix = "UO";
  const typeCode =
    type === "Unlimited"
      ? "UNL"
      : type === "Dedicated-100"
      ? "DED"
      : type === "Starter-5"
      ? "STR"
      : type === "Trial"
      ? "TRL"
      : "VPS";
  const durationCode = String(days).toLowerCase().includes("life") ? "LIFE" : String(days || 365);
  const r1 = Math.random().toString(36).substring(2, 6).toUpperCase();
  const r2 = Math.random().toString(36).substring(2, 6).toUpperCase();
  return `${prefix}-${typeCode}-${durationCode}-${r1}-${r2}`;
}

function getDefaultLocalLicense() {
  const now = new Date();
  const expires = new Date(now.getTime() + 14 * 24 * 60 * 60 * 1000);
  const r1 = Math.random().toString(36).substring(2, 6).toUpperCase();
  const r2 = Math.random().toString(36).substring(2, 6).toUpperCase();
  return {
    key: `UO-TRL-14-${r1}-${r2}`,
    type: "Trial",
    package: "Trial",
    plan: "14-Day Free Trial",
    maxAccounts: 5,
    status: "active",
    customer: "Trial Administrator",
    serverIp: process.env.SERVER_IP || "127.0.0.1",
    activatedAt: now.toISOString(),
    expiry: expires.toISOString(),
    expiresAt: expires.toISOString(),
    trialDurationDays: 14,
    isTrial: true,
  };
}

function getLocalLicense() {
  try {
    if (fs.existsSync(LICENSE_FILE)) {
      const data = JSON.parse(fs.readFileSync(LICENSE_FILE, "utf8"));
      // Ensure existing trial has 14-day limit from activation
      if (data && data.isTrial) {
        if (!data.activatedAt) {
          data.activatedAt = new Date().toISOString();
        }
        if (!data.trialDurationDays) {
          data.trialDurationDays = 14;
        }
        if (!data.plan || data.plan.includes("30")) {
          data.plan = "14-Day Free Trial";
        }
      }
      return data;
    }
  } catch (_) {}
  const def = getDefaultLocalLicense();
  saveLocalLicense(def);
  return def;
}

function saveLocalLicense(data) {
  try {
    const dir = path.dirname(LICENSE_FILE);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(LICENSE_FILE, JSON.stringify(data, null, 2), "utf8");
  } catch (e) {
    console.error("Failed to save license:", e.message);
  }
}

// -------------------------------------------------------------
// CENTRAL LICENSE SERVER & VERIFICATION LOGIC
// -------------------------------------------------------------
const LicenseService = {
  LICENSE_TYPES,

  async verifyLicense({ key, ip }) {
    if (!key) {
      return { valid: false, message: "License key is required." };
    }
    const cleanKey = String(key).trim().toUpperCase();

    // 1. Look up in central MongoDB registry if available
    try {
      const lic = await LicenseModel.findByKey(cleanKey);
      if (lic) {
        if (lic.status !== "active") {
          return { valid: false, message: `License is ${lic.status}.` };
        }
        const now = new Date();
        const expiryDate = new Date(lic.expiry || lic.expiresAt);
        if (expiryDate < now) {
          return {
            valid: false,
            message: `License expired on ${expiryDate.toISOString().slice(0, 10)}. Please renew.`,
            expired: true,
            expiry: expiryDate.toISOString(),
          };
        }
        if (lic.ip && lic.ip !== "any" && ip && lic.ip !== ip) {
          return {
            valid: false,
            message: `IP mismatch: bound to ${lic.ip}, request originated from ${ip}.`,
          };
        }

        return {
          valid: true,
          key: lic.key,
          ip: lic.ip,
          type: lic.type || "VPS-25",
          package: lic.package || lic.type || "VPS-25",
          maxAccounts: lic.maxAccounts,
          expiry: lic.expiry || lic.expiresAt,
          durationDays: lic.durationDays || 365,
          customer: lic.customer || "Commercial Licensee",
          status: "active",
        };
      }
    } catch (_) {}

    // 2. Format & Checksum Verification for Commercial Offline / Standalone Keys
    // Accepts UO-*, FZ-*, YP-* format keys: [PREFIX]-[PACKAGE]-[DURATION]-[BLOCK1]-[BLOCK2]
    const keyParts = cleanKey.split("-");
    if (keyParts.length >= 3) {
      const prefix = keyParts[0];
      if (["UO", "FZ", "YP"].includes(prefix)) {
        let type = "VPS-25";
        const part1 = keyParts[1];
        if (part1 === "UNL" || cleanKey.includes("UNL")) type = "Unlimited";
        else if (part1 === "DED" || cleanKey.includes("DED")) type = "Dedicated-100";
        else if (part1 === "STR" || cleanKey.includes("STR")) type = "Starter-5";
        else if (part1 === "TRL" || cleanKey.includes("TRL")) type = "Trial";
        else type = "VPS-25";

        let durationDays = 365;
        let isLifetime = false;
        // Look for duration token in key
        for (const part of keyParts) {
          if (part === "LIFE" || part === "LIFETIME") {
            isLifetime = true;
            durationDays = 3650; // 10 years
            break;
          }
          const num = parseInt(part, 10);
          if ([14, 30, 60, 90, 180, 365, 730].includes(num)) {
            durationDays = num;
            break;
          }
        }

        const cfg = LICENSE_TYPES[type] || LICENSE_TYPES["VPS-25"];
        const exp = new Date(Date.now() + durationDays * 86400000);

        return {
          valid: true,
          key: cleanKey,
          type,
          package: type,
          plan: cfg.label,
          maxAccounts: cfg.maxAccounts,
          durationDays,
          isLifetime,
          expiry: exp.toISOString(),
          customer: "Verified Commercial Licensee",
          status: "active",
        };
      }
    }

    return { valid: false, message: "Invalid license key format." };
  },

  async issueLicense({ customer, email, type = "VPS-25", ip = "any", days = 365 }) {
    const config = LICENSE_TYPES[type] || LICENSE_TYPES["VPS-25"];
    const durationDays = Number(days || config.defaultDays || 365);
    const key = generateKey(type, durationDays);

    const expiry = new Date();
    expiry.setDate(expiry.getDate() + durationDays);

    const record = {
      key,
      ip: ip || "any",
      type,
      package: type,
      durationDays,
      maxAccounts: config.maxAccounts,
      customer: customer || "Acme Client",
      email: email || "",
      expiry: expiry.toISOString(),
      expiresAt: expiry.toISOString(),
      status: "active",
      createdAt: new Date().toISOString(),
      isTrial: type === "Trial",
    };

    await LicenseModel.create(record);
    return record;
  },

  async listAllLicenses() {
    return await LicenseModel.list();
  },

  async toggleLicense(key) {
    const lic = await LicenseModel.findByKey(key);
    if (!lic) throw new Error("License not found");
    const nextStatus = lic.status === "active" ? "suspended" : "active";
    await LicenseModel.update(key, { status: nextStatus });
    return { key, status: nextStatus };
  },

  async deleteLicense(key) {
    await LicenseModel.delete(key);
    return { key, status: "deleted" };
  },

  // -------------------------------------------------------------
  // LOCAL CLIENT PANEL LICENSE STATUS & ACTIVATION
  // -------------------------------------------------------------
  async getLocalStatus() {
    const lic = getLocalLicense();
    const now = new Date();
    const expires = new Date(lic.expiry || lic.expiresAt);
    const diffMs = expires.getTime() - now.getTime();
    const daysLeft = Math.ceil(diffMs / (1000 * 60 * 60 * 24));
    const hoursLeft = Math.max(0, Math.ceil(diffMs / (1000 * 60 * 60)));
    const isExpired = diffMs <= 0 || lic.status === "expired" || lic.status === "suspended";
    const isValid = !isExpired && lic.status !== "suspended";

    const status = isExpired ? (lic.status === "suspended" ? "suspended" : "expired") : (lic.status || "active");

    const result = {
      ...lic,
      status,
      daysLeft: Math.max(0, daysLeft),
      hoursLeft,
      isExpired,
      isValid,
      expiry: expires.toISOString(),
      expiresAt: expires.toISOString(),
      expiryFormatted: expires.toLocaleDateString("en-US", { year: "numeric", month: "short", day: "numeric" }),
    };

    return {
      ...result,
      license: result,
    };
  },

  async activateLocalLicense({ key, serverIp }) {
    if (!key || typeof key !== "string" || key.trim().length < 6) {
      throw new Error("Invalid license key format.");
    }
    const cleanKey = key.trim().toUpperCase();

    // 1. Verify key (checks local registry, key format, package, duration)
    let verifyResult = await LicenseService.verifyLicense({ key: cleanKey, ip: serverIp });

    // 2. If not verified locally, and remote LICENSE_SERVER_URL is set, call remote
    if (!verifyResult.valid && process.env.LICENSE_SERVER_URL) {
      try {
        const res = await fetch(`${process.env.LICENSE_SERVER_URL}/api/license/verify`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ key: cleanKey, ip: serverIp })
        });
        const data = await res.json();
        if (res.ok && data.valid) {
          verifyResult = data;
        }
      } catch (_) {}
    }

    if (!verifyResult.valid) {
      throw new Error(verifyResult.message || "Invalid or expired license key.");
    }

    const type = verifyResult.type || "VPS-25";
    const cfg = LICENSE_TYPES[type] || LICENSE_TYPES["VPS-25"];

    const updated = {
      key: cleanKey,
      type,
      package: type,
      plan: cfg.label || "Commercial License",
      maxAccounts: verifyResult.maxAccounts ?? cfg.maxAccounts,
      status: "active",
      customer: verifyResult.customer || "Commercial Licensee",
      serverIp: serverIp || process.env.SERVER_IP || "127.0.0.1",
      activatedAt: new Date().toISOString(),
      expiry: verifyResult.expiry,
      expiresAt: verifyResult.expiry,
      durationDays: verifyResult.durationDays || 365,
      isLifetime: !!verifyResult.isLifetime,
      isTrial: false,
    };

    saveLocalLicense(updated);
    return updated;
  },

  /**
   * Boot-time license check. Called when backend starts up.
   */
  async checkBootLicense() {
    const status = await LicenseService.getLocalStatus();
    if (!status.isValid) {
      if (status.isExpired) {
        console.warn(`⚠️ [License] Trial / Commercial License EXPIRED (${status.plan || status.type}). WHM & cPanel running in restricted mode.`);
      } else {
        console.warn("⚠️ [License] Warning: Panel running with INVALID license.");
      }
    } else {
      const mode = status.isTrial ? "Trial" : "Commercial";
      console.log(`✅ [License] Active (${mode}): ${status.plan || status.type} - ${status.daysLeft} days remaining (Expires: ${status.expiry ? status.expiry.slice(0, 10) : "N/A"})`);
    }
    return status.isValid;
  }
};

module.exports = LicenseService;
