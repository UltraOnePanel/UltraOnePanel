const fs = require("fs");
const path = require("path");
const https = require("https");
const axios = require("axios");
const shell = require("./shell.service");

const httpsAgent = new https.Agent({ rejectUnauthorized: false });

const LICENSE_FILE = shell.IS_LINUX
  ? "/etc/facezila/license.json"
  : path.join(__dirname, "../../.license.json");

const LICENSE_SERVER_URL = process.env.LICENSE_SERVER_URL || "https://185.70.184.125:2087";

const isLicenseServer =
  process.env.IS_LICENSE_SERVER === "true" ||
  process.env.SERVER_IP === "185.70.184.125";

const LICENSE_TYPES = {
  "Trial": { maxAccounts: 5, maxDomains: 5, defaultDays: 14, label: "Trial Edition (14-Day Free Trial)" },
  "Solo": { maxAccounts: 1, maxDomains: 1, defaultDays: 365, label: "Solo Edition (1 Account / 1 Domain)" },
  "Admin": { maxAccounts: 5, maxDomains: 5, defaultDays: 365, label: "Admin Edition (Up to 5 Accounts)" },
  "Pro": { maxAccounts: 30, maxDomains: 30, defaultDays: 365, label: "Pro Edition (Up to 30 Accounts)" },
  "Premier": { maxAccounts: 100, maxDomains: 100, defaultDays: 365, label: "Premier Edition (Up to 100 Accounts)" },
  "Enterprise": { maxAccounts: 0, maxDomains: 0, defaultDays: 365, label: "Enterprise Unlimited" },
};

function getDefaultLocalLicense() {
  const now = new Date();
  if (isLicenseServer) {
    const expires = new Date(now.getTime() + 3650 * 86400000);
    return {
      key: "UO-MASTER-AUTHORITY-0001",
      type: "Enterprise",
      package: "Enterprise",
      product: "whm_cpanel",
      productLabel: "cPanel & WHM (Full Suite)",
      plan: "UltraOnePanel Master Licensing Authority",
      maxAccounts: 0,
      maxDomains: 0,
      allowWhm: true,
      allowCpanel: true,
      status: "active",
      customer: "Central Licensing Administrator",
      serverIp: process.env.SERVER_IP || "185.70.184.125",
      activatedAt: now.toISOString(),
      expiry: expires.toISOString(),
      expiresAt: expires.toISOString(),
      isLifetime: true,
      isTrial: false,
      isMaster: true,
      isLicenseServer: true,
    };
  }

  const expires = new Date(now.getTime() + 14 * 24 * 60 * 60 * 1000);
  const r1 = Math.random().toString(36).substring(2, 6).toUpperCase();
  const r2 = Math.random().toString(36).substring(2, 6).toUpperCase();
  return {
    key: `UO-TRL-14-${r1}-${r2}`,
    type: "Trial",
    package: "Trial",
    product: "whm_cpanel",
    productLabel: "cPanel & WHM (Full Suite)",
    plan: "14-Day Free Trial",
    maxAccounts: 5,
    maxDomains: 5,
    allowWhm: true,
    allowCpanel: true,
    status: "active",
    customer: "Trial Administrator",
    serverIp: process.env.SERVER_IP || "127.0.0.1",
    activatedAt: now.toISOString(),
    expiry: expires.toISOString(),
    expiresAt: expires.toISOString(),
    trialDurationDays: 14,
    isTrial: true,
    isLifetime: false,
    isLicenseServer: false,
    licenseServerUrl: LICENSE_SERVER_URL,
  };
}

function getLocalLicense() {
  try {
    if (fs.existsSync(LICENSE_FILE)) {
      const data = JSON.parse(fs.readFileSync(LICENSE_FILE, "utf8"));
      if (data && data.isTrial) {
        if (!data.activatedAt) data.activatedAt = new Date().toISOString();
        if (!data.trialDurationDays) data.trialDurationDays = 14;
        if (!data.plan || data.plan.includes("30")) data.plan = "14-Day Free Trial";
      }
      return data;
    }
  } catch (_) {}
  const def = getDefaultLocalLicense();
  saveLocalLicense(def);
  return def;
}

function saveLocalLicense(data) {
  try {
    const dir = path.dirname(LICENSE_FILE);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(LICENSE_FILE, JSON.stringify(data, null, 2), "utf8");
  } catch (e) {
    console.error("Failed to save license:", e.message);
  }
}

// -------------------------------------------------------------
// CENTRAL LICENSE SERVER & VERIFICATION LOGIC
// -------------------------------------------------------------
const LicenseService = {
  LICENSE_TYPES,
  isLicenseServer,
  LICENSE_SERVER_URL,

  /**
   * Called by client VPS nodes via POST /api/license/verify to authenticate.
   */
  async verifyLicense({ key, ip }) {
    if (!key) {
      return { valid: false, message: "License key is required." };
    }
    const cleanKey = String(key).trim().toUpperCase();

    // 1. Try local license-server daemon running on port 9000 (if this host is master node)
    try {
      const res = await axios.post("http://127.0.0.1:9000/api/verify", {
        key: cleanKey,
        ip,
      }, { timeout: 3500 });
      if (res.data) return res.data;
    } catch (daemonErr) {
      if (daemonErr.response?.data) return daemonErr.response.data;
    }

    // 2. Fallback key format check if master daemon is offline
    const keyParts = cleanKey.split("-");
    if (keyParts.length >= 3 && ["UO", "YP", "FZ"].includes(keyParts[0])) {
      return {
        valid: true,
        key: cleanKey,
        customer: "Commercial Licensee",
        product: "whm_cpanel",
        productLabel: "cPanel & WHM (Full Suite)",
        allowWhm: true,
        allowCpanel: true,
        tier: "Pro-30",
        maxAccounts: 30,
        maxDomains: 30,
        isLifetime: cleanKey.includes("LIFE"),
        expiry: new Date(Date.now() + 365 * 86400000).toISOString(),
        status: "active",
      };
    }

    return { valid: false, message: "Invalid license key format or key not found in central registry." };
  },

  // -------------------------------------------------------------
  // LOCAL CLIENT PANEL LICENSE STATUS & ACTIVATION
  // -------------------------------------------------------------
  async getLocalStatus() {
    const lic = getLocalLicense();
    const now = new Date();
    const expires = new Date(lic.expiry || lic.expiresAt);
    const diffMs = expires.getTime() - now.getTime();
    const daysLeft = Math.ceil(diffMs / (1000 * 60 * 60 * 24));
    const hoursLeft = Math.max(0, Math.ceil(diffMs / (1000 * 60 * 60)));
    const isExpired = !lic.isLifetime && (diffMs <= 0 || lic.status === "expired" || lic.status === "suspended");
    const isValid = (!isExpired || lic.isLifetime) && lic.status !== "suspended";

    const status = isExpired ? (lic.status === "suspended" ? "suspended" : "expired") : (lic.status || "active");

    const result = {
      ...lic,
      status,
      daysLeft: lic.isLifetime ? 9999 : Math.max(0, daysLeft),
      hoursLeft,
      isExpired,
      isValid,
      isLicenseServer,
      licenseServerUrl: LICENSE_SERVER_URL,
      expiry: expires.toISOString(),
      expiresAt: expires.toISOString(),
      expiryFormatted: lic.isLifetime ? "Lifetime (Perpetual)" : expires.toLocaleDateString("en-US", { year: "numeric", month: "short", day: "numeric" }),
    };

    return {
      ...result,
      license: result,
    };
  },

  async activateLocalLicense({ key, serverIp }) {
    if (!key || typeof key !== "string" || key.trim().length < 6) {
      throw new Error("Invalid license key format.");
    }
    const cleanKey = key.trim().toUpperCase();
    const effectiveIp = serverIp || process.env.SERVER_IP || "127.0.0.1";

    let verifyResult = null;

    // 1. If remote master licensing server is configured and this server is not the master server:
    if (LICENSE_SERVER_URL && !isLicenseServer) {
      try {
        const res = await axios.post(`${LICENSE_SERVER_URL}/api/license/verify`, {
          key: cleanKey,
          ip: effectiveIp,
        }, {
          httpsAgent,
          timeout: 7000,
        });

        if (res.data && res.data.valid) {
          verifyResult = res.data;
        } else if (res.data && !res.data.valid) {
          throw new Error(res.data.message || "Central license server rejected this license key.");
        }
      } catch (err) {
        if (err.response?.data?.message) {
          throw new Error(err.response.data.message);
        }
        console.warn("[Licensing] Could not reach central licensing server:", err.message);
      }
    }

    // 2. If running on Master Server or local daemon fallback:
    if (!verifyResult || !verifyResult.valid) {
      verifyResult = await LicenseService.verifyLicense({ key: cleanKey, ip: effectiveIp });
    }

    if (!verifyResult || !verifyResult.valid) {
      throw new Error(verifyResult?.message || "Invalid or expired license key.");
    }

    const product = verifyResult.product || "whm_cpanel";
    const productLabel = verifyResult.productLabel || (product === "cpanel_only" ? "cPanel Only (End-User Hosting)" : product === "whm_only" ? "WHM Only (Reseller/Server Admin)" : "cPanel & WHM (Full Suite)");
    const allowWhm = verifyResult.allowWhm !== undefined ? verifyResult.allowWhm : product !== "cpanel_only";
    const allowCpanel = verifyResult.allowCpanel !== undefined ? verifyResult.allowCpanel : product !== "whm_only";
    const tier = verifyResult.tier || verifyResult.type || "Pro-30";
    const maxAccounts = verifyResult.maxAccounts !== undefined ? verifyResult.maxAccounts : 30;
    const maxDomains = verifyResult.maxDomains !== undefined ? verifyResult.maxDomains : 30;

    const updated = {
      key: cleanKey,
      type: tier,
      package: tier,
      product,
      productLabel,
      plan: `${productLabel} - ${tier} (${maxAccounts === 0 ? "Unlimited Accounts" : maxAccounts + " Accounts"})`,
      allowWhm,
      allowCpanel,
      maxAccounts,
      maxDomains,
      status: "active",
      customer: verifyResult.customer || "Commercial Licensee",
      serverIp: effectiveIp,
      activatedAt: new Date().toISOString(),
      expiry: verifyResult.expiry || verifyResult.expiryDate,
      expiresAt: verifyResult.expiry || verifyResult.expiryDate,
      durationDays: verifyResult.durationDays || 365,
      isLifetime: !!verifyResult.isLifetime,
      isTrial: false,
      licenseServerUrl: LICENSE_SERVER_URL,
    };

    saveLocalLicense(updated);
    return updated;
  },

  /**
   * Client VPS syncs with Central Master Server (185.70.184.125) every 24h
   */
  async syncWithMasterServer() {
    if (isLicenseServer || !LICENSE_SERVER_URL) return;
    const lic = getLocalLicense();
    if (!lic || lic.isTrial) return;

    const effectiveIp = lic.serverIp || process.env.SERVER_IP || "127.0.0.1";
    try {
      const res = await axios.post(`${LICENSE_SERVER_URL}/api/license/verify`, {
        key: lic.key,
        ip: effectiveIp,
      }, {
        httpsAgent,
        timeout: 7000,
      });

      if (res.data && res.data.valid) {
        lic.status = "active";
        lic.expiry = res.data.expiry || lic.expiry;
        lic.expiresAt = lic.expiry;
        lic.maxAccounts = res.data.maxAccounts !== undefined ? res.data.maxAccounts : lic.maxAccounts;
        lic.maxDomains = res.data.maxDomains !== undefined ? res.data.maxDomains : lic.maxDomains;
        lic.allowWhm = res.data.allowWhm !== undefined ? res.data.allowWhm : lic.allowWhm;
        lic.allowCpanel = res.data.allowCpanel !== undefined ? res.data.allowCpanel : lic.allowCpanel;
        saveLocalLicense(lic);
        console.log("✅ [License Sync] Verified active with Central Authority (185.70.184.125).");
      } else if (res.data && !res.data.valid) {
        lic.status = "suspended";
        saveLocalLicense(lic);
        console.warn("⚠️ [License Sync] Central Authority suspended/revoked this license:", res.data.message);
      }
    } catch (err) {
      console.warn("⚠️ [License Sync] Could not reach central server (grace period active):", err.message);
    }
  },

  /**
   * Boot-time license check. Called when backend starts up.
   */
  async checkBootLicense() {
    if (!isLicenseServer) {
      await LicenseService.syncWithMasterServer();
    }
    const status = await LicenseService.getLocalStatus();
    if (!status.isValid) {
      if (status.isExpired) {
        console.warn(`⚠️ [License] Trial / Commercial License EXPIRED (${status.plan || status.type}). WHM & cPanel running in restricted mode.`);
      } else {
        console.warn("⚠️ [License] Warning: Panel running with INVALID license.");
      }
    } else {
      const mode = status.isTrial ? "Trial" : status.isMaster ? "Master" : "Commercial";
      console.log(`✅ [License] Active (${mode}): ${status.plan || status.type} - ${status.daysLeft} days remaining (Expires: ${status.expiry ? status.expiry.slice(0, 10) : "N/A"})`);
    }
    return status.isValid;
  }
};

module.exports = LicenseService;
