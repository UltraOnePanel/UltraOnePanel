const fs=require("fs"),path=require("path"),https=require("https"),axios=require("axios"),shell=require("./shell.service"),platform=require("../lib/platform"),insecureAgent=new https.Agent({rejectUnauthorized:!1}),VERSION_FILE=process.platform==="linux"?"/opt/facezila/version.json":path.resolve(__dirname,"../../version.json"),CURRENT_FALLBACK_VERSION="1.3.0",LICENSE_SERVER_CANDIDATES=[process.env.LICENSE_SERVER_URL,"http://127.0.0.1:9000","https://license.ultraonepanel.com","https://api.ultraonepanel.com","https://ultraonepanel.com:2087"].filter(Boolean),LICENSE_SERVER_URL=LICENSE_SERVER_CANDIDATES[0]||"https://license.ultraonepanel.com";function getCurrentVersion(){try{if(fs.existsSync(VERSION_FILE))return JSON.parse(fs.readFileSync(VERSION_FILE,"utf8")).version||CURRENT_FALLBACK_VERSION}catch{}return CURRENT_FALLBACK_VERSION}function compareVersions(v1,v2){const p1=(v1||"0").replace(/^v/i,"").split(".").map(Number),p2=(v2||"0").replace(/^v/i,"").split(".").map(Number);for(let i=0;i<Math.max(p1.length,p2.length);i++){const n1=p1[i]||0,n2=p2[i]||0;if(n1>n2)return 1;if(n1<n2)return-1}return 0}async function checkForUpdates(){const currentVersion=getCurrentVersion();let latestInfo=null;for(const srvUrl of LICENSE_SERVER_CANDIDATES)try{const res=await axios.get(`${srvUrl}/api/updates/check`,{httpsAgent:insecureAgent,timeout:3500});if(res.data&&res.data.success){latestInfo=res.data;break}}catch{}const latestVersion=latestInfo?.latestVersion||currentVersion,hasUpdate=compareVersions(latestVersion,currentVersion)>0;return{success:!0,currentVersion,latestVersion,hasUpdate,releaseDate:latestInfo?.releaseDate||"2026-11-21",changelog:latestInfo?.changelog||["Multi-PHP Selector from PHP 7.2 to 8.5 with live extension toggles","Per Domain Settings with 1-click 'Use PHP Selector' inheritance","Complete design redesign for Change Password & Preferences","Integrated Password Generator & Real-time Strength Meter","One-click Application & System Auto-Updater","Performance enhancements and FastCGI socket stability fixes"],downloadUrl:latestInfo?.downloadUrl||"https://license.ultraonepanel.com/latest.tar.gz",archiveSize:latestInfo?.archiveSize||"980 KB"}}async function ensurePhpMyAdminInstalled(){if(!shell.IS_LINUX)return!0;const pmaLocations=["/var/www/database-admin/phpmyadmin","/www/server/phpmyadmin/phpmyadmin"];let needsInstall=!0;for(const loc of pmaLocations)if(fs.existsSync(path.join(loc,"index.php"))){needsInstall=!1;break}const primaryDir="/var/www/database-admin/phpmyadmin";if(needsInstall&&(console.log("[Update] phpMyAdmin is missing. Installing phpMyAdmin 5.2.2..."),await shell.run(`mkdir -p ${primaryDir} && curl -k -fsSL https://files.phpmyadmin.net/phpMyAdmin/5.2.2/phpMyAdmin-5.2.2-all-languages.tar.gz -o /tmp/pma.tar.gz || wget --no-check-certificate -qO /tmp/pma.tar.gz https://files.phpmyadmin.net/phpMyAdmin/5.2.2/phpMyAdmin-5.2.2-all-languages.tar.gz && tar -xzf /tmp/pma.tar.gz --strip-components=1 -C ${primaryDir} && rm -f /tmp/pma.tar.gz`).catch(err=>console.warn("[Update] phpMyAdmin download/extract warning:",err.message))),fs.existsSync(primaryDir)){const cfgPath=path.join(primaryDir,"config.inc.php");if(fs.existsSync(cfgPath))await shell.run(`grep -q "SignonSession" ${cfgPath} 2>/dev/null || sed -i "s/\\$cfg\\['Servers'\\]\\[\\$i\\]\\['auth_type'\\] = 'cookie';/if (!empty(\\$_COOKIE['SignonSession'])) {\\n    \\$cfg['Servers'][\\$i]['auth_type'] = 'signon';\\n    \\$cfg['Servers'][\\$i]['SignonSession'] = 'SignonSession';\\n    \\$cfg['Servers'][\\$i]['SignonURL'] = '\\/phpmyadmin\\/index.php';\\n} else {\\n    \\$cfg['Servers'][\\$i]['auth_type'] = 'cookie';\\n}/" ${cfgPath}`).catch(()=>{});else{const defaultCfg=`<?php
ini_set('session.cookie_path', '/phpmyadmin/');
$cfg['blowfish_secret'] = '${require("crypto").randomBytes(16).toString("hex")}';
$cfg['PmaAbsoluteUri'] = '/phpmyadmin/';
$i = 0;
$i++;
if (!empty($_COOKIE['SignonSession'])) {
    $cfg['Servers'][$i]['auth_type'] = 'signon';
    $cfg['Servers'][$i]['SignonSession'] = 'SignonSession';
    $cfg['Servers'][$i]['SignonURL'] = '/phpmyadmin/index.php';
} else {
    $cfg['Servers'][$i]['auth_type'] = 'cookie';
}
$cfg['Servers'][$i]['host'] = '127.0.0.1';
$cfg['Servers'][$i]['compress'] = false;
$cfg['Servers'][$i]['AllowNoPassword'] = false;
$cfg['UploadDir'] = '';
$cfg['SaveDir'] = '';
$cfg['TempDir'] = '/tmp';
`;fs.writeFileSync(cfgPath,defaultCfg,"utf8")}const ssoPath=path.join(primaryDir,"sso.php");fs.writeFileSync(ssoPath,`<?php
@ini_set('display_errors', '0');
error_reporting(0);
define('PMA_SSO_SECRET', 'UltraOnePanel_PMA_Secret_Key_2026_Secure');
$token = isset($_GET['token']) ? trim($_GET['token']) : '';
$db = isset($_GET['db']) ? trim($_GET['db']) : '';
if (empty($token)) { http_response_code(403); die('Access Denied: Missing SSO token'); }

$loginUser = 'root';
$loginPass = '';

$parts = explode('.', $token);
if (count($parts) === 3) {
    list($expStr, $b64Payload, $sig) = $parts;
    if (time() > intval($expStr)) { http_response_code(403); die('Token Expired'); }
    if (!hash_equals(hash_hmac('sha256', $expStr . '.' . $b64Payload, PMA_SSO_SECRET), $sig)) { http_response_code(403); die('Invalid Signature'); }
    $decoded = base64_decode($b64Payload);
    if ($decoded !== false && !empty($decoded)) {
        if (strpos($decoded, ':') !== false) {
            list($pDb, $pUser, $pPass) = array_pad(explode(':', $decoded, 3), 3, '');
            if (!empty($pDb)) $db = $pDb;
            if (!empty($pUser)) $loginUser = $pUser;
            if (!empty($pPass)) $loginPass = $pPass;
        } else {
            $db = $decoded;
        }
    }
} else {
    // Fallback token lookup
    $cleanToken = preg_replace('/[^a-zA-Z0-9_-]/', '', $token);
    $json = @file_get_contents('/tmp/pma_sso_' . $cleanToken . '.json');
    if ($json) {
        $data = @json_decode($json, true);
        if ($data && !empty($data['user'])) {
            $loginUser = $data['user'];
            $loginPass = $data['password'] ?? '';
            @unlink('/tmp/pma_sso_' . $cleanToken . '.json');
        }
    }
}

// If logging in as root and password not in token, look up stored root credentials
if ($loginUser === 'root' && empty($loginPass)) {
    if (file_exists('/www/server/panel/data/default.db')) {
        $out = @shell_exec('sqlite3 /www/server/panel/data/default.db "SELECT mysql_root FROM config LIMIT 1;" 2>/dev/null');
        if ($out) $loginPass = trim($out);
    }
    if (empty($loginPass) && file_exists('/root/.mysql_secret')) {
        $out = @file_get_contents('/root/.mysql_secret');
        if ($out) $loginPass = trim($out);
    }
    if (empty($loginPass) && file_exists('/etc/mysql/debian.cnf')) {
        preg_match('/password\\s*=\\s*(\\S+)/', (string)@file_get_contents('/etc/mysql/debian.cnf'), $m);
        if (!empty($m[1])) $loginPass = $m[1];
    }
}

ini_set('session.use_cookies', 'true');
session_set_cookie_params(['lifetime' => 0, 'path' => '/', 'domain' => '', 'secure' => false, 'httponly' => true, 'samesite' => 'Lax']);
session_name('SignonSession');
@session_start();
$_SESSION['PMA_single_signon_user'] = $loginUser;
$_SESSION['PMA_single_signon_password'] = $loginPass;
$_SESSION['PMA_single_signon_host'] = 'localhost';
$_SESSION['PMA_single_signon_port'] = '';
$_SESSION['PMA_single_signon_cfgupdate'] = [];
$_SESSION['PMA_single_signon_HMAC_secret'] = hash('sha1', uniqid((string)mt_rand(), true));
session_write_close();

$redirect = !empty($db) ? '/phpmyadmin/index.php?route=/database/structure&db=' . urlencode($db) : '/phpmyadmin/index.php';
header('Location: ' . $redirect);
exit;
`,"utf8"),await shell.run(`chmod 644 ${ssoPath} 2>/dev/null || true`).catch(()=>{})}return fs.existsSync(primaryDir)&&(await shell.run("mkdir -p /www/server/phpmyadmin && ln -sfn /var/www/database-admin/phpmyadmin /www/server/phpmyadmin/phpmyadmin 2>/dev/null || true").catch(()=>{}),await shell.run("chown -R www-data:www-data /var/www/database-admin/phpmyadmin 2>/dev/null || chown -R www:www /var/www/database-admin/phpmyadmin 2>/dev/null || true").catch(()=>{})),!0}async function ensureNodeDependencies(){return shell.IS_LINUX&&(fs.existsSync("/opt/facezila/node_modules/basic-ftp")||(console.log("[Update] Installing missing basic-ftp module for cPanel migration..."),await shell.run("cd /opt/facezila && npm install --no-audit --no-fund --omit=dev basic-ftp 2>/dev/null || true").catch(()=>{}))),!0}async function applyUpdate({user="system"}={}){const updateInfo=await checkForUpdates(),targetVersion=updateInfo.latestVersion||"1.3.0";if(!shell.IS_LINUX)return fs.writeFileSync(VERSION_FILE,JSON.stringify({version:targetVersion,updatedAt:new Date().toISOString()},null,2)),{success:!0,currentVersion:targetVersion,status:"updated",message:`System updated to v${targetVersion} (dev-mode simulated).`};const downloadUrl=updateInfo.downloadUrl,tempArchive="/tmp/facezila_latest_update.tar.gz",unpackDir="/tmp/facezila_update_unpack";try{if(fs.existsSync("/opt/license-server/public/latest.tar.gz"))fs.copyFileSync("/opt/license-server/public/latest.tar.gz",tempArchive);else{const primaryUrl=downloadUrl||"https://license.ultraonepanel.com/latest.tar.gz",githubUrl="https://raw.githubusercontent.com/UltraOnePanel/UltraOnePanel/main/ultraonepanel-latest.tar.gz";await shell.run(`curl -fsSL -o "${tempArchive}" "${primaryUrl}" 2>/dev/null || curl -fsSL -o "${tempArchive}" "${githubUrl}" 2>/dev/null || curl -k -fsSL -o "${tempArchive}" "${primaryUrl}" 2>/dev/null || wget -qO "${tempArchive}" "${primaryUrl}" 2>/dev/null || wget -qO "${tempArchive}" "${githubUrl}"`)}if(!fs.existsSync(tempArchive)||fs.statSync(tempArchive).size<1e3)throw new Error("Update archive could not be retrieved from the central repository or GitHub.");return await shell.run(`rm -rf ${unpackDir} && mkdir -p ${unpackDir}`),await shell.run(`tar -xzf ${tempArchive} -C ${unpackDir}`),fs.existsSync(`${unpackDir}/backend/src`)?await shell.run(`cp -r ${unpackDir}/backend/src/* /opt/facezila/src/`):fs.existsSync(`${unpackDir}/src`)&&await shell.run(`cp -r ${unpackDir}/src/* /opt/facezila/src/`),fs.existsSync(`${unpackDir}/frontend/dist`)?(await shell.run("mkdir -p /opt/facezila/dist /opt/facezila/frontend/dist"),await shell.run(`cp -r ${unpackDir}/frontend/dist/* /opt/facezila/dist/`),await shell.run(`cp -r ${unpackDir}/frontend/dist/* /opt/facezila/frontend/dist/`)):fs.existsSync(`${unpackDir}/dist`)&&(await shell.run("mkdir -p /opt/facezila/dist /opt/facezila/frontend/dist"),await shell.run(`cp -r ${unpackDir}/dist/* /opt/facezila/dist/`),await shell.run(`cp -r ${unpackDir}/dist/* /opt/facezila/frontend/dist/`)),fs.existsSync(`${unpackDir}/whm-frontend/dist`)?(await shell.run("mkdir -p /opt/facezila/whm-dist /opt/facezila/whm-frontend/dist"),await shell.run(`cp -r ${unpackDir}/whm-frontend/dist/* /opt/facezila/whm-dist/`),await shell.run(`cp -r ${unpackDir}/whm-frontend/dist/* /opt/facezila/whm-frontend/dist/`)):fs.existsSync(`${unpackDir}/whm-dist`)&&(await shell.run("mkdir -p /opt/facezila/whm-dist /opt/facezila/whm-frontend/dist"),await shell.run(`cp -r ${unpackDir}/whm-dist/* /opt/facezila/whm-dist/`),await shell.run(`cp -r ${unpackDir}/whm-dist/* /opt/facezila/whm-frontend/dist/`)),fs.existsSync(`${unpackDir}/package.json`)&&await shell.run(`cp -f ${unpackDir}/package.json /opt/facezila/package.json 2>/dev/null || true`),fs.existsSync(`${unpackDir}/installer/upanel`)&&await shell.run(`cp -f ${unpackDir}/installer/upanel /usr/local/bin/upanel && chmod +x /usr/local/bin/upanel && ln -sf /usr/local/bin/upanel /usr/local/bin/facezila`),await ensurePhpMyAdminInstalled().catch(err=>console.warn("[Update] ensurePhpMyAdminInstalled notice:",err.message)),await ensureNodeDependencies().catch(err=>console.warn("[Update] ensureNodeDependencies notice:",err.message)),fs.writeFileSync(VERSION_FILE,JSON.stringify({version:targetVersion,updatedAt:new Date().toISOString(),updatedBy:user},null,2)),await shell.run(`rm -rf ${tempArchive} ${unpackDir}`).catch(()=>{}),setTimeout(()=>{shell.run("systemctl restart facezila.service").catch(()=>{})},1500),{success:!0,currentVersion:targetVersion,message:`Successfully upgraded to v${targetVersion}. Facezila services are reloading.`}}catch(err){throw new Error(`Update installation failed: ${err.message}`)}}module.exports={getCurrentVersion,checkForUpdates,applyUpdate,ensurePhpMyAdminInstalled,ensureNodeDependencies};
