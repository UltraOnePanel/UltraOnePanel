const fs = require("fs");
const path = require("path");
const axios = require("axios");
const shell = require("./shell.service");
const platform = require("../lib/platform");

const VERSION_FILE = process.platform === "linux" ? "/opt/facezila/version.json" : path.resolve(__dirname, "../../version.json");
const CURRENT_FALLBACK_VERSION = "1.3.0";

const LICENSE_SERVER_URL = process.env.LICENSE_SERVER_URL || "http://127.0.0.1:9000";

function getCurrentVersion() {
  try {
    if (fs.existsSync(VERSION_FILE)) {
      const data = JSON.parse(fs.readFileSync(VERSION_FILE, "utf8"));
      return data.version || CURRENT_FALLBACK_VERSION;
    }
  } catch (_) {}
  return CURRENT_FALLBACK_VERSION;
}

function compareVersions(v1, v2) {
  const p1 = (v1 || "0").replace(/^v/i, "").split(".").map(Number);
  const p2 = (v2 || "0").replace(/^v/i, "").split(".").map(Number);
  for (let i = 0; i < Math.max(p1.length, p2.length); i++) {
    const n1 = p1[i] || 0;
    const n2 = p2[i] || 0;
    if (n1 > n2) return 1;
    if (n1 < n2) return -1;
  }
  return 0;
}

async function checkForUpdates() {
  const currentVersion = getCurrentVersion();
  let latestInfo = null;

  try {
    const res = await axios.get(`${LICENSE_SERVER_URL}/api/updates/check`, { timeout: 3500 });
    if (res.data && res.data.success) {
      latestInfo = res.data;
    }
  } catch (_) {
    // If license server update endpoint isn't answering, fallback to checking local archive
  }

  const latestVersion = latestInfo?.latestVersion || currentVersion;
  const hasUpdate = compareVersions(latestVersion, currentVersion) > 0;

  return {
    success: true,
    currentVersion,
    latestVersion,
    hasUpdate,
    releaseDate: latestInfo?.releaseDate || "2026-11-21",
    changelog: latestInfo?.changelog || [
      "Multi-PHP Selector from PHP 7.2 to 8.5 with live extension toggles",
      "Per Domain Settings with 1-click 'Use PHP Selector' inheritance",
      "Complete design redesign for Change Password & Preferences",
      "Integrated Password Generator & Real-time Strength Meter",
      "One-click Application & System Auto-Updater",
      "Performance enhancements and FastCGI socket stability fixes"
    ],
    downloadUrl: latestInfo?.downloadUrl || `${LICENSE_SERVER_URL}/latest.tar.gz`,
    archiveSize: latestInfo?.archiveSize || "925 KB"
  };
}

async function applyUpdate({ user = "system" } = {}) {
  const updateInfo = await checkForUpdates();
  const targetVersion = updateInfo.latestVersion || "1.3.0";

  if (!shell.IS_LINUX) {
    // Development environment mock
    fs.writeFileSync(VERSION_FILE, JSON.stringify({ version: targetVersion, updatedAt: new Date().toISOString() }, null, 2));
    return {
      success: true,
      currentVersion: targetVersion,
      status: "updated",
      message: `System updated to v${targetVersion} (dev-mode simulated).`
    };
  }

  const downloadUrl = updateInfo.downloadUrl;
  const tempArchive = "/tmp/facezila_latest_update.tar.gz";
  const unpackDir = "/tmp/facezila_update_unpack";

  try {
    // 1. Download or copy latest package
    if (fs.existsSync("/opt/license-server/public/latest.tar.gz")) {
      fs.copyFileSync("/opt/license-server/public/latest.tar.gz", tempArchive);
    } else {
      const githubUrl = "https://raw.githubusercontent.com/UltraOnePanel/UltraOnePanel/main/ultraonepanel-latest.tar.gz";
      await shell.run(`curl -fsSL -o ${tempArchive} ${downloadUrl} 2>/dev/null || curl -fsSL -o ${tempArchive} ${githubUrl} || wget -qO ${tempArchive} ${githubUrl}`);
    }

    if (!fs.existsSync(tempArchive) || fs.statSync(tempArchive).size < 1000) {
      throw new Error("Update archive could not be retrieved from the central repository or GitHub.");
    }

    // 2. Unpack safely
    await shell.run(`rm -rf ${unpackDir} && mkdir -p ${unpackDir}`);
    await shell.run(`tar -xzf ${tempArchive} -C ${unpackDir}`);

    // 3. Deploy update files (supports both direct and nested archive structures)
    if (fs.existsSync(`${unpackDir}/backend/src`)) {
      await shell.run(`cp -r ${unpackDir}/backend/src/* /opt/facezila/src/`);
    } else if (fs.existsSync(`${unpackDir}/src`)) {
      await shell.run(`cp -r ${unpackDir}/src/* /opt/facezila/src/`);
    }

    if (fs.existsSync(`${unpackDir}/frontend/dist`)) {
      await shell.run(`mkdir -p /opt/facezila/dist /opt/facezila/frontend/dist`);
      await shell.run(`cp -r ${unpackDir}/frontend/dist/* /opt/facezila/dist/`);
      await shell.run(`cp -r ${unpackDir}/frontend/dist/* /opt/facezila/frontend/dist/`);
    } else if (fs.existsSync(`${unpackDir}/dist`)) {
      await shell.run(`mkdir -p /opt/facezila/dist /opt/facezila/frontend/dist`);
      await shell.run(`cp -r ${unpackDir}/dist/* /opt/facezila/dist/`);
      await shell.run(`cp -r ${unpackDir}/dist/* /opt/facezila/frontend/dist/`);
    }

    if (fs.existsSync(`${unpackDir}/whm-frontend/dist`)) {
      await shell.run(`mkdir -p /opt/facezila/whm-dist /opt/facezila/whm-frontend/dist`);
      await shell.run(`cp -r ${unpackDir}/whm-frontend/dist/* /opt/facezila/whm-dist/`);
      await shell.run(`cp -r ${unpackDir}/whm-frontend/dist/* /opt/facezila/whm-frontend/dist/`);
    } else if (fs.existsSync(`${unpackDir}/whm-dist`)) {
      await shell.run(`mkdir -p /opt/facezila/whm-dist /opt/facezila/whm-frontend/dist`);
      await shell.run(`cp -r ${unpackDir}/whm-dist/* /opt/facezila/whm-dist/`);
      await shell.run(`cp -r ${unpackDir}/whm-dist/* /opt/facezila/whm-frontend/dist/`);
    }

    if (fs.existsSync(`${unpackDir}/package.json`)) {
      await shell.run(`cp -f ${unpackDir}/package.json /opt/facezila/package.json 2>/dev/null || true`);
    }

    if (fs.existsSync(`${unpackDir}/installer/upanel`)) {
      await shell.run(`cp -f ${unpackDir}/installer/upanel /usr/local/bin/upanel && chmod +x /usr/local/bin/upanel && ln -sf /usr/local/bin/upanel /usr/local/bin/facezila`);
    }

    // 4. Update version file
    fs.writeFileSync(VERSION_FILE, JSON.stringify({
      version: targetVersion,
      updatedAt: new Date().toISOString(),
      updatedBy: user
    }, null, 2));

    // 5. Clean up temporary files
    await shell.run(`rm -rf ${tempArchive} ${unpackDir}`).catch(() => {});

    // 6. Schedule background restart of service so HTTP response completes cleanly first
    setTimeout(() => {
      shell.run("systemctl restart facezila.service").catch(() => {});
    }, 1500);

    return {
      success: true,
      currentVersion: targetVersion,
      message: `Successfully upgraded to v${targetVersion}. Facezila services are reloading.`
    };
  } catch (err) {
    throw new Error(`Update installation failed: ${err.message}`);
  }
}

module.exports = {
  getCurrentVersion,
  checkForUpdates,
  applyUpdate
};
