const fs = require("fs");
const os = require("os");
const shell = require("./shell.service");
const platform = require("../lib/platform");

function formatUptime(s) {
  const d = Math.floor(s / 86400);
  const h = Math.floor((s % 86400) / 3600);
  const m = Math.floor((s % 3600) / 60);
  if (d > 0) return d + "d " + h + "h " + m + "m";
  if (h > 0) return h + "h " + m + "m";
  return m + "m";
}

// ---------------------------------------------------------------- samplers

function readCpuTimes() {
  if (fs.existsSync("/proc/stat")) {
    const parts = fs.readFileSync("/proc/stat", "utf8").split("\n")[0].trim().split(/\s+/).slice(1).map(Number);
    const idle = parts[3] + (parts[4] || 0);
    return { idle, total: parts.reduce((a, b) => a + b, 0) };
  }
  const t = os.cpus().reduce((acc, c) => {
    const v = c.times;
    acc.idle += v.idle;
    acc.total += v.user + v.nice + v.sys + v.idle + v.irq;
    return acc;
  }, { idle: 0, total: 0 });
  return t;
}

function readNet() {
  if (!fs.existsSync("/proc/net/dev")) return { rx: 0, tx: 0 };
  let rx = 0, tx = 0;
  for (const line of fs.readFileSync("/proc/net/dev", "utf8").split("\n").slice(2)) {
    const [iface, data] = line.split(":");
    if (!data || /^(lo|docker|veth|br-)/.test(iface.trim())) continue;
    const f = data.trim().split(/\s+/).map(Number);
    rx += f[0];
    tx += f[8];
  }
  return { rx, tx };
}

function readMem() {
  const total = os.totalmem();
  let available = os.freemem();
  try {
    const m = fs.readFileSync("/proc/meminfo", "utf8").match(/MemAvailable:\s+(\d+)/);
    if (m) available = Number(m[1]) * 1024;
  } catch (_) {}
  return { total, used: total - available, free: available };
}

let lastCpu = readCpuTimes();
let lastNet = { ...readNet(), at: Date.now() };
let current = { cpuPercent: 0, rxRate: 0, txRate: 0 };
const history = [];

function sample() {
  const cpu = readCpuTimes();
  const dTotal = cpu.total - lastCpu.total;
  const dIdle = cpu.idle - lastCpu.idle;
  const cpuPercent = dTotal > 0 ? Math.max(0, Math.min(100, Math.round((1 - dIdle / dTotal) * 100))) : 0;
  lastCpu = cpu;

  const net = readNet();
  const secs = Math.max(1, (Date.now() - lastNet.at) / 1000);
  const rxRate = Math.max(0, Math.round((net.rx - lastNet.rx) / secs));
  const txRate = Math.max(0, Math.round((net.tx - lastNet.tx) / secs));
  lastNet = { ...net, at: Date.now() };

  const mem = readMem();
  current = { cpuPercent, rxRate, txRate };
  history.push({ t: Date.now(), cpu: cpuPercent, mem: Math.round((mem.used / mem.total) * 100), rx: rxRate, tx: txRate });
  if (history.length > 360) history.shift();
}

// One sample every 10s keeps an hour of history for the graphs.
setInterval(sample, 10000).unref();
setTimeout(sample, 1000).unref();

// ---------------------------------------------------------------- disk

async function readDisk() {
  if (!shell.IS_LINUX) return { total: "-", used: "-", percent: 0 };
  const out = await shell.tryGet("df -h / | tail -1", "");
  const parts = out.split(/\s+/);
  return { total: parts[1] || "-", used: parts[2] || "-", free: parts[3] || "-", percent: parseInt(parts[4], 10) || 0 };
}

// ---------------------------------------------------------------- public

async function getStats() {
  const load = os.loadavg();
  const mem = readMem();
  const GB = 1024 * 1024 * 1024;
  const net = readNet();
  return {
    uptime: { seconds: os.uptime(), human: formatUptime(os.uptime()) },
    cpu: {
      load1: Number(load[0].toFixed(2)),
      load5: Number(load[1].toFixed(2)),
      load15: Number(load[2].toFixed(2)),
      cpuCount: os.cpus().length || 1,
      model: (os.cpus()[0] || {}).model || "",
      percent: current.cpuPercent,
    },
    loadAvg: load.map((l) => Number(l.toFixed(2))),
    memory: {
      totalGB: Number((mem.total / GB).toFixed(1)),
      usedGB: Number((mem.used / GB).toFixed(1)),
      freeGB: Number((mem.free / GB).toFixed(1)),
      percent: Math.round((mem.used / mem.total) * 100),
    },
    disk: await readDisk(),
    network: { rxRate: current.rxRate, txRate: current.txRate, rxTotal: net.rx, txTotal: net.tx },
    platform: process.platform,
    profile: platform.PROFILE,
    hostname: os.hostname(),
    os: shell.IS_LINUX ? await shell.tryGet("grep PRETTY_NAME /etc/os-release | cut -d'\"' -f2", "Linux") : os.type(),
    nodeVersion: process.version,
  };
}

function getHistory() {
  return history;
}

async function getProcesses(limit = 20, user) {
  if (!shell.IS_LINUX) return [];
  const out = await shell.tryGet("ps -eo pid,user,pcpu,pmem,rss,etime,comm --sort=-pcpu --no-headers | head -n " + Number(limit), "");
  let procs = out.split("\n").filter(Boolean).map((l) => {
    const [pid, user, cpu, mem, rss, elapsed, ...cmd] = l.trim().split(/\s+/);
    return { pid: Number(pid), user, cpu: Number(cpu), mem: Number(mem), rssMB: Math.round(Number(rss) / 1024), elapsed, command: cmd.join(" ") };
  });
  if (user && user.role !== "admin" && user.username !== "root") {
    const un = (user.username || "").toLowerCase().trim();
    procs = procs.filter((p) => p.user && p.user.toLowerCase() === un);
  }
  return procs;
}

async function getServices() {
  const php = platform.phpVersions().map((v) => ({ name: platform.phpFpmService(v), label: "PHP-FPM " + v }));
  const list = [
    { name: "nginx", label: "Nginx" },
    { name: "mysql", label: "MySQL / MariaDB", alt: ["mariadb", "mysqld"] },
    ...php,
    { name: "postfix", label: "Postfix (SMTP)" },
    { name: "dovecot", label: "Dovecot (IMAP/POP3)" },
    { name: "named", label: "Bind9 DNS", alt: ["bind9"] },
    { name: "vsftpd", label: "vsftpd FTP", alt: ["pure-ftpd"] },
    { name: "ufw", label: "UFW firewall" },
    { name: "fail2ban", label: "Fail2ban" },
    { name: "redis-server", label: "Redis", alt: ["redis"] },
    { name: "cron", label: "Cron" },
  ];
  return Promise.all(list.map(async (s) => {
    let state = await shell.serviceStatus(s.name);
    let unit = s.name;
    for (const alt of s.alt || []) {
      if (state === "active") break;
      const st = await shell.serviceStatus(alt);
      if (st !== "not-installed") { state = st; unit = alt; }
    }
    return { name: unit, label: s.label, state };
  }));
}

const RESTARTABLE = /^(nginx|mysql|mariadb|postfix|dovecot|named|bind9|vsftpd|pure-ftpd|fail2ban|redis-server|cron|php\d\.\d-fpm|php-fpm-\d\d)$/;

async function controlService({ name, action, user }) {
  if (!RESTARTABLE.test(name)) throw Object.assign(new Error("This service cannot be controlled from the panel."), { status: 400 });
  if (!["start", "stop", "restart", "reload"].includes(action)) throw Object.assign(new Error("Invalid action."), { status: 400 });
  if (name === "nginx" && action !== "start") await shell.run("nginx -t", { user });
  await shell.serviceAction(name, action, { user, timeout: 60000 });
  return { name, action, state: await shell.serviceStatus(name) };
}

async function mailQueue() {
  if (!shell.IS_LINUX || !shell.hasCommand("postqueue")) return { available: false, messages: [] };
  const out = await shell.tryGet("postqueue -j", "");
  const messages = out.split("\n").filter(Boolean).map((l) => {
    try {
      const j = JSON.parse(l);
      return { id: j.queue_id, queue: j.queue_name, sender: j.sender, size: j.message_size, arrival: new Date(j.arrival_time * 1000).toISOString(),
        recipients: (j.recipients || []).map((r) => r.address + (r.delay_reason ? " (" + r.delay_reason + ")" : "")) };
    } catch (_) { return null; }
  }).filter(Boolean);
  return { available: true, messages };
}

module.exports = { getStats, getHistory, getProcesses, getServices, controlService, mailQueue };
