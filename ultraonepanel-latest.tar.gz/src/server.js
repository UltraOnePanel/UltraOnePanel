const path = require("path");
const fs = require("fs");
const http = require("http");
const https = require("https");
const { spawn } = require("child_process");
const { WebSocketServer } = require("ws");

let nodePty = null;
try {
  nodePty = require("node-pty");
} catch (_) {}

require("dotenv").config({ path: path.resolve(__dirname, "../.env") });
require("dotenv").config(); // fallback to current dir
const express = require("express");
const cors = require("cors");
const platform = require("./lib/platform");
const { connectDB } = require("./lib/db");
const licenseService = require("./services/license.service");
const { checkLicenseStatus, requireValidLicense } = require("./middleware/license.middleware");

const app = express();
const CPANEL_PORT = process.env.CPANEL_PORT || (process.env.NODE_ENV === "production" ? 2083 : (process.env.PORT || 5000));
const WHM_PORT = process.env.WHM_PORT || 2087;

// CORS configuration
const origins = (process.env.CORS_ORIGINS || "").split(",").map((s) => s.trim()).filter(Boolean);
app.use(cors({
  origin: origins.length ? origins : true,
  credentials: true,
}));
app.disable("x-powered-by");

// Database Web Interfaces Reverse Proxy (phpMyAdmin & phpPgAdmin)
function forwardDbProxy(prefix, targetPort, targetPrefix) {
  return (req, res) => {
    if (req.path === prefix) {
      return res.redirect(301, `${prefix}/${req.url.includes("?") ? req.url.slice(req.url.indexOf("?")) : ""}`);
    }

    const subPath = req.url.slice(prefix.length);
    const targetPath = `${targetPrefix}${subPath}`.replace(/\/+/g, "/");

    const options = {
      hostname: "127.0.0.1",
      port: targetPort,
      path: targetPath,
      method: req.method,
      headers: {
        ...req.headers,
        host: `127.0.0.1:${targetPort}`,
        "x-forwarded-host": req.headers.host || "",
        "x-forwarded-proto": req.secure || req.headers["x-forwarded-proto"] === "https" ? "https" : "http",
      },
    };

    const proxyReq = http.request(options, (proxyRes) => {
      const respHeaders = { ...proxyRes.headers };
      delete respHeaders["x-frame-options"];
      delete respHeaders["content-security-policy"];

      if (respHeaders.location) {
        respHeaders.location = respHeaders.location
          .replace(`http://127.0.0.1:${targetPort}${targetPrefix}`, prefix)
          .replace(`http://127.0.0.1:${targetPort}`, "");
      }

      res.writeHead(proxyRes.statusCode, respHeaders);
      proxyRes.pipe(res);
    });

    proxyReq.on("error", (err) => {
      res.status(502).send(`Gateway Error connecting to database admin: ${err.message}`);
    });

    req.pipe(proxyReq);
  };
}

app.all(["/phpmyadmin", "/phpmyadmin/*"], forwardDbProxy("/phpmyadmin", 888, "/phpmyadmin"));
app.all(["/phppgadmin", "/phppgadmin/*"], forwardDbProxy("/phppgadmin", 888, "/phppgadmin"));

app.use(express.json({ limit: "25mb" }));
app.use(express.text({ type: ["application/xml", "text/xml"], limit: "10mb" }));

// Mail Client Autoconfiguration & Autodiscovery endpoints
const autoconfig = require("./services/autoconfig");
const autodiscover = require("./services/autodiscover");
const mobileconfig = require("./services/mobileconfig");

// Autoconfig (Thunderbird / Mozilla / Evolution)
app.get([
  "/autoconfig/mail/config-v1.1.xml",
  "/mail/config-v1.1.xml",
  "/.well-known/autoconfig/mail/config-v1.1.xml"
], autoconfig.handleAutoconfigRequest);

// Autodiscover (Microsoft Outlook / Windows Mail)
app.all([
  "/Autodiscover/Autodiscover.xml",
  "/autodiscover/autodiscover.xml"
], autodiscover.handleAutodiscoverRequest);

// Apple .mobileconfig Direct Profile Download
app.get([
  "/mobileconfig/:email.mobileconfig",
  "/mobileconfig/:email"
], mobileconfig.handleMobileconfigDownload);

// Route registrations
app.use("/api/auth", require("./routes/auth.routes"));
app.use("/api/stats", require("./routes/stats.routes"));
app.use("/api/websites", require("./routes/website.routes"));
app.use("/api/domains", require("./routes/domain.routes"));
app.use("/api/databases", require("./routes/database.routes"));
app.use("/api/email", require("./routes/email.routes"));
app.use("/api/ssl", require("./routes/ssl.routes"));
app.use("/api/dns", require("./routes/dns.routes"));
app.use("/api/files", require("./routes/files.routes"));
app.use("/api/cron", require("./routes/cron.routes"));
app.use("/api/security", require("./routes/security.routes"));
app.use("/api/backup", require("./routes/backup.routes"));
app.use("/api/license", require("./routes/license.routes"));
app.use("/api/whm", require("./routes/whm.routes"));
app.use("/api/tokens", require("./routes/tokens.routes"));
app.use("/api/tools", require("./routes/tools.routes"));
app.use("/api", require("./routes/tools.routes"));

app.get("/health", (req, res) => res.json({
  status: "ok",
  profile: platform.PROFILE,
  product: "YourPanel cPanel/WHM Suite",
  version: "1.0.0",
  ports: { cpanel: CPANEL_PORT, whm: WHM_PORT }
}));

// Resolve cPanel frontend static directory
const cpanelDistCandidates = [
  path.resolve(__dirname, "../../frontend/dist"),
  path.resolve(__dirname, "../dist"),
  path.resolve(__dirname, "../frontend/dist"),
  path.resolve(__dirname, "./dist"),
];
const cpanelDistPath = cpanelDistCandidates.find((p) => fs.existsSync(path.join(p, "index.html")));

// Resolve WHM frontend static directory
const whmDistCandidates = [
  path.resolve(__dirname, "../../whm-frontend/dist"),
  path.resolve(__dirname, "../whm-frontend/dist"),
  path.resolve(__dirname, "../whm-dist"),
  path.resolve(__dirname, "./whm-dist"),
];
const whmDistPath = whmDistCandidates.find((p) => fs.existsSync(path.join(p, "index.html")));

// WHM is a separate app on port 2087. If accessed via /whm on cPanel port, redirect to WHM port 2087.
app.get("/whm*", (req, res) => {
  const scheme = isHttps ? "https" : "http";
  const host = (req.headers.host || "127.0.0.1").split(":")[0];
  res.redirect(`${scheme}://${host}:${WHM_PORT}`);
});

// cPanel URL shortcuts
app.get(["/cpanel", "/cpanel/*", "/login", "/login/*"], (req, res) => {
  res.redirect("/");
});

// Webmail shortcut (redirects to Webmail port 2096)
app.get(["/webmail", "/webmail/*"], (req, res) => {
  const scheme = isHttps ? "https" : "http";
  const host = (req.headers.host || "127.0.0.1").split(":")[0];
  res.redirect(`${scheme}://${host}:2096/`);
});

// Serve cPanel UI on root
if (cpanelDistPath) {
  app.use(express.static(cpanelDistPath));
  app.get("*", (req, res, next) => {
    if (req.path.startsWith("/api") || req.path.startsWith("/whm")) return next();
    res.sendFile(path.join(cpanelDistPath, "index.html"));
  });
}

app.use((req, res) => res.status(404).json({ success: false, message: "Route not found" }));
app.use((err, req, res, _next) => {
  const status = err.status || err.statusCode || 500;
  if (status >= 500) console.error(err);
  res.status(status).json({ success: false, message: status >= 500 ? "Internal server error" : err.message });
});

let server;
const isHttps = process.env.SSL_CERT && process.env.SSL_KEY &&
  fs.existsSync(process.env.SSL_CERT) && fs.existsSync(process.env.SSL_KEY);

if (isHttps) {
  server = https.createServer({
    cert: fs.readFileSync(process.env.SSL_CERT),
    key: fs.readFileSync(process.env.SSL_KEY)
  }, app);
} else {
  server = http.createServer(app);
}

// -------------------------------------------------------------
// WEBSOCKET TERMINAL SERVER (xterm.js bridge with Domain & User Isolation)
// -------------------------------------------------------------
const wss = new WebSocketServer({ server, path: "/terminal" });

wss.on("connection", (ws, req) => {
  const urlObj = new URL(req.url, "http://localhost");
  const token = urlObj.searchParams.get("token") || "";
  const requestedDomain = (urlObj.searchParams.get("domain") || "").trim().toLowerCase();

  const authService = require("./services/auth.service");
  const tokensService = require("./services/tokens.service");
  const websiteService = require("./services/website.service");

  let user = null;
  if (token) {
    if (token.startsWith("YP_tok_")) {
      user = tokensService.verifyApiToken(token);
    } else {
      try {
        user = authService.verify(token);
      } catch (_) {
        user = tokensService.verifyApiToken(token);
      }
    }
  }

  // Determine authorized domain
  let targetDomain = requestedDomain;
  if (user) {
    if (user.role !== "admin" && user.username !== "root") {
      // Non-admin account: enforce ownership
      if (targetDomain) {
        if (!websiteService.isUserAllowedSite(targetDomain, null, user)) {
          ws.send(`\r\n\x1b[1;31m[Security] Access Denied: You do not have permission to execute commands in "${targetDomain}".\x1b[0m\r\n`);
          ws.close();
          return;
        }
      } else {
        targetDomain = user.domain || (user.username ? user.username : "");
      }
    }
  }

  const isWin = process.platform === "win32";
  let targetDir = isWin ? process.cwd() : "/www/wwwroot";

  if (targetDomain) {
    const doc = platform.docRoot(targetDomain);
    if (doc) targetDir = doc;
  }
  if (!fs.existsSync(targetDir)) {
    try { fs.mkdirSync(targetDir, { recursive: true }); } catch (_) {}
  }

  console.log(`[Terminal] Client connected: user=${user?.username || "root"}, domain=${targetDomain || "default"}, cwd=${targetDir}`);

  const shellCmd = isWin ? "powershell.exe" : "/bin/bash";
  const shellArgs = isWin ? ["-NoLogo"] : ["-i"];

  const venvBin = path.join(targetDir, "venv", "bin");
  const dotVenvBin = path.join(targetDir, ".venv", "bin");
  const pathPrefix = [venvBin, dotVenvBin].filter((p) => fs.existsSync(p)).join(":");
  const systemPath = "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin";
  const finalPath = pathPrefix ? `${pathPrefix}:${systemPath}` : systemPath;

  const displayUser = user?.username || (isWin ? "user" : "root");
  const displayHost = targetDomain || "vps";

  const customEnv = {
    ...process.env,
    TERM: "xterm-256color",
    COLORTERM: "truecolor",
    HOME: targetDir,
    PWD: targetDir,
    DOMAIN: targetDomain || "default",
    USER: displayUser,
    PS1: `\\[\\033[01;32m\\]${displayUser}@${displayHost}\\[\\033[00m\\]:\\[\\033[01;34m\\]\\w\\[\\033[00m\\]\\$ `,
    PROMPT_COMMAND: `PS1="\\[\\033[01;32m\\]${displayUser}@${displayHost}\\[\\033[00m\\]:\\[\\033[01;34m\\]\\w\\[\\033[00m\\]\\$ "`,
    PATH: finalPath,
  };

  const spawnOpts = {
    cwd: targetDir,
    env: customEnv,
  };

  if (!isWin && user && user.role !== "admin" && user.username !== "root") {
    spawnOpts.uid = 1000;
    spawnOpts.gid = 1000;
  }

  const cols = parseInt(urlObj.searchParams.get("cols"), 10) || 80;
  const rows = parseInt(urlObj.searchParams.get("rows"), 10) || 24;

  let activePtyLib = nodePty;
  if (!activePtyLib) {
    try {
      activePtyLib = require("node-pty");
    } catch (_) {}
  }

  let pty;
  try {
    if (activePtyLib) {
      const ptyArgs = isWin ? [] : ["-l"];
      const ptyOpts = {
        name: "xterm-256color",
        cols,
        rows,
        cwd: targetDir,
        env: customEnv,
      };
      if (!isWin && spawnOpts.uid) {
        ptyOpts.uid = spawnOpts.uid;
        ptyOpts.gid = spawnOpts.gid;
      }
      pty = activePtyLib.spawn(shellCmd, ptyArgs, ptyOpts);

      // Welcome banner
      ws.send("\r\n\x1b[1;36m═══════════════════════════════════════════════════════════════\x1b[0m\r\n");
      ws.send(`\x1b[1;32m  Facezila Cloud Isolated Terminal (Real PTY)\x1b[0m\r\n`);
      ws.send(`  Target Domain:    \x1b[1;33m${targetDomain || "Default"}\x1b[0m\r\n`);
      ws.send(`  Isolated Root:    \x1b[1;34m${targetDir}\x1b[0m\r\n`);
      ws.send(`  CLI Execution:    \x1b[1;32m${displayUser} (${spawnOpts.uid === 1000 ? "Restricted www" : "Admin"})\x1b[0m\r\n`);
      ws.send(`  Ubuntu Tools:     Python 3.10, venv, Node v20, PM2, Gunicorn, Git, Nginx, Certbot, Vite\x1b[0m\r\n`);
      ws.send("\x1b[1;36m═══════════════════════════════════════════════════════════════\x1b[0m\r\n\r\n");

      pty.onData((data) => {
        if (ws.readyState === ws.OPEN) ws.send(data);
      });

      ws.on("message", (msg) => {
        try {
          const str = msg.toString();
          if (str.startsWith("{") && str.includes('"type":"resize"')) {
            try {
              const resPayload = JSON.parse(str);
              if (resPayload.cols && resPayload.rows) {
                pty.resize(resPayload.cols, resPayload.rows);
                return;
              }
            } catch (_) {}
          }
          pty.write(str);
        } catch (_) {}
      });

      ws.on("close", () => {
        try { pty.kill(); } catch (_) {}
      });

      pty.onExit(() => {
        if (ws.readyState === ws.OPEN) ws.close();
      });
    } else {
      pty = spawn(shellCmd, shellArgs, spawnOpts);

      // Welcome banner
      ws.send("\r\n\x1b[1;36m═══════════════════════════════════════════════════════════════\x1b[0m\r\n");
      ws.send(`\x1b[1;32m  Facezila Cloud Isolated Terminal\x1b[0m\r\n`);
      ws.send(`  Target Domain:    \x1b[1;33m${targetDomain || "Default"}\x1b[0m\r\n`);
      ws.send(`  Isolated Root:    \x1b[1;34m${targetDir}\x1b[0m\r\n`);
      ws.send(`  CLI Execution:    \x1b[1;32m${displayUser} (${spawnOpts.uid === 1000 ? "Restricted www" : "Admin"})\x1b[0m\r\n`);
      ws.send(`  Ubuntu Tools:     Python 3.10, venv, Node v20, PM2, Gunicorn, Git, Nginx, Certbot, Vite\x1b[0m\r\n`);
      ws.send("\x1b[1;36m═══════════════════════════════════════════════════════════════\x1b[0m\r\n\r\n");

      pty.stdout.on("data", (data) => {
        if (ws.readyState === ws.OPEN) {
          // Prevent zigzag staircase effect in pipe mode
          ws.send(data.toString().replace(/\r?\n/g, "\r\n"));
        }
      });
      pty.stderr.on("data", (data) => {
        if (ws.readyState === ws.OPEN) {
          ws.send(data.toString().replace(/\r?\n/g, "\r\n"));
        }
      });

      ws.on("message", (msg) => {
        try {
          pty.stdin.write(msg.toString());
        } catch (_) {}
      });

      ws.on("close", () => {
        try { pty.kill(); } catch (_) {}
      });

      pty.on("close", () => {
        if (ws.readyState === ws.OPEN) ws.close();
      });
    }
  } catch (err) {
    ws.send(`\r\nError starting terminal: ${err.message}\r\n`);
    ws.close();
  }
});

// -------------------------------------------------------------
// SEPARATE WHM HTTP/HTTPS SERVER (PORT 2087)
// -------------------------------------------------------------
const whmApp = express();
whmApp.use(cors({ origin: true, credentials: true }));
whmApp.disable("x-powered-by");
whmApp.use(express.json({ limit: "25mb" }));

// Route registrations on WHM
whmApp.use("/api/auth", require("./routes/auth.routes"));
whmApp.use("/api/stats", require("./routes/stats.routes"));
whmApp.use("/api/license", require("./routes/license.routes"));
whmApp.use("/api/whm", require("./routes/whm.routes"));
whmApp.use("/api/security", require("./routes/security.routes"));
whmApp.use("/api/dns", require("./routes/dns.routes"));
whmApp.use("/api/tokens", require("./routes/tokens.routes"));
whmApp.use("/api/tools", require("./routes/tools.routes"));
whmApp.use("/api", require("./routes/tools.routes"));

// cPanel shortcut on WHM port redirects to cPanel port
whmApp.get(["/cpanel", "/cpanel/*"], (req, res) => {
  const scheme = isHttps ? "https" : "http";
  const host = (req.headers.host || "127.0.0.1").split(":")[0];
  res.redirect(`${scheme}://${host}:${CPANEL_PORT}/`);
});

if (whmDistPath) {
  whmApp.use(express.static(whmDistPath));
  whmApp.get("*", (req, res, next) => {
    if (req.path.startsWith("/api")) return next();
    res.sendFile(path.join(whmDistPath, "index.html"));
  });
}

let whmServer;
if (isHttps) {
  whmServer = https.createServer({
    cert: fs.readFileSync(process.env.SSL_CERT),
    key: fs.readFileSync(process.env.SSL_KEY)
  }, whmApp);
} else {
  whmServer = http.createServer(whmApp);
}

if (require.main === module) {
  connectDB().then(async () => {
    await licenseService.checkBootLicense();
    await checkLicenseStatus();

    // 24-Hour recurring license verification cron
    setInterval(async () => {
      console.log("[License Cron] Performing 24h periodic license verification...");
      const status = await checkLicenseStatus();
      if (!status.valid) {
        console.warn("⚠️ [License Cron] Periodic verification failed:", status.reason);
      } else {
        console.log("✅ [License Cron] Periodic verification confirmed active license.");
      }
    }, 24 * 60 * 60 * 1000);
  });

  const scheme = isHttps ? "https" : "http";
  server.listen(CPANEL_PORT, "0.0.0.0", () => {
    console.log(`cPanel End-User Panel active at ${scheme}://0.0.0.0:${CPANEL_PORT} (${platform.PROFILE})`);
    console.log(`WebSocket Terminal endpoint active at ws${isHttps ? "s" : ""}://0.0.0.0:${CPANEL_PORT}/terminal`);
  });

  if (String(WHM_PORT) !== String(CPANEL_PORT)) {
    whmServer.listen(WHM_PORT, "0.0.0.0", () => {
      console.log(`WHM / Reseller Management Panel active at ${scheme}://0.0.0.0:${WHM_PORT}`);
    }).on("error", (err) => {
      console.warn(`[WHM Port] Could not bind port ${WHM_PORT} (${err.message}). WHM UI remains accessible at ${scheme}://0.0.0.0:${CPANEL_PORT}/whm`);
    });
  }
}

module.exports = { app, whmApp };
