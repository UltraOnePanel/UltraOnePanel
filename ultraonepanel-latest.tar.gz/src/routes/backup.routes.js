const express = require("express");
const auth = require("../middleware/auth");
const svc = require("../services/backup.service");
const { wrap, who } = require("../lib/http");

const router = express.Router();

router.get("/", auth, wrap(async (req) => ({ backups: await svc.listBackups(req.user), schedule: await svc.getSchedule() })));
router.post("/generate", auth, wrap(async (req) => {
  const { type, domain, databases } = req.body || {};
  return { backup: await svc.createBackup({ type, domain, databases, user: who(req) }) };
}, 202));
router.get("/download/:id", auth, (req, res) => {
  try {
    res.download(svc.downloadPath(req.params.id));
  } catch (err) {
    res.status(err.status || 500).json({ success: false, message: err.message });
  }
});
router.post("/:id/restore", auth, wrap((req) => svc.restoreBackup({ id: req.params.id, user: who(req) })));
router.put("/schedule", auth, wrap(async (req) => ({ schedule: await svc.setSchedule({ ...(req.body || {}), user: who(req) }) })));
router.delete("/:id", auth, wrap((req) => svc.deleteBackup({ id: req.params.id })));

module.exports = router;
