// Smaller feature areas: FTP, logs, SSH keys, performance, app installer, WHM accounts.
const express = require("express");
const auth = require("../middleware/auth");
const ftp = require("../services/ftp.service");
const root = require("../services/root.service");
const logs = require("../services/logs.service");
const sshkeys = require("../services/sshkeys.service");
const perf = require("../services/performance.service");
const apps = require("../services/apps.service");
const accounts = require("../services/accounts.service");
const platform = require("../lib/platform");
const { wrap, who } = require("../lib/http");

const router = express.Router();
router.use(auth);

// FTP
router.get("/ftp", wrap(async (req) => ({ accounts: await ftp.listAccounts(req.user), engine: platform.ftpEngine() })));
router.get("/ftp/sessions", wrap(async () => ({ sessions: await root.getActiveFtpSessions() })));
router.post("/ftp", wrap(async (req) => ({ account: await ftp.createAccount({ ...(req.body || {}), user: who(req) }) }), 201));
router.patch("/ftp/:username/password", wrap((req) => ftp.changePassword({ username: req.params.username, password: (req.body || {}).password, user: who(req) })));
router.delete("/ftp/:username", wrap((req) => ftp.deleteAccount({ username: req.params.username, user: who(req) })));

// Logs
router.get("/logs", wrap(async () => ({ sources: await logs.listSources() })));
router.get("/logs/:source", wrap((req) => logs.tail({ source: req.params.source, domain: req.query.domain, lines: req.query.lines })));

// Metrics sub-tools
router.get(["/metrics/visitors", "/tools/metrics/visitors"], wrap((req) => logs.getVisitors({ domain: req.query.domain, limit: req.query.limit })));
router.get(["/metrics/errors", "/tools/metrics/errors"], wrap((req) => logs.getErrors({ domain: req.query.domain, limit: req.query.limit })));
router.get(["/metrics/raw", "/tools/metrics/raw"], wrap((req) => logs.getRawLogs({ domain: req.query.domain })));
router.get(["/metrics/bandwidth", "/tools/metrics/bandwidth"], wrap(() => logs.getBandwidthStats()));
router.get(["/metrics/usage", "/tools/metrics/usage"], wrap(() => logs.getUsageStats()));

// SSH keys
router.get("/ssh-keys", wrap(async () => ({ keys: await sshkeys.listKeys() })));
router.post("/ssh-keys", wrap(async (req) => ({ key: await sshkeys.addKey(req.body || {}) }), 201));
router.delete("/ssh-keys/:id", wrap((req) => sshkeys.deleteKey({ id: decodeURIComponent(req.params.id) })));

// Performance
router.get(["/performance", "/tools/performance"], wrap(() => perf.getStatus()));
router.post(["/performance/purge", "/tools/performance/purge"], wrap((req) => perf.purge({ user: who(req) })));
router.put(["/performance/:module", "/tools/performance/:module"], wrap((req) => perf.toggle({ module: req.params.module, enabled: (req.body || {}).enabled, user: who(req) })));

// MultiPHP INI Editor
router.get(["/performance/ini", "/tools/performance/ini"], wrap((req) => perf.getPhpIni({ domain: req.query.domain, version: req.query.version })));
router.post(["/performance/ini", "/tools/performance/ini"], wrap((req) => perf.savePhpIni({ ...(req.body || {}), user: who(req) })));

// PHP Selector & Extensions
router.get(["/performance/php-extensions", "/tools/performance/php-extensions"], wrap((req) => perf.getPhpExtensions({ version: req.query.version })));
router.post(["/performance/install-php", "/tools/performance/install-php"], wrap((req) => perf.installPhpVersion({ ...(req.body || {}), user: who(req) })));

// Applications Manager
router.get(["/performance/applications", "/tools/performance/applications"], wrap((req) => perf.listApplications(who(req))));
router.post(["/performance/applications", "/tools/performance/applications"], wrap((req) => perf.createApplication({ ...(req.body || {}), user: who(req) }), 201));
router.delete(["/performance/applications/:id", "/tools/performance/applications/:id"], wrap((req) => perf.deleteApplication({ id: req.params.id, user: who(req) })));
router.post(["/performance/applications/:id/toggle", "/tools/performance/applications/:id/toggle"], wrap((req) => perf.toggleApplication({ id: req.params.id, action: (req.body || {}).action, user: who(req) })));
router.post(["/performance/install-environment", "/tools/performance/install-environment"], wrap((req) => perf.installEnvironment({ ...(req.body || {}), user: who(req) })));

// Optimize Website (Gzip)
router.get(["/performance/gzip", "/tools/performance/gzip"], wrap(() => perf.getGzipConfig()));
router.post(["/performance/gzip", "/tools/performance/gzip"], wrap((req) => perf.saveGzipConfig({ ...(req.body || {}), user: who(req) })));

// WordPress Toolkit Lite
router.get(["/performance/wordpress", "/tools/performance/wordpress"], wrap((req) => perf.listWordPressSites({ user: who(req), domain: req.query.domain })));
router.post(["/performance/wordpress/install", "/tools/performance/wordpress/install"], wrap((req) => perf.installWordPressDirect({ ...(req.body || {}), user: who(req) }), 201));

// App installer
router.get("/apps", wrap(() => ({ apps: apps.catalog() })));
router.post("/apps/install", wrap((req) => apps.install({ app: (req.body || {}).app, domain: (req.body || {}).domain, user: who(req) })));

// WHM accounts & packages
router.get("/accounts", wrap(async () => ({ accounts: await accounts.listAccounts(), packages: accounts.listPackages() })));
router.post("/accounts", wrap(async (req) => ({ account: await accounts.createAccount({ ...(req.body || {}), user: who(req) }) }), 201));
router.post("/accounts/:username/toggle", wrap((req) => accounts.toggleAccount({ username: req.params.username, user: who(req) })));
router.delete("/accounts/:username", wrap((req) => accounts.deleteAccount({ username: req.params.username, user: who(req) })));
router.post("/packages", wrap(async (req) => ({ package: accounts.createPackage(req.body || {}) }), 201));
router.delete("/packages/:id", wrap((req) => accounts.deletePackage(req.params.id)));

module.exports = router;
