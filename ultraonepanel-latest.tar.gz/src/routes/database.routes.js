const express = require("express");
const auth = require("../middleware/auth");
const svc = require("../services/database.service");
const bigimport = require("../services/bigimport.service");
const { wrap, who } = require("../lib/http");

const router = express.Router();

router.get("/", auth, wrap(async (req) => ({
  databases: await svc.listDatabases(req.user),
  phpMyAdminUrl: svc.phpMyAdminUrl(req.headers.host),
  phpPgAdminUrl: svc.phpPgAdminUrl(req.headers.host),
})));

router.post("/", auth, wrap(async (req) => {
  const { name, dbUser, dbPass } = req.body || {};
  return { database: await svc.createDatabase({ name, dbUser, dbPass, user: who(req), currentUser: req.user }) };
}, 201));

// Database Wizard (Creates DB + User + Grants permissions)
router.post("/wizard", auth, wrap(async (req) => {
  const { dbName, username, password, privileges = ["ALL"] } = req.body || {};
  const dbResult = await svc.createDatabase({ name: dbName, user: who(req), currentUser: req.user });
  const userResult = await svc.createDatabaseUser({ username, password, host: "localhost", database: dbName, user: who(req), currentUser: req.user });
  await svc.grantDatabase({ username, host: "localhost", database: dbName, privileges, user: who(req), currentUser: req.user });
  return { success: true, database: dbResult, user: userResult, status: "created_via_wizard" };
}, 201));

// Users
router.get("/users", auth, wrap(async (req) => ({ users: await svc.listDatabaseUsers(req.user) })));
router.post("/users", auth, wrap(async (req) => {
  const { username, password, database, host } = req.body || {};
  return { user: await svc.createDatabaseUser({ username, password, database, host, user: who(req), currentUser: req.user }) };
}, 201));
router.delete("/users/:username", auth, wrap((req) => svc.deleteDatabaseUser({ username: req.params.username, host: req.query.host, user: who(req), currentUser: req.user })));
router.patch("/users/:username/password", auth, wrap((req) => svc.changeUserPassword({ username: req.params.username, password: (req.body || {}).password, host: (req.body || {}).host, user: who(req), currentUser: req.user })));
router.post("/users/:username/grant", auth, wrap((req) => svc.grantDatabase({
  username: req.params.username,
  database: (req.body || {}).database,
  host: (req.body || {}).host,
  privileges: (req.body || {}).privileges || ["ALL"],
  user: who(req),
  currentUser: req.user,
})));

// Remote MySQL
router.get("/remote-hosts", auth, wrap(async () => ({ hosts: await svc.listRemoteHosts() })));
router.post("/remote-hosts", auth, wrap((req) => svc.addRemoteHost({ host: (req.body || {}).host, user: who(req) }), 201));
router.delete("/remote-hosts/:host", auth, wrap((req) => svc.deleteRemoteHost({ host: req.params.host, user: who(req) })));

// PostgreSQL
router.get("/postgresql", auth, wrap(async (req) => ({
  databases: await svc.listPostgresDatabases(),
  users: await svc.listPostgresUsers(),
  phpPgAdminUrl: svc.phpPgAdminUrl(req.headers.host),
})));
router.post("/postgresql", auth, wrap((req) => svc.createPostgresDatabase(req.body || {}), 201));
router.delete("/postgresql/:name", auth, wrap((req) => svc.deletePostgresDatabase(req.params.name)));

// Import BigData: staggered import of large dumps (BigDump-style).
router.get("/bigimport", auth, wrap(() => ({
  files: bigimport.listFiles(),
  jobs: bigimport.listJobs(),
  defaults: bigimport.DEFAULTS,
  charsets: bigimport.CHARSETS,
  importDir: bigimport.IMPORT_DIR,
})));
router.post("/bigimport/upload", auth, wrap(async (req) => ({ file: await bigimport.receiveUpload(req, req.query.name) }), 201));
router.delete("/bigimport/files/:name", auth, wrap((req) => bigimport.deleteFile(req.params.name)));
router.post("/bigimport/start", auth, wrap(async (req) => {
  const { source, database, settings } = req.body || {};
  return { job: await bigimport.startImport({ source, database, settings, user: who(req) }) };
}, 202));
router.get("/bigimport/jobs/:id", auth, wrap((req) => ({ job: bigimport.getJob(req.params.id) })));
router.post("/bigimport/jobs/:id/:action", auth, wrap((req) => bigimport.control({ id: req.params.id, action: req.params.action, settings: (req.body || {}).settings })));

// Delete MySQL database
router.delete("/:name", auth, wrap((req) => {
  if (bigimport.isImporting(req.params.name)) {
    throw Object.assign(new Error("An import into this database is in progress. Cancel it before dropping the database."), { status: 409 });
  }
  return svc.deleteDatabase({ name: req.params.name, user: who(req), currentUser: req.user });
}));

// Export streams a .sql dump; import takes the raw .sql file as request body
router.get("/:name/export", auth, (req, res) => {
  try {
    const child = svc.exportDatabase(req.params.name);
    let started = false;
    let stderr = "";
    child.stderr.on("data", (d) => { stderr += d; });
    child.stdout.once("data", () => { started = true; });
    res.setHeader("Content-Type", "application/sql");
    res.setHeader("Content-Disposition", "attachment; filename=\"" + req.params.name + "-" + new Date().toISOString().slice(0, 10) + ".sql\"");
    child.stdout.pipe(res);
    child.on("close", (code) => {
      if (code !== 0 && !started) res.status(500).end(stderr || "Export failed");
    });
  } catch (err) {
    res.status(err.status || 500).json({ success: false, message: err.message });
  }
});
router.post("/:name/import", auth, express.text({ type: "*/*", limit: "512mb" }),
  wrap((req) => svc.importDatabase({ name: req.params.name, sqlText: req.body, user: who(req) })));

module.exports = router;
