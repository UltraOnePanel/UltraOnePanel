const express = require("express");
const auth = require("../middleware/auth");
const svc = require("../services/wordpress.service");
const { wrap, who } = require("../lib/http");

const router = express.Router();

router.get("/sites", auth, wrap((req) => svc.listSites(req.user)));
router.post("/auto-login", auth, wrap((req) => svc.autoLogin({ ...(req.body || {}), user: req.user })));
router.post("/maintenance", auth, wrap((req) => svc.toggleMaintenance({ ...(req.body || {}), user: req.user })));
router.post("/debug-mode", auth, wrap((req) => svc.toggleDebugMode({ ...(req.body || {}), user: req.user })));
router.post("/install", auth, wrap((req) => svc.installWordPress({ ...(req.body || {}), user: req.user }), 201));
router.post("/ai-generate", auth, wrap((req) => svc.aiSitebuilderGenerate({ ...(req.body || {}), user: req.user })));

module.exports = router;
