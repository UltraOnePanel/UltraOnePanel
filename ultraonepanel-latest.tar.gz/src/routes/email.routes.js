const express = require("express");
const auth = require("../middleware/auth");
const email = require("../services/email.service");
const website = require("../services/website.service");
const mobileconfig = require("../services/mobileconfig");
const { wrap, who } = require("../lib/http");

const router = express.Router();
router.use(auth);

// Status & webmail
router.get("/status", wrap((req) => email.getStatus(req.headers.host)));

// Available email domains for current user
router.get("/domains", wrap(async (req) => {
  const sites = await website.listWebsites(req.user);
  let domains = sites.map((s) => s.domain).filter(Boolean);
  if (req.user && req.user.role !== "admin" && req.user.username !== "root" && req.user.domain) {
    domains = [req.user.domain, ...domains.filter(d => d.endsWith("." + req.user.domain))];
  }
  const unique = [...new Set(domains)];
  return { domains: unique, data: unique };
}));

// 1. Email Accounts
router.get("/accounts", wrap(async (req) => {
  let domain = req.query.domain;
  if (!domain && req.user && req.user.role !== "admin" && req.user.username !== "root") {
    domain = req.user.domain;
  }
  const accounts = await email.listEmails(domain, req.user);
  return { accounts, data: accounts };
}));
router.post("/accounts", wrap((req) => email.createEmail({ ...(req.body || {}), user: who(req), currentUser: req.user }), 201));
router.delete("/accounts/:email", wrap((req) => email.deleteEmail({ email: req.params.email, user: who(req), currentUser: req.user })));
router.patch("/accounts/:email/password", wrap((req) => email.changePassword({ email: req.params.email, password: (req.body || {}).password, user: who(req), currentUser: req.user })));
router.patch("/accounts/:email/quota", wrap((req) => email.changeQuota({ email: req.params.email, quota: (req.body || {}).quota, user: who(req), currentUser: req.user })));
router.get("/accounts/:email/device-config", wrap((req) => email.getDeviceConfig(req.params.email, (req.headers.host || "").split(":")[0])));
router.get("/accounts/:email/connect-info", wrap(async (req) => {
  const emailAddr = req.params.email;
  const domain = emailAddr.includes("@") ? emailAddr.split("@")[1] : "";
  if (domain) {
    try {
      const dns = require("../services/dns.service");
      await dns.ensureMailClientDnsRecords(domain, who(req));
    } catch (_) {}
  }
  return mobileconfig.getConnectDeviceInfo({
    email: emailAddr,
    hostHeader: req.headers.host,
    protocol: req.protocol || "https",
  });
}));
router.get("/accounts/:email/mobileconfig", (req, res) => {
  return mobileconfig.handleMobileconfigDownload(req, res);
});
router.get("/accounts/:email/qr", (req, res) => {
  const info = mobileconfig.getConnectDeviceInfo({
    email: req.params.email,
    hostHeader: req.headers.host,
    protocol: req.protocol || "https",
  });
  res.setHeader("Content-Type", "image/svg+xml");
  return res.status(200).send(info.qrSvg);
});
router.post("/accounts/:email/ensure-dns", wrap(async (req) => {
  const emailAddr = req.params.email;
  const domain = emailAddr.includes("@") ? emailAddr.split("@")[1] : "";
  if (!domain) throw require("../lib/validate").badRequest("Invalid email address");
  const dns = require("../services/dns.service");
  const result = await dns.ensureMailClientDnsRecords(domain, who(req));
  return { success: true, message: "autoconfig and autodiscover DNS records verified", ...result };
}));
router.post("/accounts/:email/webmail-sso", wrap(async (req) => ({ url: await email.getWebmailSsoUrl(req.params.email, req.user) })));
router.get("/accounts/:email/webmail-sso", wrap(async (req, res) => {
  const url = await email.getWebmailSsoUrl(req.params.email, req.user);
  if (req.query.redirect === "true") {
    return res.redirect(url);
  }
  return { url };
}));

// 2. Forwarders
router.get("/forwarders", wrap(async (req) => {
  const forwarders = await email.listForwarders(req.user);
  return { forwarders, data: forwarders };
}));
router.post("/forwarders", wrap((req) => email.createForwarder({ ...(req.body || {}), user: who(req), currentUser: req.user }), 201));
router.delete("/forwarders", wrap((req) => email.deleteForwarder({ source: req.query.source, destination: req.query.destination, user: who(req), currentUser: req.user })));
router.post("/domain-forwarders", wrap((req) => email.createDomainForwarder({ ...(req.body || {}), user: who(req), currentUser: req.user }), 201));
router.delete("/domain-forwarders/:sourceDomain", wrap((req) => email.deleteDomainForwarder({ sourceDomain: req.params.sourceDomain, user: who(req), currentUser: req.user })));

// 3. Email Routing
router.get("/routing/:domain", wrap((req) => email.getEmailRouting(req.params.domain)));
router.post("/routing", wrap((req) => email.setEmailRouting({ ...(req.body || {}), user: who(req), currentUser: req.user })));

// 4. Autoresponders
router.get("/autoresponders", wrap(async (req) => {
  let domain = req.query.domain;
  if (!domain && req.user && req.user.role !== "admin" && req.user.username !== "root") {
    domain = req.user.domain;
  }
  const autoresponders = await email.listAutoresponders(domain, req.user);
  return { autoresponders, data: autoresponders };
}));
router.post("/autoresponders", wrap((req) => email.createAutoresponder(req.body || {}), 201));
router.delete("/autoresponders/:email", wrap((req) => email.deleteAutoresponder(req.params.email)));

// 5. Default Address (Catch-all)
router.get("/default-address/:domain", wrap((req) => email.getDefaultAddress(req.params.domain)));
router.post("/default-address", wrap((req) => email.setDefaultAddress({ ...(req.body || {}), user: who(req) })));

// 6. Track Delivery
router.get("/track-delivery", wrap(async (req) => {
  const logs = await email.trackDelivery(req.query.q);
  return { logs, data: logs };
}));

// 7 & 8. Email Filters
router.get("/global-filters", wrap(async () => {
  const filters = await email.getGlobalFilters();
  return { filters, data: filters };
}));
router.post("/global-filters", wrap((req) => email.createGlobalFilter(req.body || {}), 201));
router.delete("/global-filters/:id", wrap((req) => email.deleteGlobalFilter(req.params.id)));

router.get("/filters/:email", wrap(async (req) => {
  const filters = await email.getAccountFilters(req.params.email);
  return { filters, data: filters };
}));
router.post("/filters/:email", wrap((req) => email.createAccountFilter({ email: req.params.email, filter: req.body || {} }), 201));
router.delete("/filters/:email/:id", wrap((req) => email.deleteAccountFilter({ email: req.params.email, id: req.params.id })));

// 9. Deliverability
router.get("/deliverability", wrap(async (req) => {
  const sites = await website.listWebsites(req.user);
  const domains = sites.map((s) => s.domain);
  const items = await email.getDeliverabilityStatus(domains.length ? domains : ["example.com"]);
  return { items, data: items };
}));

// 10. Address Importer
router.post("/import", wrap((req) => email.importAddresses({ ...(req.body || {}), user: who(req) })));

// 11. Spam Filters
router.get("/spam", wrap(() => email.getSpamSettings()));
router.post("/spam", wrap((req) => email.updateSpamSettings(req.body || {}, who(req))));

// 12. Encryption (GPG)
router.get("/encryption", wrap(async () => {
  const keys = await email.getGpgKeys();
  return { keys, data: keys };
}));
router.post("/encryption/generate", wrap((req) => email.generateGpgKey(req.body || {}), 201));
router.post("/encryption/import", wrap((req) => email.importGpgKey(req.body || {}), 201));
router.delete("/encryption/:id", wrap((req) => email.deleteGpgKey(req.params.id)));

// 13. Greylisting
router.get("/greylisting", wrap(() => email.getGreylistingStatus()));
router.post("/greylisting/toggle", wrap((req) => email.toggleGreylisting(req.body || {})));

// 14, 15, 16. Calendars & Contacts
router.get("/caldav/config", wrap((req) => email.getCalDavConfig(req.query.email, (req.headers.host || "").split(":")[0])));
router.get("/calendars", wrap(async (req) => {
  const calendars = await email.listCalendars(req.query.email);
  return { calendars, data: calendars };
}));
router.post("/calendars", wrap((req) => email.createCalendar(req.body || {}), 201));
router.delete("/calendars/:id", wrap((req) => email.deleteCalendar(req.params.id)));
router.get("/calendars/shares", wrap(async () => {
  const shares = await email.listCalendarShares();
  return { shares, data: shares };
}));
router.post("/calendars/shares", wrap((req) => email.createCalendarShare(req.body || {}), 201));

// 17. Disk Usage & Pruning
router.get("/disk-usage", wrap(async (req) => {
  const mailboxes = await email.getEmailDiskUsage(req.query.domain);
  return { mailboxes, data: mailboxes };
}));
router.post("/prune", wrap((req) => email.pruneMailbox({ ...(req.body || {}), user: who(req) })));

module.exports = router;
