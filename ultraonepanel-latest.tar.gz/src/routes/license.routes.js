const express = require("express");
const auth = require("../middleware/auth");
const license = require("../services/license.service");
const { wrap } = require("../lib/http");

const router = express.Router();

// Central verification endpoint (Public, called by client servers or WHMCS)
router.post("/verify", wrap(async (req) => {
  const { key, ip } = req.body || {};
  const callerIp = ip || req.headers["x-forwarded-for"] || req.socket.remoteAddress;
  return await license.verifyLicense({ key, ip: callerIp });
}));

// Local panel status (Protected)
router.get("/status", auth, wrap(async () => {
  return await license.getLocalStatus();
}));

// Local panel activation (Protected)
router.post("/activate", auth, wrap(async (req) => {
  const { key, serverIp } = req.body || {};
  return await license.activateLocalLicense({ key, serverIp });
}));

// Central License Server Management (Protected for WHM Admin / Licensing Admin)
router.get("/all", auth, wrap(async () => {
  return { licenses: await license.listAllLicenses(), types: license.LICENSE_TYPES };
}));

router.post("/issue", auth, wrap(async (req) => {
  const { customer, email, type, ip, days } = req.body || {};
  return { license: await license.issueLicense({ customer, email, type, ip, days }) };
}, 201));

router.post("/toggle", auth, wrap(async (req) => {
  const { key } = req.body || {};
  return await license.toggleLicense(key);
}));

router.delete("/:key", auth, wrap(async (req) => {
  return await license.deleteLicense(req.params.key);
}));

module.exports = router;
