const express = require("express");
const auth = require("../middleware/auth");
const svc = require("../services/files.service");
const { wrap } = require("../lib/http");

const router = express.Router();

function required(value, label) {
  if (!value) throw Object.assign(new Error(label + " required"), { status: 400 });
  return value;
}

router.get("/browse", auth, wrap((req) => svc.browseDirectory(req.query.path || "", req.user)));
router.get("/tree", auth, wrap((req) => ({ tree: svc.getTree(req.query.path || "", req.user) })));

router.post("/file", auth, wrap((req) => svc.createFile(req.body.path || "", required(req.body.name, "File name"), req.user), 201));
router.post("/folder", auth, wrap((req) => svc.createFolder(req.body.path || "", required(req.body.name, "Folder name"), req.user), 201));
router.post("/rename", auth, wrap((req) => svc.renameItem(req.body.path || "", required(req.body.oldName, "Old name"), required(req.body.newName, "New name"), req.user)));
router.post("/permissions", auth, wrap((req) => svc.changePermissions(req.body.path || "", required(req.body.name, "Name"), required(req.body.permissions, "Permissions"), req.user)));
router.delete("/item", auth, wrap((req) => {
  const data = { ...(req.query || {}), ...(req.body || {}) };
  const { path: dir, name, names, skipTrash } = data;
  const list = names && names.length ? (Array.isArray(names) ? names : [names]) : [required(name, "Item name")];
  let trashed = false;
  for (const n of list) trashed = svc.deleteItem(dir || "", n, !!skipTrash, req.user).trashed;
  return { count: list.length, trashed };
}));

router.get("/content", auth, wrap((req) => svc.readFile(req.query.path || "", required(req.query.name, "File name"), req.user)));
router.post("/save", auth, wrap((req) => svc.saveFile(req.body.path || "", required(req.body.name, "File name"), req.body.content || "", req.user)));

// Binary upload: raw body, target directory and name in query string
router.post("/upload", auth, express.raw({ type: () => true, limit: "512mb" }), wrap((req) => {
  const body = Buffer.isBuffer(req.body) ? req.body : Buffer.alloc(0);
  return svc.uploadFile(req.query.path || "", required(req.query.name, "File name"), body, req.query.overwrite !== "false", req.user);
}, 201));

router.get("/download", auth, (req, res) => {
  try {
    res.download(svc.downloadPath(req.query.path || "", required(req.query.name, "File name"), req.user));
  } catch (err) {
    res.status(err.status || 500).json({ success: false, message: err.message });
  }
});

router.post("/copy", auth, wrap((req) => svc.copyOrMove(req.body.path || "", required(req.body.names, "Items"), required(req.body.destination, "Destination"), false, req.user)));
router.post("/move", auth, wrap((req) => svc.copyOrMove(req.body.path || "", required(req.body.names, "Items"), required(req.body.destination, "Destination"), true, req.user)));
router.post("/compress", auth, wrap((req) => svc.compress(req.body.path || "", required(req.body.names, "Items"), req.body.archiveName, req.body.format, req.user)));
router.post("/extract", auth, wrap((req) => svc.extract(req.body.path || "", required(req.body.name, "Archive"), req.body.destination, req.user)));
router.post("/trash/restore", auth, wrap((req) => svc.restoreFromTrash(required(req.body.names, "Items"))));
router.delete("/trash", auth, wrap(() => svc.emptyTrash()));

// Images
router.post("/images/thumbnail", auth, wrap((req) => svc.processImageThumbnail(req.body || {})));
router.post("/images/scale", auth, wrap((req) => svc.processImageScale(req.body || {})));
router.post("/images/convert", auth, wrap((req) => svc.processImageConvert(req.body || {})));

// Directory Privacy
router.get("/privacy", auth, wrap((req) => svc.listProtectedDirectories(req.user)));
router.post("/privacy/protect", auth, wrap((req) => svc.protectDirectory(req.body || {}, req.user)));
router.post("/privacy/unprotect", auth, wrap((req) => svc.unprotectDirectory(req.body || {}, req.user)));

// Disk Usage Breakdown
router.get("/disk-usage", auth, wrap((req) => svc.getDiskUsageBreakdown(req.query.path || "", req.user)));

// Remote Sync & Zip Copy
router.get("/sync/jobs", auth, wrap((req) => svc.listSyncJobs(req.user)));
router.post("/sync/copy-zip", auth, wrap((req) => svc.copyFromZip(req.body || {}, req.user)));
router.post("/sync/rsync", auth, wrap((req) => svc.runRsync(req.body || {}, req.user)));

// Git Version Control
router.get("/git/repos", auth, wrap(() => svc.listGitRepos()));
router.post("/git/clone", auth, wrap((req) => svc.cloneGitRepo(req.body || {}), 201));
router.post("/git/pull", auth, wrap((req) => svc.pullGitRepo(req.body || {})));

module.exports = router;
