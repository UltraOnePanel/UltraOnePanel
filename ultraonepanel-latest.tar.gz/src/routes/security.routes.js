const express = require("express");
const auth = require("../middleware/auth");
const svc = require("../services/security.service");
const { wrap, who } = require("../lib/http");

const router = express.Router();

// Security status & rules (supporting both /api/security and /api/security/status)
router.get("/", auth, wrap(() => svc.getSecurityStatus()));
router.get("/status", auth, wrap(() => svc.getSecurityStatus()));

// IP Blocking
router.get("/blocked-ips", auth, wrap(async () => {
  const status = await svc.getSecurityStatus();
  return { success: true, ips: (status.blockedIps || []).map((b) => b.ip) };
}));
router.post("/block-ip", auth, wrap(async (req) => ({ entry: await svc.blockIp({ ...(req.body || {}), user: who(req) }) }), 201));
router.delete("/block-ip/:ip", auth, wrap((req) => svc.unblockIp({ ip: decodeURIComponent(req.params.ip), user: who(req) })));
router.post("/unblock-ip", auth, wrap((req) => svc.unblockIp({ ip: (req.body || {}).ip, user: who(req) })));

// Ports & Firewall Rules
router.post("/ports", auth, wrap(async (req) => ({ rule: await svc.addPortRule({ ...(req.body || {}), user: who(req) }) }), 201));
router.delete("/ports/:port/:protocol", auth, wrap((req) => svc.deletePortRule({ port: req.params.port, protocol: req.params.protocol, user: who(req) })));
router.delete("/ports/:port", auth, wrap((req) => svc.deletePortRule({ port: req.params.port, protocol: req.query.protocol || (req.body || {}).protocol, user: who(req) })));

// SSH Keys
router.get("/ssh-keys", auth, wrap(async () => ({ keys: await svc.listSshKeys() })));
router.post("/ssh-keys", auth, wrap(async (req) => ({ key: await svc.addSshKey(req.body || {}) }), 201));
router.post("/ssh-keys/generate", auth, wrap(async (req) => svc.generateSshKey(req.body || {}), 201));
router.delete("/ssh-keys/:id", auth, wrap((req) => svc.deleteSshKey({ id: decodeURIComponent(req.params.id) })));

// 2FA
router.get("/2fa", auth, wrap((req) => svc.get2faStatus(who(req))));
router.post("/2fa/setup", auth, wrap((req) => svc.setup2fa(who(req))));
router.post("/2fa/verify", auth, wrap((req) => svc.verify2fa({ username: who(req), ...(req.body || {}) })));
router.post("/2fa/disable", auth, wrap((req) => svc.disable2fa({ username: who(req), ...(req.body || {}) })));
router.post("/2fa", auth, wrap((req) => svc.toggle2fa({ username: who(req), ...(req.body || {}) })));

// Hotlink Protection
router.get("/hotlink", auth, wrap(async (req) => ({ config: await svc.getHotlink(req.query.domain) })));
router.post("/hotlink", auth, wrap(async (req) => svc.saveHotlink({ ...(req.body || {}), user: who(req) })));

// Leech Protection
router.get("/leech", auth, wrap(async (req) => ({ directories: await svc.getLeech(req.query.domain) })));
router.post("/leech", auth, wrap(async (req) => svc.saveLeech({ ...(req.body || {}), user: who(req) })));
router.delete("/leech/:path", auth, wrap((req) => svc.deleteLeech({ domain: req.query.domain, path: decodeURIComponent(req.params.path), user: who(req) })));

// 1. SShield AI & Malware Scanner
router.post("/sshield/scan", auth, wrap((req) => svc.runSShieldScan({ ...(req.body || {}), user: who(req) })));
router.get("/sshield/threats", auth, wrap(() => svc.getSShieldThreats()));
router.post("/sshield/quarantine", auth, wrap((req) => svc.quarantineThreat({ ...(req.body || {}), user: who(req) })));
router.post("/sshield/restore", auth, wrap((req) => svc.restoreThreat({ ...(req.body || {}), user: who(req) })));
router.delete("/sshield/threat/:id", auth, wrap((req) => svc.deleteThreatFile({ threatId: req.params.id, user: who(req) })));
router.get("/sshield/file/:id", auth, wrap((req) => svc.getThreatFile({ threatId: req.params.id, user: who(req) })));
router.put("/sshield/file/:id", auth, wrap((req) => svc.saveThreatFile({ threatId: req.params.id, content: (req.body || {}).content, user: who(req) })));
router.post("/sshield/clean", auth, wrap((req) => svc.cleanThreatFile({ threatId: (req.body || {}).threatId, user: who(req) })));

// 2. WP-Lock
router.get("/wplock/:domain", auth, wrap((req) => svc.getWpLockStatus(req.params.domain)));
router.post("/wplock/:domain/toggle", auth, wrap((req) => svc.toggleWpLock({ domain: req.params.domain, ...(req.body || {}), user: who(req) })));

// 3. ModSecurity WAF & SQLi
router.get("/waf", auth, wrap((req) => svc.getWafStatus(req.query.domain)));
router.post("/waf", auth, wrap((req) => svc.updateWafSettings({ ...(req.body || {}), user: who(req) })));

// 4. Payment Gateway & Anti-Carding Shield
router.get("/payment-shield", auth, wrap((req) => svc.getPaymentShieldStatus(req.query.domain)));
router.post("/payment-shield", auth, wrap((req) => svc.savePaymentShieldConfig({ ...(req.body || {}), user: who(req) })));

module.exports = router;
