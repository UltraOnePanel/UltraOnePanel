const express = require("express");
const auth = require("../middleware/auth");
const whm = require("../services/whm.service");
const accounts = require("../services/accounts.service");
const root = require("../services/root.service");
const dns = require("../services/dns.service");
const { wrap, who } = require("../lib/http");

const router = express.Router();
router.use(auth);

// Account Information
router.get("/accounts", wrap(async () => ({ accounts: await accounts.listAccounts(), packages: accounts.listPackages() })));
router.post("/accounts/:username/cpanel-sso", wrap(async (req) => {
  const username = req.params.username;
  const accountsList = await accounts.listAccounts();
  const target = accountsList.find((a) => a.username === username);
  if (!target) throw Object.assign(new Error("Account not found: " + username), { status: 404 });
  return {
    success: true,
    ssoToken: target.ssoToken,
    cpanelUrl: target.cpanelUrl,
  };
}));
router.post("/accounts/sync", wrap(async () => {
  const synced = await accounts.syncExistingServerAccounts();
  return { success: true, count: synced.length, accounts: await accounts.listAccounts() };
}));
router.get("/accounts/suspended", wrap(async () => {
  const all = await accounts.listAccounts();
  return { accounts: all.filter((a) => a.status === "Suspended") };
}));

// Account Functions
router.post("/accounts/create", wrap(async (req) => ({
  account: await accounts.createAccount({ ...(req.body || {}), user: who(req) })
}), 201));

router.post("/accounts/:username/suspend", wrap(async (req) => {
  return await accounts.setSuspended({ username: req.params.username, suspended: true, user: who(req) });
}));
router.post("/accounts/:username/unsuspend", wrap(async (req) => {
  return await accounts.setSuspended({ username: req.params.username, suspended: false, user: who(req) });
}));
router.post("/accounts/:username/upgrade", wrap(async (req) => {
  return await accounts.upgradeAccount({ username: req.params.username, package: req.body.package, user: who(req) });
}));
router.patch("/accounts/:username/modify", wrap(async (req) => {
  return await accounts.modifyAccount({ username: req.params.username, ...(req.body || {}), user: who(req) });
}));
router.post("/accounts/:username/force-password-change", wrap(async (req) => {
  return await accounts.forcePasswordChange({ username: req.params.username, user: who(req) });
}));
router.delete("/accounts/:username/terminate", wrap(async (req) => {
  return await accounts.deleteAccount({ username: req.params.username, user: who(req) });
}));
router.patch("/accounts/:username/password", wrap(async (req) => {
  return await accounts.changePassword({ username: req.params.username, password: (req.body || {}).password, user: who(req) });
}));

// Skeleton Directory
router.get("/skeleton", wrap(() => whm.getSkeletonDirectory()));

// Reseller Management
router.get("/resellers", wrap(() => ({ resellers: whm.listResellers(), acls: whm.getAclDefinitions() })));
router.post("/resellers", wrap((req) => ({ reseller: whm.createReseller(req.body || {}) }), 201));
router.post("/resellers/create", wrap((req) => ({ reseller: whm.createReseller(req.body || {}) }), 201));
router.get("/resellers/:username", wrap((req) => whm.getResellerStats(req.params.username)));
router.get("/resellers/:username/accounts", wrap((req) => whm.getResellerAccounts(req.params.username)));
router.get("/resellers/:username/stats", wrap((req) => whm.getResellerStats(req.params.username)));
router.patch("/resellers/:username/acls", wrap((req) => whm.updateResellerAcls(req.params.username, req.body.acls || [])));
router.post("/resellers/:username/ip", wrap((req) => whm.manageResellerIp(req.params.username, req.body || {})));
router.delete("/resellers/:username", wrap((req) => whm.deleteReseller(req.params.username)));

// Packages & Feature Manager
router.get("/packages", wrap(() => ({ packages: accounts.listPackages() })));
router.post("/packages/create", wrap((req) => ({ package: accounts.createPackage(req.body || {}) }), 201));
router.put("/packages/:id", wrap((req) => ({ package: accounts.createPackage({ ...(req.body || {}), id: req.params.id }) })));
router.delete("/packages/:id", wrap((req) => accounts.deletePackage(req.params.id)));

router.get("/feature-lists", wrap(() => ({ lists: whm.listFeatureLists() })));
router.post("/feature-lists", wrap((req) => whm.saveFeatureList(req.body || {}), 201));
router.delete("/feature-lists/:id", wrap((req) => whm.deleteFeatureList(req.params.id)));

// DNS Functions in WHM
router.get("/dns/zones", wrap(async () => ({ zones: await dns.listZones() })));
router.post("/dns/zones", wrap((req) => dns.createZone({ ...(req.body || {}), user: who(req) }), 201));
router.delete("/dns/zones/:domain", wrap((req) => dns.deleteZone({ domain: req.params.domain, user: who(req) })));
router.post("/dns/park", wrap((req) => whm.parkDomain(req.body || {})));
router.post("/dns/mx", wrap((req) => whm.editMxEntry(req.body || {})));
router.get("/dns/templates", wrap(() => ({ templates: whm.getZoneTemplates() })));
router.post("/dns/templates", wrap((req) => whm.saveZoneTemplate(req.body || {})));

// Service Configuration & System
router.get("/system/info", wrap(async () => whm.getServerInfo()));
router.get("/services", wrap(async () => ({ services: await root.listAllServices() })));
router.post("/services/:name/restart", wrap((req) => root.restartService(req.params.name, who(req))));
router.post("/system/reboot", wrap((req) => root.rebootServer(who(req))));
router.get("/webserver/config", wrap(() => whm.getWebServerConfig()));
router.get("/nameservers", wrap(() => whm.getNameserverConfig()));
router.post("/nameservers", wrap((req) => whm.saveNameserverConfig(req.body || {})));

// Security Center & Firewall & SSL Hosts
router.get("/security", wrap(() => whm.getSecurityCenterStatus()));
router.get("/security/advisor", wrap(() => whm.runSecurityAdvisor()));
router.get("/security/hosts-access", wrap(() => whm.getHostAccessControl()));
router.post("/security/hosts-access", wrap((req) => whm.saveHostAccessControl(req.body || {})));
router.post("/security/modsecurity", wrap((req) => whm.updateModSecurity((req.body || {}).enabled)));
router.get("/ssl/hosts", wrap(() => whm.listSslHosts()));
router.get("/firewall", wrap(() => root.getUfwStatus()));
router.post("/firewall/rules", wrap((req) => root.addUfwRule(req.body || {}, who(req)), 201));
router.delete("/firewall/rules/:number", wrap((req) => root.deleteUfwRule(req.params.number, who(req))));

// -------------------------------------------------------------
// WHM PROGRAMMATIC API v1 (for WHMCS, CLI, and External Automation)
// -------------------------------------------------------------
router.post("/api/v1/createacct", wrap(async (req) => {
  const result = await accounts.createAccount({ ...(req.body || {}), user: who(req) });
  return { status: 1, statusmsg: "Account created successfully", data: result };
}, 201));

router.post("/api/v1/suspendacct", wrap(async (req) => {
  const username = req.body?.username || req.body?.user;
  const reason = req.body?.reason || "";
  const result = await accounts.setSuspended({ username, suspended: true, reason, user: who(req) });
  return { status: 1, statusmsg: `Account ${username} suspended`, data: result };
}));

router.post("/api/v1/unsuspendacct", wrap(async (req) => {
  const username = req.body?.username || req.body?.user;
  const result = await accounts.setSuspended({ username, suspended: false, user: who(req) });
  return { status: 1, statusmsg: `Account ${username} unsuspended`, data: result };
}));

router.post("/api/v1/terminateacct", wrap(async (req) => {
  const username = req.body?.username || req.body?.user;
  const result = await accounts.deleteAccount({ username, user: who(req) });
  return { status: 1, statusmsg: `Account ${username} terminated`, data: result };
}));

router.post("/api/v1/passwd", wrap(async (req) => {
  const username = req.body?.username || req.body?.user;
  const password = req.body?.password;
  const result = await accounts.changePassword({ username, password, user: who(req) });
  return { status: 1, statusmsg: `Password changed for ${username}`, data: result };
}));

router.post("/api/v1/changepackage", wrap(async (req) => {
  const username = req.body?.username || req.body?.user;
  const pkg = req.body?.package || req.body?.pkg;
  const result = await accounts.upgradeAccount({ username, package: pkg, user: who(req) });
  return { status: 1, statusmsg: `Account ${username} package updated to ${result.package}`, data: result };
}));

router.get("/api/v1/listaccts", wrap(async (req) => {
  const caller = who(req);
  let accts = await accounts.listAccounts();
  if (caller && caller.role === "reseller") {
    accts = accts.filter((a) => a.owner === caller.username);
  }
  return { status: 1, acct: accts };
}));

router.get("/api/v1/myprivs", wrap((req) => {
  const caller = who(req);
  return {
    status: 1,
    user: caller?.username,
    role: caller?.role || "admin",
    isApiToken: !!caller?.isApiToken,
    permissions: caller?.permissions || ["*"],
  };
}));

module.exports = router;

