const express = require("express");
const auth = require("../middleware/auth");
const svc = require("../services/cron.service");
const { wrap, who } = require("../lib/http");

const router = express.Router();

router.get("/", auth, wrap(async (req) => ({ crons: await svc.listCrons(req.user) })));
router.post("/", auth, wrap(async (req) => ({ cron: await svc.addCron({ ...(req.body || {}), user: who(req), currentUser: req.user }) }), 201));
router.delete("/:id", auth, wrap((req) => svc.deleteCron({ id: req.params.id, user: who(req) })));
router.post("/:id/toggle", auth, wrap(async (req) => ({ cron: await svc.toggleCron({ id: req.params.id, user: who(req) }) })));

module.exports = router;
