const express = require("express");
const { rateLimit } = require("express-rate-limit");
const auth = require("../middleware/auth");
const svc = require("../services/auth.service");
const { wrap } = require("../lib/http");

const router = express.Router();

// 10 failed attempts per 15 minutes per IP.
const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 10,
  skipSuccessfulRequests: true,
  standardHeaders: "draft-7",
  legacyHeaders: false,
  message: { success: false, message: "Too many login attempts. Try again in 15 minutes." },
});

router.post("/login", loginLimiter, wrap(async (req) => {
  const { username, password } = req.body || {};
  if (!username || !password) throw Object.assign(new Error("Username and password required."), { status: 400 });
  return svc.login(username, password);
}));

router.get("/me", auth, (req, res) => res.json({ success: true, user: req.user }));
router.post("/logout", auth, (req, res) => res.json({ success: true, message: "Logged out." }));
router.post("/password", auth, wrap((req) => svc.changePassword(req.body || {})));
router.get("/settings", auth, wrap(() => ({ settings: svc.getSettings() })));
router.put("/settings", auth, wrap((req) => ({ settings: svc.saveSettings(req.body || {}) })));

module.exports = router;
