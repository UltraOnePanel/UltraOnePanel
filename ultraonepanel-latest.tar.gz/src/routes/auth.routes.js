const express = require("express");
const { rateLimit } = require("express-rate-limit");
const auth = require("../middleware/auth");
const svc = require("../services/auth.service");
const { wrap } = require("../lib/http");

const router = express.Router();

// 10 failed attempts per 15 minutes per IP.
const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 10,
  skipSuccessfulRequests: true,
  standardHeaders: "draft-7",
  legacyHeaders: false,
  message: { success: false, message: "Too many login attempts. Try again in 15 minutes." },
});

router.post("/login", loginLimiter, wrap(async (req) => {
  const { username, password } = req.body || {};
  if (!username || !password) throw Object.assign(new Error("Username and password required."), { status: 400 });
  return svc.login(username, password);
}));

router.get("/me", auth, (req, res) => res.json({ success: true, user: req.user }));
router.post("/logout", auth, (req, res) => res.json({ success: true, message: "Logged out." }));
router.post("/password", auth, wrap((req) => svc.changePassword({ ...(req.body || {}), user: req.user })));
router.get("/settings", auth, wrap(() => ({ settings: svc.getSettings() })));
router.put("/settings", auth, wrap((req) => ({ settings: svc.saveSettings(req.body || {}) })));
router.get("/profile", auth, wrap((req) => ({ profile: svc.getProfile(req.user) })));
router.put("/profile", auth, wrap((req) => ({ profile: svc.saveProfile(req.user, req.body || {}) })));
router.get("/users", auth, wrap((req) => ({ users: svc.listManagedUsers(req.user) })));
router.post("/users", auth, wrap(async (req) => ({
  user: await svc.createManagedUser(req.user, req.body || {}),
}), 201));
router.patch("/users/:username", auth, wrap(async (req) => ({
  user: await svc.updateManagedUser(req.user, req.params.username, req.body || {}),
})));
router.delete("/users/:username", auth, wrap((req) => svc.deleteManagedUser(req.user, req.params.username)));

module.exports = router;
