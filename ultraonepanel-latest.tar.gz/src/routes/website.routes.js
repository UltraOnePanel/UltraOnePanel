const express = require("express");
const auth = require("../middleware/auth");
const svc = require("../services/website.service");
const platform = require("../lib/platform");
const { wrap, who } = require("../lib/http");

const router = express.Router();

router.get("/", auth, wrap(async (req) => ({ websites: await svc.listWebsites(req.user) })));
router.get("/php-versions", auth, wrap(() => ({ versions: platform.phpVersions(), profile: platform.PROFILE })));
router.post("/", auth, wrap(async (req) => {
  const { domain, php, phpVersion, type } = req.body || {};
  return { website: await svc.createWebsite({ domain, php: php || phpVersion, type, user: who(req), currentUser: req.user }) };
}, 201));
router.delete("/:domain", auth, wrap((req) => svc.deleteWebsite({
  domain: req.params.domain,
  removeFiles: req.query.removeFiles === undefined ? undefined : req.query.removeFiles === "true",
  user: who(req),
  currentUser: req.user,
})));
router.post("/:domain/suspend", auth, wrap((req) => svc.suspendWebsite({ domain: req.params.domain, user: who(req), currentUser: req.user })));
router.post("/:domain/unsuspend", auth, wrap((req) => svc.unsuspendWebsite({ domain: req.params.domain, user: who(req), currentUser: req.user })));
router.put("/:domain/php", auth, wrap((req) => svc.changePhp({ domain: req.params.domain, php: (req.body || {}).php, user: who(req), currentUser: req.user })));

module.exports = router;
