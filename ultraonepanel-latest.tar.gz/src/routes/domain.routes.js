const express = require("express");
const auth = require("../middleware/auth");
const svc = require("../services/domain.service");
const { wrap, who } = require("../lib/http");

const router = express.Router();

router.get("/", auth, wrap(async (req) => ({ domains: await svc.listDomains(req.user) })));
router.post("/", auth, wrap(async (req) => ({ domain: await svc.addDomain({ ...(req.body || {}), user: who(req), currentUser: req.user }) }), 201));
router.delete("/:domain", auth, wrap((req) => svc.deleteDomain({ domain: req.params.domain, user: who(req), currentUser: req.user })));

module.exports = router;
