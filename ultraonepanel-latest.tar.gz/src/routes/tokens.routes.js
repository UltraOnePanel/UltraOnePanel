const express = require("express");
const auth = require("../middleware/auth");
const tokensService = require("../services/tokens.service");
const { wrap, who } = require("../lib/http");

const router = express.Router();
router.use(auth);

// List all active API tokens for user/admin
router.get("/", wrap((req) => {
  const user = who(req);
  return {
    tokens: tokensService.listTokens({ owner: user?.username, role: user?.role }),
    availablePermissions: tokensService.PERMISSIONS,
  };
}));

// Create a new API token
router.post("/", wrap((req) => {
  const user = who(req);
  const { name, permissions, expiresInDays } = req.body || {};
  const created = tokensService.createToken({
    name,
    owner: user?.username || "root",
    role: user?.role || "admin",
    permissions,
    expiresInDays,
  });
  return {
    token: created.token,
    item: created,
  };
}, 201));

// Revoke an API token
router.delete("/:id", wrap((req) => {
  const user = who(req);
  return tokensService.revokeToken(req.params.id, { owner: user?.username, role: user?.role });
}));

module.exports = router;
