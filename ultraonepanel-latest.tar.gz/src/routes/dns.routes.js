const express = require("express");
const auth = require("../middleware/auth");
const svc = require("../services/dns.service");
const { wrap, who } = require("../lib/http");

const router = express.Router();

router.get("/zones", auth, wrap(async (req) => ({ zones: await svc.listZones(req.user) })));
router.post("/zones", auth, wrap((req) => svc.createZone({ domain: (req.body || {}).domain, user: who(req), currentUser: req.user }), 201));
router.delete("/zones/:domain", auth, wrap((req) => svc.deleteZone({ domain: req.params.domain, user: who(req), currentUser: req.user })));

router.get("/", auth, wrap(async (req) => {
  let domain = req.query.domain;
  if (!domain && req.user && req.user.role !== "admin" && req.user.username !== "root") {
    domain = req.user.domain;
  }
  const records = await svc.listRecords(domain, req.user);
  const zones = await svc.listZones(req.user);
  const zoneExists = zones.some((z) => z.domain === domain) || (records && records.length > 0);
  return { records, zoneExists, zones };
}));
router.post("/", auth, wrap(async (req) => ({ record: await svc.addRecord({ ...(req.body || {}), user: who(req), currentUser: req.user }) }), 201));
router.put("/:id", auth, wrap(async (req) => ({ record: await svc.updateRecord({ ...(req.body || {}), id: req.params.id, user: who(req), currentUser: req.user }) })));
router.delete("/:id", auth, wrap((req) => svc.deleteRecord({ id: req.params.id, domain: req.query.domain, user: who(req), currentUser: req.user })));

module.exports = router;
