const express = require("express");
const auth = require("../middleware/auth");
const svc = require("../services/stats.service");
const { wrap, who } = require("../lib/http");

const router = express.Router();

router.get("/", auth, wrap(() => svc.getStats()));
router.get("/history", auth, wrap(() => ({ history: svc.getHistory() })));
router.get("/processes", auth, wrap(async (req) => ({ processes: await svc.getProcesses(Math.min(100, Number(req.query.limit) || 20), req.user) })));
router.get("/services", auth, wrap(async () => ({ services: await svc.getServices() })));
router.post("/services/:name/:action", auth, wrap((req) => svc.controlService({ name: req.params.name, action: req.params.action, user: who(req) })));
router.get("/mail-queue", auth, wrap(() => svc.mailQueue()));

module.exports = router;
