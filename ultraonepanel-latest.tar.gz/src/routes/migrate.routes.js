const express = require("express");
const auth = require("../middleware/auth");
const { wrap, who } = require("../lib/http");
const svc = require("../services/migrate.service");

const router = express.Router();

// 1. Test Connection & Auto-Discovery
router.post(
  "/test-connection",
  auth,
  wrap(async (req) => {
    return await svc.testConnection(req.body || {});
  })
);

// 2. Start Background Migration Job
router.post(
  "/start",
  auth,
  wrap(async (req) => {
    const payload = req.body || {};
    return await svc.startMigration({
      ...payload,
      destUser: payload.destUser || who(req),
    });
  })
);

// 3. Status Polling
router.get(
  "/status/:jobId",
  auth,
  wrap((req) => {
    return svc.getJobStatus(req.params.jobId);
  })
);

// 4. Retry an individual domain or database
router.post(
  "/retry/:jobId",
  auth,
  wrap((req) => {
    const { itemType, itemName } = req.body || {};
    return svc.retryItem(req.params.jobId, itemType, itemName);
  })
);

module.exports = router;
