const express = require("express");
const auth = require("../middleware/auth");
const svc = require("../services/ssl.service");
const { wrap, who } = require("../lib/http");

const router = express.Router();

router.get("/", auth, wrap(async (req) => ({ certs: await svc.listCerts(req.user) })));
router.post("/issue", auth, wrap((req) => svc.issueCert({ domain: (req.body || {}).domain, email: (req.body || {}).email, user: who(req) })));
router.post("/renew", auth, wrap((req) => svc.renewAll({ user: who(req) })));
router.delete("/:domain", auth, wrap((req) => svc.revokeCert({ domain: req.params.domain, user: who(req) })));

module.exports = router;
